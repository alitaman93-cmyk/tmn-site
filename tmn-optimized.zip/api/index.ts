import { getApiApp } from '../server.ts';

export const config = {
  maxDuration: 60,
};

const app = getApiApp();

export default app;
