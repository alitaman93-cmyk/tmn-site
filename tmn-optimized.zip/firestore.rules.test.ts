/**
 * Phase 0 Security Test Specification for TMN Firestore Rules.
 * Verifies all "Dirty Dozen" adversarial payloads are rejected (PERMISSION_DENIED)
 * and legitimate owner operations are permitted.
 *
 * Run against Firebase Emulator Suite when available, or validate rule structure statically.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

export interface AttackScenario {
  id: number;
  name: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  path: string;
  auth: { uid: string; email?: string; email_verified?: boolean } | null;
  payload?: Record<string, unknown>;
  expected: 'PERMISSION_DENIED';
}

export const DIRTY_DOZEN_SCENARIOS: AttackScenario[] = [
  {
    id: 1,
    name: 'Unauthenticated Profile Read',
    operation: 'get',
    path: '/users/userA',
    auth: null,
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: 'Cross-User PII Leak',
    operation: 'get',
    path: '/users/userA',
    auth: { uid: 'userB', email: 'b@example.com', email_verified: true },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'User Directory Scraping',
    operation: 'list',
    path: '/users',
    auth: { uid: 'userA', email: 'a@example.com', email_verified: true },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'Unverified Email Write',
    operation: 'create',
    path: '/users/userA',
    auth: { uid: 'userA', email: 'a@example.com', email_verified: false },
    payload: { uid: 'userA', email: 'a@example.com' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'Identity Spoofing on Create',
    operation: 'create',
    path: '/users/userA',
    auth: { uid: 'userB', email: 'b@example.com', email_verified: true },
    payload: { uid: 'userA', email: 'a@example.com' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Privilege Escalation Shadow Field',
    operation: 'create',
    path: '/users/userA',
    auth: { uid: 'userA', email: 'a@example.com', email_verified: true },
    payload: { uid: 'userA', isAdmin: true, role: 'admin' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'Timestamp Forgery',
    operation: 'create',
    path: '/users/userA',
    auth: { uid: 'userA', email: 'a@example.com', email_verified: true },
    payload: { uid: 'userA', createdAt: '2020-01-01T00:00:00Z' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Immutable Field Tampering',
    operation: 'update',
    path: '/users/userA',
    auth: { uid: 'userA', email: 'a@example.com', email_verified: true },
    payload: { email: 'attacker@example.com' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: 'Value Poisoning Type Mismatch',
    operation: 'update',
    path: '/users/userA',
    auth: { uid: 'userA', email: 'a@example.com', email_verified: true },
    payload: { xp: '999999', theme: 'hacked' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'Array Exhaustion Denial of Wallet',
    operation: 'update',
    path: '/users/userA',
    auth: { uid: 'userA', email: 'a@example.com', email_verified: true },
    payload: { mistakes: Array.from({ length: 501 }, (_, i) => i) },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'Orphaned or Cross-User SRS Card',
    operation: 'create',
    path: '/users/userA/srsCards/word_1',
    auth: { uid: 'userA', email: 'a@example.com', email_verified: true },
    payload: { userId: 'userB', wordId: 1, easeFactor: 2.5 },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'Site Tampering Unauthorized Collection Write',
    operation: 'create',
    path: '/siteConfig/branding',
    auth: { uid: 'userA', email: 'a@example.com', email_verified: true },
    payload: { siteName: 'Hacked' },
    expected: 'PERMISSION_DENIED',
  },
];

test('firestore.rules enforces all Eight Pillars and Dirty Dozen defenses', () => {
  const rulesPath = path.resolve(process.cwd(), 'firestore.rules');
  assert.ok(fs.existsSync(rulesPath), 'firestore.rules must exist');
  const rules = fs.readFileSync(rulesPath, 'utf-8');

  assert.equal(DIRTY_DOZEN_SCENARIOS.length, 12);
  assert.match(rules, /rules_version\s*=\s*'2';/);
  assert.match(rules, /match \/\{document=\*\*\}\s*\{\s*allow read, write: if false;\s*\}/);
  assert.match(rules, /request\.auth\.token\.email_verified == true/);
  assert.match(rules, /function isValidId\(/);
  assert.match(rules, /function isValidUserProfile\(/);
  assert.match(rules, /function isValidSrsCard\(/);
  assert.match(rules, /affectedKeys\(\)\.hasOnly\(/);
  assert.match(rules, /allow list: if false;/);
  assert.match(rules, /resource\.data\.userId == request\.auth\.uid/);
  assert.match(rules, /request\.time/);
});
