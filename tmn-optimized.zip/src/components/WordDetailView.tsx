import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Bookmark,
  BookOpen,
  Check,
  Flame,
  GitCompare,
  History,
  Image as ImageIcon,
  Layers,
  Lightbulb,
  MessageSquareQuote,
  Mic,
  Play,
  RefreshCw,
  Repeat,
  Sparkles,
  Square,
  Star,
  Trash2,
  Video,
  Volume2,
} from 'lucide-react';
import { BAND_META } from '../data/constants';
import type {
  PersistedSettings,
  SavedWordNote,
  SpeechEvalResult,
  VocabEntry,
  VocabStore,
  WordHubData,
  WordHubTabId,
  WordMasteryRecord,
  WordPhotoData,
} from '../types';
import { blobToBase64, evaluateSpeechWithAi } from '../utils/aiApi';
import { playAccentAudio, type SfxType } from '../utils/audio';
import { fetchWordPhoto, getHotWordPhoto } from '../utils/mediaApi';
import { evaluateSpokenMatch } from '../utils/sentenceLogic';
import { fetchWordHub, getHotWordHub } from '../utils/wordHubApi';
import { computeWordMastery, normalizeWordKey } from '../utils/wordHubLogic';
import {
  buildOfflineWordRelationships,
  enrichWordHubWithOfflineRelationships,
} from '../utils/wordRelationshipsOffline';
import { buildOfflineWordUsage, enrichWordHubWithOfflineUsage } from '../utils/wordUsageOffline';
import { WordHubCollapsibleCard } from './WordHubCollapsibleCard';
import { WordHubRelationshipsTab } from './WordHubRelationshipsTab';
import { WordHubUsageTab } from './WordHubUsageTab';
import { WordSentenceBuilderCard } from './WordSentenceBuilderCard';
import { WordVideoReelsPlayer } from './WordVideoReelsPlayer';

interface WordDetailViewProps {
  word: VocabEntry;
  store: VocabStore;
  settings: PersistedSettings;
  isFavorite: boolean;
  isMastered: boolean;
  isMistake: boolean;
  isAdHoc?: boolean;
  historyCount?: number;
  onSpeak: (text: string) => void;
  onSfx: (type: SfxType) => void;
  onEarnXp: (xpDelta: number) => void;
  onToggleFavorite: (id: number) => void;
  onToggleMastered: (id: number) => void;
  onToggleMistake: (id: number) => void;
  onToggleSaveWordNote: (note: Omit<SavedWordNote, 'savedAt'>) => void;
  onUpdateWordMastery: (
    wordEn: string,
    wordId: number,
    updater: (prev: WordMasteryRecord) => WordMasteryRecord,
    markMistakeOnWrong?: boolean
  ) => void;
  onExploreWord: (targetWord: string, glossAr?: string) => void;
  onStartWordSrs: (wordId: number) => void;
  onGoSettings: () => void;
  onToast: (msg: string) => void;
}

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}
interface SpeechRecognitionResultLike {
  isFinal: boolean;
  length: number;
  [index: number]: SpeechRecognitionAlternativeLike;
}
interface SpeechRecognitionEventLike {
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}
interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives?: number;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}
type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

function getSpeechRecognitionCtor(): SpeechRecognitionCtor | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

const NOTE_KIND_LABELS: Record<SavedWordNote['kind'], string> = {
  synonym: 'مرادف',
  antonym: 'ضد',
  derivative: 'مشتق',
  related: 'كلمة مرتبطة',
  collocation: 'تلازم لفظي',
  example: 'مثال',
  idiom: 'تعبير اصطلاحي',
  phrasal_verb: 'فعل مركب',
};

export function WordDetailView({
  word,
  store,
  settings,
  isFavorite,
  isMastered,
  isMistake,
  isAdHoc = false,
  onSpeak,
  onSfx,
  onEarnXp,
  onToggleFavorite,
  onToggleMastered,
  onToggleMistake,
  onToggleSaveWordNote,
  onUpdateWordMastery,
  onExploreWord,
  onStartWordSrs,
  onToast,
}: WordDetailViewProps) {
  const [activeTab, setActiveTab] = useState<WordHubTabId>('overview');

  // Word Hub rich lexicographical state (0ms synchronous hydration from hot cache when available)
  const [hubState, setHubState] = useState<{
    status: 'loading' | 'ready' | 'error';
    data: WordHubData | null;
    offline: boolean;
  }>(() => {
    const hot = getHotWordHub(word.en, settings.uiLang || 'ar');
    return hot
      ? { status: 'ready', data: hot, offline: false }
      : { status: 'loading', data: null, offline: false };
  });

  // Real Photo state (0ms synchronous hydration from hot cache when available)
  const [photoState, setPhotoState] = useState<{
    status: 'loading' | 'ready' | 'empty' | 'nokey' | 'error';
    data: WordPhotoData | null;
    page: number;
    imgLoaded: boolean;
  }>(() => {
    const hotPhoto = getHotWordPhoto(word.en, 1);
    return hotPhoto
      ? { status: 'ready', data: hotPhoto, page: 1, imgLoaded: false }
      : { status: 'loading', data: null, page: 1, imgLoaded: false };
  });

  // Voice Pronunciation Practice state
  const [isRecording, setIsRecording] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [evaluatingAi, setEvaluatingAi] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioMime, setAudioMime] = useState('audio/webm');
  const [evalResult, setEvalResult] = useState<SpeechEvalResult | null>(null);
  const [speechError, setSpeechError] = useState('');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const speechRecRef = useRef<SpeechRecognitionLike | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const transcriptRef = useRef('');
  const audioUrlRef = useRef<string | null>(null);

  const wordKey = useMemo(() => normalizeWordKey(word.en), [word.en]);

  const masteryRecord = useMemo(
    () => (settings.wordMastery || {})[wordKey],
    [settings.wordMastery, wordKey]
  );

  const masteryInfo = useMemo(
    () => computeWordMastery(masteryRecord),
    [masteryRecord]
  );

  const savedNotesForWord = useMemo(() => {
    const list = settings.savedWordNotes || [];
    return list.filter((n) => n.parentWord.toLowerCase() === word.en.toLowerCase());
  }, [settings.savedWordNotes, word.en]);

  const savedNoteIds = useMemo(
    () => new Set((settings.savedWordNotes || []).map((n) => n.id)),
    [settings.savedWordNotes]
  );

  const cleanupRecording = useCallback(() => {
    try {
      speechRecRef.current?.stop();
    } catch {
      // Ignore
    }
    speechRecRef.current = null;
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // Ignore
      }
    }
    mediaRecorderRef.current = null;
    mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
    mediaStreamRef.current = null;
  }, []);

  useEffect(() => {
    return () => {
      cleanupRecording();
      if (audioUrlRef.current) URL.revokeObjectURL(audioUrlRef.current);
    };
  }, [cleanupRecording]);

  const loadHub = useCallback(
    async (force = false) => {
      const hot = !force ? getHotWordHub(word.en, settings.uiLang || 'ar') : null;
      if (hot) {
        setHubState({ status: 'ready', data: hot, offline: false });
      } else {
        setHubState({ status: 'loading', data: null, offline: false });
      }
      try {
        const res = await fetchWordHub({
          word: word.en,
          ar: word.ar,
          band: word.band,
          uiLang: settings.uiLang,
          backendUrl: settings.backendUrl,
          force,
        });
        setHubState({ status: 'ready', data: res.data, offline: res.offline });
      } catch {
        if (!hot) {
          setHubState({ status: 'error', data: null, offline: true });
        }
      }
    },
    [word.en, word.ar, word.band, settings.uiLang, settings.backendUrl]
  );

  const loadPhoto = useCallback(
    async (page = 1, force = false) => {
      const hotPhoto = !force ? getHotWordPhoto(word.en, page) : null;
      if (hotPhoto) {
        setPhotoState({ status: 'ready', data: hotPhoto, page, imgLoaded: false });
      } else {
        setPhotoState((prev) => ({ ...prev, status: 'loading', page, imgLoaded: false }));
      }
      const res = await fetchWordPhoto(
        word.en,
        page,
        {
          backendUrl: settings.backendUrl,
          pixabayKey: settings.pixabayKey,
          unsplashKey: settings.unsplashKey,
        },
        force,
        { ar: word.ar, band: word.band }
      );
      setPhotoState({
        status: res.status,
        data: res.data,
        page,
        imgLoaded: false,
      });
    },
    [word.en, word.ar, word.band, settings.backendUrl, settings.pixabayKey, settings.unsplashKey]
  );

  useEffect(() => {
    cleanupRecording();
    setActiveTab('overview');
    setIsRecording(false);
    setLiveTranscript('');
    setEvaluatingAi(false);
    setEvalResult(null);
    setSpeechError('');
    setAudioBlob(null);
    if (audioUrlRef.current) {
      URL.revokeObjectURL(audioUrlRef.current);
      audioUrlRef.current = null;
    }
    setAudioUrl(null);
    void loadHub(false);
    void loadPhoto(1, false);
  }, [word.id, word.en, cleanupRecording, loadHub, loadPhoto]);

  const creditPronunciationPassed = useCallback(() => {
    onUpdateWordMastery(word.en, word.id, (prev) => ({
      ...prev,
      pronunciationPassed: true,
      correctAnswers: prev.correctAnswers + 1,
      updatedAt: Date.now(),
    }));
  }, [word.en, word.id, onUpdateWordMastery]);

  const creditSentencePassed = useCallback(() => {
    onUpdateWordMastery(word.en, word.id, (prev) => ({
      ...prev,
      sentencePassed: true,
      correctAnswers: prev.correctAnswers + 1,
      updatedAt: Date.now(),
    }));
    onEarnXp(10);
  }, [word.en, word.id, onUpdateWordMastery, onEarnXp]);

  const evaluateWordWithAi = useCallback(
    async (blob: Blob | null, mime: string, spokenText?: string) => {
      setEvaluatingAi(true);
      setSpeechError('');
      try {
        const audioBase64 = blob ? await blobToBase64(blob) : undefined;
        const result = await evaluateSpeechWithAi({
          targetSentence: word.en,
          spokenText: spokenText || undefined,
          audioBase64,
          audioMimeType: mime || blob?.type || 'audio/webm',
        });
        setEvalResult(result);
        if (result.isMatch || result.score >= 80) {
          creditPronunciationPassed();
        }
      } catch (err) {
        setSpeechError(err instanceof Error ? err.message : 'تعذر تقييم النطق حالياً.');
      } finally {
        setEvaluatingAi(false);
      }
    },
    [word.en, creditPronunciationPassed]
  );

  const finalizeWordRecording = useCallback(
    (blob: Blob | null, mime: string, capturedText: string, candidates: string[] = []) => {
      if (audioUrlRef.current) {
        URL.revokeObjectURL(audioUrlRef.current);
        audioUrlRef.current = null;
      }
      if (blob && blob.size > 0) {
        const url = URL.createObjectURL(blob);
        audioUrlRef.current = url;
        setAudioUrl(url);
        setAudioBlob(blob);
        setAudioMime(mime);
      }

      const allSpoken = Array.from(
        new Set([capturedText.trim(), ...candidates.map((c) => c.trim())].filter(Boolean))
      );

      if (allSpoken.length > 0) {
        let bestEval = evaluateSpokenMatch(word.en, allSpoken[0]);
        for (let i = 1; i < allSpoken.length; i++) {
          const candidateEval = evaluateSpokenMatch(word.en, allSpoken[i]);
          if (candidateEval.score > bestEval.score) {
            bestEval = candidateEval;
          }
        }
        setEvalResult(bestEval);
        if (bestEval.isMatch || bestEval.score >= 80) {
          creditPronunciationPassed();
        }
      } else if (blob && blob.size > 400) {
        void evaluateWordWithAi(blob, mime);
      } else {
        setSpeechError('لم يتم التقاط صوت واضح. اضغط على زر التسجيل وانطق الكلمة بوضوح.');
      }
    },
    [word.en, evaluateWordWithAi, creditPronunciationPassed]
  );

  const startMediaRecorderFallback = useCallback(async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setIsRecording(false);
      setSpeechError('الميكروفون غير مدعوم في هذا المتصفح.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      const preferredMime =
        typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
          ? 'audio/webm;codecs=opus'
          : typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported('audio/webm')
            ? 'audio/webm'
            : typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported('audio/mp4')
              ? 'audio/mp4'
              : '';

      const recorder = preferredMime
        ? new MediaRecorder(stream, { mimeType: preferredMime })
        : new MediaRecorder(stream);

      const actualMime = (recorder.mimeType || preferredMime || 'audio/webm').split(';')[0];

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) chunksRef.current.push(ev.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: actualMime });
        chunksRef.current = [];
        mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
        mediaStreamRef.current = null;
        mediaRecorderRef.current = null;
        setIsRecording(false);
        finalizeWordRecording(blob, actualMime, transcriptRef.current);
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
    } catch {
      setIsRecording(false);
      setSpeechError('يرجى السماح بصلاحية الميكروفون من المتصفح لاختبار نطقك.');
    }
  }, [finalizeWordRecording]);

  const stopPronunciationRecording = useCallback(() => {
    const sr = speechRecRef.current;
    speechRecRef.current = null;
    const rec = mediaRecorderRef.current;

    if (rec && rec.state !== 'inactive') {
      try {
        sr?.stop();
      } catch {
        // Ignore
      }
      rec.stop();
      return;
    }

    if (sr) {
      try {
        sr.stop();
      } catch {
        setIsRecording(false);
        finalizeWordRecording(null, 'audio/webm', transcriptRef.current);
      }
      return;
    }

    mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
    mediaStreamRef.current = null;
    setIsRecording(false);
    finalizeWordRecording(null, 'audio/webm', transcriptRef.current);
  }, [finalizeWordRecording]);

  const startPronunciationRecording = useCallback(async () => {
    if (isRecording) {
      stopPronunciationRecording();
      return;
    }

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    transcriptRef.current = '';
    chunksRef.current = [];
    setLiveTranscript('');
    setEvalResult(null);
    setSpeechError('');
    setIsRecording(true);

    const SR = getSpeechRecognitionCtor();
    if (SR) {
      // Use Web Speech API exclusively without simultaneously locking the microphone via getUserMedia
      // (concurrent getUserMedia + SpeechRecognition breaks audio capture on HTTPS / Vercel / Mobile browsers).
      try {
        const rec = new SR();
        rec.lang = 'en-US';
        rec.continuous = false;
        rec.interimResults = true;
        rec.maxAlternatives = 5;

        let settled = false;
        let fallbackTriggered = false;
        let capturedAlts: string[] = [];

        rec.onresult = (event) => {
          let combined = '';
          const altPool: string[] = [];
          for (let i = 0; i < event.results.length; i++) {
            const resItem = event.results[i];
            if (resItem?.[0]?.transcript) {
              combined += resItem[0].transcript + ' ';
            }
            const altLen = Math.min(resItem?.length || 1, 5);
            for (let a = 0; a < altLen; a++) {
              const t = resItem?.[a]?.transcript?.trim();
              if (t) altPool.push(t);
            }
          }
          const clean = combined.trim();
          transcriptRef.current = clean;
          capturedAlts = altPool;
          setLiveTranscript(clean);
        };

        rec.onerror = (ev) => {
          const code = ev?.error || '';
          if (code === 'not-allowed' || code === 'service-not-allowed') {
            settled = true;
            speechRecRef.current = null;
            setIsRecording(false);
            setSpeechError('يرجى السماح بصلاحية الميكروفون من إعدادات المتصفح لاختبار نطقك.');
            return;
          }
          if (code === 'network' || code === 'audio-capture' || code === 'language-not-supported') {
            fallbackTriggered = true;
            settled = true;
            speechRecRef.current = null;
            void startMediaRecorderFallback();
          }
        };

        rec.onend = () => {
          speechRecRef.current = null;
          if (settled || fallbackTriggered) return;
          settled = true;
          setIsRecording(false);
          finalizeWordRecording(null, 'audio/webm', transcriptRef.current, capturedAlts);
        };

        speechRecRef.current = rec;
        rec.start();
        return;
      } catch {
        speechRecRef.current = null;
      }
    }

    await startMediaRecorderFallback();
  }, [isRecording, stopPronunciationRecording, finalizeWordRecording, startMediaRecorderFallback]);

  const hub = useMemo<WordHubData>(() => {
    if (hubState.data) {
      const withUsage = enrichWordHubWithOfflineUsage(hubState.data, {
        word: word.en,
        ar: word.ar,
        band: word.band,
      });
      return enrichWordHubWithOfflineRelationships(withUsage, {
        word: word.en,
        ar: word.ar,
        band: word.band,
        store,
      });
    }
    const offlineUsage = buildOfflineWordUsage({
      word: word.en,
      ar: word.ar,
      band: word.band,
    });
    const offlineRel = buildOfflineWordRelationships({
      word: word.en,
      ar: word.ar,
      band: word.band,
      store,
    });
    return {
      word: word.en,
      posEn: '',
      posAr: '',
      ipaUs: '',
      ipaUk: '',
      definitionEn: '',
      definitionAr: word.ar || '',
      synonyms: offlineRel.synonyms,
      antonyms: offlineRel.antonyms,
      wordFamily: offlineRel.wordFamily,
      relatedWords: offlineRel.relatedWords,
      collocations: offlineUsage.collocations,
      examples: offlineUsage.examples,
      commonMistakes: offlineUsage.commonMistakes,
      usageNotes: offlineUsage.usageNotes,
      formalVsInformal: offlineUsage.formalVsInformal,
      idioms: offlineUsage.idioms,
      phrasalVerbs: offlineUsage.phrasalVerbs,
      wordOrigin: '',
      memoryTip: '',
      source: 'offline',
    };
  }, [hubState.data, word.en, word.ar, word.band, store]);

  const displayAr = word.ar || hub.definitionAr || '';
  const relCount =
    hub.synonyms.length +
    hub.antonyms.length +
    hub.wordFamily.length +
    hub.relatedWords.length;
  const usageCount =
    hub.collocations.length +
    hub.examples.length +
    hub.idioms.length +
    hub.phrasalVerbs.length;

  const tabs: Array<{
    id: WordHubTabId;
    label: string;
    icon: typeof BookOpen;
    count?: number;
  }> = [
    { id: 'overview', label: 'نظرة عامة', icon: BookOpen },
    { id: 'relationships', label: 'العلاقات', icon: GitCompare, count: relCount > 0 ? relCount : undefined },
    { id: 'usage', label: 'الاستخدام', icon: Layers, count: usageCount > 0 ? usageCount : undefined },
    { id: 'videos', label: 'الفيديوهات', icon: Video },
  ];

  return (
    <div className="space-y-6">
      {/* Persistent Word Learning Hub Identity Header */}
      <section className="tmn-card rounded-3xl p-6 sm:p-7">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0 flex-1">
            {/* Clean Unboxed Metadata Line */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
              <span
                className={`inline-flex h-6 items-center justify-center rounded-md px-2 font-en text-xs font-extrabold text-white ${BAND_META[word.band].bgClass}`}
              >
                {word.band}
              </span>
              <span>{BAND_META[word.band].ar}</span>
              {hub?.posEn && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>
                    {hub.posEn}
                    {hub.posAr ? ` (${hub.posAr})` : ''}
                  </span>
                </>
              )}
              {hub?.formalVsInformal && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{hub.formalVsInformal.registerLabelAr}</span>
                </>
              )}
            </div>

            {/* Word Headline */}
            <h1
              className="mt-3 w-fit font-en text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100 sm:text-4xl"
              dir="ltr"
            >
              {word.en}
            </h1>

            {/* Translation */}
            <div className="mt-2">
              <p className="text-xl font-bold text-indigo-600 dark:text-indigo-400">
                {displayAr || (hubState.status === 'loading' ? '...' : '—')}
              </p>
            </div>

            {/* Dual US & UK Accent Pronunciation + IPA */}
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  playAccentAudio(word.en, 'us', hub?.audioUs, settings.ttsRate, onToast)
                }
                aria-label={`نطق أمريكي لكلمة ${word.en}`}
                className="inline-flex h-10 shrink-0 items-center gap-2 rounded-xl bg-indigo-600 px-3.5 text-xs font-bold whitespace-nowrap text-white transition-colors hover:bg-indigo-700"
              >
                <Volume2 className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span className="font-en">US</span>
                {hub?.ipaUs && (
                  <span dir="ltr" className="font-code text-[11px] font-medium whitespace-nowrap opacity-90">
                    /{hub.ipaUs}/
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() =>
                  playAccentAudio(word.en, 'uk', hub?.audioUk, settings.ttsRate, onToast)
                }
                aria-label={`نطق بريطاني لكلمة ${word.en}`}
                className="inline-flex h-10 shrink-0 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-xs font-bold whitespace-nowrap text-slate-800 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
              >
                <Volume2 className="h-4 w-4 shrink-0 text-indigo-600 dark:text-indigo-400" aria-hidden="true" />
                <span className="font-en">UK</span>
                {(hub?.ipaUk || hub?.ipaUs) && (
                  <span dir="ltr" className="font-code text-[11px] font-medium whitespace-nowrap text-slate-500 dark:text-slate-400">
                    /{hub?.ipaUk || hub?.ipaUs}/
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Quick Learning Actions */}
          {!isAdHoc && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onToggleFavorite(word.id)}
                aria-label={isFavorite ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
                className={`flex h-10 w-10 items-center justify-center rounded-xl border transition-colors ${
                  isFavorite
                    ? 'border-amber-300 bg-amber-50 text-amber-600 dark:border-amber-500/40 dark:bg-amber-500/15 dark:text-amber-400'
                    : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
                }`}
              >
                <Star className={`h-4 w-4 ${isFavorite ? 'fill-current' : ''}`} aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={() => onToggleMistake(word.id)}
                aria-label={isMistake ? 'إزالة من بنك الأخطاء' : 'إضافة لبنك الأخطاء'}
                className={`inline-flex h-10 items-center gap-1.5 rounded-xl border px-3 text-xs font-bold transition-colors whitespace-nowrap ${
                  isMistake
                    ? 'border-amber-500 bg-amber-500 text-slate-950'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <Flame className="h-3.5 w-3.5" aria-hidden="true" />
                <span className="hidden sm:inline">{isMistake ? 'في الأخطاء' : 'للأخطاء'}</span>
              </button>

              <button
                type="button"
                onClick={() => onStartWordSrs(word.id)}
                aria-label={`مراجعة كلمة ${word.en} في أنكي`}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 whitespace-nowrap"
              >
                <Repeat className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-400" aria-hidden="true" />
                <span>أنكي</span>
              </button>
            </div>
          )}
        </div>

        {/* Earned Mastery Progress Meter (Never mastered by mere viewing) */}
        <div className="mt-5 border-t border-slate-100 pt-4 dark:border-slate-800">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex flex-wrap items-center gap-2 font-bold text-slate-700 dark:text-slate-200">
              <span>تقدّم إتقان الكلمة:</span>
              <span className="font-code tabular-nums text-indigo-600 dark:text-indigo-400">
                {masteryInfo.scorePct}%
              </span>
              {(masteryInfo.isEarnedMastered || isMastered) && (
                <span className="inline-flex items-center gap-1 font-extrabold text-emerald-600 dark:text-emerald-400">
                  <Check className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>متقنة</span>
                </span>
              )}
            </div>

            <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
              {!masteryInfo.isEarnedMastered && (
                <span>يُكتسب الإتقان بالتدريب والألعاب والنطق وبناء الجملة</span>
              )}
              {!isAdHoc && isMastered && !masteryInfo.isEarnedMastered && (
                <button
                  type="button"
                  onClick={() => onToggleMastered(word.id)}
                  className="font-bold text-slate-500 underline hover:text-slate-700 dark:text-slate-400"
                >
                  إلغاء الإتقان اليدوي
                </button>
              )}
            </div>
          </div>

          <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                masteryInfo.isEarnedMastered || isMastered ? 'bg-emerald-500' : 'bg-indigo-600'
              }`}
              style={{
                width: `${Math.max(
                  masteryInfo.scorePct,
                  isMastered ? 100 : 0
                )}%`,
              }}
            />
          </div>
        </div>
      </section>

      {/* 5 Clean Organized Single-Line Tabs */}
      <nav
        aria-label="أقسام صفحة الكلمة"
        data-testid="word-hub-tabs"
        className="-mx-1 overflow-x-auto px-1 pb-1"
      >
        <div
          role="tablist"
          className="inline-flex min-w-full items-center gap-1.5 rounded-2xl border border-slate-200 bg-white p-1.5 dark:border-slate-800 dark:bg-[#131c2e] sm:grid sm:grid-cols-4"
        >
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => {
                  setActiveTab(tab.id);
                  onSfx('tap');
                }}
                className={`inline-flex h-10 shrink-0 items-center justify-center gap-2 rounded-xl px-3.5 text-xs font-extrabold whitespace-nowrap transition-colors sm:px-3 sm:text-sm ${
                  active
                    ? 'bg-indigo-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-slate-100'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>{tab.label}</span>
                {typeof tab.count === 'number' && (
                  <span
                    className={`font-code text-[11px] tabular-nums ${
                      active ? 'text-indigo-100' : 'text-slate-400 dark:text-slate-500'
                    }`}
                  >
                    ({tab.count})
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* TAB 1: OVERVIEW (Definition + Image + Memory Tip + Origin + Pronunciation + Sentence Builder) */}
      {activeTab === 'overview' && (
        <div className="space-y-5">
          {/* 2-Column Balanced Split: Definition & Meaning + Real Image */}
          <div className="grid grid-cols-1 items-stretch gap-5 lg:grid-cols-2">
            {/* Core Definition & Meaning Card */}
            <section className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e]">
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-sm font-extrabold text-slate-900 dark:text-slate-100">
                    <BookOpen className="h-4 w-4 text-indigo-500" aria-hidden="true" />
                    <span>التعريف والمعنى الأساسي</span>
                  </div>
                  {hubState.offline && (
                    <button
                      type="button"
                      onClick={() => void loadHub(true)}
                      className="inline-flex h-8 items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                    >
                      <RefreshCw className="h-3 w-3" aria-hidden="true" />
                      <span>تحديث</span>
                    </button>
                  )}
                </div>

                {hubState.status === 'loading' ? (
                  <div className="space-y-2.5 py-2">
                    <div className="h-4 w-5/6 animate-pulse rounded bg-slate-100 dark:bg-slate-800" />
                    <div className="h-4 w-3/4 animate-pulse rounded bg-slate-100 dark:bg-slate-800" />
                    <div className="h-4 w-2/3 animate-pulse rounded bg-slate-100 dark:bg-slate-800" />
                  </div>
                ) : (
                  <>
                    {hub?.definitionEn ? (
                      <div className="space-y-1.5">
                        <p
                          dir="ltr"
                          className="text-left font-en text-base leading-relaxed font-semibold text-slate-900 dark:text-slate-100"
                        >
                          {hub.definitionEn}
                        </p>
                        {hub.definitionAr && (
                          <p className="text-sm leading-relaxed font-medium text-slate-600 dark:text-slate-300">
                            {hub.definitionAr}
                          </p>
                        )}
                      </div>
                    ) : (
                      <p className="text-sm text-slate-600 dark:text-slate-300">
                        {displayAr}
                      </p>
                    )}

                    {/* Secondary Genuine Meanings */}
                    {hub?.secondaryMeanings && hub.secondaryMeanings.length > 0 && (
                      <div className="space-y-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                        <div className="text-xs font-bold text-slate-500 dark:text-slate-400">
                          معانٍ إضافية شائعة:
                        </div>
                        {hub.secondaryMeanings.map((sec, idx) => (
                          <div key={idx} className="text-xs leading-relaxed">
                            <span className="font-en font-bold text-slate-500 dark:text-slate-400">
                              ({sec.posEn}){' '}
                            </span>
                            <span dir="ltr" className="font-en font-medium text-slate-800 dark:text-slate-200">
                              {sec.definitionEn}
                            </span>
                            {sec.ar && (
                              <span className="text-slate-500 dark:text-slate-400"> — {sec.ar}</span>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Primary Example Preview */}
                    {hub?.examples?.[0] && (
                      <div className="rounded-xl border border-slate-200/80 bg-slate-50 p-3.5 dark:border-slate-800 dark:bg-slate-900/60">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1 space-y-1">
                            <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                              <MessageSquareQuote className="h-3.5 w-3.5 text-indigo-500" aria-hidden="true" />
                              <span>مثال سريع</span>
                            </div>
                            <p dir="ltr" className="text-left font-en text-sm font-semibold text-slate-900 dark:text-slate-100">
                              &ldquo;{hub.examples[0].en}&rdquo;
                            </p>
                            {hub.examples[0].ar && (
                              <p className="text-xs text-slate-600 dark:text-slate-400">
                                {hub.examples[0].ar}
                              </p>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => onSpeak(hub.examples[0].en)}
                            aria-label="نطق المثال السريع"
                            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                          >
                            <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>

              {hub && (hub.synonyms.length > 0 || hub.collocations.length > 0) && (
                <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-slate-100 pt-3 text-xs dark:border-slate-800">
                  {hub.synonyms.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('relationships')}
                      className="font-bold text-indigo-600 hover:underline dark:text-indigo-400"
                    >
                      استكشف {hub.synonyms.length} مرادفات وعائلة الكلمة
                    </button>
                  )}
                  {hub.collocations.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('usage')}
                      className="font-bold text-slate-600 hover:text-indigo-600 hover:underline dark:text-slate-300 dark:hover:text-indigo-400"
                    >
                      عرض {hub.collocations.length} تلازمات وأمثلة
                    </button>
                  )}
                </div>
              )}
            </section>

            {/* Real Photo Card */}
            <section className="flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#131c2e]">
              <div className="flex items-center justify-between gap-2 border-b border-slate-100 px-5 py-3.5 dark:border-slate-800">
                <div className="flex items-center gap-2 text-sm font-extrabold text-slate-900 dark:text-slate-100">
                  <ImageIcon className="h-4 w-4 text-indigo-500" aria-hidden="true" />
                  <span>صورة واقعية للكلمة</span>
                </div>

                {photoState.status === 'ready' ? (
                  <button
                    type="button"
                    onClick={() => void loadPhoto((photoState.page % 3) + 1, false)}
                    className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                  >
                    <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>صورة أخرى</span>
                  </button>
                ) : photoState.status !== 'loading' ? (
                  <button
                    type="button"
                    onClick={() => void loadPhoto(1, true)}
                    className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                  >
                    <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>إعادة</span>
                  </button>
                ) : null}
              </div>

              <div className="flex flex-1 flex-col justify-between p-4">
                {photoState.status === 'loading' ? (
                  <div className="flex h-52 w-full items-center justify-center rounded-xl bg-slate-100 text-sm text-slate-500 dark:bg-slate-800/60 dark:text-slate-400">
                    جاري البحث عن صورة...
                  </div>
                ) : photoState.status === 'ready' && photoState.data?.imageUrl ? (
                  <>
                    <div className="relative h-52 w-full overflow-hidden rounded-xl border border-slate-200 bg-slate-100 dark:border-slate-700/80 dark:bg-slate-800 sm:h-60">
                      <img
                        src={photoState.data.imageUrl}
                        alt={photoState.data.alt || word.en}
                        referrerPolicy="no-referrer"
                        onLoad={() => setPhotoState((p) => ({ ...p, imgLoaded: true }))}
                        className={`h-full w-full object-cover transition-opacity duration-300 ${
                          photoState.imgLoaded ? 'opacity-100' : 'opacity-0'
                        }`}
                      />
                    </div>
                    {!photoState.data.isFallbackCard && (
                      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <span>
                          تصوير:{' '}
                          <a
                            href={photoState.data.photographerUrl || '#'}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-semibold text-indigo-600 hover:underline dark:text-indigo-400"
                          >
                            {photoState.data.photographer || 'Contributor'}
                          </a>{' '}
                          ({photoState.data.providerLabel})
                        </span>
                        <a
                          href={photoState.data.photoPageUrl || '#'}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-semibold text-indigo-600 hover:underline dark:text-indigo-400"
                        >
                          الأصلية
                        </a>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="flex h-52 items-center justify-center rounded-xl bg-slate-50 text-center text-sm text-slate-500 dark:bg-slate-800/40 dark:text-slate-400">
                    {photoState.status === 'error'
                      ? photoState.data?.message || 'تعذر جلب الصورة.'
                      : 'لا توجد صورة واقعية مطابقة لهذه الكلمة.'}
                  </div>
                )}
              </div>
            </section>
          </div>

          {/* Memory Tip & Word Origin (Collapsible — only shown when reliable) */}
          {(hub?.memoryTip || hub?.wordOrigin) && (
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              {hub.memoryTip && (
                <WordHubCollapsibleCard
                  title="حيلة ذكية لتذكر الكلمة (Memory Tip)"
                  icon={<Lightbulb className="h-4 w-4" aria-hidden="true" />}
                  defaultOpen
                >
                  <p className="text-sm leading-relaxed text-slate-700 dark:text-slate-200">
                    {hub.memoryTip}
                  </p>
                </WordHubCollapsibleCard>
              )}

              {hub.wordOrigin && (
                <WordHubCollapsibleCard
                  title="أصل الكلمة واشتقاقها التاريخي (Word Origin)"
                  icon={<History className="h-4 w-4" aria-hidden="true" />}
                  defaultOpen={false}
                >
                  <p className="text-sm leading-relaxed text-slate-700 dark:text-slate-200">
                    {hub.wordOrigin}
                  </p>
                </WordHubCollapsibleCard>
              )}
            </div>
          )}

          {/* Voice Pronunciation Practice Card */}
          <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e]">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 text-sm font-extrabold text-slate-900 dark:text-slate-100">
                  <Mic className="h-4 w-4 text-indigo-500" aria-hidden="true" />
                  <span>اختبر نطقك للكلمة بصوتك</span>
                </div>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  سجّل صوتك وأنت تنطق{' '}
                  <span className="font-en font-bold text-slate-800 dark:text-slate-200" dir="ltr">
                    {word.en}
                  </span>{' '}
                  لتعرف فوراً مدى صحة نطقك وترفع نسبة إتقان الكلمة.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {isRecording ? (
                  <button
                    type="button"
                    onClick={stopPronunciationRecording}
                    className="inline-flex h-10 items-center gap-2 rounded-xl bg-rose-600 px-4 text-xs font-bold text-white shadow-xs transition-colors hover:bg-rose-700"
                  >
                    <Square className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                    <span>إيقاف وتقييم النطق</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => void startPronunciationRecording()}
                    className="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white transition-colors hover:bg-indigo-700"
                  >
                    <Mic className="h-4 w-4" aria-hidden="true" />
                    <span>سجّل نطقك الآن</span>
                  </button>
                )}

                {audioUrl && !isRecording && (
                  <button
                    type="button"
                    onClick={() => {
                      const audio = new Audio(audioUrl);
                      void audio.play().catch(() => {});
                    }}
                    className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3 text-xs font-bold text-emerald-700 hover:bg-emerald-100 dark:border-emerald-700/60 dark:bg-emerald-950/40 dark:text-emerald-300"
                  >
                    <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                    <span>اسمع تسجيلك</span>
                  </button>
                )}

                {audioBlob && !isRecording && !evaluatingAi && evalResult?.source !== 'ai' && (
                  <button
                    type="button"
                    onClick={() =>
                      void evaluateWordWithAi(audioBlob, audioMime, evalResult?.heardText)
                    }
                    className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-indigo-200 bg-indigo-50 px-3 text-xs font-bold text-indigo-700 hover:bg-indigo-100 dark:border-indigo-700/60 dark:bg-indigo-950/40 dark:text-indigo-300"
                  >
                    <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>تقييم دقيق بـ AI</span>
                  </button>
                )}
              </div>
            </div>

            {isRecording && (
              <div className="mt-3 rounded-xl border border-rose-200 bg-rose-50 p-3 dark:border-rose-800/60 dark:bg-rose-950/30">
                <div className="flex items-center gap-2 text-xs font-bold text-rose-700 dark:text-rose-300">
                  جاري التسجيل... انطق كلمة «{word.en}» الآن ثم اضغط «إيقاف وتقييم النطق»
                </div>
                {liveTranscript && (
                  <p dir="ltr" className="mt-1.5 text-left font-en text-xs font-bold text-slate-700 dark:text-slate-200">
                    {liveTranscript}
                  </p>
                )}
              </div>
            )}

            {evaluatingAi && (
              <div className="mt-3 rounded-xl border border-indigo-200 bg-indigo-50 p-3 text-xs font-bold text-indigo-700 dark:border-indigo-800/60 dark:bg-indigo-950/40 dark:text-indigo-300">
                جاري تحليل نطقك بالذكاء الاصطناعي...
              </div>
            )}

            {speechError && !isRecording && (
              <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs font-semibold text-amber-800 dark:border-amber-800/60 dark:bg-amber-950/40 dark:text-amber-200">
                {speechError}
              </div>
            )}

            {evalResult && !isRecording && !evaluatingAi && (
              <div
                className={`mt-3 rounded-xl border p-3.5 ${
                  evalResult.isMatch
                    ? 'border-emerald-200 bg-emerald-50/70 dark:border-emerald-800/60 dark:bg-emerald-950/25'
                    : 'border-amber-200 bg-amber-50/70 dark:border-amber-800/60 dark:bg-amber-950/25'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span
                    className={`text-xs font-extrabold ${
                      evalResult.isMatch
                        ? 'text-emerald-700 dark:text-emerald-300'
                        : 'text-amber-800 dark:text-amber-300'
                    }`}
                  >
                    {evalResult.feedbackAr}
                  </span>
                  <span className="font-code text-xs font-extrabold tabular-nums text-slate-700 dark:text-slate-200">
                    الدقة {evalResult.score}%
                  </span>
                </div>
                {evalResult.heardText && (
                  <div className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                    <span className="font-bold">ما تم سماعه: </span>
                    <span dir="ltr" className="inline-block font-en font-bold">
                      &ldquo;{evalResult.heardText}&rdquo;
                    </span>
                  </div>
                )}
                {evalResult.tipAr && (
                  <div className="mt-1.5 text-xs font-medium text-slate-700 dark:text-slate-300">
                    <span className="font-bold">نصيحة النطق: </span>
                    {evalResult.tipAr}
                  </div>
                )}
              </div>
            )}
          </section>

          {/* Sentence Builder Card (Voice or Text with Red-Underline AI Correction) */}
          <WordSentenceBuilderCard
            word={word}
            onSpeak={onSpeak}
            onSentencePassed={creditSentencePassed}
          />

          {/* Saved Notes for this word */}
          {savedNotesForWord.length > 0 && (
            <WordHubCollapsibleCard
              title="ملاحظاتك المحفوظة لهذه الكلمة"
              subtitle="المرادفات أو التلازمات أو الأمثلة التي حفظتها بشكل منفصل"
              count={savedNotesForWord.length}
              icon={<Bookmark className="h-4 w-4" aria-hidden="true" />}
              defaultOpen
            >
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {savedNotesForWord.map((note) => (
                  <div
                    key={note.id}
                    className="flex items-start justify-between gap-3 py-3 first:pt-0 last:pb-0"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <span className="font-bold">{NOTE_KIND_LABELS[note.kind]}</span>
                        <span aria-hidden="true">·</span>
                        <span dir="ltr" className="font-en text-sm font-extrabold text-slate-900 dark:text-slate-100">
                          {note.text}
                        </span>
                      </div>
                      {note.meaningAr && (
                        <p className="mt-0.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                          {note.meaningAr}
                        </p>
                      )}
                      {note.extra && (
                        <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                          {note.extra}
                        </p>
                      )}
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onSpeak(note.text)}
                        aria-label={`نطق ${note.text}`}
                        className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
                      >
                        <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onToggleSaveWordNote(note)}
                        aria-label={`حذف ${note.text} من المحفوظات`}
                        className="flex h-8 w-8 items-center justify-center rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                      >
                        <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </WordHubCollapsibleCard>
          )}
        </div>
      )}

      {/* TAB 2: RELATIONSHIPS (100% Offline-Ready Synonyms, Antonyms, Word Family, Related Words) */}
      {activeTab === 'relationships' && (
        <WordHubRelationshipsTab
          wordEn={word.en}
          hub={hub}
          loading={false}
          hideTranslation={false}
          savedNoteIds={savedNoteIds}
          onSpeak={onSpeak}
          onExploreWord={onExploreWord}
          onToggleSaveNote={onToggleSaveWordNote}
        />
      )}

      {/* TAB 3: USAGE & CONTEXT (100% Offline-Ready Collocations, Examples, Formal/Informal, Mistakes, Idioms, Phrasal Verbs) */}
      {activeTab === 'usage' && (
        <WordHubUsageTab
          wordEn={word.en}
          hub={hub}
          loading={false}
          hideTranslation={false}
          savedNoteIds={savedNoteIds}
          onSpeak={onSpeak}
          onExploreWord={onExploreWord}
          onToggleSaveNote={onToggleSaveWordNote}
        />
      )}

      {/* TAB 4: DEDICATED VIDEOS TAB (±3s Spoken Video Reels Player) */}
      {activeTab === 'videos' && (
        <WordVideoReelsPlayer word={word.en} meaningAr={displayAr} uiLang={settings.uiLang} />
      )}
    </div>
  );
}
