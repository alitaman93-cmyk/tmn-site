import { useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  BookOpen,
  Clock,
  Loader2,
  Search,
  Sparkles,
  Star,
  Volume2,
  X,
} from 'lucide-react';
import { useI18n } from '../contexts/LanguageContext';
import { BAND_META } from '../data/constants';
import type { ArticleItem, CefrBand, VocabStore, WordLookupResult } from '../types';
import { searchArticlesWithAi, translateSingleWordWithAi } from '../utils/aiApi';
import { speakEn } from '../utils/audio';
import {
  ARTICLE_TOPICS,
  CURATED_ARTICLES,
  lookupWordInStore,
  tokenizeArticleParagraph,
} from '../utils/writingLogic';

interface ArticlesViewProps {
  store: VocabStore;
  ttsRate: number;
  defaultBand: CefrBand;
  favoritesSet: Set<number>;
  onToggleFavorite: (id: number) => void;
  onSummarizeWithAi: (article: ArticleItem) => void;
  onToast: (msg: string) => void;
}

const READING_LEVELS: CefrBand[] = ['A1', 'A2', 'B1', 'B2', 'C1'];

const CONTENT_TYPES = [
  { id: 'all', label: 'الكل (مقالات وقصص)' },
  { id: 'article', label: 'مقالات' },
  { id: 'story', label: 'قصص وروايات قصيرة' },
  { id: 'essay', label: 'نصوص ثقافية' },
] as const;

export function ArticlesView({
  store,
  ttsRate,
  defaultBand,
  favoritesSet,
  onToggleFavorite,
  onSummarizeWithAi,
  onToast,
}: ArticlesViewProps) {
  const { t } = useI18n();
  const [selectedTopic, setSelectedTopic] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [readingLevel, setReadingLevel] = useState<CefrBand>(
    READING_LEVELS.includes(defaultBand) ? defaultBand : 'B1'
  );
  const [contentType, setContentType] = useState<'all' | 'article' | 'story' | 'essay'>('all');

  const [generatedArticles, setGeneratedArticles] = useState<ArticleItem[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState('');
  const [activeSearchLabel, setActiveSearchLabel] = useState('');

  // Currently opened article reader
  const [activeArticle, setActiveArticle] = useState<ArticleItem | null>(null);

  // Clicked word instant Arabic translation state
  const [selectedWordKey, setSelectedWordKey] = useState<string>('');
  const [wordLookup, setWordLookup] = useState<WordLookupResult | null>(null);
  const [lookingUpWord, setLookingUpWord] = useState(false);
  const wordCacheRef = useRef<Map<string, WordLookupResult>>(new Map());

  const visibleArticles = useMemo(() => {
    if (generatedArticles.length > 0 && selectedTopic === 'search') {
      return generatedArticles;
    }
    const base =
      selectedTopic === 'all'
        ? [...generatedArticles, ...CURATED_ARTICLES]
        : CURATED_ARTICLES.filter((a) => a.topicId === selectedTopic);

    const q = searchQuery.trim().toLowerCase();
    if (!q || selectedTopic === 'search') return base;
    const filtered = base.filter(
      (a) =>
        a.title.toLowerCase().includes(q) ||
        a.titleAr.includes(q) ||
        a.summaryHintAr.includes(q) ||
        a.paragraphs.some((p) => p.toLowerCase().includes(q))
    );
    return filtered.length > 0 ? filtered : base;
  }, [generatedArticles, selectedTopic, searchQuery]);

  const handleGenerateTopicArticles = async (topicQuery?: string) => {
    const q = (topicQuery ?? searchQuery).trim();
    if (!q) {
      onToast('اكتب موضوعاً تحب القراءة عنه (مثل: الفضاء، قصص مغامرات، الطبخ، كرة القدم)');
      return;
    }
    setSearching(true);
    setSearchError('');
    try {
      const results = await searchArticlesWithAi({
        query: q,
        level: readingLevel,
        contentType,
      });
      setGeneratedArticles(results);
      setSelectedTopic('search');
      setActiveSearchLabel(q);
      setActiveArticle(null);
    } catch (err) {
      setSearchError(err instanceof Error ? err.message : 'تعذر البحث وتوليد المقالات حالياً.');
    } finally {
      setSearching(false);
    }
  };

  const handleClickArticleWord = async (
    rawWord: string,
    paragraphText: string,
    tokenKey: string
  ) => {
    const clean = rawWord.replace(/^[^A-Za-z]+|[^A-Za-z]+$/g, '');
    if (!clean) return;

    setSelectedWordKey(tokenKey);
    const cacheKey = clean.toLowerCase();

    // 1) Instant cache hit
    const cached = wordCacheRef.current.get(cacheKey);
    if (cached) {
      setWordLookup(cached);
      setLookingUpWord(false);
      return;
    }

    // 2) Instant 0ms lookup in TMN's 18,484-word dictionary
    const localHit = lookupWordInStore(clean, store);
    if (localHit) {
      const found: WordLookupResult = {
        word: clean,
        ar: localHit.ar,
        band: localHit.band,
        wordId: localHit.id,
      };
      wordCacheRef.current.set(cacheKey, found);
      setWordLookup(found);
      setLookingUpWord(false);
      return;
    }

    // 3) Live contextual Arabic translation via server AI endpoint
    setWordLookup({ word: clean, ar: '' });
    setLookingUpWord(true);
    try {
      const res = await translateSingleWordWithAi({
        word: clean,
        contextSentence: paragraphText.slice(0, 220),
      });
      const lookupObj: WordLookupResult = {
        word: clean,
        ar: res.ar,
        posAr: res.posAr,
      };
      wordCacheRef.current.set(cacheKey, lookupObj);
      setWordLookup(lookupObj);
    } catch {
      setWordLookup({
        word: clean,
        ar: 'تعذر جلب الترجمة الآن — حاول مرة أخرى.',
      });
    } finally {
      setLookingUpWord(false);
    }
  };

  // ===================== ARTICLE READER SCREEN =====================
  if (activeArticle) {
    const fullText = activeArticle.paragraphs.join(' ');
    const isFavWord =
      wordLookup?.wordId !== undefined && favoritesSet.has(wordLookup.wordId);

    return (
      <div className="mx-auto max-w-4xl space-y-5">
        {/* Top Back & Action Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              setActiveArticle(null);
              setWordLookup(null);
              setSelectedWordKey('');
              if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
                window.speechSynthesis.cancel();
              }
            }}
            className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
            <span>{t.back} — {t.navReading}</span>
          </button>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => speakEn(fullText, ttsRate, onToast)}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 text-xs font-bold text-slate-700 hover:border-indigo-400 hover:text-indigo-600 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-200"
            >
              <Volume2 className="h-4 w-4" aria-hidden="true" />
              <span>{t.listen}</span>
            </button>
            <button
              type="button"
              onClick={() => speakEn(fullText, 0.72, onToast)}
              className="inline-flex h-10 items-center rounded-xl border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-600 hover:text-slate-900 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-300"
            >
              {t.slow}
            </button>
            <button
              type="button"
              onClick={() => onSummarizeWithAi(activeArticle)}
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white hover:bg-indigo-700"
            >
              <Sparkles className="h-4 w-4" aria-hidden="true" />
              <span>{t.readingSummarizeBtn}</span>
            </button>
          </div>
        </div>

        {/* Sticky Instant Click-to-Translate Word Bar */}
        <div
          role="region"
          aria-live="polite"
          aria-label="الترجمة الفورية للكلمة المختارة"
          className="sticky top-16 z-30 rounded-2xl border border-indigo-200 bg-white/95 p-3.5 shadow-lg backdrop-blur-md dark:border-indigo-500/40 dark:bg-[#131c2e]/95"
        >
          {wordLookup ? (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2.5">
                <span
                  dir="ltr"
                  className="rounded-lg bg-indigo-600 px-3 py-1 font-en text-sm font-extrabold text-white"
                >
                  {wordLookup.word}
                </span>
                {wordLookup.band && (
                  <span
                    className={`rounded-md px-2 py-0.5 font-en text-[11px] font-extrabold text-white ${BAND_META[wordLookup.band].bgClass}`}
                  >
                    {wordLookup.band}
                  </span>
                )}
                {lookingUpWord ? (
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-300">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                    جاري ترجمة الكلمة...
                  </span>
                ) : (
                  <span className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                    {wordLookup.ar}
                    {wordLookup.posAr ? (
                      <span className="mr-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
                        ({wordLookup.posAr})
                      </span>
                    ) : null}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => speakEn(wordLookup.word, ttsRate, onToast)}
                  aria-label={`نطق كلمة ${wordLookup.word}`}
                  className="inline-flex h-8 items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs font-bold text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                >
                  <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>نطق</span>
                </button>
                {wordLookup.wordId !== undefined && (
                  <button
                    type="button"
                    onClick={() => onToggleFavorite(wordLookup.wordId!)}
                    aria-label={isFavWord ? 'إزالة من المفضلة' : 'حفظ في المفضلة'}
                    className={`inline-flex h-8 items-center gap-1 rounded-lg border px-2.5 text-xs font-bold transition-colors ${
                      isFavWord
                        ? 'border-amber-400 bg-amber-50 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-amber-400 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                  >
                    <Star className={`h-3.5 w-3.5 ${isFavWord ? 'fill-current' : ''}`} aria-hidden="true" />
                    <span>{isFavWord ? 'محفوظة' : 'مفضلة'}</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setWordLookup(null);
                    setSelectedWordKey('');
                  }}
                  aria-label="إغلاق الترجمة"
                  className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
                >
                  <X className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300">
              <BookOpen className="h-4 w-4 shrink-0 text-indigo-500" aria-hidden="true" />
              <span>
                اضغط على <strong className="text-indigo-600 dark:text-indigo-400">أي كلمة إنجليزية</strong> داخل النص أدناه لعرض ترجمتها العربية ونطقها فوراً.
              </span>
            </div>
          )}
        </div>

        {/* Article Body Card */}
        <article className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-[#131c2e] sm:p-8">
          <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
            <span
              className={`rounded-md px-2 py-0.5 font-en text-white ${BAND_META[activeArticle.level].bgClass}`}
            >
              {activeArticle.level}
            </span>
            <span className="rounded-md bg-indigo-50 px-2.5 py-0.5 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300">
              {activeArticle.typeLabel}
            </span>
            <span className="inline-flex items-center gap-1 text-slate-500 dark:text-slate-400">
              <Clock className="h-3.5 w-3.5" aria-hidden="true" />
              {activeArticle.readingMinutes} دقائق قراءة
            </span>
          </div>

          <h1
            dir="ltr"
            className="mt-3 text-left font-en text-2xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100 sm:text-3xl"
          >
            {activeArticle.title}
          </h1>
          <p className="mt-1.5 text-sm font-bold text-indigo-600 dark:text-indigo-400">
            {activeArticle.titleAr}
          </p>

          <div
            dir="ltr"
            className="mt-6 space-y-5 border-t border-slate-100 pt-6 text-left font-en text-base leading-[2.05] text-slate-800 dark:border-slate-800 dark:text-slate-200 sm:text-lg"
          >
            {activeArticle.paragraphs.map((paragraph, pIdx) => {
              const tokens = tokenizeArticleParagraph(paragraph);
              return (
                <div key={pIdx} className="group relative rounded-xl p-1">
                  <p>
                    {tokens.map((tk, tIdx) => {
                      if (!tk.isWord) {
                        const prev = tIdx > 0 ? tokens[tIdx - 1] : null;
                        if (prev?.isWord) {
                          const m = tk.text.match(/^([,.;:!?'"”’)\]]+)([\s\S]*)$/);
                          if (m) {
                            return m[2] ? <span key={tIdx}>{m[2]}</span> : null;
                          }
                        }
                        return <span key={tIdx}>{tk.text}</span>;
                      }
                      const next = tIdx + 1 < tokens.length ? tokens[tIdx + 1] : null;
                      const nextMatch =
                        next && !next.isWord
                          ? next.text.match(/^([,.;:!?'"”’)\]]+)([\s\S]*)$/)
                          : null;
                      const attachedPunct = nextMatch ? nextMatch[1] : '';
                      const key = `${pIdx}-${tIdx}`;
                      const isSelected = selectedWordKey === key;
                      const wordBtn = (
                        <button
                          type="button"
                          onClick={() => void handleClickArticleWord(tk.text, paragraph, key)}
                          className={`inline cursor-pointer rounded transition-colors ${
                            isSelected
                              ? 'bg-indigo-600 px-1 font-bold text-white'
                              : 'hover:bg-indigo-100 hover:text-indigo-800 dark:hover:bg-indigo-500/25 dark:hover:text-indigo-200'
                          }`}
                        >
                          {tk.text}
                        </button>
                      );
                      if (attachedPunct) {
                        return (
                          <span key={tIdx} className="whitespace-nowrap">
                            {wordBtn}
                            {attachedPunct}
                          </span>
                        );
                      }
                      return <span key={tIdx}>{wordBtn}</span>;
                    })}
                  </p>
                </div>
              );
            })}
          </div>
        </article>

        {/* Bottom CTA: Transition to AI Coach for Voice/Text Summary */}
        <section className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-indigo-200 bg-indigo-50/60 p-5 dark:border-indigo-500/35 dark:bg-indigo-950/30">
          <div className="max-w-xl">
            <div className="flex items-center gap-2 text-sm font-extrabold text-indigo-700 dark:text-indigo-300">
              <Sparkles className="h-4 w-4" aria-hidden="true" />
              <span>أنهيت القراءة؟ اختبر فهمك وتحدثك الآن!</span>
            </div>
            <p className="mt-1 text-xs leading-relaxed font-semibold text-slate-600 dark:text-slate-300">
              انتقل إلى الذكاء الاصطناعي ليطلب منك تلخيص هذه المقالة بالصوت أو بالكتابة بالإنجليزية، ثم يصحح أخطاءك ويقيّم استيعابك.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onSummarizeWithAi(activeArticle)}
            className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white hover:bg-indigo-700"
          >
            <Sparkles className="h-4 w-4" aria-hidden="true" />
            <span>لخّص هذه المقالة مع الذكاء الاصطناعي</span>
          </button>
        </section>
      </div>
    );
  }

  // ===================== ARTICLES DISCOVERY & SEARCH HUB =====================
  return (
    <div className="space-y-6">
      {/* Header + Search + Level/Type Controls */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e] sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-indigo-600 dark:text-indigo-400" aria-hidden="true" />
              <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 sm:text-2xl">
                {t.readingTitle}
              </h1>
            </div>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 sm:text-sm">
              {t.readingDesc}
            </p>
          </div>
        </div>

        {/* Topic Search Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void handleGenerateTopicArticles();
          }}
          className="mt-5 flex flex-col gap-2.5 sm:flex-row"
        >
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute top-1/2 start-3.5 h-4 w-4 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              aria-label={t.readingTitle}
              placeholder={t.readingSearchPlaceholder}
              className="h-11 w-full rounded-xl border border-slate-200 bg-slate-50 ps-10 pe-4 text-sm font-semibold text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-900/70 dark:text-slate-100 dark:focus:border-indigo-400"
            />
          </div>

          <button
            type="submit"
            disabled={searching || !searchQuery.trim()}
            className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white transition-colors hover:bg-indigo-700 disabled:opacity-45"
          >
            {searching ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                <span>...</span>
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" aria-hidden="true" />
                <span>{t.readingSearchBtn}</span>
              </>
            )}
          </button>
        </form>

        {/* Level & Content Type Filters */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4 dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">نوع النص:</span>
            {CONTENT_TYPES.map((ct) => (
              <button
                key={ct.id}
                type="button"
                onClick={() => setContentType(ct.id)}
                className={`h-8 rounded-lg border px-2.5 text-xs font-bold transition-colors ${
                  contentType === ct.id
                    ? 'border-indigo-500 bg-indigo-600 text-white'
                    : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-300'
                }`}
              >
                {ct.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">المستوى:</span>
            {READING_LEVELS.map((lv) => (
              <button
                key={lv}
                type="button"
                onClick={() => setReadingLevel(lv)}
                className={`h-8 w-9 rounded-lg border font-code text-xs font-bold transition-colors ${
                  readingLevel === lv
                    ? 'border-indigo-500 bg-indigo-600 text-white'
                    : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-300'
                }`}
              >
                {lv}
              </button>
            ))}
          </div>
        </div>

        {/* Suggested Topics Strip */}
        <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-4 dark:border-slate-800">
          {generatedArticles.length > 0 && (
            <button
              type="button"
              onClick={() => setSelectedTopic('search')}
              className={`rounded-xl border px-3.5 py-1.5 text-xs font-bold transition-colors ${
                selectedTopic === 'search'
                  ? 'border-emerald-500 bg-emerald-600 text-white'
                  : 'border-emerald-300 bg-emerald-50 text-emerald-700 dark:border-emerald-700/60 dark:bg-emerald-950/40 dark:text-emerald-300'
              }`}
            >
              نتائج بحثك: {activeSearchLabel} ({generatedArticles.length})
            </button>
          )}
          {ARTICLE_TOPICS.map((tp) => (
            <button
              key={tp.id}
              type="button"
              onClick={() => setSelectedTopic(tp.id)}
              className={`rounded-xl border px-3.5 py-1.5 text-xs font-bold transition-colors ${
                selectedTopic === tp.id
                  ? 'border-indigo-500 bg-indigo-600 text-white'
                  : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900/50 dark:text-slate-300'
              }`}
            >
              {tp.label}
            </button>
          ))}
        </div>

        {searchError && (
          <div className="mt-3 rounded-xl border border-rose-300 bg-rose-50 p-3 text-xs font-bold text-rose-700 dark:border-rose-700/60 dark:bg-rose-950/35 dark:text-rose-300">
            {searchError}
          </div>
        )}
      </section>

      {/* Articles Cards Grid */}
      <section className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {visibleArticles.map((art) => (
          <article
            key={art.id}
            className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-5 transition-colors hover:border-indigo-400 dark:border-slate-800 dark:bg-[#131c2e] dark:hover:border-indigo-500/60"
          >
            <div>
              <div className="flex items-center justify-between gap-2 text-xs font-bold">
                <span className="rounded-md bg-indigo-50 px-2.5 py-0.5 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300">
                  {art.typeLabel}
                </span>
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 text-slate-500 dark:text-slate-400">
                    <Clock className="h-3.5 w-3.5" aria-hidden="true" />
                    {art.readingMinutes} د
                  </span>
                  <span
                    className={`rounded px-2 py-0.5 font-en text-[11px] font-extrabold text-white ${BAND_META[art.level].bgClass}`}
                  >
                    {art.level}
                  </span>
                </div>
              </div>

              <h2
                dir="ltr"
                className="mt-3 text-left font-en text-lg font-extrabold leading-snug text-slate-900 dark:text-slate-100"
              >
                {art.title}
              </h2>
              <p className="mt-1 text-xs font-bold text-indigo-600 dark:text-indigo-400">
                {art.titleAr}
              </p>
              <p className="mt-2.5 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
                {art.summaryHintAr}
              </p>
            </div>

            <div className="mt-5 flex items-center gap-2 border-t border-slate-100 pt-3.5 dark:border-slate-800">
              <button
                type="button"
                onClick={() => {
                  setActiveArticle(art);
                  setWordLookup(null);
                  setSelectedWordKey('');
                  window.scrollTo({ top: 0 });
                }}
                className="inline-flex h-10 flex-1 items-center justify-center gap-1.5 rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white hover:bg-indigo-700"
              >
                <BookOpen className="h-4 w-4" aria-hidden="true" />
                <span>{t.readingReadNow}</span>
              </button>
              <button
                type="button"
                onClick={() => onSummarizeWithAi(art)}
                aria-label={`تلخيص ${art.title} مع الذكاء الاصطناعي`}
                title="لخّصها مع الذكاء الاصطناعي"
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-indigo-600 hover:border-indigo-400 hover:bg-indigo-50 dark:border-slate-700 dark:bg-slate-800 dark:text-indigo-400 dark:hover:bg-slate-700"
              >
                <Sparkles className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}
