import { useEffect, useState } from 'react';
import {
  ArrowRight,
  Award,
  BarChart3,
  BookOpen,
  BookOpenText,
  Gamepad2,
  GraduationCap,
  Headphones,
  Home,
  Layers,
  LogIn,
  Menu,
  MessageSquareText,
  NotebookPen,
  Search,
  Settings,
  Sparkles,
  UserPlus,
  X,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useI18n } from '../contexts/LanguageContext';
import { TMN_LOGO_URL } from '../data/constants';
import { getListeningGrammarStrings } from '../i18n/listeningGrammarStrings';
import type { NavTab, ScreenId } from '../types';

interface TopBarProps {
  screen: ScreenId;
  navTab: NavTab;
  subTitle: string;
  mistakesCount: number;
  srsDueCount: number;
  gameHud?: {
    current: number;
    total: number;
    correct: number;
    wrong: number;
  } | null;
  onSelectTab: (tab: NavTab) => void;
  onBack: () => void;
  onOpenAuth: (mode: 'signup' | 'signin') => void;
  onOpenPlacement: () => void;
  onOpenGlobalSearch: () => void;
  onOpenNotebook: () => void;
  onToast: (msg: string) => void;
}

export function TopBar({
  screen,
  navTab,
  subTitle,
  mistakesCount,
  srsDueCount,
  gameHud,
  onSelectTab,
  onBack,
  onOpenAuth,
  onOpenPlacement,
  onOpenGlobalSearch,
  onOpenNotebook,
}: TopBarProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { user, clearAuthError } = useAuth();
  const { lang, t } = useI18n();
  const lgStrings = getListeningGrammarStrings(lang);

  const primaryNavItems: Array<{ id: NavTab; label: string }> = [
    { id: 'games', label: t.navGames },
    { id: 'levels', label: t.navWords },
    { id: 'sentences', label: t.navSentences },
    { id: 'listening', label: lgStrings.navListening },
    { id: 'ai_coach', label: t.navCoach },
    { id: 'articles', label: t.navReading },
    { id: 'grammar', label: lgStrings.navGrammar },
  ];

  // Strictly 3 calm tabs on Mobile Bottom Bar: Games, Words, Sentences
  const mobileBottomItems: Array<{ id: NavTab; label: string }> = [
    { id: 'games', label: t.navGames },
    { id: 'levels', label: t.navWords },
    { id: 'sentences', label: t.navSentences },
  ];

  // Skills inside ☰ Hamburger Drawer: Listening, Conversation & Writing, Reading, Grammar
  const drawerSkillItems: Array<{ id: NavTab; label: string }> = [
    { id: 'listening', label: lgStrings.navListening },
    { id: 'ai_coach', label: t.navCoach },
    { id: 'articles', label: t.navReading },
    { id: 'grammar', label: lgStrings.navGrammar },
  ];

  const isInGame =
    screen === 'game' ||
    screen === 'arcade_game' ||
    screen === 'study' ||
    screen === 'sentence_game';
  const isSubScreen =
    screen === 'game_setup' ||
    screen === 'band_levels' ||
    screen === 'level_detail' ||
    screen === 'word_detail';

  // Show Mobile Bottom Bar ONLY on Home & its 3 core tabs (Games, Words, Sentences) — hidden on all Skills & secondary screens
  const showMobileBottomNav =
    screen === 'games' ||
    screen === 'levels' ||
    screen === 'band_levels' ||
    screen === 'level_detail' ||
    screen === 'sentences';

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [menuOpen]);

  const handleDrawerNav = (tab: NavTab) => {
    setMenuOpen(false);
    onSelectTab(tab);
  };

  return (
    <>
      <header className="glass-header sticky top-0 z-40 h-14 sm:h-16">
        <div className="mx-auto flex h-full max-w-6xl items-center justify-between gap-3 px-4 sm:gap-5 sm:px-6">
          {/* Start side: Hamburger Menu (3 lines) or Back Button */}
          <div className="flex min-w-0 items-center gap-2.5">
            {isInGame || isSubScreen ? (
              <>
                <button
                  type="button"
                  onClick={onBack}
                  aria-label={isInGame ? t.close : t.back}
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200/80 bg-white/80 text-slate-700 shadow-2xs transition-colors hover:bg-slate-100 dark:border-slate-700/60 dark:bg-[#11192b] dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  {isInGame ? (
                    <X className="h-4 w-4" aria-hidden="true" />
                  ) : (
                    <ArrowRight className="h-4 w-4 ltr:rotate-180" aria-hidden="true" />
                  )}
                </button>
                <span className="truncate text-sm font-bold text-slate-900 dark:text-slate-100 sm:text-base">
                  {subTitle}
                </span>
              </>
            ) : (
              <button
                type="button"
                data-testid="menu-open-btn"
                onClick={() => {
                  clearAuthError();
                  setMenuOpen(true);
                }}
                aria-label={t.menuTitle}
                aria-expanded={menuOpen}
                aria-controls="tmn-main-drawer"
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200/80 bg-white/85 text-slate-800 shadow-2xs transition-colors hover:border-indigo-400/60 hover:bg-indigo-50/70 hover:text-indigo-700 dark:border-slate-700/60 dark:bg-[#11192b] dark:text-slate-100 dark:hover:border-indigo-500/50 dark:hover:bg-[#162036]"
              >
                <Menu className="h-5 w-5" aria-hidden="true" />
              </button>
            )}
          </div>

          {/* CENTER: Pill-style Primary Navigation Tabs (Desktop) */}
          {!isInGame && (
            <nav
              aria-label={t.menuMain}
              className="hidden items-center gap-1 rounded-full border border-slate-200/75 bg-white/75 p-1 shadow-2xs dark:border-slate-700/50 dark:bg-[#11192b]/85 md:flex"
            >
              {primaryNavItems.map((item) => {
                const active = navTab === item.id && !isSubScreen;
                return (
                  <button
                    key={item.id}
                    type="button"
                    data-testid={`nav-tab-${item.id}`}
                    onClick={() => onSelectTab(item.id)}
                    aria-current={active ? 'page' : undefined}
                    className={`shrink-0 whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-bold transition-all lg:px-3.5 lg:text-[13px] ${
                      active
                        ? 'bg-indigo-600 text-white shadow-xs dark:bg-indigo-500 dark:text-white'
                        : 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800/70 dark:hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </nav>
          )}

          {/* End side: Instant Search + Quick Theme Toggle + TMN Brand Logo OR Live Game HUD */}
          <div className="flex shrink-0 items-center gap-2 sm:gap-2.5">
            {isInGame && gameHud ? (
              <div className="flex items-center gap-3 rounded-full border border-slate-200/80 bg-white/85 px-3.5 py-1.5 font-code text-xs font-semibold tabular-nums dark:border-slate-700/60 dark:bg-[#11192b] sm:text-sm">
                <span className="text-slate-600 dark:text-slate-300">
                  {gameHud.current}/{gameHud.total}
                </span>
                {(gameHud.correct + gameHud.wrong > 0 ||
                  screen === 'game' ||
                  screen === 'sentence_game') && (
                  <>
                    <span className="text-emerald-600 dark:text-emerald-400">
                      ✓ {gameHud.correct}
                    </span>
                    <span className="text-rose-600 dark:text-rose-400">✕ {gameHud.wrong}</span>
                  </>
                )}
              </div>
            ) : (
              <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
                <button
                  type="button"
                  data-testid="topbar-global-search-btn"
                  onClick={onOpenGlobalSearch}
                  aria-label={t.readingSearchBtn}
                  title={t.readingSearchBtn}
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-slate-200/80 bg-white/85 text-slate-700 shadow-2xs transition-colors hover:border-indigo-400/60 hover:bg-indigo-50/70 hover:text-indigo-700 dark:border-slate-700/60 dark:bg-[#11192b] dark:text-slate-200 dark:hover:border-indigo-500/50 dark:hover:bg-[#162036]"
                >
                  <Search className="h-4 w-4" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  onClick={() => onSelectTab('games')}
                  aria-label="TMN"
                  dir="ltr"
                  className="flex shrink-0 items-center gap-1.5 rounded-xl px-1 py-1 transition-opacity hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 sm:gap-2 sm:px-1.5"
                >
                  <img
                    src={TMN_LOGO_URL}
                    alt="TMN"
                    className="h-8 w-8 rounded-xl border border-indigo-400/35 object-cover shadow-xs sm:h-9 sm:w-9"
                  />
                  <span className="font-en text-base font-extrabold tracking-wider text-slate-900 dark:text-white sm:text-xl">
                    TMN
                  </span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Slide-Over Drawer for ☰ Menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 flex justify-start">
          <div
            className="fixed inset-0 bg-slate-950/65 backdrop-blur-xs"
            onClick={() => setMenuOpen(false)}
            aria-hidden="true"
          />
          <aside
            id="tmn-main-drawer"
            role="dialog"
            aria-modal="true"
            aria-label={t.menuTitle}
            className="relative z-10 flex h-full w-80 max-w-[86vw] flex-col border-e border-slate-200/80 bg-white shadow-2xl dark:border-slate-800/80 dark:bg-[#0d1424]"
          >
            {/* Drawer Header */}
            <div className="flex items-center justify-between border-b border-slate-200/80 px-5 py-4 dark:border-slate-800/80">
              <div className="flex items-center gap-2.5">
                <img
                  src={TMN_LOGO_URL}
                  alt="TMN"
                  className="h-9 w-9 rounded-xl border border-indigo-400/35 object-cover"
                />
                <div>
                  <div className="font-en text-base font-extrabold tracking-wider text-slate-900 dark:text-white">
                    TMN
                  </div>
                  <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    {t.appTagline}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setMenuOpen(false)}
                aria-label={t.close}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200/80 bg-slate-50 text-slate-600 hover:bg-slate-100 dark:border-slate-700/60 dark:bg-[#11192b] dark:text-slate-300"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            {/* Top Quick Section (Guest Sign In / Sign Up + Home Button) */}
            <div className="border-b border-slate-200/80 p-4 dark:border-slate-800/80">
              {!user && (
                <div className="mb-2.5 grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    data-testid="drawer-signup-btn"
                    onClick={() => {
                      setMenuOpen(false);
                      onOpenAuth('signup');
                    }}
                    className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl bg-sky-500 px-3 text-xs font-extrabold text-slate-950 hover:bg-sky-400"
                  >
                    <UserPlus className="h-4 w-4" aria-hidden="true" />
                    <span>{t.signUp}</span>
                  </button>
                  <button
                    type="button"
                    data-testid="drawer-signin-btn"
                    onClick={() => {
                      setMenuOpen(false);
                      onOpenAuth('signin');
                    }}
                    className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl bg-indigo-600 px-3 text-xs font-bold text-white hover:bg-indigo-700"
                  >
                    <LogIn className="h-4 w-4" aria-hidden="true" />
                    <span>{t.signIn}</span>
                  </button>
                </div>
              )}

              {/* Home Button */}
              <button
                type="button"
                data-testid="drawer-home-btn"
                onClick={() => handleDrawerNav('games')}
                className={`flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-extrabold transition-colors ${
                  showMobileBottomNav
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'border border-indigo-500/25 bg-indigo-500/10 text-indigo-700 hover:bg-indigo-500/15 dark:text-indigo-300'
                }`}
              >
                <Home className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>الصفحة الرئيسية</span>
              </button>
            </div>

            {/* Menu Items */}
            <nav aria-label={t.menuTools} className="flex-1 space-y-1.5 overflow-y-auto p-4">
              {/* Skills Section: Listening, Conversation & Writing, Reading, Grammar */}
              <div className="mb-2 px-2 text-[11px] font-bold text-slate-400">
                أقسام المهارات
              </div>
              {drawerSkillItems.map((item) => {
                const active = navTab === item.id && !isSubScreen;
                return (
                  <button
                    key={item.id}
                    type="button"
                    data-testid={`drawer-nav-tab-${item.id}`}
                    onClick={() => handleDrawerNav(item.id)}
                    className={`flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-bold transition-colors ${
                      active
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-800 hover:bg-slate-100 dark:text-slate-100 dark:hover:bg-[#151f35]'
                    }`}
                  >
                    {item.id === 'listening' && (
                      <Headphones className="h-4 w-4" aria-hidden="true" />
                    )}
                    {item.id === 'ai_coach' && <Sparkles className="h-4 w-4" aria-hidden="true" />}
                    {item.id === 'articles' && (
                      <BookOpenText className="h-4 w-4" aria-hidden="true" />
                    )}
                    {item.id === 'grammar' && (
                      <GraduationCap className="h-4 w-4" aria-hidden="true" />
                    )}
                    <span>{item.label}</span>
                  </button>
                );
              })}

              <div className="my-3 border-t border-slate-200/80 dark:border-slate-800/80" />
              <div className="mb-2 px-2 text-[11px] font-bold text-slate-400">{t.menuTools}</div>

              <button
                type="button"
                data-testid="drawer-stats-btn"
                onClick={() => handleDrawerNav('stats')}
                className={`flex w-full items-center justify-between rounded-xl px-3.5 py-2.5 text-sm font-bold transition-colors ${
                  navTab === 'stats'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-800 hover:bg-slate-100 dark:text-slate-100 dark:hover:bg-[#151f35]'
                }`}
              >
                <span className="flex items-center gap-3">
                  <BarChart3 className="h-4 w-4" aria-hidden="true" />
                  <span>{t.navStats}</span>
                </span>
                {srsDueCount > 0 && (
                  <span
                    className={`rounded-md px-2 py-0.5 font-code text-[11px] font-bold tabular-nums ${
                      navTab === 'stats'
                        ? 'bg-white/20 text-white'
                        : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-300'
                    }`}
                  >
                    {srsDueCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                data-testid="drawer-dict-btn"
                onClick={() => handleDrawerNav('dict')}
                className={`flex w-full items-center justify-between rounded-xl px-3.5 py-2.5 text-sm font-bold transition-colors ${
                  navTab === 'dict'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-800 hover:bg-slate-100 dark:text-slate-100 dark:hover:bg-[#151f35]'
                }`}
              >
                <span className="flex items-center gap-3">
                  <BookOpen className="h-4 w-4" aria-hidden="true" />
                  <span>{t.navDict}</span>
                </span>
                {mistakesCount > 0 && (
                  <span
                    className={`rounded-md px-2 py-0.5 font-code text-[11px] font-bold tabular-nums ${
                      navTab === 'dict'
                        ? 'bg-white/20 text-white'
                        : 'bg-rose-50 text-rose-700 dark:bg-rose-500/20 dark:text-rose-300'
                    }`}
                  >
                    {mistakesCount > 99 ? '99+' : mistakesCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                data-testid="drawer-notebook-btn"
                onClick={() => {
                  setMenuOpen(false);
                  onOpenNotebook();
                }}
                className="flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-bold text-slate-800 transition-colors hover:bg-slate-100 dark:text-slate-100 dark:hover:bg-[#151f35]"
              >
                <NotebookPen className="h-4 w-4 text-indigo-500" aria-hidden="true" />
                <span>دفتري الشخصي</span>
              </button>

              <button
                type="button"
                data-testid="drawer-placement-btn"
                onClick={() => {
                  setMenuOpen(false);
                  onOpenPlacement();
                }}
                className="flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-bold text-emerald-700 transition-colors hover:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/15"
              >
                <Award className="h-4 w-4 text-emerald-500" aria-hidden="true" />
                <span>{t.takePlacementBtn}</span>
              </button>

              <button
                type="button"
                data-testid="drawer-settings-btn"
                onClick={() => handleDrawerNav('settings')}
                className={`flex w-full items-center justify-between rounded-xl px-3.5 py-2.5 text-sm font-bold transition-colors ${
                  navTab === 'settings'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-800 hover:bg-slate-100 dark:text-slate-100 dark:hover:bg-[#151f35]'
                }`}
              >
                <span className="flex items-center gap-3">
                  <Settings className="h-4 w-4" aria-hidden="true" />
                  <span>{t.navSettings}</span>
                </span>
              </button>
            </nav>
          </aside>
        </div>
      )}

      {/* Clean Fixed Mobile Bottom Navigation Bar (Visible ONLY on Home: Games, Words, Sentences) */}
      {showMobileBottomNav && (
        <nav
          aria-label={t.menuMain}
          data-testid="mobile-bottom-nav"
          className="tmn-bottom-bar fixed bottom-0 left-0 right-0 z-40 min-h-16 pt-1 pb-[max(0.35rem,env(safe-area-inset-bottom))] md:hidden"
        >
          <div className="mx-auto grid h-full max-w-lg grid-cols-3 px-2">
            {mobileBottomItems.map((item) => {
              const active = navTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  data-testid={`mobile-nav-tab-${item.id}`}
                  onClick={() => onSelectTab(item.id)}
                  aria-current={active ? 'page' : undefined}
                  className={`relative flex min-h-[48px] min-w-0 flex-col items-center justify-center gap-1 px-1 text-[11px] font-bold transition-colors ${
                    active
                      ? 'text-indigo-600 dark:text-indigo-400'
                      : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
                  }`}
                >
                  <span
                    className={`flex h-7 w-12 items-center justify-center rounded-full transition-colors ${
                      active ? 'bg-indigo-500/12 dark:bg-indigo-400/16' : 'bg-transparent'
                    }`}
                  >
                    {item.id === 'games' && (
                      <Gamepad2 className="h-[19px] w-[19px] shrink-0" aria-hidden="true" />
                    )}
                    {item.id === 'levels' && (
                      <Layers className="h-[19px] w-[19px] shrink-0" aria-hidden="true" />
                    )}
                    {item.id === 'sentences' && (
                      <MessageSquareText
                        className="h-[19px] w-[19px] shrink-0"
                        aria-hidden="true"
                      />
                    )}
                  </span>
                  <span className="max-w-full truncate whitespace-nowrap leading-none">
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
        </nav>
      )}
    </>
  );
}
