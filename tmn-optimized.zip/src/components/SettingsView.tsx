import { useState } from 'react';
import {
  Award,
  Compass,
  Globe,
  Keyboard,
  LogIn,
  LogOut,
  Moon,
  ShieldCheck,
  Sun,
  Trash2,
  User as UserIcon,
  UserPlus,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useI18n } from '../contexts/LanguageContext';
import type { PersistedSettings } from '../types';
import { getGoalLabelAr } from '../utils/learningFeaturesLogic';

interface SettingsViewProps {
  settings: PersistedSettings;
  onUpdateSettings: (patch: Partial<PersistedSettings>) => void;
  onSpeakSample: (rate: number) => void;
  onResetProgress: () => void;
  onOpenAuth: (mode: 'signup' | 'signin') => void;
  onOpenPlacement: () => void;
  onOpenOnboarding: () => void;
  onToast: (msg: string) => void;
}

export function SettingsView({
  settings,
  onUpdateSettings,
  onSpeakSample,
  onResetProgress,
  onOpenAuth,
  onOpenPlacement,
  onOpenOnboarding,
  onToast,
}: SettingsViewProps) {
  const [confirmReset, setConfirmReset] = useState(false);
  const { user, signOutUser } = useAuth();
  const { lang, languages, setLang, t } = useI18n();

  const handleSignOut = async () => {
    await signOutUser();
    onToast(t.signOut);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
        {t.settingsTitle}
      </h1>

      {/* 10-Language Interface Selector Card */}
      <section
        data-testid="settings-language-card"
        className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e]"
      >
        <div className="mb-3 flex items-start gap-2.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sky-500/15 text-sky-500">
            <Globe className="h-5 w-5" aria-hidden="true" />
          </div>
          <div>
            <h2 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
              {t.languageLabel}
            </h2>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{t.languageDesc}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
          {languages.map((opt) => (
            <button
              key={opt.code}
              type="button"
              data-testid={`settings-lang-${opt.code}`}
              data-keep-native="true"
              onClick={() => setLang(opt.code)}
              className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-extrabold transition-colors ${
                lang === opt.code
                  ? 'border-sky-500 bg-sky-500/15 text-sky-700 dark:text-sky-300'
                  : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-sky-400 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-200'
              }`}
            >
              <span>{opt.flag}</span>
              <span className="truncate">{opt.nativeName}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Personal Account & CEFR Placement Card */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e]">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'TMN'}
                referrerPolicy="no-referrer"
                className="h-12 w-12 rounded-full border border-indigo-400/40 object-cover"
              />
            ) : (
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-indigo-50 text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-400">
                <UserIcon className="h-6 w-6" aria-hidden="true" />
              </div>
            )}
            <div>
              <div className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
                {user ? user.displayName || 'TMN' : t.createAccount}
              </div>
              <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                {user ? <span dir="ltr">{user.email}</span> : t.guestSaveDesc}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onOpenPlacement}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-emerald-500/35 bg-emerald-500/10 px-3.5 text-xs font-extrabold text-emerald-700 hover:bg-emerald-500/20 dark:text-emerald-300"
            >
              <Award className="h-4 w-4" aria-hidden="true" />
              <span>{t.takePlacementBtn}</span>
            </button>

            {user ? (
              <>
                <span className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
                  <ShieldCheck className="h-4 w-4" aria-hidden="true" />
                  <span>{t.accountSynced}</span>
                </span>
                <button
                  type="button"
                  onClick={() => void handleSignOut()}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3.5 text-xs font-bold text-rose-700 transition-colors hover:bg-rose-100 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-300"
                >
                  <LogOut className="h-4 w-4" aria-hidden="true" />
                  <span>{t.signOut}</span>
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => onOpenAuth('signup')}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-sky-500 px-3.5 text-xs font-extrabold text-slate-950 hover:bg-sky-400"
                >
                  <UserPlus className="h-4 w-4" aria-hidden="true" />
                  <span>{t.signUp}</span>
                </button>
                <button
                  type="button"
                  onClick={() => onOpenAuth('signin')}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 text-xs font-bold text-white hover:bg-indigo-700"
                >
                  <LogIn className="h-4 w-4" aria-hidden="true" />
                  <span>{t.signIn}</span>
                </button>
              </>
            )}
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        {/* Appearance & Audio Preferences */}
        <section className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white px-5 dark:divide-slate-800 dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="flex items-center justify-between gap-4 py-4">
            <div>
              <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                {t.themeLabel}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.themeDesc}</div>
            </div>
            <button
              type="button"
              data-testid="settings-theme-toggle"
              onClick={() =>
                onUpdateSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' })
              }
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-xs font-bold text-slate-800 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
            >
              {settings.theme === 'dark' ? (
                <>
                  <Sun className="h-4 w-4 text-amber-400" aria-hidden="true" />
                  <span>{t.lightMode}</span>
                </>
              ) : (
                <>
                  <Moon className="h-4 w-4 text-indigo-600" aria-hidden="true" />
                  <span>{t.darkMode}</span>
                </>
              )}
            </button>
          </div>

          <div className="flex items-center justify-between gap-4 py-4">
            <div>
              <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                {t.sfxLabel}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.sfxDesc}</div>
            </div>
            <button
              type="button"
              onClick={() => onUpdateSettings({ sfx: !settings.sfx })}
              className={`inline-flex h-10 items-center gap-2 rounded-xl border px-3.5 text-xs font-bold transition-colors ${
                settings.sfx
                  ? 'border-emerald-500 bg-emerald-600 text-white'
                  : 'border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
              }`}
            >
              {settings.sfx ? (
                <>
                  <Volume2 className="h-4 w-4" aria-hidden="true" />
                  <span>{t.enabled}</span>
                </>
              ) : (
                <>
                  <VolumeX className="h-4 w-4" aria-hidden="true" />
                  <span>{t.muted}</span>
                </>
              )}
            </button>
          </div>

          <div className="flex items-center justify-between gap-4 py-4">
            <div>
              <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                {t.autoSpeakLabel}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.autoSpeakDesc}</div>
            </div>
            <button
              type="button"
              onClick={() => onUpdateSettings({ autoSpeak: !settings.autoSpeak })}
              className={`h-10 rounded-xl border px-3.5 text-xs font-bold transition-colors ${
                settings.autoSpeak
                  ? 'border-emerald-500 bg-emerald-600 text-white'
                  : 'border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
              }`}
            >
              {settings.autoSpeak ? t.enabled : t.off}
            </button>
          </div>

          <div className="flex items-center justify-between gap-4 py-4">
            <div>
              <label
                htmlFor="ttsRateSelect"
                className="text-sm font-bold text-slate-900 dark:text-slate-100"
              >
                {t.ttsRateLabel}
              </label>
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.ttsRateDesc}</div>
            </div>
            <select
              id="ttsRateSelect"
              value={settings.ttsRate}
              onChange={(e) => {
                const rate = parseFloat(e.target.value) || 0.92;
                onUpdateSettings({ ttsRate: rate });
                onSpeakSample(rate);
              }}
              className="h-10 rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm font-bold text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              <option value="0.7">0.7x</option>
              <option value="0.92">0.9x</option>
              <option value="1.1">1.1x</option>
            </select>
          </div>
        </section>

        {/* Learning Goals, Keyboard Shortcuts & Progress Reset */}
        <section className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white px-5 dark:divide-slate-800 dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="flex flex-wrap items-center justify-between gap-4 py-4">
            <div>
              <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                خطة التعلم والهدف اليومي
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                {getGoalLabelAr(settings.learningGoal)} · {settings.dailyPaceMinutes || 10} دقائق يومياً · مستوى {settings.lastBand}
              </div>
            </div>
            <button
              type="button"
              data-testid="settings-reopen-onboarding-btn"
              onClick={onOpenOnboarding}
              className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-xl border border-indigo-200 bg-indigo-50 px-3.5 text-xs font-bold text-indigo-700 hover:bg-indigo-100 dark:border-indigo-500/30 dark:bg-indigo-500/15 dark:text-indigo-300"
            >
              <Compass className="h-4 w-4" aria-hidden="true" />
              <span>تعديل خطة التعلم</span>
            </button>
          </div>
          <div className="flex items-center justify-between gap-4 py-4">
            <div>
              <label
                htmlFor="dailyGoalSelect"
                className="text-sm font-bold text-slate-900 dark:text-slate-100"
              >
                {t.dailyGoalLabel}
              </label>
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.dailyGoalDesc}</div>
            </div>
            <select
              id="dailyGoalSelect"
              value={settings.dailyGoal}
              onChange={(e) =>
                onUpdateSettings({ dailyGoal: parseInt(e.target.value, 10) || 20 })
              }
              className="h-10 rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm font-bold text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              {[10, 20, 30, 50, 100].map((n) => (
                <option key={n} value={n}>
                  {n} {t.wordsLabel}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-between gap-4 py-4">
            <div>
              <label
                htmlFor="levelSizeSelect"
                className="text-sm font-bold text-slate-900 dark:text-slate-100"
              >
                {t.levelSizeLabel}
              </label>
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.levelSizeDesc}</div>
            </div>
            <select
              id="levelSizeSelect"
              value={settings.levelSize}
              onChange={(e) =>
                onUpdateSettings({ levelSize: parseInt(e.target.value, 10) || 20 })
              }
              className="h-10 rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm font-bold text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              {[10, 15, 20, 30, 50].map((n) => (
                <option key={n} value={n}>
                  {n} {t.wordsLabel}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-between gap-4 py-4">
            <div>
              <label
                htmlFor="mcqDirSelect"
                className="text-sm font-bold text-slate-900 dark:text-slate-100"
              >
                {t.mcqDirLabel}
              </label>
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.mcqDirDesc}</div>
            </div>
            <select
              id="mcqDirSelect"
              value={settings.mcqDir}
              onChange={(e) =>
                onUpdateSettings({
                  mcqDir: e.target.value === 'ar2en' ? 'ar2en' : 'en2ar',
                })
              }
              className="h-10 rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm font-bold text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              <option value="en2ar">EN → Native</option>
              <option value="ar2en">Native → EN</option>
            </select>
          </div>

          <div className="flex items-start gap-3 py-4">
            <Keyboard className="mt-0.5 h-4 w-4 shrink-0 text-sky-500" aria-hidden="true" />
            <div>
              <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                {t.keyboardTitle}
              </div>
              <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                {t.keyboardDesc}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 py-4">
            <div>
              <div className="text-sm font-bold text-rose-600 dark:text-rose-400">
                {t.resetLabel}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.resetDesc}</div>
            </div>
            {confirmReset ? (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onResetProgress();
                    setConfirmReset(false);
                  }}
                  className="h-10 rounded-xl bg-rose-600 px-3.5 text-xs font-bold text-white hover:bg-rose-700"
                >
                  {t.confirmResetBtn}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="h-10 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                >
                  {t.cancel}
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3.5 text-xs font-bold text-rose-700 transition-colors hover:bg-rose-100 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-300 dark:hover:bg-rose-500/25"
              >
                <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{t.resetBtn}</span>
              </button>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}

