import { useEffect, useRef } from 'react';
import { useI18n } from '../contexts/LanguageContext';
import type { UiLanguageCode as AppLang } from '../types';
import {
  containsArabic,
  getCachedUiTranslation,
  translateArabicUiBatch,
} from '../utils/liveTranslator';

interface ZeroArabicLeakTranslatorProps {
  backendUrl?: string;
}

const TRANSLATABLE_ATTRS = ['placeholder', 'title', 'aria-label'] as const;
const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'CODE', 'PRE', 'TEXTAREA', 'SVG']);

const originalTextMap = new WeakMap<Text, string>();
const originalAttrMap = new WeakMap<Element, Partial<Record<(typeof TRANSLATABLE_ATTRS)[number], string>>>();

function isInsideSkippedElement(node: Node | null): boolean {
  let el: Element | null =
    node && node.nodeType === Node.ELEMENT_NODE
      ? (node as Element)
      : node?.parentElement ?? null;
  while (el) {
    if (SKIP_TAGS.has(el.tagName)) return true;
    if (el.getAttribute('data-keep-native') === 'true') return true;
    el = el.parentElement;
  }
  return false;
}

function preserveEdgeSpaces(source: string, translated: string): string {
  const lead = source.match(/^\s*/)?.[0] ?? '';
  const trail = source.match(/\s*$/)?.[0] ?? '';
  return `${lead}${translated.trim()}${trail}`;
}

export function ZeroArabicLeakTranslator({ backendUrl = '' }: ZeroArabicLeakTranslatorProps) {
  const { lang } = useI18n();
  const langRef = useRef<AppLang>(lang);
  langRef.current = lang;

  useEffect(() => {
    const root = document.getElementById('root') || document.body;
    if (!root) return;

    let cancelled = false;
    let applying = false;
    let debounceTimer: number | null = null;
    const pendingTextNodes = new Set<Text>();
    const pendingElements = new Set<Element>();

    const restoreAllArabic = () => {
      applying = true;
      try {
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        let cur = walker.nextNode();
        while (cur) {
          const tNode = cur as Text;
          const orig = originalTextMap.get(tNode);
          if (orig !== undefined && tNode.nodeValue !== orig) {
            tNode.nodeValue = orig;
          }
          cur = walker.nextNode();
        }
        const els = root.querySelectorAll('*');
        els.forEach((el) => {
          const origAttrs = originalAttrMap.get(el);
          if (!origAttrs) return;
          for (const attr of TRANSLATABLE_ATTRS) {
            const origVal = origAttrs[attr];
            if (origVal !== undefined && el.getAttribute(attr) !== origVal) {
              el.setAttribute(attr, origVal);
            }
          }
        });
      } finally {
        applying = false;
      }
    };

    if (lang === 'ar') {
      restoreAllArabic();
      return;
    }

    const collectFromSubtree = (container: Node) => {
      if (isInsideSkippedElement(container)) return;

      if (container.nodeType === Node.TEXT_NODE) {
        const tNode = container as Text;
        const val = tNode.nodeValue || '';
        const orig = originalTextMap.get(tNode);
        if (containsArabic(val)) {
          originalTextMap.set(tNode, val);
          pendingTextNodes.add(tNode);
        } else if (orig && containsArabic(orig)) {
          pendingTextNodes.add(tNode);
        }
        return;
      }

      if (container.nodeType === Node.ELEMENT_NODE) {
        const el = container as Element;
        for (const attr of TRANSLATABLE_ATTRS) {
          const attrVal = el.getAttribute(attr);
          const origAttrs = originalAttrMap.get(el);
          if (attrVal && containsArabic(attrVal)) {
            const nextOrig = origAttrs || {};
            nextOrig[attr] = attrVal;
            originalAttrMap.set(el, nextOrig);
            pendingElements.add(el);
          } else if (origAttrs?.[attr]) {
            pendingElements.add(el);
          }
        }
      }

      const walker = document.createTreeWalker(
        container,
        NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT
      );
      let cur = walker.nextNode();
      while (cur) {
        if (!isInsideSkippedElement(cur)) {
          if (cur.nodeType === Node.TEXT_NODE) {
            const tNode = cur as Text;
            const val = tNode.nodeValue || '';
            const orig = originalTextMap.get(tNode);
            if (containsArabic(val)) {
              originalTextMap.set(tNode, val);
              pendingTextNodes.add(tNode);
            } else if (orig && containsArabic(orig)) {
              pendingTextNodes.add(tNode);
            }
          } else if (cur.nodeType === Node.ELEMENT_NODE) {
            const el = cur as Element;
            for (const attr of TRANSLATABLE_ATTRS) {
              const attrVal = el.getAttribute(attr);
              const origAttrs = originalAttrMap.get(el);
              if (attrVal && containsArabic(attrVal)) {
                const nextOrig = origAttrs || {};
                nextOrig[attr] = attrVal;
                originalAttrMap.set(el, nextOrig);
                pendingElements.add(el);
              } else if (origAttrs?.[attr]) {
                pendingElements.add(el);
              }
            }
          }
        }
        cur = walker.nextNode();
      }
    };

    const flushPending = async () => {
      if (cancelled || langRef.current !== lang) return;
      const textTargets = Array.from(pendingTextNodes).filter((n) => n.isConnected);
      const attrTargets = Array.from(pendingElements).filter((e) => e.isConnected);
      pendingTextNodes.clear();
      pendingElements.clear();

      if (textTargets.length === 0 && attrTargets.length === 0) return;

      const missingStrings = new Set<string>();

      // Synchronous instant pass from RAM / hot cache
      applying = true;
      try {
        for (const tNode of textTargets) {
          if (isInsideSkippedElement(tNode)) continue;
          const orig = originalTextMap.get(tNode) ?? tNode.nodeValue ?? '';
          if (!containsArabic(orig)) continue;
          const cached = getCachedUiTranslation(lang, orig);
          if (cached) {
            if (tNode.nodeValue !== cached) tNode.nodeValue = cached;
          } else {
            missingStrings.add(orig.trim());
          }
        }

        for (const el of attrTargets) {
          if (isInsideSkippedElement(el)) continue;
          const origAttrs = originalAttrMap.get(el);
          if (!origAttrs) continue;
          for (const attr of TRANSLATABLE_ATTRS) {
            const origVal = origAttrs[attr];
            if (!origVal || !containsArabic(origVal)) continue;
            const cached = getCachedUiTranslation(lang, origVal);
            if (cached) {
              if (el.getAttribute(attr) !== cached) el.setAttribute(attr, cached);
            } else {
              missingStrings.add(origVal.trim());
            }
          }
        }
      } finally {
        applying = false;
      }

      if (missingStrings.size === 0) return;

      // Async network + IDB batch pass
      const translated = await translateArabicUiBatch(Array.from(missingStrings), lang, backendUrl);
      if (cancelled || langRef.current !== lang || translated.size === 0) return;

      applying = true;
      try {
        for (const tNode of textTargets) {
          if (!tNode.isConnected || isInsideSkippedElement(tNode)) continue;
          const orig = originalTextMap.get(tNode);
          if (!orig) continue;
          const tr = translated.get(orig.trim());
          if (tr) {
            const nextVal = preserveEdgeSpaces(orig, tr);
            if (tNode.nodeValue !== nextVal) tNode.nodeValue = nextVal;
          }
        }

        for (const el of attrTargets) {
          if (!el.isConnected || isInsideSkippedElement(el)) continue;
          const origAttrs = originalAttrMap.get(el);
          if (!origAttrs) continue;
          for (const attr of TRANSLATABLE_ATTRS) {
            const origVal = origAttrs[attr];
            if (!origVal) continue;
            const tr = translated.get(origVal.trim());
            if (tr && el.getAttribute(attr) !== tr) {
              el.setAttribute(attr, tr);
            }
          }
        }
      } finally {
        applying = false;
      }
    };

    const scheduleFlush = () => {
      if (debounceTimer !== null) return;
      debounceTimer = window.setTimeout(() => {
        debounceTimer = null;
        void flushPending();
      }, 35);
    };

    // Initial full scan
    collectFromSubtree(root);
    void flushPending();

    const observer = new MutationObserver((mutations) => {
      if (applying || cancelled || langRef.current !== lang) return;
      let found = false;
      for (const m of mutations) {
        if (m.type === 'characterData' && m.target.nodeType === Node.TEXT_NODE) {
          const tNode = m.target as Text;
          if (!isInsideSkippedElement(tNode) && containsArabic(tNode.nodeValue || '')) {
            originalTextMap.set(tNode, tNode.nodeValue || '');
            pendingTextNodes.add(tNode);
            found = true;
          }
        } else if (m.type === 'attributes' && m.target.nodeType === Node.ELEMENT_NODE) {
          const el = m.target as Element;
          const attr = m.attributeName as (typeof TRANSLATABLE_ATTRS)[number] | null;
          if (attr && !isInsideSkippedElement(el)) {
            const val = el.getAttribute(attr);
            if (val && containsArabic(val)) {
              const origAttrs = originalAttrMap.get(el) || {};
              origAttrs[attr] = val;
              originalAttrMap.set(el, origAttrs);
              pendingElements.add(el);
              found = true;
            }
          }
        } else if (m.type === 'childList') {
          m.addedNodes.forEach((node) => {
            collectFromSubtree(node);
            found = true;
          });
        }
      }
      if (found) {
        scheduleFlush();
      }
    });

    observer.observe(root, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: [...TRANSLATABLE_ATTRS],
    });

    return () => {
      cancelled = true;
      observer.disconnect();
      if (debounceTimer !== null) window.clearTimeout(debounceTimer);
    };
  }, [lang, backendUrl]);

  return null;
}
