import {
  AlertCircle,
  CloudRain,
  EyeOff,
  Grid3X3,
  Headphones,
  Layers,
  ListOrdered,
  MessageCircle,
  Mic,
  PenTool,
  RefreshCw,
  Rocket,
  Sparkles,
  Zap,
} from 'lucide-react';
import { useI18n } from '../contexts/LanguageContext';
import { GAMES } from '../data/constants';
import type {
  ArcadeGameModeId,
  GameModeId,
  PersistedSettings,
  SentenceGameModeId,
} from '../types';
import { todayStr } from '../utils/storage';
import { GameIcon } from './GameIcon';

interface GamesHomeProps {
  settings: PersistedSettings;
  onSelectGame: (mode: GameModeId) => void;
  onStartArcadeGame: (mode: ArcadeGameModeId) => void;
  onStartSentenceGame: (mode: SentenceGameModeId) => void;
}

export function GamesHome({
  settings,
  onSelectGame,
  onStartArcadeGame,
  onStartSentenceGame,
}: GamesHomeProps) {
  const { t } = useI18n();
  const today = todayStr();
  const wordleDoneToday =
    settings.wordleDailyDate === today && settings.wordleDailyStatus === 'won';

  return (
    <div className="space-y-6 sm:space-y-8">
      {/* Section 1: Sentence Games (Flagship Pattern Swap + 8 Interactive Sentence Games) */}
      <section data-testid="sentence-games-section">
        <div className="mb-3 flex items-baseline justify-between gap-3 sm:mb-4">
          <h2 className="text-base font-extrabold tracking-tight text-slate-900 dark:text-slate-100 sm:text-lg">
            {t.sentenceGamesTitle}
          </h2>
          <span className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 sm:text-xs">
            9 ألعاب تفاعلية للطلاقة
          </span>
        </div>

        {/* Flagship Featured Card: Pattern Swap */}
        <button
          type="button"
          data-testid="launch-sentence-pattern-swap"
          onClick={() => onStartSentenceGame('sentence_pattern_swap')}
          className="tmn-card-hover group mb-3 flex w-full items-center justify-between gap-3 rounded-2xl border-indigo-500/30 p-3.5 text-start ring-1 ring-indigo-500/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 dark:ring-indigo-400/25 sm:mb-4 sm:gap-4 sm:p-5"
        >
          <div className="flex min-w-0 items-center gap-3 sm:gap-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-sky-500 text-white shadow-sm sm:h-12 sm:w-12 sm:rounded-2xl">
              <RefreshCw className="h-4 w-4 sm:h-5 sm:w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <h3 className="truncate text-sm font-extrabold text-slate-900 dark:text-slate-50 sm:text-lg">
                تحدي تبديل الأنماط
              </h3>
              <span className="mt-0.5 inline-flex items-center gap-1 text-[11px] font-bold text-indigo-600 dark:text-indigo-400 sm:text-xs">
                <Sparkles className="h-3 w-3 shrink-0 sm:h-3.5 sm:w-3.5" aria-hidden="true" />
                <span className="truncate">تدريب الطلاقة الأهم</span>
              </span>
            </div>
          </div>
          <span className="inline-flex h-9 shrink-0 items-center justify-center rounded-xl bg-indigo-600 px-3 text-[11px] font-extrabold text-white transition-colors group-hover:bg-indigo-500 sm:h-10 sm:px-4 sm:text-xs">
            ابدأ التحدي
          </span>
        </button>

        <div className="grid grid-cols-2 gap-2.5 sm:gap-3.5 lg:grid-cols-4">
          <button
            type="button"
            onClick={() => onStartSentenceGame('sentence_order')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-3.5 sm:p-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-indigo-600 text-white shadow-xs">
              <ListOrdered className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="text-xs font-extrabold leading-snug text-slate-900 dark:text-slate-50 sm:text-sm">
                {t.sentOrderTitle}
              </h3>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onStartSentenceGame('sentence_error')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-3.5 sm:p-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-amber-500 text-slate-950 shadow-xs">
              <AlertCircle className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="text-xs font-extrabold leading-snug text-slate-900 dark:text-slate-50 sm:text-sm">
                {t.sentErrorTitle}
              </h3>
            </div>
          </button>

          <button
            type="button"
            data-testid="launch-sentence-dictation"
            onClick={() => onStartSentenceGame('sentence_dictation')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-3.5 sm:p-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-emerald-600 text-white shadow-xs">
              <Headphones className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="text-xs font-extrabold leading-snug text-slate-900 dark:text-slate-50 sm:text-sm">
                {t.sentDictTitle}
              </h3>
            </div>
          </button>

          <button
            type="button"
            data-testid="launch-sentence-vanish"
            onClick={() => onStartSentenceGame('sentence_vanish')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-3.5 sm:p-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-violet-600 text-white shadow-xs">
              <EyeOff className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="text-xs font-extrabold leading-snug text-slate-900 dark:text-slate-50 sm:text-sm">
                الجملة المتلاشية
              </h3>
            </div>
          </button>

          <button
            type="button"
            data-testid="launch-sentence-cloze"
            onClick={() => onStartSentenceGame('sentence_cloze')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-3.5 sm:p-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-sky-600 text-white shadow-xs">
              <PenTool className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="text-xs font-extrabold leading-snug text-slate-900 dark:text-slate-50 sm:text-sm">
                أكمل الفراغ الذكي
              </h3>
            </div>
          </button>

          <button
            type="button"
            data-testid="launch-sentence-chat-reply"
            onClick={() => onStartSentenceGame('sentence_chat_reply')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-3.5 sm:p-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-teal-600 text-white shadow-xs">
              <MessageCircle className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="text-xs font-extrabold leading-snug text-slate-900 dark:text-slate-50 sm:text-sm">
                الرد السريع في المحادثة
              </h3>
            </div>
          </button>

          <button
            type="button"
            data-testid="launch-sentence-speak"
            onClick={() => onStartSentenceGame('sentence_speak')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-3.5 sm:p-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-rose-600 text-white shadow-xs">
              <Mic className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="text-xs font-extrabold leading-snug text-slate-900 dark:text-slate-50 sm:text-sm">
                تحدي النطق المباشر
              </h3>
            </div>
          </button>

          <button
            type="button"
            data-testid="launch-sentence-blitz"
            onClick={() => onStartSentenceGame('sentence_blitz')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-3.5 sm:p-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-orange-500 text-slate-950 shadow-xs">
              <Zap className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-xs font-extrabold leading-snug text-slate-900 dark:text-slate-50 sm:text-sm">
                  سباق الجمل — 60 ثانية
                </h3>
                {(settings.bestSentenceBlitzScore || 0) > 0 && (
                  <span className="font-code text-[11px] font-bold tabular-nums text-orange-600 dark:text-orange-400">
                    ★ {settings.bestSentenceBlitzScore}
                  </span>
                )}
              </div>
            </div>
          </button>
        </div>
      </section>

      {/* Section 2: Word Games (5 Offline Arcade Word Games + 10 Classic Word Game Modes) */}
      <section data-testid="word-games-section">
        <div className="mb-3 flex items-baseline justify-between gap-3 sm:mb-4">
          <h2 className="text-base font-extrabold tracking-tight text-slate-900 dark:text-slate-50 sm:text-lg">
            {t.wordGamesTitle}
          </h2>
          <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 sm:text-xs">
            15 لعبة وتحدي للمفردات
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5 sm:gap-3.5 lg:grid-cols-3">
          {/* 1. Word Challenge */}
          <button
            type="button"
            data-testid="arcade-card-wordle"
            onClick={() => onStartArcadeGame('wordle')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-4 sm:p-4.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-emerald-600 text-white shadow-xs">
              <Grid3X3 className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-xs font-bold leading-snug text-slate-900 dark:text-slate-50 sm:text-base">
                  تحدي الكلمة
                </h3>
                {wordleDoneToday && (
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                    ✓ اليوم
                  </span>
                )}
              </div>
            </div>
          </button>

          {/* 2. 60-Second Speed Blitz */}
          <button
            type="button"
            data-testid="arcade-card-speed_blitz"
            onClick={() => onStartArcadeGame('speed_blitz')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-4 sm:p-4.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-amber-500 text-slate-950 shadow-xs">
              <Zap className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-xs font-bold leading-snug text-slate-900 dark:text-slate-50 sm:text-base">
                  سباق 60 ثانية
                </h3>
                {(settings.bestBlitzScore || 0) > 0 && (
                  <span className="font-code text-xs font-bold tabular-nums text-amber-600 dark:text-amber-400">
                    ★ {settings.bestBlitzScore}
                  </span>
                )}
              </div>
            </div>
          </button>

          {/* 3. Memory Flip Cards */}
          <button
            type="button"
            data-testid="arcade-card-memory_flip"
            onClick={() => onStartArcadeGame('memory_flip')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-4 sm:p-4.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-violet-600 text-white shadow-xs">
              <Layers className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-xs font-bold leading-snug text-slate-900 dark:text-slate-50 sm:text-base">
                  بطاقات الذاكرة
                </h3>
                {(settings.bestMemoryMoves || 0) > 0 && (
                  <span className="font-code text-xs font-bold tabular-nums text-violet-600 dark:text-violet-400">
                    {settings.bestMemoryMoves} حركة
                  </span>
                )}
              </div>
            </div>
          </button>

          {/* 4. Word Rain */}
          <button
            type="button"
            data-testid="arcade-card-word_rain"
            onClick={() => onStartArcadeGame('word_rain')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-4 sm:p-4.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-sky-600 text-white shadow-xs">
              <CloudRain className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-xs font-bold leading-snug text-slate-900 dark:text-slate-50 sm:text-base">
                  مطر الكلمات
                </h3>
                {(settings.bestWordRainScore || 0) > 0 && (
                  <span className="font-code text-xs font-bold tabular-nums text-sky-600 dark:text-sky-400">
                    ★ {settings.bestWordRainScore}
                  </span>
                )}
              </div>
            </div>
          </button>

          {/* 5. Save the Rocket */}
          <button
            type="button"
            data-testid="arcade-card-save_rocket"
            onClick={() => onStartArcadeGame('save_rocket')}
            className="tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-4 sm:p-4.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11 bg-rose-600 text-white shadow-xs">
              <Rocket className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-xs font-bold leading-snug text-slate-900 dark:text-slate-50 sm:text-base">
                  أنقذ الصاروخ
                </h3>
                {(settings.bestRocketStreak || 0) > 0 && (
                  <span className="font-code text-xs font-bold tabular-nums text-rose-600 dark:text-rose-400">
                    سلسلة {settings.bestRocketStreak}
                  </span>
                )}
              </div>
            </div>
          </button>

          {/* Classic 10 Word Game Modes */}
          {GAMES.map((game) => {
            const gLoc = t.games[game.id] || { name: game.name, desc: game.desc };
            return (
              <button
                key={game.id}
                type="button"
                onClick={() => onSelectGame(game.id)}
                className={`tmn-card-hover group flex items-center gap-2.5 rounded-2xl p-3 text-start sm:gap-4 sm:p-4.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 ${
                  game.featured
                    ? 'ring-1 ring-indigo-500/30 dark:ring-indigo-400/25'
                    : ''
                }`}
              >
                <div
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-colors sm:h-11 sm:w-11 ${
                    game.featured
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 group-hover:bg-indigo-600 group-hover:text-white dark:bg-slate-800/80 dark:text-slate-200'
                  }`}
                >
                  <GameIcon mode={game.id} className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-xs font-bold leading-snug text-slate-900 dark:text-slate-100 sm:text-base">
                      {gLoc.name}
                    </h3>
                    {game.id === 'listen_type' && (
                      <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                        · {t.badgeNew}
                      </span>
                    )}
                    {game.id === 'mixed' && (
                      <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                        · {t.badgeAll}
                      </span>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
}
