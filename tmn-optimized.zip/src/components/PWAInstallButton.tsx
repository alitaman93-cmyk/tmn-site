import { useState } from 'react';
import { CheckCircle2, Smartphone, Share, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  compact?: boolean;
  onShowGuide?: () => void;
}

export function PWAInstallButton({ compact = false }: PWAInstallButtonProps) {
  const { canPromptInstall, isInstalled, isIOS, promptInstall } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);

  if (isInstalled) {
    if (compact) return null;
    return (
      <div className="inline-flex h-11 items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 text-xs font-bold text-emerald-700 dark:text-emerald-300">
        <CheckCircle2 className="h-4 w-4 shrink-0" aria-hidden="true" />
        <span>التطبيق مثبّت على جهازك</span>
      </div>
    );
  }

  const handleClick = async () => {
    if (canPromptInstall) {
      await promptInstall();
    } else {
      setShowGuideModal(true);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => void handleClick()}
        className={
          compact
            ? 'inline-flex h-10 items-center gap-2 whitespace-nowrap rounded-xl bg-indigo-600 px-3.5 text-xs font-bold text-white transition-colors hover:bg-indigo-700'
            : 'inline-flex h-11 items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-indigo-600 px-4 text-sm font-bold text-white transition-colors hover:bg-indigo-700'
        }
      >
        <Smartphone className="h-4 w-4 shrink-0" aria-hidden="true" />
        <span>تثبيت التطبيق على الموبايل</span>
      </button>

      {showGuideModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-install-guide-title"
          onClick={() => setShowGuideModal(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 text-right shadow-2xl dark:border-slate-700 dark:bg-[#131c2e]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-indigo-600 text-white">
                  <Smartphone className="h-5 w-5" aria-hidden="true" />
                </span>
                <div>
                  <h3
                    id="pwa-install-guide-title"
                    className="text-base font-extrabold text-slate-900 dark:text-slate-100"
                  >
                    تثبيت التطبيق على الموبايل
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    يعمل بالكامل بدون إنترنت مع جميع الـ 18,484 كلمة
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                aria-label="إغلاق"
                className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-600 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            {isIOS ? (
              <ol className="mt-5 space-y-3 text-sm text-slate-700 dark:text-slate-200">
                <li className="flex items-start gap-2.5">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-600/15 font-code text-xs font-bold text-indigo-600 dark:text-indigo-400">
                    1
                  </span>
                  <span>
                    افتح رابط التطبيق في متصفح <strong>Safari</strong> على iPhone أو iPad.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-600/15 font-code text-xs font-bold text-indigo-600 dark:text-indigo-400">
                    2
                  </span>
                  <span className="inline-flex flex-wrap items-center gap-1">
                    اضغط زر <strong>المشاركة</strong>{' '}
                    <Share className="inline h-4 w-4 text-indigo-500" aria-hidden="true" /> أسفل
                    الشاشة.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-600/15 font-code text-xs font-bold text-indigo-600 dark:text-indigo-400">
                    3
                  </span>
                  <span>
                    اختر <strong>إضافة إلى الشاشة الرئيسية (Add to Home Screen)</strong> ثم اضغط{' '}
                    <strong>إضافة</strong>.
                  </span>
                </li>
              </ol>
            ) : (
              <ol className="mt-5 space-y-3 text-sm text-slate-700 dark:text-slate-200">
                <li className="flex items-start gap-2.5">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-600/15 font-code text-xs font-bold text-indigo-600 dark:text-indigo-400">
                    1
                  </span>
                  <span>
                    افتح التطبيق في نافذة متصفح مستقلة (<strong>Chrome</strong> أو{' '}
                    <strong>Edge</strong> على أندرويد، أو <strong>Safari</strong> على آيفون).
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-600/15 font-code text-xs font-bold text-indigo-600 dark:text-indigo-400">
                    2
                  </span>
                  <span>
                    اضغط قائمة المتصفح (<strong>⋮</strong>) واختر{' '}
                    <strong>تثبيت التطبيق (Install App)</strong> أو{' '}
                    <strong>إضافة إلى الشاشة الرئيسية</strong>.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-600/15 font-code text-xs font-bold text-indigo-600 dark:text-indigo-400">
                    3
                  </span>
                  <span>
                    أو اضغط زر <strong>تنزيل index.html الكامل</strong> لحفظ نسخة ملف واحد جاهزة
                    للفتح مباشرة على أي موبايل أو تحويلها إلى APK.
                  </span>
                </li>
              </ol>
            )}

            <button
              type="button"
              onClick={() => setShowGuideModal(false)}
              className="mt-6 h-11 w-full rounded-xl bg-indigo-600 text-sm font-bold text-white transition-colors hover:bg-indigo-700"
            >
              فهمت
            </button>
          </div>
        </div>
      )}
    </>
  );
}
