import {
  CheckCircle2,
  ChevronLeft,
  Mic,
  Play,
  RotateCcw,
  Square,
  Volume2,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import type { SentenceEntry, SpeechEvalResult } from '../types';
import { speakEn } from '../utils/audio';
import { evaluateSpokenMatch } from '../utils/sentenceLogic';

interface ShadowingModalProps {
  open: boolean;
  sentences: SentenceEntry[];
  initialIndex: number;
  translationsMap: Record<string, string>;
  onClose: () => void;
  onSentencePracticed: (num: number) => void;
  onToast: (msg: string) => void;
}

type ShadowPhase =
  | 'idle'
  | 'playing_slow'
  | 'playing_normal'
  | 'countdown'
  | 'recording'
  | 'review';

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  0: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: { error?: string }) => void) | null;
  start: () => void;
  stop: () => void;
}

type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

function getSpeechRecCtor(): SpeechRecognitionCtor | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

function speakWithPromise(text: string, rate: number): Promise<void> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      globalThis.setTimeout(resolve, 1100);
      return;
    }
    try {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.lang = 'en-US';
      utter.rate = rate;
      let done = false;
      const finish = () => {
        if (!done) {
          done = true;
          resolve();
        }
      };
      utter.onend = finish;
      utter.onerror = finish;
      window.speechSynthesis.speak(utter);
      // Safety timeout in headless browsers where speechSynthesis never fires onend
      window.setTimeout(finish, Math.max(1400, Math.min(4500, text.length * 90)));
    } catch {
      window.setTimeout(resolve, 900);
    }
  });
}

export function ShadowingModal({
  open,
  sentences,
  initialIndex,
  translationsMap,
  onClose,
  onSentencePracticed,
  onToast,
}: ShadowingModalProps) {
  const [idx, setIdx] = useState(initialIndex);
  const [phase, setPhase] = useState<ShadowPhase>('idle');
  const [countdown, setCountdown] = useState(3);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [evalResult, setEvalResult] = useState<SpeechEvalResult | null>(null);
  const [recordingUrl, setRecordingUrl] = useState<string | null>(null);
  const [micError, setMicError] = useState('');

  const cancelledRef = useRef(false);
  const speechRecRef = useRef<SpeechRecognitionLike | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const transcriptRef = useRef('');
  const urlsRef = useRef<string[]>([]);

  const currentSentence = sentences[idx] || sentences[0] || null;
  const cleanEnglish = currentSentence ? currentSentence.en.split('=')[0].trim() : '';

  const stopActiveMedia = useCallback(() => {
    try {
      speechRecRef.current?.stop();
    } catch {
      // Ignore
    }
    speechRecRef.current = null;

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // Ignore
      }
    }
    mediaRecorderRef.current = null;
    mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
    mediaStreamRef.current = null;
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }, []);

  useEffect(() => {
    if (open) {
      cancelledRef.current = false;
      setIdx(Math.max(0, Math.min(initialIndex, Math.max(0, sentences.length - 1))));
      setPhase('idle');
      setEvalResult(null);
      setRecordingUrl(null);
      setLiveTranscript('');
      setMicError('');
    } else {
      cancelledRef.current = true;
      stopActiveMedia();
    }
  }, [open, initialIndex, sentences.length, stopActiveMedia]);

  useEffect(() => {
    return () => {
      cancelledRef.current = true;
      stopActiveMedia();
      urlsRef.current.forEach((u) => URL.revokeObjectURL(u));
    };
  }, [stopActiveMedia]);

  const finishRecordingAndEvaluate = useCallback(
    (blob: Blob | null, spoken: string) => {
      if (!currentSentence) return;
      if (blob && blob.size > 0) {
        const url = URL.createObjectURL(blob);
        urlsRef.current.push(url);
        setRecordingUrl(url);
      }
      const trimmed = spoken.trim();
      const evaluation = evaluateSpokenMatch(
        cleanEnglish,
        trimmed || ''
      );
      setEvalResult(evaluation);
      setPhase('review');
      if (evaluation.score >= 60 || (blob && blob.size > 500)) {
        onSentencePracticed(currentSentence.num);
      }
    },
    [cleanEnglish, currentSentence, onSentencePracticed]
  );

  const beginRecording = useCallback(async () => {
    if (cancelledRef.current || !currentSentence) return;
    setPhase('recording');
    setMicError('');
    setLiveTranscript('');
    transcriptRef.current = '';
    chunksRef.current = [];

    const startMediaFallback = async () => {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          if (cancelledRef.current) {
            stream.getTracks().forEach((t) => t.stop());
            return;
          }
          mediaStreamRef.current = stream;
          const mime =
            typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported('audio/webm')
              ? 'audio/webm'
              : '';
          const recorder = mime
            ? new MediaRecorder(stream, { mimeType: mime })
            : new MediaRecorder(stream);
          recorder.ondataavailable = (ev) => {
            if (ev.data && ev.data.size > 0) chunksRef.current.push(ev.data);
          };
          recorder.onstop = () => {
            const blob = new Blob(chunksRef.current, { type: mime || 'audio/webm' });
            chunksRef.current = [];
            mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
            mediaStreamRef.current = null;
            if (!cancelledRef.current) {
              finishRecordingAndEvaluate(blob, transcriptRef.current);
            }
          };
          mediaRecorderRef.current = recorder;
          recorder.start();
        } catch {
          setMicError('يرجى السماح بصلاحية الميكروفون أو استمع وكرر الجملة بصوتك.');
          setPhase('idle');
        }
      } else {
        setMicError('الميكروفون غير متاح في هذا المتصفح — يمكنك الاستماع والترديد مباشرة.');
        setPhase('idle');
      }
    };

    const SR = getSpeechRecCtor();
    if (SR) {
      try {
        const rec = new SR();
        rec.lang = 'en-US';
        rec.continuous = true;
        rec.interimResults = true;
        rec.onresult = (ev) => {
          let combined = '';
          for (let i = 0; i < ev.results.length; i++) {
            combined += ev.results[i][0].transcript + ' ';
          }
          const clean = combined.trim();
          transcriptRef.current = clean;
          setLiveTranscript(clean);
        };
        rec.onerror = (ev) => {
          const code = ev?.error || '';
          if (code === 'not-allowed' || code === 'service-not-allowed') {
            speechRecRef.current = null;
            setMicError('يرجى السماح بصلاحية الميكروفون أو استمع وكرر الجملة بصوتك.');
            setPhase('idle');
          } else if (code === 'network' || code === 'audio-capture') {
            speechRecRef.current = null;
            void startMediaFallback();
          }
        };
        rec.start();
        speechRecRef.current = rec;
        return;
      } catch {
        speechRecRef.current = null;
      }
    }

    await startMediaFallback();
  }, [currentSentence, finishRecordingAndEvaluate]);

  const stopRecording = useCallback(() => {
    try {
      speechRecRef.current?.stop();
    } catch {
      // Ignore
    }
    speechRecRef.current = null;
    const rec = mediaRecorderRef.current;
    if (rec && rec.state !== 'inactive') {
      rec.stop();
    } else {
      finishRecordingAndEvaluate(null, transcriptRef.current);
    }
  }, [finishRecordingAndEvaluate]);

  const runGuidedLoop = useCallback(async () => {
    if (!currentSentence) return;
    cancelledRef.current = false;
    setEvalResult(null);
    setRecordingUrl(null);
    setMicError('');
    setLiveTranscript('');

    // Step 1a: Slow 0.75x
    setPhase('playing_slow');
    await speakWithPromise(cleanEnglish, 0.75);
    if (cancelledRef.current) return;

    // Step 1b: Natural 1.0x
    setPhase('playing_normal');
    await speakWithPromise(cleanEnglish, 1.0);
    if (cancelledRef.current) return;

    // Step 2: 3-2-1 visual countdown
    setPhase('countdown');
    for (const c of [3, 2, 1]) {
      if (cancelledRef.current) return;
      setCountdown(c);
      await new Promise((r) => window.setTimeout(r, 650));
    }
    if (cancelledRef.current) return;

    // Step 3: Auto-start recording
    await beginRecording();
  }, [beginRecording, cleanEnglish, currentSentence]);

  const handleNextSentence = () => {
    cancelledRef.current = true;
    stopActiveMedia();
    const nextIdx = (idx + 1) % Math.max(1, sentences.length);
    setIdx(nextIdx);
    setPhase('idle');
    setEvalResult(null);
    setRecordingUrl(null);
    setLiveTranscript('');
    setMicError('');
  };

  if (!open || !currentSentence) return null;

  const arTranslation = translationsMap[currentSentence.en] || '';

  return (
    <div
      data-testid="shadowing-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="تدريب الظل للنطق (Shadowing)"
    >
      <div className="tmn-card flex max-h-[90vh] w-full max-w-xl flex-col overflow-hidden rounded-3xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200/80 px-5 py-4 dark:border-slate-800 sm:px-6">
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
              تدريب الظل للنطق (Shadowing)
            </h2>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              استمع ببطء ← استمع طبيعي ← سجّل صوتك وقارن
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              cancelledRef.current = true;
              stopActiveMedia();
              onClose();
            }}
            aria-label="إغلاق"
            className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 space-y-5 overflow-y-auto p-5 sm:p-6">
          {/* 3-Step Indicator */}
          <div className="grid grid-cols-3 gap-2 text-center text-[11px] font-bold">
            <div
              className={`rounded-xl border px-2 py-2 ${
                phase === 'playing_slow' || phase === 'playing_normal'
                  ? 'border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-200'
                  : 'border-slate-200/80 text-slate-500 dark:border-slate-800 dark:text-slate-400'
              }`}
            >
              1. استمع (0.75x → 1x)
            </div>
            <div
              className={`rounded-xl border px-2 py-2 ${
                phase === 'countdown' || phase === 'recording'
                  ? 'border-rose-500 bg-rose-50 text-rose-700 dark:bg-rose-500/20 dark:text-rose-200'
                  : 'border-slate-200/80 text-slate-500 dark:border-slate-800 dark:text-slate-400'
              }`}
            >
              2. ردّد وسجّل
            </div>
            <div
              className={`rounded-xl border px-2 py-2 ${
                phase === 'review'
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-200'
                  : 'border-slate-200/80 text-slate-500 dark:border-slate-800 dark:text-slate-400'
              }`}
            >
              3. قارن النطق
            </div>
          </div>

          {/* Target Sentence Card */}
          <div className="rounded-2xl border border-slate-200/80 bg-slate-50/70 p-5 dark:border-slate-800 dark:bg-slate-900/50">
            <div className="mb-2 flex items-center justify-between text-xs font-bold text-slate-400">
              <span className="font-code tabular-nums">#{currentSentence.num}</span>
              <span className="tabular-nums">
                {idx + 1} / {sentences.length}
              </span>
            </div>

            {evalResult?.tokens && evalResult.tokens.length > 0 ? (
              <p
                dir="ltr"
                className="flex flex-wrap gap-1.5 text-left font-en text-lg font-extrabold leading-relaxed sm:text-xl"
              >
                {evalResult.tokens.map((tok, i) => (
                  <span
                    key={`${tok.word}-${i}`}
                    className={`rounded-md px-1.5 py-0.5 ${
                      tok.matched
                        ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                        : 'bg-rose-500/15 text-rose-700 dark:text-rose-300'
                    }`}
                  >
                    {tok.word}
                  </span>
                ))}
              </p>
            ) : (
              <p
                dir="ltr"
                className="text-left font-en text-lg font-extrabold leading-relaxed text-slate-900 dark:text-white sm:text-xl"
              >
                {cleanEnglish}
              </p>
            )}

            {arTranslation && (
              <p className="mt-2.5 text-sm font-medium text-indigo-700 dark:text-indigo-300">
                {arTranslation}
              </p>
            )}
          </div>

          {/* Dynamic Phase Panel */}
          {phase === 'idle' && (
            <div className="flex flex-col items-center gap-3 py-2 text-center">
              <button
                type="button"
                data-testid="shadowing-start-loop-btn"
                onClick={() => void runGuidedLoop()}
                className="inline-flex h-12 items-center gap-2 rounded-2xl bg-indigo-600 px-6 text-sm font-bold text-white shadow-sm transition-colors hover:bg-indigo-700"
              >
                <Play className="h-4 w-4 fill-current" />
                <span>ابدأ جلسة الظل الموجهة</span>
              </button>
              <div className="flex flex-wrap items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={() => speakEn(cleanEnglish, 0.75, onToast)}
                  className="rounded-xl border border-slate-200 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  استمع بطيء 0.75x
                </button>
                <button
                  type="button"
                  onClick={() => speakEn(cleanEnglish, 1.0, onToast)}
                  className="rounded-xl border border-slate-200 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  استمع طبيعي 1.0x
                </button>
              </div>
            </div>
          )}

          {(phase === 'playing_slow' || phase === 'playing_normal') && (
            <div className="rounded-2xl border border-indigo-200 bg-indigo-50/70 p-4 text-center dark:border-indigo-500/30 dark:bg-indigo-500/10">
              <div className="inline-flex items-center gap-2 text-sm font-extrabold text-indigo-700 dark:text-indigo-300">
                <Volume2 className="h-5 w-5" />
                <span>
                  {phase === 'playing_slow'
                    ? 'الخطوة 1: استمع للنطق البطيء (0.75x)...'
                    : 'الخطوة 1: الآن بالسرعة الطبيعية (1.0x)...'}
                </span>
              </div>
            </div>
          )}

          {phase === 'countdown' && (
            <div className="rounded-2xl border border-amber-200 bg-amber-50/80 py-6 text-center dark:border-amber-500/30 dark:bg-amber-500/10">
              <div className="text-xs font-bold text-amber-800 dark:text-amber-200">
                استعد للتسجيل والنطق...
              </div>
              <div className="mt-2 font-code text-4xl font-extrabold text-amber-600 tabular-nums dark:text-amber-300">
                {countdown}
              </div>
            </div>
          )}

          {phase === 'recording' && (
            <div className="rounded-2xl border border-rose-200 bg-rose-50/80 p-4 text-center dark:border-rose-500/30 dark:bg-rose-500/10">
              <div className="flex items-center justify-center gap-2 text-sm font-extrabold text-rose-700 dark:text-rose-300">
                <Mic className="h-4.5 w-4.5" />
                <span>تحدّث الآن وكرّر الجملة بوضوح</span>
              </div>
              {liveTranscript && (
                <p
                  dir="ltr"
                  className="mt-2 font-en text-sm font-semibold text-slate-700 dark:text-slate-200"
                >
                  {liveTranscript}
                </p>
              )}
              <button
                type="button"
                onClick={stopRecording}
                className="mt-4 inline-flex h-10 items-center gap-2 rounded-xl bg-rose-600 px-5 text-xs font-bold text-white hover:bg-rose-700"
              >
                <Square className="h-3.5 w-3.5 fill-current" />
                <span>إيقاف ومقارنة النطق</span>
              </button>
            </div>
          )}

          {phase === 'review' && (
            <div className="space-y-3 rounded-2xl border border-emerald-200/80 bg-emerald-50/60 p-4 dark:border-emerald-500/25 dark:bg-emerald-500/[0.08]">
              <div className="flex items-center justify-between">
                <div className="inline-flex items-center gap-2 text-sm font-extrabold text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="h-4.5 w-4.5" />
                  <span>نتيجة تدريب الظل</span>
                </div>
                {evalResult && (
                  <span className="font-code text-sm font-extrabold text-emerald-700 tabular-nums dark:text-emerald-300">
                    {evalResult.score}%
                  </span>
                )}
              </div>

              {evalResult?.feedbackAr && (
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                  {evalResult.feedbackAr}
                </p>
              )}

              {/* Side-by-side comparison buttons */}
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => speakEn(cleanEnglish, 1.0, onToast)}
                  className="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                >
                  <Volume2 className="h-4 w-4 text-indigo-500" />
                  <span>النطق الأصلي</span>
                </button>
                <button
                  type="button"
                  disabled={!recordingUrl}
                  onClick={() => {
                    if (!recordingUrl) return;
                    const audio = new Audio(recordingUrl);
                    void audio.play().catch(() => onToast('تعذر تشغيل تسجيلك.'));
                  }}
                  className="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-emerald-300 bg-white text-xs font-bold text-emerald-700 hover:bg-emerald-50 disabled:opacity-40 dark:border-emerald-700/60 dark:bg-slate-900 dark:text-emerald-300"
                >
                  <Play className="h-4 w-4 fill-current" />
                  <span>تشغيل تسجيلك</span>
                </button>
              </div>
            </div>
          )}

          {micError && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs font-semibold text-amber-800 dark:border-amber-700/60 dark:bg-amber-950/40 dark:text-amber-200">
              {micError}
            </div>
          )}
        </div>

        {/* Footer Controls */}
        <div className="flex items-center justify-between gap-2 border-t border-slate-200/80 px-5 py-3.5 dark:border-slate-800 sm:px-6">
          <button
            type="button"
            onClick={() => void runGuidedLoop()}
            className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>كرّر الجملة</span>
          </button>

          <button
            type="button"
            data-testid="shadowing-next-sentence-btn"
            onClick={handleNextSentence}
            className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white hover:bg-indigo-700"
          >
            <span>الجملة التالية</span>
            <ChevronLeft className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
