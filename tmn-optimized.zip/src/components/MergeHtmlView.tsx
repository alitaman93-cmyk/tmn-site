import { useRef, useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileCode2,
  Play,
  RotateCcw,
  Upload,
} from 'lucide-react';
import { BANDS, BAND_META } from '../data/constants';
import type { VocabStore } from '../types';
import {
  buildStandaloneHtml,
  extractVocabFromInput,
  getBandCounts,
  type ExtractedVocabResult,
} from '../utils/vocabLogic';
import { PWAInstallButton } from './PWAInstallButton';

interface MergeHtmlViewProps {
  currentStore: VocabStore;
  usingCustom: boolean;
  customSourceName: string;
  unsplashKey: string;
  pixabayKey: string;
  onDownloadFullHtml: () => void;
  onApplyExtractedVocab: (rawTsv: string, sourceName: string) => Promise<void>;
  onRestoreStarter: () => Promise<void>;
  onToast: (msg: string) => void;
}

export function MergeHtmlView({
  currentStore,
  usingCustom,
  customSourceName,
  unsplashKey,
  pixabayKey,
  onDownloadFullHtml,
  onApplyExtractedVocab,
  onRestoreStarter,
  onToast,
}: MergeHtmlViewProps) {
  const [pastedText, setPastedText] = useState('');
  const [sourceName, setSourceName] = useState('');
  const [extracted, setExtracted] = useState<ExtractedVocabResult | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [isApplying, setIsApplying] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const processInput = (text: string, label: string) => {
    setErrorMsg('');
    const result = extractVocabFromInput(text);
    if (!result.found) {
      setExtracted(null);
      setErrorMsg(
        'لم يتم العثور على جدول كلمات صالح. تأكد من رفع ملفك الأصلي الذي يحتوي على <script type="text/plain" id="embedded-vocab"> أو ملف CSV/TSV بصيغة صحيحة.'
      );
      return;
    }
    setSourceName(label);
    setExtracted(result);
    onToast(`تم استخراج ${result.store.words.length.toLocaleString('en-US')} كلمة بدون أي فقدان`);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const content = typeof reader.result === 'string' ? reader.result : '';
      processInput(content, file.name);
    };
    reader.onerror = () => {
      setErrorMsg('تعذر قراءة الملف المختار. حاول مرة أخرى.');
    };
    reader.readAsText(file, 'utf-8');
    e.target.value = '';
  };

  const handleParsePasted = () => {
    if (!pastedText.trim()) {
      setErrorMsg('الصق محتوى ملف HTML الأصلي أو سطور الكلمات أولاً.');
      return;
    }
    processInput(pastedText, 'نص مُلصق');
  };

  const triggerDownloadHtml = (rawVocabBlock: string, filename = 'index.html') => {
    try {
      const finalHtml = buildStandaloneHtml(rawVocabBlock, { unsplashKey, pixabayKey });
      const blob = new Blob([finalHtml], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      onToast(`تم تجهيز وتنزيل ملف ${filename} بنجاح`);
    } catch {
      onToast('تعذر إنشاء ملف التنزيل.');
    }
  };

  const handleApplyLive = async () => {
    if (!extracted || !extracted.found) return;
    setIsApplying(true);
    try {
      await onApplyExtractedVocab(extracted.rawVocabBlock, sourceName || 'ملف مخصص');
    } finally {
      setIsApplying(false);
    }
  };

  const bandCounts = extracted ? getBandCounts(extracted.store) : null;

  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 sm:text-2xl">
          دمج ملف الكلمات وتصدير{' '}
          <span className="font-code text-indigo-600 dark:text-indigo-400" dir="ltr">
            index.html
          </span>
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300">
          ارفع ملفك الأصلي الذي يحتوي على الـ 18 ألف كلمة داخل{' '}
          <span className="font-code text-xs" dir="ltr">
            &lt;script id=&quot;embedded-vocab&quot;&gt;
          </span>{' '}
          أو ملف CSV/TSV — سنحافظ على كل كلمة كما هي بدون أي حذف أو تعديل ونجهّز لك ملف{' '}
          <span className="font-code text-xs font-bold" dir="ltr">
            index.html
          </span>{' '}
          واحداً نهائياً قابلاً للتنزيل والتشغيل المباشر.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
        {/* Step 1: Upload or Paste Original File */}
        <section className="space-y-4 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-[#131c2e] lg:col-span-7">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              1. اختر ملفك الأصلي أو الصق الكلمات
            </h2>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              HTML · CSV · TSV
            </span>
          </div>

          <div className="rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 p-6 text-center dark:border-slate-700 dark:bg-slate-800/40">
            <FileCode2
              className="mx-auto h-9 w-9 text-indigo-500"
              aria-hidden="true"
            />
            <p className="mt-2 text-sm font-bold text-slate-900 dark:text-slate-100">
              ارفع ملف التطبيق الأصلي (.html) أو ملف الكلمات (.csv / .txt)
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              تتم المعالجة بالكامل محلياً داخل متصفحك بسرعة فائقة وخصوصية تامة.
            </p>
            <input
              ref={fileInputRef}
              type="file"
              accept=".html,.htm,.csv,.tsv,.txt"
              onChange={handleFileChange}
              aria-label="رفع ملف الكلمات الأصلي"
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="mt-4 inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white transition-colors hover:bg-indigo-700"
            >
              <Upload className="h-4 w-4" aria-hidden="true" />
              <span>اختيار الملف من الجهاز</span>
            </button>
          </div>

          <div className="space-y-2 pt-2">
            <label
              htmlFor="pasteVocabArea"
              className="block text-xs font-bold text-slate-700 dark:text-slate-300"
            >
              أو الصق كود ملفك الأصلي / سطور الكلمات مباشرة:
            </label>
            <textarea
              id="pasteVocabArea"
              rows={5}
              value={pastedText}
              onChange={(e) => setPastedText(e.target.value)}
              dir="ltr"
              placeholder={'<script type="text/plain" id="embedded-vocab">\nA0\tapple\tتفاحة\nA1\tbridge\tجسر\n</script>'}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 p-3 font-code text-xs text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900/70 dark:text-slate-100"
            />
            <div className="flex flex-wrap items-center justify-between gap-2">
              <button
                type="button"
                onClick={handleParsePasted}
                className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 text-xs font-bold text-slate-800 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
              >
                <span>تحليل واستخراج الكلمات</span>
              </button>
              {pastedText && (
                <button
                  type="button"
                  onClick={() => {
                    setPastedText('');
                    setErrorMsg('');
                  }}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:text-slate-400"
                >
                  مسح النص
                </button>
              )}
            </div>
          </div>

          {errorMsg && (
            <div
              role="alert"
              className="rounded-xl border border-rose-500/40 bg-rose-50 p-3.5 text-xs font-bold text-rose-700 dark:bg-rose-500/15 dark:text-rose-300"
            >
              {errorMsg}
            </div>
          )}
        </section>

        {/* Step 2: Verification & Export Panel */}
        <section className="flex flex-col justify-between space-y-5 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-[#131c2e] lg:col-span-5">
          {extracted && extracted.found && bandCounts ? (
            <>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2
                    className="mt-0.5 h-6 w-6 shrink-0 text-emerald-500"
                    aria-hidden="true"
                  />
                  <div>
                    <h2 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                      تم الاستخراج بنجاح ({sourceName})
                    </h2>
                    <p className="mt-0.5 text-sm text-slate-600 dark:text-slate-300">
                      إجمالي الكلمات الجاهزة للدمج:{' '}
                      <strong className="font-code text-emerald-600 dark:text-emerald-400 tabular-nums">
                        {extracted.store.words.length.toLocaleString('en-US')}
                      </strong>{' '}
                      كلمة
                    </p>
                  </div>
                </div>

                {/* CEFR Band Counts */}
                <div className="grid grid-cols-4 gap-2 sm:grid-cols-7 lg:grid-cols-4">
                  {BANDS.map((b) => (
                    <div
                      key={b}
                      className="rounded-xl border border-slate-200 bg-slate-50 p-2 text-center dark:border-slate-700/80 dark:bg-slate-800/60"
                    >
                      <div className={`font-en text-xs font-extrabold ${BAND_META[b].textClass}`}>
                        {b}
                      </div>
                      <div className="mt-0.5 font-code text-xs font-bold tabular-nums text-slate-800 dark:text-slate-200">
                        {bandCounts[b].toLocaleString('en-US')}
                      </div>
                    </div>
                  ))}
                </div>

                {/* First & Last Word Preview */}
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 text-xs dark:border-slate-700/80 dark:bg-slate-800/50">
                  <div className="mb-1.5 font-bold text-slate-700 dark:text-slate-200">
                    معاينة أول وآخر كلمة في الملف المدمج:
                  </div>
                  <div className="space-y-1 font-code text-slate-600 dark:text-slate-300">
                    <div className="flex items-center justify-between gap-2">
                      <bdi dir="ltr">
                        #1 · {extracted.store.words[0].band} · {extracted.store.words[0].en}
                      </bdi>
                      <span>{extracted.store.words[0].ar}</span>
                    </div>
                    {extracted.store.words.length > 1 && (
                      <div className="flex items-center justify-between gap-2 border-t border-slate-200 pt-1 dark:border-slate-700">
                        <bdi dir="ltr">
                          #{extracted.store.words.length} ·{' '}
                          {extracted.store.words[extracted.store.words.length - 1].band} ·{' '}
                          {extracted.store.words[extracted.store.words.length - 1].en}
                        </bdi>
                        <span>
                          {extracted.store.words[extracted.store.words.length - 1].ar}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => triggerDownloadHtml(extracted.rawVocabBlock, 'index.html')}
                  className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 px-5 text-sm font-bold text-white transition-colors hover:bg-emerald-700"
                >
                  <Download className="h-4 w-4" aria-hidden="true" />
                  <span>تنزيل index.html النهائي المدمج</span>
                </button>

                <button
                  type="button"
                  disabled={isApplying}
                  onClick={() => void handleApplyLive()}
                  className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white transition-colors hover:bg-indigo-700 disabled:opacity-50"
                >
                  <Play className="h-4 w-4 fill-current" aria-hidden="true" />
                  <span>
                    {isApplying ? 'جاري التفعيل...' : 'تشغيل هذه الكلمات داخل التطبيق الآن'}
                  </span>
                </button>
              </div>
            </>
          ) : (
            <div className="flex h-full flex-col justify-between space-y-5">
              <div className="space-y-3">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2
                    className="mt-0.5 h-5 w-5 shrink-0 text-emerald-500"
                    aria-hidden="true"
                  />
                  <div>
                    <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                      التطبيق الكامل جاهز للتنزيل والتثبيت
                    </h2>
                    <p className="mt-0.5 text-sm text-slate-500 dark:text-slate-400">
                      مُدمج حالياً{' '}
                      <strong className="font-code tabular-nums text-emerald-600 dark:text-emerald-400">
                        {currentStore.words.length.toLocaleString('en-US')}
                      </strong>{' '}
                      كلمة ({usingCustom ? customSourceName || 'ملف مخصص' : 'القاموس الكامل A0–C2'})
                      {unsplashKey ? ' · مفتاح Unsplash مُفعّل' : ''}.
                    </p>
                  </div>
                </div>

                {/* Live CEFR Band Breakdown */}
                <div className="grid grid-cols-4 gap-2 sm:grid-cols-7 lg:grid-cols-4">
                  {BANDS.map((b) => (
                    <div
                      key={b}
                      className="rounded-xl border border-slate-200 bg-slate-50 p-2 text-center dark:border-slate-700/80 dark:bg-slate-800/60"
                    >
                      <div className={`font-en text-xs font-extrabold ${BAND_META[b].textClass}`}>
                        {b}
                      </div>
                      <div className="mt-0.5 font-code text-xs font-bold tabular-nums text-slate-800 dark:text-slate-200">
                        {(currentStore.byBand[b] || []).length.toLocaleString('en-US')}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={onDownloadFullHtml}
                  className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 text-sm font-bold text-white transition-colors hover:bg-emerald-700"
                >
                  <Download className="h-4 w-4" aria-hidden="true" />
                  <span>
                    تنزيل index.html الكامل ({currentStore.words.length.toLocaleString('en-US')} كلمة)
                  </span>
                </button>

                <div className="flex flex-col">
                  <PWAInstallButton />
                </div>

                {usingCustom && (
                  <button
                    type="button"
                    onClick={() => void onRestoreStarter()}
                    className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-xl border border-amber-300 bg-amber-50 px-4 text-xs font-bold text-amber-800 transition-colors hover:bg-amber-100 dark:border-amber-500/40 dark:bg-amber-500/15 dark:text-amber-300 dark:hover:bg-amber-500/25"
                  >
                    <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>استعادة القاموس المدمج (18,484 كلمة)</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
