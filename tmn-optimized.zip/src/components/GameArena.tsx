import { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Check,
  Delete,
  Eye,
  Headphones,
  Image as ImageIcon,
  Lightbulb,
  RotateCcw,
  SkipForward,
  Star,
  Trophy,
  Volume2,
  X,
} from 'lucide-react';
import type {
  BankTile,
  CefrBand,
  GameModeId,
  LetterSlot,
  McqOption,
  PersistedSettings,
  SourceType,
  VocabStore,
} from '../types';
import {
  buildMissingLettersData,
  buildScrambleData,
  checkArabicMatch,
  checkEnglishMatch,
  computeCharDiff,
  getBandSubCount,
  normalizeAr,
  pickDistractors,
  shuffleArr,
} from '../utils/vocabLogic';
import { prefetchWordsBatch } from '../utils/prefetchEngine';
import { WordRow } from './WordRow';

export interface GameSessionConfig {
  id: number;
  mode: Exclude<GameModeId, 'study'>;
  sourceType: SourceType;
  band: CefrBand | '';
  subIdx: number;
  pool: number[];
}

interface GameArenaProps {
  store: VocabStore;
  settings: PersistedSettings;
  session: GameSessionConfig;
  favoritesSet: Set<number>;
  mistakesSet: Set<number>;
  masteredSet: Set<number>;
  onSpeak: (text: string) => void;
  onSpeakSlow?: (text: string) => void;
  onSfx: (type: 'ok' | 'err' | 'tap' | 'win') => void;
  onRecordOutcome: (wordIdx: number, isCorrect: boolean, sourceType: SourceType) => void;
  onOverrideCorrect: (wordIdx: number) => void;
  onFinishLevel: (band: CefrBand, subIdx: number, pct: number) => void;
  onToggleFavorite: (wordIdx: number) => void;
  onOpenWordDetail: (wordIdx: number) => void;
  onRestart: (overridePool?: number[], overrideSubIdx?: number) => void;
  onExit: () => void;
  onHudChange: (hud: { current: number; total: number; correct: number; wrong: number }) => void;
  onRoundComplete?: () => void;
  onToast: (msg: string) => void;
}

type SubMode = 'mcq' | 'tf' | 'missing' | 'scramble' | 'type_en' | 'type_ar' | 'listen_type';

interface QuestionState {
  subMode: SubMode;
  idx: number;
  en: string;
  ar: string;
  // mcq
  en2ar?: boolean;
  opts?: McqOption[];
  pickedId?: number | null;
  // tf
  shownAr?: string;
  isTrue?: boolean;
  userPicked?: boolean | null;
  // slot puzzles
  slots?: LetterSlot[];
  bank?: BankTile[];
  // typing
  hintLevel?: number;
  overridden?: boolean;
}

interface MatchState {
  left: number[];
  right: number[];
  matched: Set<number>;
  selLeft: number | null;
  selRight: number | null;
  wrongFlash: { l: number; r: number } | null;
  roundMistakes: Set<number>;
}

function buildQuestionState(
  store: VocabStore,
  mode: Exclude<GameModeId, 'study'>,
  idx: number,
  qIndex: number,
  mcqDir: 'en2ar' | 'ar2en'
): QuestionState {
  const word = store.words[idx];
  const en = word?.en || '';
  const ar = word?.ar || '';
  const subMode: SubMode =
    mode === 'mixed'
      ? (['mcq', 'tf', 'missing', 'scramble', 'type_en', 'type_ar', 'listen_type'][
          qIndex % 7
        ] as SubMode)
      : (mode as SubMode);

  if (subMode === 'mcq') {
    const en2ar = mcqDir === 'en2ar';
    const dist = pickDistractors(store, idx, 3, en2ar);
    const opts: McqOption[] = shuffleArr([idx, ...dist]).map((id) => ({
      id,
      label: en2ar ? store.words[id]?.ar || '' : store.words[id]?.en || '',
      isCorrect: id === idx,
    }));
    return { subMode, idx, en, ar, en2ar, opts, pickedId: null };
  }

  if (subMode === 'tf') {
    const isTrue = Math.random() < 0.5;
    let shownAr = ar;
    if (!isTrue) {
      const dist = pickDistractors(store, idx, 1, true);
      if (dist.length && store.words[dist[0]]) shownAr = store.words[dist[0]].ar;
    }
    return { subMode, idx, en, ar, shownAr, isTrue, userPicked: null };
  }

  if (subMode === 'missing') {
    const { slots, bank } = buildMissingLettersData(en);
    return { subMode, idx, en, ar, slots, bank };
  }

  if (subMode === 'scramble') {
    const { slots, bank } = buildScrambleData(en);
    return { subMode, idx, en, ar, slots, bank };
  }

  if (subMode === 'type_en' || subMode === 'listen_type') {
    return { subMode, idx, en, ar, hintLevel: 0 };
  }

  return { subMode: 'type_ar', idx, en, ar, hintLevel: 0, overridden: false };
}

function buildMatchRounds(pool: number[]): number[][] {
  const rounds: number[][] = [];
  for (let i = 0; i < pool.length; i += 5) {
    rounds.push(pool.slice(i, i + 5));
  }
  return rounds.length ? rounds : [[]];
}

function initMatchState(ids: number[]): MatchState {
  return {
    left: shuffleArr(ids),
    right: shuffleArr(ids),
    matched: new Set(),
    selLeft: null,
    selRight: null,
    wrongFlash: null,
    roundMistakes: new Set(),
  };
}

export function GameArena({
  store,
  settings,
  session,
  favoritesSet,
  mistakesSet,
  masteredSet,
  onSpeak,
  onSpeakSlow,
  onSfx,
  onRecordOutcome,
  onOverrideCorrect,
  onFinishLevel,
  onToggleFavorite,
  onOpenWordDetail,
  onRestart,
  onExit,
  onHudChange,
  onRoundComplete,
  onToast,
}: GameArenaProps) {
  const isMatch = session.mode === 'match';
  const [matchRounds] = useState<number[][]>(() => (isMatch ? buildMatchRounds(session.pool) : []));
  const [matchRoundIdx, setMatchRoundIdx] = useState(0);
  const [matchState, setMatchState] = useState<MatchState>(() =>
    isMatch ? initMatchState(buildMatchRounds(session.pool)[0] || []) : initMatchState([])
  );
  const [matchRoundDone, setMatchRoundDone] = useState(false);

  const [qIndex, setQIndex] = useState(0);
  const [qState, setQState] = useState<QuestionState | null>(() =>
    !isMatch && session.pool.length > 0
      ? buildQuestionState(store, session.mode, session.pool[0], 0, settings.mcqDir)
      : null
  );
  const [typingValue, setTypingValue] = useState('');
  const [showListenArHint, setShowListenArHint] = useState(false);
  const [answered, setAnswered] = useState(false);
  const [lastCorrect, setLastCorrect] = useState(false);
  const [lastUserAnswer, setLastUserAnswer] = useState('');
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [sessionWrong, setSessionWrong] = useState<number[]>([]);
  const [finished, setFinished] = useState(false);

  const inputRef = useRef<HTMLInputElement | null>(null);
  const flashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const total = isMatch ? matchRounds.length : session.pool.length;
    const current = finished ? total : isMatch ? matchRoundIdx + 1 : qIndex + 1;
    onHudChange({ current, total, correct: correctCount, wrong: wrongCount });
  }, [isMatch, matchRounds.length, session.pool.length, finished, matchRoundIdx, qIndex, correctCount, wrongCount, onHudChange]);

  useEffect(() => {
    return () => {
      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (!qState || isMatch || finished) return;
    if (
      qState.subMode === 'listen_type' ||
      (settings.autoSpeak &&
        ((qState.subMode === 'mcq' && qState.en2ar) ||
          qState.subMode === 'tf' ||
          qState.subMode === 'type_ar'))
    ) {
      const t = setTimeout(() => onSpeak(qState.en), 150);
      return () => clearTimeout(t);
    }
  }, [qIndex, qState?.idx, qState?.subMode, isMatch, finished]);

  useEffect(() => {
    if (finished) return;
    const upcomingIds = isMatch
      ? (matchRounds[matchRoundIdx + 1] || []).slice(0, 3)
      : session.pool.slice(qIndex + 1, qIndex + 4);
    const upcomingWords = upcomingIds
      .map((id) => store.words[id])
      .filter((w): w is NonNullable<typeof w> => Boolean(w));
    if (upcomingWords.length > 0) {
      prefetchWordsBatch(
        upcomingWords,
        {
          backendUrl: settings.backendUrl,
          pixabayKey: settings.pixabayKey,
          unsplashKey: settings.unsplashKey,
        },
        3,
        false
      );
    }
  }, [
    finished,
    isMatch,
    matchRounds,
    matchRoundIdx,
    session.pool,
    qIndex,
    store.words,
    settings.backendUrl,
    settings.pixabayKey,
    settings.unsplashKey,
  ]);

  useEffect(() => {
    if (
      !answered &&
      (qState?.subMode === 'type_en' ||
        qState?.subMode === 'type_ar' ||
        qState?.subMode === 'listen_type')
    ) {
      const t = setTimeout(() => inputRef.current?.focus(), 40);
      return () => clearTimeout(t);
    }
  }, [qIndex, answered, qState?.subMode]);

  const record = (wordIdx: number, isOk: boolean) => {
    onRecordOutcome(wordIdx, isOk, session.sourceType);
    if (isOk) {
      setCorrectCount((c) => c + 1);
      onSfx('ok');
    } else {
      setWrongCount((c) => c + 1);
      setSessionWrong((prev) => (prev.includes(wordIdx) ? prev : [...prev, wordIdx]));
      onSfx('err');
    }
  };

  const finishSession = (finalCorrect: number, finalWrong: number) => {
    setFinished(true);
    const total = Math.max(1, finalCorrect + finalWrong);
    const pct = Math.round((finalCorrect / total) * 100);
    if (session.sourceType === 'level' && session.band && session.subIdx >= 0) {
      onFinishLevel(session.band, session.subIdx, pct);
    }
    onSfx('win');
    onRoundComplete?.();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNextQuestion = () => {
    if (qIndex >= session.pool.length - 1) {
      finishSession(correctCount, wrongCount);
      return;
    }
    const nextIdx = qIndex + 1;
    setQIndex(nextIdx);
    setQState(
      buildQuestionState(store, session.mode, session.pool[nextIdx], nextIdx, settings.mcqDir)
    );
    setAnswered(false);
    setLastCorrect(false);
    setLastUserAnswer('');
    setTypingValue('');
    setShowListenArHint(false);
    window.scrollTo({ top: 0 });
  };

  const handleSkipQuestion = () => {
    onSfx('tap');
    handleNextQuestion();
  };

  // --- MCQ ---
  const handleAnswerMcq = (pickedId: number) => {
    if (!qState || answered) return;
    const ok = pickedId === qState.idx;
    setQState({ ...qState, pickedId });
    setAnswered(true);
    setLastCorrect(ok);
    record(qState.idx, ok);
    if (settings.autoSpeak && !qState.en2ar) onSpeak(qState.en);
  };

  // --- True / False ---
  const handleAnswerTf = (val: boolean) => {
    if (!qState || answered) return;
    const ok = val === qState.isTrue;
    setQState({ ...qState, userPicked: val });
    setAnswered(true);
    setLastCorrect(ok);
    record(qState.idx, ok);
  };

  // --- Slot Puzzles (Missing / Scramble) ---
  const submitSlots = (slots: LetterSlot[], idx: number, en: string) => {
    const built = slots.map((s) => s.value).join('');
    const ok = checkEnglishMatch(built, en);
    setLastUserAnswer(built);
    setAnswered(true);
    setLastCorrect(ok);
    record(idx, ok);
    if (settings.autoSpeak) onSpeak(en);
  };

  const handlePickBankTile = (tileId: number) => {
    if (!qState || answered || !qState.slots || !qState.bank) return;
    const bank = qState.bank.map((t) => ({ ...t }));
    const slots = qState.slots.map((s) => ({ ...s }));
    const tile = bank.find((t) => t.id === tileId);
    if (!tile || tile.used) return;
    const targetSlot = slots.find((s) => s.type === 'blank' && !s.value);
    if (!targetSlot) return;

    tile.used = true;
    targetSlot.value = tile.ch;
    targetSlot.tileId = tile.id;
    onSfx('tap');

    setQState({ ...qState, slots, bank });

    const allFilled = !slots.some((s) => s.type === 'blank' && !s.value);
    if (allFilled && checkEnglishMatch(slots.map((s) => s.value).join(''), qState.en)) {
      submitSlots(slots, qState.idx, qState.en);
    }
  };

  const handleRemoveSlotLetter = (slotIndex: number) => {
    if (!qState || answered || !qState.slots || !qState.bank) return;
    const slots = qState.slots.map((s) => ({ ...s }));
    const bank = qState.bank.map((t) => ({ ...t }));
    const slot = slots[slotIndex];
    if (!slot || slot.type !== 'blank' || !slot.value) return;
    if (slot.tileId !== null) {
      const tile = bank.find((t) => t.id === slot.tileId);
      if (tile) tile.used = false;
    }
    slot.value = '';
    slot.tileId = null;
    onSfx('tap');
    setQState({ ...qState, slots, bank });
  };

  const handleBackspaceSlots = () => {
    if (!qState || answered || !qState.slots) return;
    for (let i = qState.slots.length - 1; i >= 0; i--) {
      if (qState.slots[i].type === 'blank' && qState.slots[i].value) {
        handleRemoveSlotLetter(i);
        return;
      }
    }
  };

  const handleClearSlots = () => {
    if (!qState || answered || !qState.slots || !qState.bank) return;
    const slots = qState.slots.map((s) =>
      s.type === 'blank' ? { ...s, value: '', tileId: null } : { ...s }
    );
    const bank = qState.bank.map((t) => ({ ...t, used: false }));
    onSfx('tap');
    setQState({ ...qState, slots, bank });
  };

  const handleHintSlots = () => {
    if (!qState || answered || !qState.slots || !qState.bank) return;
    const slots = qState.slots.map((s) => ({ ...s }));
    const bank = qState.bank.map((t) => ({ ...t }));
    const blankIdx = slots.findIndex(
      (s) => s.type === 'blank' && s.value.toLowerCase() !== s.target.toLowerCase()
    );
    if (blankIdx === -1) return;

    const slot = slots[blankIdx];
    if (slot.tileId !== null) {
      const oldTile = bank.find((t) => t.id === slot.tileId);
      if (oldTile) oldTile.used = false;
      slot.value = '';
      slot.tileId = null;
    }

    let matchTile = bank.find(
      (t) => !t.used && t.ch.toLowerCase() === slot.target.toLowerCase()
    );
    if (!matchTile) {
      const donor = slots.find(
        (s, si) =>
          si > blankIdx && s.type === 'blank' && s.value.toLowerCase() === slot.target.toLowerCase()
      );
      if (donor && donor.tileId !== null) {
        matchTile = bank.find((t) => t.id === donor.tileId);
        donor.value = '';
        donor.tileId = null;
        if (matchTile) matchTile.used = false;
      }
    }

    if (matchTile) {
      matchTile.used = true;
      slot.value = matchTile.ch;
      slot.tileId = matchTile.id;
    } else {
      slot.value = slot.target;
      slot.tileId = null;
    }

    onSfx('tap');
    setQState({ ...qState, slots, bank });

    const allFilled = !slots.some((s) => s.type === 'blank' && !s.value);
    if (allFilled && checkEnglishMatch(slots.map((s) => s.value).join(''), qState.en)) {
      submitSlots(slots, qState.idx, qState.en);
    }
  };

  // --- Typing (type_en, type_ar, listen_type) ---
  const handleSubmitType = () => {
    if (!qState || answered) return;
    const val = typingValue.trim();
    const isEnglishInput = qState.subMode === 'type_en' || qState.subMode === 'listen_type';
    if (!val) {
      onToast(isEnglishInput ? 'اكتب الكلمة بالإنجليزية أولاً' : 'اكتب المعنى أولاً');
      return;
    }
    const ok = isEnglishInput
      ? checkEnglishMatch(val, qState.en)
      : checkArabicMatch(val, qState.ar);
    setLastUserAnswer(val);
    setAnswered(true);
    setLastCorrect(ok);
    record(qState.idx, ok);
    if (qState.subMode === 'type_en' && settings.autoSpeak) onSpeak(qState.en);
  };

  const handleRevealTypingHint = () => {
    if (!qState || answered) return;
    onSfx('tap');
    setQState({ ...qState, hintLevel: (qState.hintLevel || 0) + 1 });
  };

  const handleShowSolution = () => {
    if (!qState || answered) return;
    setLastUserAnswer('');
    setAnswered(true);
    setLastCorrect(false);
    record(qState.idx, false);
  };

  const handleOverrideArabic = () => {
    if (!qState || !answered || lastCorrect || qState.overridden) return;
    setQState({ ...qState, overridden: true });
    setLastCorrect(true);
    setWrongCount((c) => Math.max(0, c - 1));
    setCorrectCount((c) => c + 1);
    setSessionWrong((prev) => prev.filter((id) => id !== qState.idx));
    onOverrideCorrect(qState.idx);
    onSfx('ok');
    onToast('تم احتساب إجابتك صحيحة');
  };

  // --- Match Pairs ---
  const handlePickMatch = (side: 'left' | 'right', id: number) => {
    if (!isMatch || matchRoundDone || matchState.matched.has(id) || matchState.wrongFlash) return;
    onSfx('tap');

    const nextLeft = side === 'left' ? (matchState.selLeft === id ? null : id) : matchState.selLeft;
    const nextRight =
      side === 'right' ? (matchState.selRight === id ? null : id) : matchState.selRight;

    if (nextLeft !== null && nextRight !== null) {
      const lWord = store.words[nextLeft];
      const rWord = store.words[nextRight];
      const isPairOk =
        nextLeft === nextRight ||
        (lWord && rWord && normalizeAr(lWord.ar) === normalizeAr(rWord.ar));

      if (isPairOk) {
        const nextMatched = new Set(matchState.matched);
        nextMatched.add(nextLeft);
        if (nextLeft !== nextRight) nextMatched.add(nextRight);

        if (!matchState.roundMistakes.has(nextLeft)) {
          record(nextLeft, true);
        } else {
          onSfx('ok');
        }

        setMatchState({
          ...matchState,
          matched: nextMatched,
          selLeft: null,
          selRight: null,
        });
        if (nextMatched.size >= matchState.left.length) {
          setMatchRoundDone(true);
        }
      } else {
        const nextMistakes = new Set(matchState.roundMistakes);
        if (!nextMistakes.has(nextLeft)) {
          nextMistakes.add(nextLeft);
          record(nextLeft, false);
        } else {
          onSfx('err');
        }
        setMatchState({
          ...matchState,
          selLeft: nextLeft,
          selRight: nextRight,
          wrongFlash: { l: nextLeft, r: nextRight },
          roundMistakes: nextMistakes,
        });
        if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
        flashTimerRef.current = setTimeout(() => {
          setMatchState((cur) => ({
            ...cur,
            wrongFlash: null,
            selLeft: null,
            selRight: null,
          }));
        }, 380);
      }
      return;
    }

    setMatchState({
      ...matchState,
      selLeft: nextLeft,
      selRight: nextRight,
    });
  };

  const handleNextMatchRound = () => {
    const next = matchRoundIdx + 1;
    if (next >= matchRounds.length) {
      finishSession(correctCount, wrongCount);
      return;
    }
    setMatchRoundIdx(next);
    setMatchState(initMatchState(matchRounds[next]));
    setMatchRoundDone(false);
    window.scrollTo({ top: 0 });
  };

  // ===================== SUMMARY SCREEN =====================
  if (finished) {
    const total = Math.max(1, correctCount + wrongCount);
    const pct = Math.round((correctCount / total) * 100);
    const nextSub =
      session.sourceType === 'level' &&
      session.band &&
      session.subIdx + 1 < getBandSubCount(store, session.band, settings.levelSize)
        ? session.subIdx + 1
        : -1;

    return (
      <div className="mx-auto max-w-3xl space-y-6 pb-28">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-400">
            <Trophy className="h-7 w-7" aria-hidden="true" />
          </div>
          <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
            أنهيت الجولة بنجاح
          </h1>
          <div
            className={`mt-2 font-code text-5xl font-extrabold tabular-nums ${
              pct >= 80
                ? 'text-emerald-600 dark:text-emerald-400'
                : pct >= 50
                  ? 'text-amber-600 dark:text-amber-400'
                  : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {pct}%
          </div>
          <div className="mt-3 flex flex-wrap items-center justify-center gap-3 text-sm font-semibold text-slate-600 dark:text-slate-300">
            <span className="text-emerald-600 dark:text-emerald-400">صحيح: {correctCount}</span>
            <span aria-hidden="true">·</span>
            <span className="text-rose-600 dark:text-rose-400">خطأ: {wrongCount}</span>
            <span aria-hidden="true">·</span>
            <span className="font-code tabular-nums">إجمالي XP: {settings.xp}</span>
          </div>

          {sessionWrong.length > 0 && (
            <button
              type="button"
              onClick={() => onRestart(sessionWrong.slice())}
              className="mt-5 inline-flex h-11 items-center gap-2 rounded-xl bg-amber-500 px-5 text-sm font-bold text-slate-950 transition-colors hover:bg-amber-400"
            >
              <span>تدرّب على أخطاء الجولة ({sessionWrong.length})</span>
            </button>
          )}
        </div>

        {sessionWrong.length > 0 && (
          <section className="space-y-3">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              الكلمات التي أخطأت بها
            </h2>
            <div className="space-y-2">
              {sessionWrong.map((id) => {
                const w = store.words[id];
                if (!w) return null;
                return (
                  <WordRow
                    key={id}
                    word={w}
                    isFavorite={favoritesSet.has(id)}
                    isMistake={mistakesSet.has(id)}
                    isMastered={masteredSet.has(id)}
                    onOpenDetail={onOpenWordDetail}
                    onSpeak={onSpeak}
                    onToggleFavorite={onToggleFavorite}
                  />
                );
              })}
            </div>
          </section>
        )}

        <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-200 bg-white/95 p-3 backdrop-blur-md dark:border-slate-800 dark:bg-[#0f172a]/95">
          <div className="mx-auto flex max-w-3xl gap-2.5">
            <button
              type="button"
              onClick={() => onRestart()}
              className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 text-sm font-bold text-slate-800 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
            >
              <RotateCcw className="h-4 w-4" aria-hidden="true" />
              <span>إعادة</span>
            </button>
            {nextSub >= 0 ? (
              <button
                type="button"
                onClick={() => onRestart(undefined, nextSub)}
                className="inline-flex h-12 flex-[1.5] items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 text-sm font-bold text-white hover:bg-emerald-700"
              >
                <span>المستوى التالي ({nextSub + 1})</span>
                <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              </button>
            ) : (
              <button
                type="button"
                onClick={onExit}
                className="inline-flex h-12 flex-[1.5] items-center justify-center gap-2 rounded-xl bg-indigo-600 px-4 text-sm font-bold text-white hover:bg-indigo-700"
              >
                <span>العودة للألعاب</span>
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ===================== ACTIVE QUESTION =====================
  const totalSteps = isMatch ? matchRounds.length : session.pool.length;
  const curStep = isMatch ? matchRoundIdx : qIndex;
  const pct = Math.round(((curStep + (answered || matchRoundDone ? 1 : 0)) / Math.max(1, totalSteps)) * 100);
  const nextBlankIdx = qState?.slots?.findIndex((s) => s.type === 'blank' && !s.value) ?? -1;
  const allSlotsFilled = qState?.slots ? !qState.slots.some((s) => s.type === 'blank' && !s.value) : false;

  const typingHintText =
    qState && (qState.hintLevel || 0) > 0 && !answered
      ? qState.subMode === 'type_en' || qState.subMode === 'listen_type'
        ? Array.from(qState.en)
            .map((ch, i) => (i < (qState.hintLevel || 0) || !/[a-zA-Z]/.test(ch) ? ch : '_'))
            .join(' ')
        : Array.from(qState.ar)
            .map((ch, i) => (i < (qState.hintLevel || 0) || ch === ' ' ? ch : 'ـ'))
            .join('')
      : '';

  return (
    <div className="mx-auto max-w-3xl space-y-5 pb-44">
      {/* Progress Bar */}
      <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
        <div
          className="h-full rounded-full bg-indigo-600 transition-all duration-200 dark:bg-indigo-500"
          style={{ width: `${pct}%` }}
        />
      </div>

      {/* Main Question Card */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center dark:border-slate-800 dark:bg-[#131c2e] sm:p-8">
        {isMatch ? (
          <>
            <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
              وصّل كل كلمة إنجليزية بمعناها العربي
            </p>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="space-y-2.5">
                {matchState.left.map((id) => {
                  const isMatched = matchState.matched.has(id);
                  const isSelected = matchState.selLeft === id;
                  const isShake = matchState.wrongFlash?.l === id;
                  return (
                    <button
                      key={`l-${id}`}
                      type="button"
                      disabled={isMatched}
                      onClick={() => handlePickMatch('left', id)}
                      dir="ltr"
                      className={`flex min-h-[54px] w-full items-center justify-center rounded-xl border-2 px-3 py-2.5 font-en text-sm font-bold transition-colors sm:text-base ${
                        isMatched
                          ? 'border-emerald-500/40 bg-emerald-50 text-emerald-700 opacity-40 dark:bg-emerald-500/10 dark:text-emerald-400'
                          : isShake
                            ? 'animate-match-shake border-rose-500 bg-rose-50 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300'
                            : isSelected
                              ? 'border-indigo-600 bg-indigo-50 text-indigo-700 dark:border-indigo-400 dark:bg-indigo-500/20 dark:text-indigo-200'
                              : 'border-slate-200 bg-slate-50 text-slate-900 hover:border-slate-300 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-100'
                      }`}
                    >
                      {store.words[id]?.en}
                    </button>
                  );
                })}
              </div>
              <div className="space-y-2.5">
                {matchState.right.map((id) => {
                  const isMatched = matchState.matched.has(id);
                  const isSelected = matchState.selRight === id;
                  const isShake = matchState.wrongFlash?.r === id;
                  return (
                    <button
                      key={`r-${id}`}
                      type="button"
                      disabled={isMatched}
                      onClick={() => handlePickMatch('right', id)}
                      className={`flex min-h-[54px] w-full items-center justify-center rounded-xl border-2 px-3 py-2.5 text-sm font-bold transition-colors sm:text-base ${
                        isMatched
                          ? 'border-emerald-500/40 bg-emerald-50 text-emerald-700 opacity-40 dark:bg-emerald-500/10 dark:text-emerald-400'
                          : isShake
                            ? 'animate-match-shake border-rose-500 bg-rose-50 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300'
                            : isSelected
                              ? 'border-indigo-600 bg-indigo-50 text-indigo-700 dark:border-indigo-400 dark:bg-indigo-500/20 dark:text-indigo-200'
                              : 'border-slate-200 bg-slate-50 text-slate-900 hover:border-slate-300 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-100'
                      }`}
                    >
                      {store.words[id]?.ar}
                    </button>
                  );
                })}
              </div>
            </div>
          </>
        ) : qState ? (
          <>
            {/* MCQ */}
            {qState.subMode === 'mcq' && (
              <>
                <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                  {qState.en2ar ? 'اختر الترجمة العربية الصحيحة' : 'اختر الكلمة الإنجليزية الصحيحة'}
                </p>
                <div
                  className={`mt-3 text-3xl font-extrabold text-slate-900 dark:text-slate-100 sm:text-4xl ${
                    qState.en2ar ? 'font-en' : ''
                  }`}
                  dir={qState.en2ar ? 'ltr' : 'rtl'}
                >
                  {qState.en2ar ? qState.en : qState.ar}
                </div>
                <div className="mt-4 flex items-center justify-center gap-2">
                  {qState.en2ar && (
                    <button
                      type="button"
                      onClick={() => onSpeak(qState.en)}
                      className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                    >
                      <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>نطق</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => onToggleFavorite(qState.idx)}
                    aria-label={favoritesSet.has(qState.idx) ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
                    className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                  >
                    <Star
                      className={`h-3.5 w-3.5 ${
                        favoritesSet.has(qState.idx) ? 'fill-amber-400 text-amber-500' : ''
                      }`}
                      aria-hidden="true"
                    />
                    <span>{favoritesSet.has(qState.idx) ? 'في المفضلة' : 'مفضلة'}</span>
                  </button>
                </div>

                <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {(qState.opts || []).map((opt) => {
                    let cls =
                      'border-slate-200 bg-slate-50 text-slate-900 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-100';
                    if (answered) {
                      if (opt.isCorrect) {
                        cls =
                          'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300';
                      } else if (opt.id === qState.pickedId) {
                        cls =
                          'border-rose-500 bg-rose-50 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300';
                      }
                    }
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        disabled={answered}
                        onClick={() => handleAnswerMcq(opt.id)}
                        dir={!qState.en2ar ? 'ltr' : 'rtl'}
                        className={`flex min-h-[56px] items-center justify-center rounded-xl border-2 px-4 py-3 text-base font-bold transition-colors ${
                          !qState.en2ar ? 'font-en' : ''
                        } ${cls}`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
              </>
            )}

            {/* True / False */}
            {qState.subMode === 'tf' && (
              <>
                <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                  هل الترجمة المعروضة صحيحة أم خاطئة؟
                </p>
                <div className="mx-auto mt-4 max-w-md rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-5 dark:border-slate-700 dark:bg-slate-800/50">
                  <div className="font-en text-3xl font-extrabold text-slate-900 dark:text-slate-100" dir="ltr">
                    {qState.en}
                  </div>
                  <p className="my-2 text-xs text-slate-500 dark:text-slate-400">معناها بالعربية:</p>
                  <div className="text-2xl font-extrabold text-cyan-600 dark:text-cyan-400">
                    {qState.shownAr}
                  </div>
                </div>

                <div className="mt-4 flex justify-center">
                  <button
                    type="button"
                    onClick={() => onSpeak(qState.en)}
                    className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                  >
                    <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>اسمع النطق</span>
                  </button>
                </div>

                <div className="mx-auto mt-5 grid max-w-md grid-cols-2 gap-3">
                  <button
                    type="button"
                    disabled={answered}
                    onClick={() => handleAnswerTf(true)}
                    className={`flex min-h-[58px] items-center justify-center gap-2 rounded-xl border-2 text-lg font-extrabold transition-colors ${
                      answered
                        ? qState.isTrue
                          ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300'
                          : qState.userPicked === true
                            ? 'border-rose-500 bg-rose-50 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300'
                            : 'border-slate-200 bg-slate-50 text-slate-500 dark:border-slate-700 dark:bg-slate-800/40'
                        : 'border-slate-200 bg-slate-50 text-slate-900 hover:border-emerald-500 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-100'
                    }`}
                  >
                    <Check className="h-5 w-5" aria-hidden="true" />
                    <span>صح</span>
                  </button>
                  <button
                    type="button"
                    disabled={answered}
                    onClick={() => handleAnswerTf(false)}
                    className={`flex min-h-[58px] items-center justify-center gap-2 rounded-xl border-2 text-lg font-extrabold transition-colors ${
                      answered
                        ? !qState.isTrue
                          ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300'
                          : qState.userPicked === false
                            ? 'border-rose-500 bg-rose-50 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300'
                            : 'border-slate-200 bg-slate-50 text-slate-500 dark:border-slate-700 dark:bg-slate-800/40'
                        : 'border-slate-200 bg-slate-50 text-slate-900 hover:border-rose-500 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-100'
                    }`}
                  >
                    <X className="h-5 w-5" aria-hidden="true" />
                    <span>خطأ</span>
                  </button>
                </div>
              </>
            )}

            {/* Missing Letters & Scramble */}
            {(qState.subMode === 'missing' || qState.subMode === 'scramble') && (
              <>
                <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                  {qState.subMode === 'missing'
                    ? 'أكمل الأحرف الناقصة في الكلمة'
                    : 'رتّب الأحرف المبعثرة لتكوين الكلمة'}
                </p>
                <div className="mt-3 text-3xl font-extrabold text-slate-900 dark:text-slate-100">
                  {qState.ar}
                </div>
                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => onSpeak(qState.en)}
                    className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                  >
                    <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>اسمع النطق</span>
                  </button>
                  {!answered && (
                    <button
                      type="button"
                      onClick={handleClearSlots}
                      className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                    >
                      <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>مسح الكل</span>
                    </button>
                  )}
                </div>

                {/* Letter Slots */}
                <div className="my-6 flex flex-wrap justify-center gap-1.5" dir="ltr">
                  {(qState.slots || []).map((slot, i) => {
                    if (slot.type === 'punct') {
                      return (
                        <span
                          key={i}
                          className="inline-flex h-11 min-w-[18px] items-center justify-center font-en text-xl font-bold text-slate-400"
                        >
                          {slot.value}
                        </span>
                      );
                    }
                    let cls =
                      'border-slate-300 bg-slate-100 text-slate-800 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100';
                    if (slot.type === 'fixed') {
                      cls =
                        'border-indigo-300 bg-indigo-50 text-indigo-700 dark:border-indigo-500/40 dark:bg-indigo-500/15 dark:text-indigo-200';
                    } else if (answered) {
                      cls =
                        slot.value.toLowerCase() === slot.target.toLowerCase()
                          ? 'border-emerald-600 bg-emerald-600 text-white'
                          : 'border-rose-600 bg-rose-600 text-white';
                    } else if (slot.value) {
                      cls = 'border-indigo-600 bg-indigo-600 text-white';
                    } else if (i === nextBlankIdx) {
                      cls =
                        'border-indigo-500 bg-slate-50 ring-2 ring-indigo-500/30 dark:bg-slate-800/80';
                    } else {
                      cls =
                        'border-dashed border-indigo-400/70 bg-slate-50 dark:border-indigo-500/50 dark:bg-slate-800/50';
                    }

                    const removable = !answered && slot.type === 'blank' && Boolean(slot.value);
                    return removable ? (
                      <button
                        key={i}
                        type="button"
                        onClick={() => handleRemoveSlotLetter(i)}
                        aria-label={`إزالة الحرف ${slot.value}`}
                        className={`inline-flex h-11 min-w-[38px] items-center justify-center rounded-xl border-2 px-1.5 font-en text-xl font-extrabold transition-colors ${cls}`}
                      >
                        {slot.value}
                      </button>
                    ) : (
                      <span
                        key={i}
                        className={`inline-flex h-11 min-w-[38px] items-center justify-center rounded-xl border-2 px-1.5 font-en text-xl font-extrabold ${cls}`}
                      >
                        {slot.value || ''}
                      </span>
                    );
                  })}
                </div>

                {/* Letter Bank */}
                {!answered && (
                  <div className="flex flex-wrap justify-center gap-2" dir="ltr">
                    {(qState.bank || []).map((tile) => (
                      <button
                        key={tile.id}
                        type="button"
                        disabled={tile.used}
                        onClick={() => handlePickBankTile(tile.id)}
                        className={`inline-flex h-11 min-w-[44px] items-center justify-center rounded-xl border-2 border-slate-300 bg-white px-3 font-en text-lg font-extrabold text-slate-900 shadow-xs transition-all hover:border-indigo-500 active:scale-95 disabled:opacity-20 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100`}
                      >
                        {tile.ch}
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}

            {/* Typing EN / AR / Listen & Type Dictation */}
            {(qState.subMode === 'type_en' ||
              qState.subMode === 'type_ar' ||
              qState.subMode === 'listen_type') && (
              <>
                <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                  {qState.subMode === 'listen_type'
                    ? 'استمع لنطق الكلمة ثم اكتبها باللغة الإنجليزية'
                    : qState.subMode === 'type_en'
                      ? 'اكتب الكلمة باللغة الإنجليزية'
                      : 'اكتب المعنى باللغة العربية'}
                </p>

                {qState.subMode === 'listen_type' ? (
                  <div className="mt-4 flex flex-col items-center gap-3">
                    <button
                      type="button"
                      onClick={() => onSpeak(qState.en)}
                      aria-label="استمع لنطق الكلمة"
                      className="flex h-20 w-20 items-center justify-center rounded-full bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 transition-transform hover:scale-105 hover:bg-indigo-700 active:scale-95"
                    >
                      <Headphones className="h-9 w-9" aria-hidden="true" />
                    </button>
                    <div className="flex flex-wrap items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={() => onSpeak(qState.en)}
                        className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-indigo-200 bg-indigo-50 px-3.5 text-xs font-bold text-indigo-700 hover:bg-indigo-100 dark:border-indigo-700/60 dark:bg-indigo-950/50 dark:text-indigo-300"
                      >
                        <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>إعادة الاستماع</span>
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onSpeakSlow ? onSpeakSlow(qState.en) : onSpeak(qState.en)
                        }
                        className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3.5 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                      >
                        <span>نطق بطيء</span>
                      </button>
                      {!answered && (
                        <button
                          type="button"
                          onClick={() => setShowListenArHint((v) => !v)}
                          className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                        >
                          <Eye className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>{showListenArHint ? 'إخفاء المعنى' : 'إظهار المعنى'}</span>
                        </button>
                      )}
                    </div>
                    {(showListenArHint || answered) && (
                      <div className="text-lg font-extrabold text-cyan-600 dark:text-cyan-400">
                        {qState.ar}
                      </div>
                    )}
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      عدد الأحرف:{' '}
                      <span className="font-code tabular-nums">{qState.en.length}</span>
                    </p>
                  </div>
                ) : (
                  <>
                    <div
                      className={`mt-3 text-3xl font-extrabold text-slate-900 dark:text-slate-100 sm:text-4xl ${
                        qState.subMode === 'type_ar' ? 'font-en' : ''
                      }`}
                      dir={qState.subMode === 'type_ar' ? 'ltr' : 'rtl'}
                    >
                      {qState.subMode === 'type_en' ? qState.ar : qState.en}
                    </div>

                    {qState.subMode === 'type_en' && (
                      <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                        عدد الأحرف:{' '}
                        <span className="font-code tabular-nums">{qState.en.length}</span>
                      </p>
                    )}

                    <div className="mt-4 flex justify-center">
                      <button
                        type="button"
                        onClick={() => onSpeak(qState.en)}
                        className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                      >
                        <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>{qState.subMode === 'type_en' ? 'تلميح صوتي' : 'اسمع النطق'}</span>
                      </button>
                    </div>
                  </>
                )}

                {typingHintText && (
                  <div
                    className="mt-3 font-code text-lg font-bold tracking-widest text-amber-600 dark:text-amber-400"
                    dir={qState.subMode === 'type_ar' ? 'rtl' : 'ltr'}
                  >
                    {typingHintText}
                  </div>
                )}

                <input
                  ref={inputRef}
                  type="text"
                  value={typingValue}
                  disabled={answered}
                  onChange={(e) => setTypingValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      if (answered) handleNextQuestion();
                      else handleSubmitType();
                    }
                  }}
                  dir={qState.subMode === 'type_ar' ? 'rtl' : 'ltr'}
                  autoComplete="off"
                  autoCapitalize="off"
                  spellCheck={false}
                  aria-label={
                    qState.subMode === 'type_ar'
                      ? 'اكتب المعنى بالعربية'
                      : 'اكتب الكلمة بالإنجليزية'
                  }
                  placeholder={
                    qState.subMode === 'type_ar'
                      ? 'اكتب المعنى بالعربية...'
                      : 'Type the English word you heard...'
                  }
                  className="mx-auto mt-4 block w-full max-w-md rounded-xl border-2 border-slate-200 bg-slate-50 px-4 py-3.5 text-center text-lg font-bold text-slate-900 focus:border-indigo-500 focus:outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                />

                {answered &&
                  !lastCorrect &&
                  lastUserAnswer &&
                  (qState.subMode === 'type_en' || qState.subMode === 'listen_type') && (
                    <div
                      className="mt-3 inline-block rounded-lg bg-slate-900/90 px-3 py-1.5 font-code text-base"
                      dir="ltr"
                    >
                      {computeCharDiff(lastUserAnswer, qState.en).map((part, i) => (
                        <span
                          key={i}
                          className={
                            part.kind === 'ok'
                              ? 'font-bold text-emerald-400'
                              : part.kind === 'bad'
                                ? 'text-rose-400 line-through'
                                : 'font-bold text-amber-400'
                          }
                        >
                          {part.text}
                        </span>
                      ))}
                    </div>
                  )}
              </>
            )}
          </>
        ) : null}
      </div>

      {/* Bottom Action & Feedback Dock */}
      <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-200 bg-white/95 p-3 shadow-lg backdrop-blur-md dark:border-slate-800 dark:bg-[#0f172a]/95">
        <div className="mx-auto max-w-3xl space-y-2.5">
          {isMatch ? (
            matchRoundDone ? (
              <>
                <div className="rounded-xl border border-emerald-500/40 bg-emerald-50 px-4 py-2.5 text-sm font-bold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                  أحسنت! أنهيت توصيل كل الكلمات في هذه المجموعة.
                </div>
                <button
                  type="button"
                  onClick={handleNextMatchRound}
                  className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 px-6 text-base font-bold text-white hover:bg-emerald-700"
                >
                  <span>
                    {matchRoundIdx >= matchRounds.length - 1 ? 'عرض النتيجة' : 'المجموعة التالية'}
                  </span>
                  <ArrowLeft className="h-4 w-4" aria-hidden="true" />
                </button>
              </>
            ) : (
              <div className="flex items-center justify-between gap-3">
                <span className="text-sm font-bold text-slate-600 dark:text-slate-300">
                  تم توصيل{' '}
                  <span className="font-code tabular-nums">
                    {matchState.matched.size} / {matchState.left.length}
                  </span>
                </span>
                <button
                  type="button"
                  onClick={handleNextMatchRound}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-4 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  <SkipForward className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>{matchRoundIdx >= matchRounds.length - 1 ? 'إنهاء' : 'تخطي'}</span>
                </button>
              </div>
            )
          ) : qState && answered ? (
            <>
              <div
                className={`flex flex-wrap items-center justify-between gap-3 rounded-xl border px-4 py-2.5 ${
                  lastCorrect
                    ? 'border-emerald-500/40 bg-emerald-50 dark:bg-emerald-500/15'
                    : 'border-rose-500/40 bg-rose-50 dark:bg-rose-500/15'
                }`}
              >
                <div className="text-right">
                  <div
                    className={`text-xs font-extrabold ${
                      lastCorrect
                        ? 'text-emerald-700 dark:text-emerald-300'
                        : 'text-rose-700 dark:text-rose-300'
                    }`}
                  >
                    {lastCorrect ? 'إجابة صحيحة' : 'إجابة خاطئة'}
                  </div>
                  <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    <span className="font-en" dir="ltr">
                      {qState.en}
                    </span>{' '}
                    = {qState.ar}
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => onOpenWordDetail(qState.idx)}
                    aria-label="تفاصيل الكلمة"
                    className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                  >
                    <ImageIcon className="h-4 w-4" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onSpeak(qState.en)}
                    aria-label={`نطق ${qState.en}`}
                    className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                  >
                    <Volume2 className="h-4 w-4" aria-hidden="true" />
                  </button>
                  {qState.subMode === 'type_ar' &&
                    !lastCorrect &&
                    lastUserAnswer &&
                    !qState.overridden && (
                      <button
                        type="button"
                        onClick={handleOverrideArabic}
                        className="h-10 rounded-lg bg-emerald-600 px-3 text-xs font-bold text-white hover:bg-emerald-700"
                      >
                        مرادف صحيح
                      </button>
                    )}
                </div>
              </div>

              <button
                type="button"
                onClick={handleNextQuestion}
                className={`inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl px-6 text-base font-bold text-white transition-colors ${
                  lastCorrect
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : 'bg-indigo-600 hover:bg-indigo-700'
                }`}
              >
                <span>
                  {qIndex >= session.pool.length - 1 ? 'عرض النتيجة النهائية' : 'الكلمة التالية'}
                </span>
                <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              </button>
            </>
          ) : qState ? (
            qState.subMode === 'mcq' || qState.subMode === 'tf' ? (
              <button
                type="button"
                onClick={handleSkipQuestion}
                className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                <SkipForward className="h-4 w-4" aria-hidden="true" />
                <span>تخطي للكلمة التالية</span>
              </button>
            ) : qState.subMode === 'missing' || qState.subMode === 'scramble' ? (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleHintSlots}
                  className="inline-flex h-11 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  <Lightbulb className="h-4 w-4" aria-hidden="true" />
                  <span>تلميح</span>
                </button>
                <button
                  type="button"
                  onClick={handleBackspaceSlots}
                  aria-label="حذف آخر حرف"
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  <Delete className="h-4 w-4" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  disabled={!allSlotsFilled}
                  onClick={() => qState.slots && submitSlots(qState.slots, qState.idx, qState.en)}
                  className="h-11 flex-1 rounded-xl bg-indigo-600 px-4 text-sm font-bold text-white hover:bg-indigo-700 disabled:opacity-45"
                >
                  تحقق
                </button>
                <button
                  type="button"
                  onClick={handleSkipQuestion}
                  className="h-11 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  تخطي
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleRevealTypingHint}
                  className="inline-flex h-11 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  <Lightbulb className="h-4 w-4" aria-hidden="true" />
                  <span>تلميح</span>
                </button>
                <button
                  type="button"
                  onClick={handleSubmitType}
                  className="h-11 flex-1 rounded-xl bg-indigo-600 px-4 text-sm font-bold text-white hover:bg-indigo-700"
                >
                  تحقق
                </button>
                <button
                  type="button"
                  onClick={handleShowSolution}
                  className="h-11 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  أظهر الحل
                </button>
              </div>
            )
          ) : null}
        </div>
      </div>
    </div>
  );
}
