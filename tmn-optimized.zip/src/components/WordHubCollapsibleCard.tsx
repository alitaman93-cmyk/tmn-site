import { useState, type ReactNode } from 'react';
import { ChevronDown } from 'lucide-react';

interface WordHubCollapsibleCardProps {
  title: string;
  subtitle?: string;
  count?: number;
  icon: ReactNode;
  defaultOpen?: boolean;
  headerRight?: ReactNode;
  children: ReactNode;
}

export function WordHubCollapsibleCard({
  title,
  subtitle,
  count,
  icon,
  defaultOpen = true,
  headerRight,
  children,
}: WordHubCollapsibleCardProps) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#131c2e]">
      <div className="flex items-center justify-between gap-3 px-5 py-4">
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          className="flex min-w-0 flex-1 items-center gap-3 text-right focus-visible:outline-none"
        >
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-indigo-600 dark:bg-slate-800 dark:text-indigo-400">
            {icon}
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 sm:text-base">
                {title}
              </h3>
              {typeof count === 'number' && count > 0 && (
                <span className="text-xs font-semibold tabular-nums text-slate-500 dark:text-slate-400">
                  · {count}
                </span>
              )}
            </div>
            {subtitle && (
              <p className="mt-0.5 truncate text-xs text-slate-500 dark:text-slate-400">
                {subtitle}
              </p>
            )}
          </div>
          <ChevronDown
            className={`h-4 w-4 shrink-0 text-slate-400 transition-transform duration-200 ${
              open ? 'rotate-180' : ''
            }`}
            aria-hidden="true"
          />
        </button>
        {headerRight && <div className="shrink-0">{headerRight}</div>}
      </div>

      {open && (
        <div className="border-t border-slate-100 px-5 py-4 dark:border-slate-800">{children}</div>
      )}
    </section>
  );
}
