import { Component, type ErrorInfo, type ReactNode } from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    let friendly = 'حدث خطأ غير متوقع أثناء تشغيل التطبيق.';
    if (error.message.includes('Missing or insufficient permissions') || error.message.includes('permission-denied')) {
      friendly = 'تعذر الوصول إلى البيانات السحابية بسبب صلاحيات الحساب. يرجى تسجيل الدخول مجدداً.';
    }
    return { hasError: true, message: friendly };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error('TMN ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          dir="rtl"
          className="flex min-h-screen items-center justify-center bg-slate-50 p-6 text-slate-900 dark:bg-[#0b1120] dark:text-slate-100"
        >
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-lg dark:border-slate-800 dark:bg-[#131c2e]">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-rose-50 text-rose-600 dark:bg-rose-500/15 dark:text-rose-400">
              <AlertTriangle className="h-6 w-6" aria-hidden="true" />
            </div>
            <h1 className="text-lg font-extrabold">عذراً، حدث خطأ مؤقت</h1>
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="mt-5 inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white hover:bg-indigo-700"
            >
              <RotateCcw className="h-4 w-4" aria-hidden="true" />
              <span>إعادة تحميل TMN</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
