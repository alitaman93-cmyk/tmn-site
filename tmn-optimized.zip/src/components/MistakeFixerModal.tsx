import {
  CheckCircle2,
  Sparkles,
  Trophy,
  Volume2,
  X,
  XCircle,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type { VocabEntry, VocabStore } from '../types';
import type { SfxType } from '../utils/audio';
import {
  createMistakeFixerSession,
  getMistakeFixerPhase,
  MISTAKE_FIXER_GRADUATION_XP,
  submitMistakeFixerAnswer,
  type MistakeFixerState,
} from '../utils/learningFeaturesLogic';

interface MistakeFixerModalProps {
  open: boolean;
  store: VocabStore;
  mistakeIds: number[];
  onClose: () => void;
  onSpeak: (text: string) => void;
  onSfx: (type: SfxType) => void;
  onGraduateWord: (wordId: number, xpAwarded: number) => void;
}

function buildOptionsForWord(target: VocabEntry, allWords: VocabEntry[]): VocabEntry[] {
  const pool: VocabEntry[] = [target];
  const used = new Set<number>([target.id]);
  const bandWords = allWords.filter((w) => w.band === target.band && w.id !== target.id);
  const source = bandWords.length >= 6 ? bandWords : allWords;

  let guard = 0;
  while (pool.length < 4 && guard < 80 && source.length > 0) {
    guard++;
    const pick = source[(target.id * 17 + guard * 31) % source.length];
    if (pick && !used.has(pick.id) && pick.ar !== target.ar) {
      used.add(pick.id);
      pool.push(pick);
    }
  }
  // Deterministic shuffle per step
  return pool.sort((a, b) => ((a.id * 13 + target.id) % 29) - ((b.id * 13 + target.id) % 29));
}

export function MistakeFixerModal({
  open,
  store,
  mistakeIds,
  onClose,
  onSpeak,
  onSfx,
  onGraduateWord,
}: MistakeFixerModalProps) {
  const [session, setSession] = useState<MistakeFixerState>(() =>
    createMistakeFixerSession(mistakeIds, 8)
  );
  const [typeInput, setTypeInput] = useState('');
  const [feedback, setFeedback] = useState<{
    status: 'correct' | 'wrong' | 'graduated';
    message: string;
    answerEn: string;
    answerAr: string;
  } | null>(null);

  useEffect(() => {
    if (open) {
      setSession(createMistakeFixerSession(mistakeIds, 8));
      setTypeInput('');
      setFeedback(null);
    }
  }, [open, mistakeIds]);

  const currentWordId = session.queue[0];
  const currentWord: VocabEntry | null =
    currentWordId !== undefined ? store.words[currentWordId] || null : null;
  const phase = getMistakeFixerPhase(session);

  const options = useMemo(() => {
    if (!currentWord) return [];
    return buildOptionsForWord(currentWord, store.words);
  }, [currentWord, store.words]);

  // Auto-speak in listen phase
  useEffect(() => {
    if (open && currentWord && phase === 'listen' && !feedback) {
      onSpeak(currentWord.en);
    }
  }, [open, currentWord, phase, feedback, onSpeak]);

  if (!open) return null;

  const totalTargetWords = Object.keys(session.progress).length;
  const graduatedCount = session.graduatedIds.length;
  const isFinished = session.queue.length === 0;

  const handleAnswer = (isCorrect: boolean) => {
    if (!currentWord || feedback) return;
    const result = submitMistakeFixerAnswer(session, isCorrect);

    if (result.graduatedWordId !== null) {
      onSfx('win');
      onGraduateWord(result.graduatedWordId, result.xpAwarded);
      setFeedback({
        status: 'graduated',
        message: `أحسنت! أتقنت الكلمة مرتين متتاليتين وتمت إزالتها من الأخطاء (+${MISTAKE_FIXER_GRADUATION_XP} XP)`,
        answerEn: currentWord.en,
        answerAr: currentWord.ar,
      });
    } else if (isCorrect) {
      onSfx('ok');
      setFeedback({
        status: 'correct',
        message: 'إجابة صحيحة! تبقى مرة واحدة متتالية لتتخرج هذه الكلمة من بنك الأخطاء.',
        answerEn: currentWord.en,
        answerAr: currentWord.ar,
      });
    } else {
      onSfx('err');
      setFeedback({
        status: 'wrong',
        message: 'لا بأس — ستظهر لك قريباً لتثبيتها في ذاكرتك.',
        answerEn: currentWord.en,
        answerAr: currentWord.ar,
      });
    }

    window.setTimeout(() => {
      setSession(result.nextState);
      setTypeInput('');
      setFeedback(null);
    }, 1050);
  };

  const handleTypeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentWord || !typeInput.trim()) return;
    const normInput = typeInput.trim().toLowerCase().replace(/[^a-z\s'-]/g, '');
    const normTarget = currentWord.en.trim().toLowerCase().replace(/[^a-z\s'-]/g, '');
    handleAnswer(normInput === normTarget);
  };

  const currentConsecutive = currentWord
    ? session.progress[currentWord.id]?.consecutiveCorrect || 0
    : 0;

  return (
    <div
      data-testid="mistake-fixer-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="إصلاح أخطائي السريع"
    >
      <div className="tmn-card flex max-h-[90vh] w-full max-w-lg flex-col overflow-hidden rounded-3xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200/80 px-5 py-4 dark:border-slate-800 sm:px-6">
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
              إصلاح أخطائي السريع (دقيقتان)
            </h2>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              أجب بشكل صحيح مرتين متتاليتين لإزالة الكلمة من الأخطاء وكسب +{MISTAKE_FIXER_GRADUATION_XP} XP
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Progress Strip */}
        <div className="border-b border-slate-200/60 px-5 py-3 dark:border-slate-800/80 sm:px-6">
          <div className="mb-1.5 flex items-center justify-between text-xs font-bold">
            <span className="text-slate-500 dark:text-slate-400">
              الكلمات التي تخرجت من الأخطاء
            </span>
            <span className="font-code text-emerald-600 tabular-nums dark:text-emerald-400">
              {graduatedCount} / {totalTargetWords}
            </span>
          </div>
          <div className="tmn-progress-track h-2 w-full">
            <div
              className="tmn-progress-fill h-full"
              style={{
                width: `${totalTargetWords > 0 ? Math.round((graduatedCount / totalTargetWords) * 100) : 100}%`,
              }}
            />
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6">
          {isFinished ? (
            <div className="py-8 text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/15 text-emerald-500">
                <Trophy className="h-7 w-7" />
              </div>
              <h3 className="mt-4 text-lg font-extrabold text-slate-900 dark:text-white">
                رائع! أنهيت جلسة إصلاح الأخطاء
              </h3>
              <p className="mt-1.5 text-sm text-slate-500 dark:text-slate-400">
                أصلحت {graduatedCount} كلمات بنجاح واكتسبت{' '}
                <span className="font-code font-bold text-indigo-600 tabular-nums dark:text-indigo-400">
                  +{session.totalXpEarned} XP
                </span>
              </p>
              <button
                type="button"
                onClick={onClose}
                className="mt-6 rounded-xl bg-indigo-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-indigo-700"
              >
                إغلاق والعودة
              </button>
            </div>
          ) : currentWord ? (
            <div className="space-y-5">
              {/* Mode & Streak Meta */}
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-indigo-600 dark:text-indigo-400">
                  {phase === 'listen'
                    ? 'المرحلة 1 · استمع واختر المعنى'
                    : phase === 'choose'
                      ? 'المرحلة 2 · اختر الكلمة الصحيحة'
                      : 'المرحلة 3 · اكتب الكلمة بالإنجليزية'}
                </span>
                <span className="font-code text-slate-500 tabular-nums dark:text-slate-400">
                  إتقان الكلمة: {currentConsecutive}/2
                </span>
              </div>

              {/* Prompt Card */}
              <div className="rounded-2xl border border-slate-200/80 bg-slate-50/70 p-5 text-center dark:border-slate-800 dark:bg-slate-900/50">
                {phase === 'listen' && (
                  <div className="space-y-3">
                    <button
                      type="button"
                      onClick={() => onSpeak(currentWord.en)}
                      className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-sm hover:bg-indigo-700"
                      aria-label="استمع للنطق"
                    >
                      <Volume2 className="h-6 w-6" />
                    </button>
                    <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      اضغط للاستماع مجدداً ثم اختر المعنى الصحيح
                    </p>
                  </div>
                )}

                {phase === 'choose' && (
                  <div>
                    <div
                      dir="ltr"
                      className="font-en text-2xl font-extrabold text-slate-900 dark:text-white"
                    >
                      {currentWord.en}
                    </div>
                    <button
                      type="button"
                      onClick={() => onSpeak(currentWord.en)}
                      className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-indigo-600 hover:underline dark:text-indigo-400"
                    >
                      <Volume2 className="h-3.5 w-3.5" />
                      <span>نطق الكلمة</span>
                    </button>
                  </div>
                )}

                {phase === 'type' && (
                  <div>
                    <div className="text-lg font-extrabold text-slate-900 dark:text-white">
                      {currentWord.ar}
                    </div>
                    <div className="mt-1.5 text-xs text-slate-500 dark:text-slate-400">
                      تلميح: تبدأ بحرف{' '}
                      <span className="font-code font-bold uppercase text-indigo-600 dark:text-indigo-400">
                        {currentWord.en[0]}
                      </span>{' '}
                      ({currentWord.en.length} حروف)
                    </div>
                  </div>
                )}
              </div>

              {/* Answer Area */}
              {(phase === 'listen' || phase === 'choose') && (
                <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                  {options.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      disabled={Boolean(feedback)}
                      data-testid={`fixer-opt-${opt.id === currentWord.id ? 'correct' : 'other'}`}
                      onClick={() => handleAnswer(opt.id === currentWord.id)}
                      className="rounded-xl border border-slate-200/90 bg-white px-4 py-3 text-sm font-bold text-slate-800 transition-colors hover:border-indigo-400 hover:bg-indigo-50/60 disabled:opacity-60 dark:border-slate-700/80 dark:bg-slate-900/60 dark:text-slate-100 dark:hover:border-indigo-500"
                    >
                      {opt.ar}
                    </button>
                  ))}
                </div>
              )}

              {phase === 'type' && (
                <form onSubmit={handleTypeSubmit} className="space-y-3">
                  <input
                    type="text"
                    dir="ltr"
                    autoFocus
                    disabled={Boolean(feedback)}
                    value={typeInput}
                    onChange={(e) => setTypeInput(e.target.value)}
                    placeholder="Type the English word..."
                    className="h-12 w-full rounded-xl border border-slate-200 bg-white px-4 font-en text-base font-bold text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                  />
                  <button
                    type="submit"
                    disabled={Boolean(feedback) || !typeInput.trim()}
                    className="h-11 w-full rounded-xl bg-indigo-600 text-xs font-bold text-white hover:bg-indigo-700 disabled:opacity-50"
                  >
                    تحقق من الإجابة
                  </button>
                </form>
              )}

              {/* Feedback Banner */}
              {feedback && (
                <div
                  className={`flex items-start gap-2.5 rounded-2xl border p-3.5 text-xs font-bold ${
                    feedback.status === 'graduated'
                      ? 'border-emerald-300 bg-emerald-50 text-emerald-800 dark:border-emerald-600/50 dark:bg-emerald-950/50 dark:text-emerald-200'
                      : feedback.status === 'correct'
                        ? 'border-indigo-300 bg-indigo-50 text-indigo-800 dark:border-indigo-600/50 dark:bg-indigo-950/50 dark:text-indigo-200'
                        : 'border-rose-300 bg-rose-50 text-rose-800 dark:border-rose-600/50 dark:bg-rose-950/50 dark:text-rose-200'
                  }`}
                >
                  {feedback.status === 'graduated' ? (
                    <Sparkles className="mt-0.5 h-4 w-4 shrink-0" />
                  ) : feedback.status === 'correct' ? (
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                  ) : (
                    <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  )}
                  <div>
                    <div>{feedback.message}</div>
                    <div className="mt-1 font-en text-[11px] opacity-85">
                      {feedback.answerEn} — {feedback.answerAr}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
