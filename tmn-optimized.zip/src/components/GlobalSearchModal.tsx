import {
  BookOpen,
  CornerDownLeft,
  GraduationCap,
  MessageSquareText,
  Search,
  X,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { GRAMMAR_LESSONS } from '../data/grammarLessons';
import type { SentenceEntry, VocabStore } from '../types';
import {
  parseSentencesTSV,
  STARTER_AR_TRANSLATIONS,
  STARTER_SENTENCES_TSV,
} from '../utils/sentenceLogic';
import { idbGetDataset, idbSetDataset } from '../utils/storage';

interface GlobalSearchModalProps {
  open: boolean;
  store: VocabStore;
  onClose: () => void;
  onSelectWord: (wordId: number) => void;
  onSelectSentence: (sentenceText: string) => void;
  onSelectGrammar: (lessonId: string) => void;
}

type SearchResultItem =
  | {
      key: string;
      group: 'words';
      wordId: number;
      title: string;
      subtitle: string;
      meta: string;
    }
  | {
      key: string;
      group: 'sentences';
      sentenceText: string;
      title: string;
      subtitle: string;
      meta: string;
    }
  | {
      key: string;
      group: 'grammar';
      lessonId: string;
      title: string;
      subtitle: string;
      meta: string;
    };

let cachedSentencesCorpus: SentenceEntry[] | null = null;

export function GlobalSearchModal({
  open,
  store,
  onClose,
  onSelectWord,
  onSelectSentence,
  onSelectGrammar,
}: GlobalSearchModalProps) {
  const [query, setQuery] = useState('');
  const [activeIndex, setActiveIndex] = useState(0);
  const [sentences, setSentences] = useState<SentenceEntry[]>(
    () => cachedSentencesCorpus || parseSentencesTSV(STARTER_SENTENCES_TSV)
  );
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Focus input on open
  useEffect(() => {
    if (!open) return;
    setQuery('');
    setActiveIndex(0);
    const id = window.setTimeout(() => inputRef.current?.focus(), 30);
    return () => window.clearTimeout(id);
  }, [open]);

  // Load full offline sentences corpus lazily once when palette opens
  useEffect(() => {
    if (!open || cachedSentencesCorpus) return;
    let active = true;
    void (async () => {
      try {
        const cached = await idbGetDataset('sentences-21k');
        if (cached && cached.length > 1000) {
          const parsed = parseSentencesTSV(cached);
          if (parsed.length > 50) {
            cachedSentencesCorpus = parsed;
            if (active) setSentences(parsed);
            return;
          }
        }
      } catch {
        // Proceed to fetch
      }
      try {
        const res = await fetch('/sentences-21k.tsv');
        if (res.ok) {
          const text = await res.text();
          const parsed = parseSentencesTSV(text);
          if (parsed.length > 0) {
            cachedSentencesCorpus = parsed;
            if (active) setSentences(parsed);
            void idbSetDataset('sentences-21k', text);
          }
        }
      } catch {
        // Keep starter corpus offline
      }
    })();
    return () => {
      active = false;
    };
  }, [open]);

  const groupedResults = useMemo(() => {
    const q = query.trim().toLowerCase();

    const words: SearchResultItem[] = [];
    const sents: SearchResultItem[] = [];
    const grammar: SearchResultItem[] = [];

    if (!q) {
      // Show helpful quick suggestions when query is empty
      for (let i = 0; i < Math.min(4, store.words.length); i++) {
        const w = store.words[i];
        words.push({
          key: `w-${w.id}`,
          group: 'words',
          wordId: w.id,
          title: w.en,
          subtitle: w.ar,
          meta: w.band,
        });
      }
      for (const s of sentences.slice(0, 3)) {
        sents.push({
          key: `s-${s.num}`,
          group: 'sentences',
          sentenceText: s.en,
          title: s.en,
          subtitle: STARTER_AR_TRANSLATIONS[s.en] || `جملة #${s.num}`,
          meta: `#${s.num}`,
        });
      }
      for (const g of GRAMMAR_LESSONS.slice(0, 3)) {
        grammar.push({
          key: `g-${g.id}`,
          group: 'grammar',
          lessonId: g.id,
          title: g.titleAr,
          subtitle: g.titleEn,
          meta: g.band,
        });
      }
      return { words, sentences: sents, grammar, flat: [...words, ...sents, ...grammar] };
    }

    // 1) Instant search across 18,484 words (prefix matches prioritized)
    const wordStarts: SearchResultItem[] = [];
    const wordContains: SearchResultItem[] = [];
    for (let i = 0; i < store.words.length; i++) {
      const w = store.words[i];
      const enLow = w.en.toLowerCase();
      const arLow = w.ar.toLowerCase();
      if (enLow === q || enLow.startsWith(q) || arLow.startsWith(q)) {
        wordStarts.push({
          key: `w-${w.id}`,
          group: 'words',
          wordId: w.id,
          title: w.en,
          subtitle: w.ar,
          meta: w.band,
        });
        if (wordStarts.length >= 6) break;
      } else if (wordContains.length < 6 && (enLow.includes(q) || arLow.includes(q))) {
        wordContains.push({
          key: `w-${w.id}`,
          group: 'words',
          wordId: w.id,
          title: w.en,
          subtitle: w.ar,
          meta: w.band,
        });
      }
    }
    words.push(...wordStarts.concat(wordContains).slice(0, 6));

    // 2) Instant search across offline sentences corpus
    for (let i = 0; i < sentences.length; i++) {
      const s = sentences[i];
      const ar = STARTER_AR_TRANSLATIONS[s.en] || '';
      if (
        s.en.toLowerCase().includes(q) ||
        (ar && ar.toLowerCase().includes(q)) ||
        String(s.num) === q
      ) {
        sents.push({
          key: `s-${s.num}`,
          group: 'sentences',
          sentenceText: s.en,
          title: s.en,
          subtitle: ar || `جملة رقم #${s.num}`,
          meta: `#${s.num}`,
        });
        if (sents.length >= 5) break;
      }
    }

    // 3) Instant search across all 36 Grammar lessons
    for (const g of GRAMMAR_LESSONS) {
      const hay = `${g.titleAr} ${g.titleEn} ${g.formula} ${g.summaryAr} ${g.band}`.toLowerCase();
      if (hay.includes(q)) {
        grammar.push({
          key: `g-${g.id}`,
          group: 'grammar',
          lessonId: g.id,
          title: g.titleAr,
          subtitle: `${g.titleEn} · ${g.formula}`,
          meta: g.band,
        });
        if (grammar.length >= 5) break;
      }
    }

    return {
      words,
      sentences: sents,
      grammar,
      flat: [...words, ...sents, ...grammar],
    };
  }, [query, store.words, sentences]);

  const handleActivate = (item: SearchResultItem) => {
    onClose();
    if (item.group === 'words') {
      onSelectWord(item.wordId);
    } else if (item.group === 'sentences') {
      onSelectSentence(item.sentenceText);
    } else {
      onSelectGrammar(item.lessonId);
    }
  };

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
        return;
      }
      if (groupedResults.flat.length === 0) return;
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setActiveIndex((prev) => (prev + 1) % groupedResults.flat.length);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setActiveIndex(
          (prev) => (prev - 1 + groupedResults.flat.length) % groupedResults.flat.length
        );
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const chosen = groupedResults.flat[activeIndex] || groupedResults.flat[0];
        if (chosen) handleActivate(chosen);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  if (!open) return null;

  let runningIdx = 0;

  const renderGroup = (
    titleAr: string,
    icon: React.ReactNode,
    items: SearchResultItem[]
  ) => {
    if (items.length === 0) return null;
    return (
      <div className="mb-3 last:mb-0">
        <div className="mb-1.5 flex items-center gap-1.5 px-2 text-[11px] font-bold text-slate-400">
          {icon}
          <span>{titleAr}</span>
        </div>
        <div className="space-y-1">
          {items.map((item) => {
            const idx = runningIdx++;
            const isSelected = idx === activeIndex;
            return (
              <button
                key={item.key}
                type="button"
                data-testid={`global-search-item-${item.key}`}
                onMouseEnter={() => setActiveIndex(idx)}
                onClick={() => handleActivate(item)}
                className={`flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-start transition-colors ${
                  isSelected
                    ? 'bg-indigo-600/12 text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-200'
                    : 'text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800/70'
                }`}
              >
                <div className="min-w-0 flex-1 text-start">
                  <div
                    className={`truncate text-sm font-bold ${
                      item.group === 'grammar' ? '' : 'font-en'
                    }`}
                  >
                    <bdi>{item.title}</bdi>
                  </div>
                  <div className="mt-0.5 truncate text-xs text-slate-500 dark:text-slate-400">
                    {item.subtitle}
                  </div>
                </div>
                <span
                  dir="ltr"
                  className="shrink-0 font-code text-[11px] font-bold text-slate-400 tabular-nums"
                >
                  {item.meta}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div
      data-testid="global-search-modal"
      className="fixed inset-0 z-50 flex items-start justify-center bg-slate-950/65 px-4 pt-16 backdrop-blur-sm sm:pt-24"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="البحث الشامل الفوري"
    >
      <div
        className="tmn-card flex max-h-[75vh] w-full max-w-2xl flex-col overflow-hidden rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Row */}
        <div className="flex items-center gap-3 border-b border-slate-200/80 px-4 py-3.5 dark:border-slate-800">
          <Search className="h-5 w-5 shrink-0 text-indigo-500" aria-hidden="true" />
          <input
            ref={inputRef}
            type="text"
            data-testid="global-search-input"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setActiveIndex(0);
            }}
            placeholder="ابحث فوراً في 18,484 كلمة، الجمل الإنجليزية، و36 درس قواعد..."
            className="w-full bg-transparent text-sm font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-none dark:text-white"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              aria-label="مسح البحث"
              className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
            >
              <X className="h-4 w-4" />
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق البحث"
            className="hidden rounded-lg border border-slate-200 px-2 py-1 font-code text-[10px] font-bold text-slate-400 sm:inline-flex dark:border-slate-700"
          >
            ESC
          </button>
        </div>

        {/* Grouped Results */}
        <div className="flex-1 overflow-y-auto p-3.5">
          {groupedResults.flat.length === 0 ? (
            <div className="py-12 text-center text-sm font-semibold text-slate-400">
              لا توجد نتائج مطابقة لـ «{query}»
            </div>
          ) : (
            <>
              {renderGroup(
                'الكلمات (18,484 كلمة)',
                <BookOpen className="h-3.5 w-3.5" aria-hidden="true" />,
                groupedResults.words
              )}
              {renderGroup(
                'الجمل الإنجليزية',
                <MessageSquareText className="h-3.5 w-3.5" aria-hidden="true" />,
                groupedResults.sentences
              )}
              {renderGroup(
                'قواعد اللغة الإنجليزية (36 درساً)',
                <GraduationCap className="h-3.5 w-3.5" aria-hidden="true" />,
                groupedResults.grammar
              )}
            </>
          )}
        </div>

        {/* Footer Hint */}
        <div className="flex items-center justify-between border-t border-slate-200/80 bg-slate-50/70 px-4 py-2.5 text-[11px] font-semibold text-slate-500 dark:border-slate-800 dark:bg-slate-900/60 dark:text-slate-400">
          <span>يعمل 100% بدون إنترنت</span>
          <span className="hidden items-center gap-1.5 sm:inline-flex">
            <CornerDownLeft className="h-3.5 w-3.5" />
            <span>Enter للفتح · ↑↓ للتنقل</span>
          </span>
        </div>
      </div>
    </div>
  );
}
