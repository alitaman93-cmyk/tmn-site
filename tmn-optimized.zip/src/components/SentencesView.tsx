import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AudioWaveform,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Film,
  FolderOpen,
  RefreshCw,
  Search,
  Star,
  Volume2,
  X,
} from 'lucide-react';
import { useI18n } from '../contexts/LanguageContext';
import type { SentenceEntry, SentenceGameModeId } from '../types';
import { translateSentencesBatch } from '../utils/aiApi';
import { speakEn } from '../utils/audio';
import { fetchSentenceVideoClips } from '../utils/mediaApi';
import {
  prefetchSentenceTranslations,
  prefetchSentenceVideos,
} from '../utils/prefetchEngine';
import {
  filterSentences,
  parseSentencesTSV,
  SENTENCE_SECTIONS,
  STARTER_AR_TRANSLATIONS,
  STARTER_SENTENCES_TSV,
} from '../utils/sentenceLogic';
import {
  idbGetDataset,
  idbGetSentenceTranslations,
  idbSetDataset,
  idbSetSentenceTranslations,
} from '../utils/storage';
import { WordVideoReelsPlayer } from './WordVideoReelsPlayer';

const ShadowingModal = lazy(() =>
  import('./ShadowingModal').then((m) => ({ default: m.ShadowingModal }))
);

interface SentencesViewProps {
  ttsRate: number;
  favoriteSentences: number[];
  practicedSentences: number[];
  initialSearchQuery?: string;
  onToggleFavoriteSentence: (num: number) => void;
  onMarkPracticedSentence: (num: number) => void;
  onStartSentenceGame?: (mode: SentenceGameModeId) => void;
  onToast: (msg: string) => void;
}

const PAGE_SIZE = 15;

export function SentencesView({
  ttsRate,
  favoriteSentences,
  practicedSentences,
  initialSearchQuery,
  onToggleFavoriteSentence,
  onMarkPracticedSentence,
  onToast,
}: SentencesViewProps) {
  const { lang } = useI18n();
  const [sentences, setSentences] = useState<SentenceEntry[]>(() =>
    parseSentencesTSV(STARTER_SENTENCES_TSV)
  );
  const [loadingCorpus, setLoadingCorpus] = useState(true);

  const [tab, setTab] = useState<'all' | 'favorites' | 'practiced'>('all');
  const [query, setQuery] = useState(initialSearchQuery || '');
  const [debouncedQuery, setDebouncedQuery] = useState(initialSearchQuery || '');
  const [page, setPage] = useState(0);
  const [activeSectionId, setActiveSectionId] = useState<string>('all');
  const [categoriesOpen, setCategoriesOpen] = useState(false);

  // Shadowing Pronunciation Mode modal state
  const [shadowingOpen, setShadowingOpen] = useState(false);
  const [shadowingStartIdx, setShadowingStartIdx] = useState(0);

  useEffect(() => {
    if (initialSearchQuery !== undefined && initialSearchQuery.trim()) {
      setQuery(initialSearchQuery);
      setDebouncedQuery(initialSearchQuery);
      setTab('all');
      setActiveSectionId('all');
      setPage(0);
    }
  }, [initialSearchQuery]);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query), query ? 220 : 0);
    return () => clearTimeout(timer);
  }, [query]);

  // Active-language translations cache in memory (hydrated from Starter (ar) + IndexedDB + Fast Translate)
  const [arMap, setArMap] = useState<Record<string, string>>(() =>
    lang === 'ar' ? { ...STARTER_AR_TRANSLATIONS } : {}
  );
  const [translatingPage, setTranslatingPage] = useState(false);
  const [translationError, setTranslationError] = useState('');

  // Real-speech Full-Sentence Video Clips Reels drawer state (only 1 sentence open at a time)
  const [videoSentenceNum, setVideoSentenceNum] = useState<number | null>(null);

  const arMapRef = useRef<Record<string, string>>(arMap);

  useEffect(() => {
    arMapRef.current = arMap;
  }, [arMap]);

  // Reset in-memory sentence translation map cleanly whenever the active UI language changes
  useEffect(() => {
    const initial = lang === 'ar' ? { ...STARTER_AR_TRANSLATIONS } : {};
    arMapRef.current = initial;
    setArMap(initial);
  }, [lang]);

  // Load full 21,708 sentences dataset offline-first (IndexedDB dataset cache -> network refresh)
  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const cachedText = await idbGetDataset('sentences-21k');
        if (active && cachedText && cachedText.length > 1000) {
          const parsedCached = parseSentencesTSV(cachedText);
          if (active && parsedCached.length > 50) {
            setSentences(parsedCached);
            setLoadingCorpus(false);
          }
        }
      } catch {
        // Proceed to network fetch
      }

      try {
        const res = await fetch('/sentences-21k.tsv');
        if (res.ok) {
          const text = await res.text();
          const parsed = parseSentencesTSV(text);
          if (active && parsed.length > 0) {
            setSentences(parsed);
            void idbSetDataset('sentences-21k', text);
          }
        }
      } catch {
        // Keep cached or starter sentences if offline before precache
      } finally {
        if (active) setLoadingCorpus(false);
      }
    };
    void load();
    return () => {
      active = false;
    };
  }, []);

  const favSet = useMemo(() => new Set(favoriteSentences), [favoriteSentences]);
  const practicedSet = useMemo(() => new Set(practicedSentences), [practicedSentences]);

  const sectionCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const sec of SENTENCE_SECTIONS) counts[sec.id] = 0;
    for (const s of sentences) {
      for (const sec of SENTENCE_SECTIONS) {
        if (s.num >= sec.startNum && s.num <= sec.endNum) {
          counts[sec.id] += 1;
          break;
        }
      }
    }
    return counts;
  }, [sentences]);

  const filtered = useMemo(
    () => filterSentences(sentences, debouncedQuery, arMap, tab, favSet, practicedSet, activeSectionId),
    [sentences, debouncedQuery, arMap, tab, favSet, practicedSet, activeSectionId]
  );

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages - 1);

  const visibleSentences = useMemo(() => {
    const start = safePage * PAGE_SIZE;
    return filtered.slice(start, start + PAGE_SIZE);
  }, [filtered, safePage]);

  const nextTwoPagesSentences = useMemo(() => {
    const start = (safePage + 1) * PAGE_SIZE;
    return start < filtered.length ? filtered.slice(start, start + PAGE_SIZE * 2) : [];
  }, [filtered, safePage]);

  // Automatically hydrate active-language translations for visible sentences immediately (IDB -> Server/GTX)
  const fetchMissingTranslations = useCallback(
    async (items: SentenceEntry[], signal?: AbortSignal, silent = false) => {
      const keys = items.map((s) => s.en);
      if (!keys.length) return;

      const missingFromMem = keys.filter((k) => !arMapRef.current[k]);
      if (!missingFromMem.length) {
        if (!silent) setTranslationError('');
        return;
      }

      const keyPrefix = lang === 'ar' ? '' : `${lang}::`;
      const storageKeys = missingFromMem.map((k) => `${keyPrefix}${k}`);

      // Check IndexedDB cache first
      const cachedRaw = await idbGetSentenceTranslations(storageKeys);
      if (signal?.aborted) return;

      const cachedByEn: Record<string, string> = {};
      for (const k of missingFromMem) {
        const val = cachedRaw[`${keyPrefix}${k}`];
        if (val) cachedByEn[k] = val;
      }

      if (Object.keys(cachedByEn).length > 0) {
        setArMap((prev) => ({ ...prev, ...cachedByEn }));
      }

      const stillMissing = missingFromMem.filter((k) => !cachedByEn[k]);
      if (!stillMissing.length) {
        if (!silent) setTranslationError('');
        return;
      }

      if (!silent) {
        setTranslatingPage(true);
        setTranslationError('');
      }
      try {
        const fetched = await translateSentencesBatch(stillMissing, signal, lang);
        if (signal?.aborted) return;
        if (Object.keys(fetched).length > 0) {
          setArMap((prev) => ({ ...prev, ...fetched }));
          const toStore: Record<string, string> = {};
          for (const [en, tr] of Object.entries(fetched)) {
            if (tr) toStore[`${keyPrefix}${en}`] = tr;
          }
          void idbSetSentenceTranslations(toStore);
        }
      } catch (err) {
        if (!signal?.aborted && !silent) {
          setTranslationError(
            err instanceof Error ? err.message : 'تعذر ترجمة هذه الصفحة حالياً.'
          );
        }
      } finally {
        if (!signal?.aborted && !silent) {
          setTranslatingPage(false);
        }
      }
    },
    [lang]
  );

  useEffect(() => {
    const controller = new AbortController();
    void (async () => {
      await fetchMissingTranslations(visibleSentences, controller.signal, false);
      if (controller.signal.aborted) return;
      // Silently prefetch the next 2 pages (30 sentences) in active UI language
      if (nextTwoPagesSentences.length > 0) {
        prefetchSentenceTranslations(
          nextTwoPagesSentences.map((s) => s.en),
          lang
        );
      }
      // Preload primary video clips & posters for the top visible sentences so opening Reels is instant
      if (visibleSentences.length > 0) {
        prefetchSentenceVideos(visibleSentences.slice(0, 8).map((s) => s.en));
      }
    })();
    return () => {
      controller.abort();
    };
  }, [visibleSentences, nextTwoPagesSentences, lang, fetchMissingTranslations]);

  const handleSelectSection = (sectionId: string) => {
    setActiveSectionId(sectionId);
    setPage(0);
    setCategoriesOpen(false);
  };

  const activeSectionMeta = useMemo(
    () => SENTENCE_SECTIONS.find((s) => s.id === activeSectionId) || null,
    [activeSectionId]
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <section className="tmn-card rounded-3xl p-5 sm:p-6">
        <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 sm:text-2xl">
          مكتبة الجمل الإنجليزية ({sentences.length.toLocaleString('en-US')} جملة)
        </h1>

        {/* Shadowing Practice & Organized Categories Trigger Row */}
        <div className="mt-4 flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            data-testid="sentences-shadowing-header-btn"
            onClick={() => {
              setShadowingStartIdx(0);
              setShadowingOpen(true);
            }}
            className="inline-flex h-10 items-center gap-2 whitespace-nowrap rounded-xl bg-emerald-600 px-4 text-xs font-bold text-white transition-colors hover:bg-emerald-700"
          >
            <AudioWaveform className="h-4 w-4" aria-hidden="true" />
            <span>تدريب الظل (Shadowing)</span>
          </button>

          <button
            type="button"
            data-testid="sentence-categories-toggle"
            aria-expanded={categoriesOpen}
            onClick={() => setCategoriesOpen((v) => !v)}
            className={`inline-flex h-10 items-center gap-2 rounded-xl border px-4 text-xs font-bold transition-colors ${
              categoriesOpen || activeSectionId !== 'all'
                ? 'border-indigo-500 bg-indigo-600 text-white shadow-xs'
                : 'border-slate-200 bg-slate-50 text-slate-800 hover:border-indigo-400 hover:bg-indigo-50 dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-100'
            }`}
          >
            <FolderOpen className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span>
              {activeSectionMeta
                ? `التصنيف: ${activeSectionMeta.label}`
                : `تصنيفات الجمل (${SENTENCE_SECTIONS.length})`}
            </span>
            <ChevronDown
              className={`h-4 w-4 shrink-0 transition-transform ${
                categoriesOpen ? 'rotate-180' : ''
              }`}
              aria-hidden="true"
            />
          </button>

          {activeSectionMeta && (
            <button
              type="button"
              onClick={() => handleSelectSection('all')}
              className="inline-flex h-10 items-center gap-1 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-600 hover:border-rose-300 hover:text-rose-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
            >
              <X className="h-3.5 w-3.5" aria-hidden="true" />
              <span>إلغاء التصنيف</span>
            </button>
          )}
        </div>

        {/* Collapsible Neatly Stacked Vertical Category List */}
        {categoriesOpen && (
          <div
            data-testid="sentence-categories-list"
            className="mt-3 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-[#0f172a]"
          >
            <div className="flex items-center justify-between border-b border-slate-100 px-4 py-2.5 dark:border-slate-800">
              <span className="text-xs font-extrabold text-slate-700 dark:text-slate-200">
                اختر تصنيف الجمل ({SENTENCE_SECTIONS.length} تصنيفاً)
              </span>
              <button
                type="button"
                onClick={() => setCategoriesOpen(false)}
                aria-label="إغلاق قائمة التصنيفات"
                className="flex h-7 w-7 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            <div className="max-h-80 divide-y divide-slate-100 overflow-y-auto dark:divide-slate-800/70">
              <button
                type="button"
                data-testid="sentence-category-option-all"
                onClick={() => handleSelectSection('all')}
                className={`flex w-full items-center justify-between gap-3 px-4 py-3 text-start text-sm font-bold transition-colors ${
                  activeSectionId === 'all'
                    ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300'
                    : 'text-slate-800 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-slate-800/60'
                }`}
              >
                <span className="flex items-center gap-2">
                  {activeSectionId === 'all' && (
                    <Check className="h-4 w-4 text-indigo-600 dark:text-indigo-400" aria-hidden="true" />
                  )}
                  <span>جميع الجمل (الكل)</span>
                </span>
                <span className="font-code text-xs font-bold tabular-nums text-slate-500 dark:text-slate-400">
                  {sentences.length.toLocaleString('en-US')}
                </span>
              </button>

              {SENTENCE_SECTIONS.map((sec) => {
                const isActive = activeSectionId === sec.id;
                const count = sectionCounts[sec.id] || 0;
                return (
                  <button
                    key={sec.id}
                    type="button"
                    data-testid={`sentence-category-option-${sec.id}`}
                    onClick={() => handleSelectSection(sec.id)}
                    className={`flex w-full items-center justify-between gap-3 px-4 py-3 text-start text-sm font-semibold transition-colors ${
                      isActive
                        ? 'bg-indigo-50 font-bold text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300'
                        : 'text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      {isActive && (
                        <Check className="h-4 w-4 text-indigo-600 dark:text-indigo-400" aria-hidden="true" />
                      )}
                      <span>{sec.label}</span>
                    </span>
                    <span className="font-code text-xs font-semibold tabular-nums text-slate-500 dark:text-slate-400">
                      {count.toLocaleString('en-US')}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Search & Filter Row */}
        <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute top-1/2 right-3.5 h-4 w-4 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(0);
              }}
              placeholder="ابحث بالإنجليزية أو برقم الجملة (مثلاً: airport أو 4484)..."
              className="h-11 w-full rounded-lg border border-slate-200 bg-slate-50 pr-10 pl-9 text-sm text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-100 dark:focus:border-indigo-400 dark:focus:bg-slate-900"
            />
            {query && (
              <button
                type="button"
                onClick={() => {
                  setQuery('');
                  setPage(0);
                }}
                aria-label="مسح البحث"
                className="absolute top-1/2 left-2.5 -translate-y-1/2 rounded p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 p-1 dark:border-slate-700 dark:bg-slate-900/60">
            {(
              [
                { id: 'all', label: 'الكل' },
                { id: 'favorites', label: 'المفضلة' },
                { id: 'practiced', label: 'تدرّبت عليها' },
              ] as const
            ).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setTab(item.id);
                  setPage(0);
                }}
                className={`h-9 rounded-md px-3 text-xs font-bold transition-colors ${
                  tab === item.id
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Pagination & Status Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-1">
        <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
          {loadingCorpus
            ? 'جاري تحميل جميع الجمل...'
            : `عرض ${filtered.length === 0 ? 0 : safePage * PAGE_SIZE + 1}–${Math.min(
                (safePage + 1) * PAGE_SIZE,
                filtered.length
              )} من ${filtered.length.toLocaleString('en-US')} جملة`}
          {translatingPage && (
            <span className="mr-2 text-indigo-600 dark:text-indigo-400">
              • جاري تجهيز الترجمة العربية...
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {translationError && (
            <button
              type="button"
              onClick={() => void fetchMissingTranslations(visibleSentences)}
              className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-amber-300 bg-amber-50 px-3 text-xs font-bold text-amber-800 dark:border-amber-700 dark:bg-amber-950/50 dark:text-amber-200"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              إعادة الترجمة
            </button>
          )}
          <button
            type="button"
            disabled={safePage <= 0}
            onClick={() => {
              setPage((p) => Math.max(0, p - 1));
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex h-9 items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-[#162032] dark:text-slate-200"
          >
            <ChevronRight className="h-4 w-4" />
            السابق
          </button>
          <span className="font-code text-xs font-bold text-slate-600 tabular-nums dark:text-slate-300">
            {safePage + 1} / {totalPages}
          </span>
          <button
            type="button"
            disabled={safePage >= totalPages - 1}
            onClick={() => {
              setPage((p) => Math.min(totalPages - 1, p + 1));
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex h-9 items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-[#162032] dark:text-slate-200"
          >
            التالي
            <ChevronLeft className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Empty State */}
      {visibleSentences.length === 0 && (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center dark:border-slate-800 dark:bg-[#162032]">
          <p className="text-sm font-bold text-slate-700 dark:text-slate-200">
            لا توجد جمل مطابقة للبحث أو الفلتر الحالي.
          </p>
          <button
            type="button"
            onClick={() => {
              setQuery('');
              setTab('all');
              setPage(0);
            }}
            className="mt-3 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-700"
          >
            عرض جميع الجمل
          </button>
        </div>
      )}

      {/* Sentences List */}
      <div className="space-y-3">
        {visibleSentences.map((item) => {
          const ar = arMap[item.en];
          const isFav = favSet.has(item.num);
          const isPracticed = practicedSet.has(item.num);
          const isVideoOpen = videoSentenceNum === item.num;
          const cleanSentence = item.en.split('=')[0].trim();

          return (
            <article
              key={item.num}
              className="tmn-card rounded-2xl p-5 transition-colors sm:p-6"
            >
              {/* Top Row: Number, English Sentence, Favorite & Practiced */}
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="mb-1.5 flex items-center gap-2">
                    <span className="font-code rounded bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-600 tabular-nums dark:bg-slate-800 dark:text-slate-300">
                      #{item.num}
                    </span>
                    {isPracticed && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        تم التدريب
                      </span>
                    )}
                  </div>

                  <p
                    dir="ltr"
                    className="text-left text-base font-bold leading-relaxed text-slate-900 dark:text-slate-50 sm:text-lg"
                  >
                    {item.en}
                  </p>

                  {/* Arabic Translation */}
                  <div className="mt-2 min-h-[24px]">
                    {ar ? (
                      <p className="text-sm font-medium text-indigo-700 dark:text-indigo-300">
                        {ar}
                      </p>
                    ) : translatingPage ? (
                      <div className="h-4 w-48 animate-pulse rounded bg-slate-200 dark:bg-slate-700/70" />
                    ) : (
                      <button
                        type="button"
                        onClick={() => void fetchMissingTranslations([item])}
                        className="text-xs font-semibold text-slate-400 underline hover:text-indigo-500"
                      >
                        اضغط لعرض الترجمة العربية
                      </button>
                    )}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onToggleFavoriteSentence(item.num)}
                  aria-label={isFav ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border transition-colors ${
                    isFav
                      ? 'border-amber-300 bg-amber-50 text-amber-500 dark:border-amber-700/70 dark:bg-amber-950/40'
                      : 'border-slate-200 bg-slate-50 text-slate-400 hover:text-amber-500 dark:border-slate-700 dark:bg-slate-800/70'
                  }`}
                >
                  <Star className={`h-4 w-4 ${isFav ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Controls Bar: Listen, Slow Listen, Shadowing, Full-Sentence Videos */}
              <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => speakEn(cleanSentence, ttsRate, onToast)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3.5 text-xs font-bold text-slate-700 transition-colors hover:border-indigo-400 hover:bg-indigo-50 hover:text-indigo-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:border-indigo-500 dark:hover:bg-indigo-950/50 dark:hover:text-indigo-300"
                >
                  <Volume2 className="h-4 w-4" />
                  استمع للنطق
                </button>

                <button
                  type="button"
                  onClick={() => speakEn(cleanSentence, 0.65, onToast)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-semibold text-slate-600 transition-colors hover:border-slate-300 hover:text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:text-white"
                >
                  نطق بطيء
                </button>

                <button
                  type="button"
                  data-testid={`sentence-shadow-btn-${item.num}`}
                  onClick={() => {
                    const idxInVisible = visibleSentences.findIndex((s) => s.num === item.num);
                    setShadowingStartIdx(idxInVisible >= 0 ? idxInVisible : 0);
                    setShadowingOpen(true);
                  }}
                  className="inline-flex h-10 items-center gap-1.5 rounded-lg border border-emerald-300/80 bg-emerald-50 px-3.5 text-xs font-bold text-emerald-700 transition-colors hover:border-emerald-500 hover:bg-emerald-100 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/20"
                >
                  <AudioWaveform className="h-4 w-4" aria-hidden="true" />
                  <span>تدريب الظل</span>
                </button>

                {cleanSentence && (
                  <button
                    type="button"
                    data-testid={`sentence-video-btn-${item.num}`}
                    onMouseEnter={() => {
                      void fetchSentenceVideoClips(cleanSentence, 0).catch(() => {});
                    }}
                    onClick={() =>
                      setVideoSentenceNum((curr) => (curr === item.num ? null : item.num))
                    }
                    className={`inline-flex h-10 items-center gap-1.5 rounded-lg border px-3.5 text-xs font-bold transition-colors ${
                      isVideoOpen
                        ? 'border-sky-500 bg-sky-500 text-slate-950 shadow-sm'
                        : 'border-sky-300/80 bg-sky-50 text-sky-700 hover:border-sky-500 hover:bg-sky-100 dark:border-sky-500/40 dark:bg-sky-500/10 dark:text-sky-300 dark:hover:bg-sky-500/20'
                    }`}
                  >
                    <Film className="h-4 w-4" />
                    <span>{isVideoOpen ? 'إخفاء الفيديوهات' : 'فيديوهات للجملة'}</span>
                  </button>
                )}
              </div>

              {/* Full-Sentence Real-Speech Video Clips Player */}
              {isVideoOpen && cleanSentence && (
                <div
                  data-testid={`sentence-video-panel-${item.num}`}
                  className="mt-4 space-y-3 rounded-2xl border border-sky-500/30 bg-slate-50/90 p-3.5 dark:bg-slate-950/60 sm:p-4"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <span className="text-xs font-extrabold text-slate-700 dark:text-slate-200">
                        مقاطع فيديو حقيقية للجملة كاملة:
                      </span>
                      <p
                        dir="ltr"
                        className="mt-0.5 truncate text-left font-en text-xs font-semibold text-sky-700 dark:text-sky-300"
                      >
                        &ldquo;{cleanSentence}&rdquo;
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setVideoSentenceNum(null)}
                      aria-label="إغلاق مشغل الفيديو"
                      className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-300 bg-white text-slate-500 hover:text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400 dark:hover:text-white"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>

                  <WordVideoReelsPlayer
                    key={`${item.num}-${cleanSentence}`}
                    word={cleanSentence}
                    meaningAr={ar || cleanSentence}
                    uiLang={lang}
                    mode="sentence"
                  />
                </div>
              )}
            </article>
          );
        })}
      </div>

      {/* Bottom Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 pt-2">
          <button
            type="button"
            disabled={safePage <= 0}
            onClick={() => {
              setPage((p) => Math.max(0, p - 1));
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex h-10 items-center gap-1 rounded-lg border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-[#162032] dark:text-slate-200"
          >
            <ChevronRight className="h-4 w-4" />
            الصفحة السابقة
          </button>
          <span className="font-code text-xs font-bold text-slate-600 tabular-nums dark:text-slate-300">
            {safePage + 1} / {totalPages}
          </span>
          <button
            type="button"
            disabled={safePage >= totalPages - 1}
            onClick={() => {
              setPage((p) => Math.min(totalPages - 1, p + 1));
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex h-10 items-center gap-1 rounded-lg border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-[#162032] dark:text-slate-200"
          >
            الصفحة التالية
            <ChevronLeft className="h-4 w-4" />
          </button>
        </div>
      )}
      {/* Lazy-Loaded Shadowing Pronunciation Mode Modal */}
      {shadowingOpen && (
        <Suspense fallback={null}>
          <ShadowingModal
            open={shadowingOpen}
            sentences={visibleSentences.length > 0 ? visibleSentences : sentences.slice(0, 15)}
            initialIndex={shadowingStartIdx}
            translationsMap={arMap}
            onClose={() => setShadowingOpen(false)}
            onSentencePracticed={(num) => onMarkPracticedSentence(num)}
            onToast={onToast}
          />
        </Suspense>
      )}
    </div>
  );
}
