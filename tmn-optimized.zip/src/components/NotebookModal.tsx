import {
  Bookmark,
  Download,
  NotebookPen,
  Plus,
  Printer,
  Star,
  Trash2,
  Volume2,
  X,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type { SavedWordNote, SentenceEntry, VocabStore } from '../types';
import { buildAnkiCsvExport } from '../utils/learningFeaturesLogic';
import {
  parseSentencesTSV,
  STARTER_AR_TRANSLATIONS,
  STARTER_SENTENCES_TSV,
} from '../utils/sentenceLogic';
import { idbGetDataset } from '../utils/storage';

interface NotebookPanelProps {
  store: VocabStore;
  favoriteWordIds: number[];
  savedWordNotes: SavedWordNote[];
  favoriteSentenceNums: number[];
  onSpeak: (text: string) => void;
  onOpenWordDetail: (wordId: number) => void;
  onAddNote: (note: SavedWordNote) => void;
  onDeleteNote: (noteId: string) => void;
  onToast: (msg: string) => void;
}

export function NotebookPanel({
  store,
  favoriteWordIds,
  savedWordNotes,
  favoriteSentenceNums,
  onSpeak,
  onOpenWordDetail,
  onAddNote,
  onDeleteNote,
  onToast,
}: NotebookPanelProps) {
  const [sentences, setSentences] = useState<SentenceEntry[]>(() =>
    parseSentencesTSV(STARTER_SENTENCES_TSV)
  );
  const [noteTerm, setNoteTerm] = useState('');
  const [noteMeaning, setNoteMeaning] = useState('');

  useEffect(() => {
    let active = true;
    void (async () => {
      try {
        const cached = await idbGetDataset('sentences-21k');
        if (active && cached && cached.length > 1000) {
          setSentences(parseSentencesTSV(cached));
        }
      } catch {
        // Keep starter corpus
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const favoriteWords = useMemo(
    () => favoriteWordIds.map((id) => store.words[id]).filter(Boolean),
    [favoriteWordIds, store.words]
  );

  const favoriteSentenceItems = useMemo(() => {
    const favSet = new Set(favoriteSentenceNums);
    if (favSet.size === 0) return [];
    return sentences
      .filter((s) => favSet.has(s.num))
      .map((s) => ({
        num: s.num,
        en: s.en,
        ar: STARTER_AR_TRANSLATIONS[s.en] || '',
      }));
  }, [favoriteSentenceNums, sentences]);

  const totalItems =
    favoriteWords.length + savedWordNotes.length + favoriteSentenceItems.length;

  const handleExportCsv = () => {
    if (totalItems === 0) {
      onToast('أضف كلمات أو ملاحظات أو جمل مفضلة أولاً للتصدير');
      return;
    }
    const csv = buildAnkiCsvExport(
      favoriteWords,
      savedWordNotes,
      favoriteSentenceItems.map((s) => ({ en: s.en, ar: s.ar }))
    );
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'TMN-Study-Notebook-Anki.csv';
    a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    onToast('تم تصدير دفتري الشخصي بصيغة أنكي CSV بنجاح');
  };

  const handlePrint = () => {
    window.print();
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    const text = noteTerm.trim();
    const meaningAr = noteMeaning.trim();
    if (!text || !meaningAr) return;
    onAddNote({
      id: `custom-${Date.now()}`,
      parentWord: text.split(/\s+/)[0] || text,
      kind: 'example',
      text,
      meaningAr,
      savedAt: Date.now(),
    });
    setNoteTerm('');
    setNoteMeaning('');
    onToast('تم حفظ الملاحظة في دفتري الشخصي');
  };

  return (
    <div data-testid="notebook-panel" className="print-notebook-sheet space-y-5">
      {/* Header & Export Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200/80 bg-slate-50/70 p-4 dark:border-slate-800 dark:bg-slate-900/50">
        <div>
          <h3 className="flex items-center gap-2 text-base font-extrabold text-slate-900 dark:text-white">
            <NotebookPen className="h-4.5 w-4.5 text-indigo-500" />
            <span>دفتري الشخصي</span>
          </h3>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
            {favoriteWords.length} كلمة مفضلة · {savedWordNotes.length} ملاحظة محفوظة ·{' '}
            {favoriteSentenceItems.length} جملة مفضلة
          </p>
        </div>

        <div className="no-print flex flex-wrap items-center gap-2">
          <button
            type="button"
            data-testid="notebook-export-csv-btn"
            onClick={handleExportCsv}
            className="inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-xl bg-indigo-600 px-3.5 text-xs font-bold text-white hover:bg-indigo-700"
          >
            <Download className="h-3.5 w-3.5" />
            <span>تصدير أنكي (CSV)</span>
          </button>
          <button
            type="button"
            data-testid="notebook-print-btn"
            onClick={handlePrint}
            className="inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-xl border border-slate-200 bg-white px-3.5 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
          >
            <Printer className="h-3.5 w-3.5" />
            <span>طباعة ورقة مراجعة</span>
          </button>
        </div>
      </div>

      {/* Quick Add Custom Note */}
      <form
        onSubmit={handleAddNote}
        className="no-print grid grid-cols-1 gap-2 rounded-2xl border border-slate-200/80 bg-white p-3.5 sm:grid-cols-[1fr_1fr_auto] dark:border-slate-800 dark:bg-slate-900/40"
      >
        <input
          type="text"
          dir="ltr"
          value={noteTerm}
          onChange={(e) => setNoteTerm(e.target.value)}
          placeholder="English word or phrase..."
          className="h-10 rounded-xl border border-slate-200 bg-slate-50 px-3 font-en text-xs font-semibold text-slate-900 focus:border-indigo-500 focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white"
        />
        <input
          type="text"
          value={noteMeaning}
          onChange={(e) => setNoteMeaning(e.target.value)}
          placeholder="المعنى أو ملاحظتك الشخصية..."
          className="h-10 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-semibold text-slate-900 focus:border-indigo-500 focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white"
        />
        <button
          type="submit"
          disabled={!noteTerm.trim() || !noteMeaning.trim()}
          className="inline-flex h-10 items-center justify-center gap-1.5 whitespace-nowrap rounded-xl bg-emerald-600 px-4 text-xs font-bold text-white hover:bg-emerald-700 disabled:opacity-40"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>إضافة ملاحظة</span>
        </button>
      </form>

      {/* Saved Notes */}
      <section className="space-y-2">
        <h4 className="flex items-center gap-1.5 text-xs font-bold text-slate-500 dark:text-slate-400">
          <Bookmark className="h-3.5 w-3.5 text-indigo-500" />
          <span>الملاحظات المحفوظة ({savedWordNotes.length})</span>
        </h4>
        {savedWordNotes.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-200 p-4 text-center text-xs text-slate-400 dark:border-slate-800">
            لا توجد ملاحظات بعد — أضف ملاحظة بالأعلى أو احفظ أي تعبير من صفحة تفاصيل الكلمة.
          </div>
        ) : (
          <div className="space-y-2">
            {savedWordNotes.map((note) => (
              <div
                key={note.id}
                className="flex items-center justify-between gap-3 rounded-xl border border-slate-200/80 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900/40"
              >
                <div className="min-w-0 flex-1">
                  <div dir="ltr" className="truncate text-left font-en text-sm font-bold text-slate-900 dark:text-white">
                    {note.text}
                  </div>
                  <div className="mt-0.5 text-xs text-slate-600 dark:text-slate-300">
                    {note.meaningAr}
                  </div>
                </div>
                <div className="no-print flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => onSpeak(note.text)}
                    aria-label="استمع"
                    className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-indigo-600 dark:hover:bg-slate-800"
                  >
                    <Volume2 className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteNote(note.id)}
                    aria-label="حذف الملاحظة"
                    className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Favorite Words */}
      <section className="space-y-2">
        <h4 className="flex items-center gap-1.5 text-xs font-bold text-slate-500 dark:text-slate-400">
          <Star className="h-3.5 w-3.5 text-amber-500" />
          <span>الكلمات المفضلة ({favoriteWords.length})</span>
        </h4>
        {favoriteWords.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-200 p-4 text-center text-xs text-slate-400 dark:border-slate-800">
            لم تضف كلمات إلى المفضلة بعد.
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {favoriteWords.slice(0, 60).map((w) => (
              <div
                key={w.id}
                className="flex items-center justify-between gap-2 rounded-xl border border-slate-200/80 bg-white px-3.5 py-2.5 dark:border-slate-800 dark:bg-slate-900/40"
              >
                <button
                  type="button"
                  onClick={() => onOpenWordDetail(w.id)}
                  className="min-w-0 flex-1 text-start"
                >
                  <div dir="ltr" className="truncate text-left font-en text-sm font-bold text-slate-900 dark:text-white">
                    {w.en}
                  </div>
                  <div className="truncate text-xs text-slate-500 dark:text-slate-400">
                    {w.ar} · {w.band}
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => onSpeak(w.en)}
                  aria-label="استمع"
                  className="no-print flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-indigo-600 dark:hover:bg-slate-800"
                >
                  <Volume2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Favorite Sentences */}
      <section className="space-y-2">
        <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400">
          الجمل المفضلة ({favoriteSentenceItems.length})
        </h4>
        {favoriteSentenceItems.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-200 p-4 text-center text-xs text-slate-400 dark:border-slate-800">
            لم تضف جملاً إلى المفضلة بعد.
          </div>
        ) : (
          <div className="space-y-2">
            {favoriteSentenceItems.slice(0, 40).map((s) => (
              <div
                key={s.num}
                className="flex items-center justify-between gap-3 rounded-xl border border-slate-200/80 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900/40"
              >
                <div className="min-w-0 flex-1">
                  <div dir="ltr" className="text-left font-en text-sm font-bold text-slate-900 dark:text-white">
                    {s.en}
                  </div>
                  {s.ar && (
                    <div className="mt-0.5 text-xs text-indigo-700 dark:text-indigo-300">
                      {s.ar}
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => onSpeak(s.en)}
                  aria-label="استمع"
                  className="no-print flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-indigo-600 dark:hover:bg-slate-800"
                >
                  <Volume2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

interface NotebookModalProps extends NotebookPanelProps {
  open: boolean;
  onClose: () => void;
}

export function NotebookModal({ open, onClose, ...panelProps }: NotebookModalProps) {
  if (!open) return null;
  return (
    <div
      data-testid="notebook-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="دفتري الشخصي"
    >
      <div className="tmn-card flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl">
        <div className="no-print flex items-center justify-between border-b border-slate-200/80 px-5 py-4 dark:border-slate-800 sm:px-6">
          <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
            دفتري الشخصي والتصدير
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-5 sm:p-6">
          <NotebookPanel {...panelProps} />
        </div>
      </div>
    </div>
  );
}
