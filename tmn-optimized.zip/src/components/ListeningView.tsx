import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  Captions,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronUp,
  Clock,
  Headphones,
  Loader2,
  Play,
  RotateCcw,
  RotateCw,
  Search,
  SkipForward,
  Sparkles,
  XCircle,
} from 'lucide-react';
import { useI18n } from '../contexts/LanguageContext';
import { BAND_META } from '../data/constants';
import { getListeningGrammarStrings } from '../i18n/listeningGrammarStrings';
import type {
  CaptionLangCode,
  CefrBand,
  ListeningCatalogResponse,
  ListeningQuizQuestion,
  ListeningVideoDetail,
  ListeningVideoItem,
  PersistedSettings,
  UiLanguageCode,
  VideoCaptionCue,
} from '../types';
import {
  fetchListeningCaptions,
  fetchListeningCatalog,
  fetchListeningQuiz,
  fetchListeningVideoDetail,
  prefetchListeningVideos,
} from '../utils/listeningGrammarApi';
import {
  LISTENING_LEVELS,
  LISTENING_LEVEL_MAP,
  computeListeningLevelProgress,
  formatDurationMMSS,
  formatTotalHours,
  getActiveListeningCue,
} from '../utils/listeningLogic';

interface ListeningViewProps {
  settings: PersistedSettings;
  onRecordListeningComplete: (
    band: CefrBand,
    videoId: string,
    durationSec: number,
    quizScorePct: number
  ) => void;
  onEarnXp: (xpDelta: number) => void;
  onToast: (msg: string) => void;
}

const SPEEDS = [0.75, 1, 1.25] as const;

export function ListeningView({
  settings,
  onRecordListeningComplete,
  onEarnXp,
  onToast,
}: ListeningViewProps) {
  const { lang, languages } = useI18n();
  const s = useMemo(() => getListeningGrammarStrings(lang), [lang]);
  const currentLangOption = useMemo(
    () => languages.find((l) => l.code === lang) || languages[0],
    [languages, lang]
  );

  // Navigation within Listening tab: levels -> catalog -> player
  const [selectedBand, setSelectedBand] = useState<CefrBand | null>(null);
  const [catalog, setCatalog] = useState<ListeningCatalogResponse | null>(null);
  const [catalogLoading, setCatalogLoading] = useState(false);
  const [catalogError, setCatalogError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'todo' | 'done'>('all');
  const [visibleCount, setVisibleCount] = useState(24);

  // Active video player state
  const [activeItem, setActiveItem] = useState<ListeningVideoItem | null>(null);
  const [videoDetail, setVideoDetail] = useState<ListeningVideoDetail | null>(null);
  const [videoLoading, setVideoLoading] = useState(false);
  const [videoError, setVideoError] = useState('');
  const [captionMode, setCaptionMode] = useState<CaptionLangCode>('en');
  const [captionTransLang, setCaptionTransLang] = useState<UiLanguageCode>(lang);
  const [captionLoading, setCaptionLoading] = useState(false);
  const [translatedCuesMap, setTranslatedCuesMap] = useState<Record<string, VideoCaptionCue[]>>(
    {}
  );
  const [currentTime, setCurrentTime] = useState(0);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [showTranscript, setShowTranscript] = useState(false);
  const [videoUseProxy, setVideoUseProxy] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Post-video quiz state
  const [quizQuestions, setQuizQuestions] = useState<ListeningQuizQuestion[]>([]);
  const [quizLoading, setQuizLoading] = useState(false);
  const [quizIdx, setQuizIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [answeredCorrectCount, setAnsweredCorrectCount] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);

  // Keep default translated caption language synced with Settings language
  useEffect(() => {
    setCaptionTransLang(lang);
  }, [lang]);

  // Load CEFR level catalog when selectedBand changes
  const loadBandCatalog = useCallback(
    async (band: CefrBand) => {
      setSelectedBand(band);
      setActiveItem(null);
      setVideoDetail(null);
      setCatalogLoading(true);
      setCatalogError('');
      setSearchQuery('');
      setStatusFilter('all');
      setVisibleCount(24);
      try {
        const data = await fetchListeningCatalog(band);
        setCatalog(data);
        prefetchListeningVideos(
          data.videos.slice(0, 2).map((v) => v.slug),
          data.videos.slice(0, 6).map((v) => v.posterUrl),
          lang
        );
      } catch (err) {
        setCatalogError(err instanceof Error ? err.message : 'تعذر تحميل فيديوهات المستوى.');
      } finally {
        setCatalogLoading(false);
      }
    },
    [lang]
  );

  // Open a specific video & auto-load its captions + post-video comprehension quiz
  const openVideo = useCallback(
    async (item: ListeningVideoItem) => {
      setActiveItem(item);
      setVideoDetail(null);
      setVideoLoading(true);
      setVideoError('');
      setVideoUseProxy(false);
      setCurrentTime(0);
      setShowTranscript(false);
      setQuizQuestions([]);
      setQuizLoading(true);
      setQuizIdx(0);
      setSelectedOption(null);
      setAnsweredCorrectCount(0);
      setQuizFinished(false);
      window.scrollTo({ top: 0 });

      try {
        const detail = await fetchListeningVideoDetail(item.slug, captionTransLang);
        setVideoDetail(detail);
        setTranslatedCuesMap(detail.translatedCues || {});
        setVideoLoading(false);

        const qs = await fetchListeningQuiz({
          videoId: detail.id,
          title: detail.title,
          speaker: detail.speaker,
          band: item.band,
          cues: detail.enCues,
        });
        setQuizQuestions(qs);
      } catch (err) {
        setVideoError(err instanceof Error ? err.message : 'تعذر تحميل هذا الفيديو.');
        setVideoLoading(false);
      } finally {
        setQuizLoading(false);
      }
    },
    [captionTransLang]
  );

  // Switch translation language dynamically for any of the 10 supported languages
  const handleSelectTranslationLang = useCallback(
    async (targetLang: UiLanguageCode, switchModeToTarget = true) => {
      setCaptionTransLang(targetLang);
      if (switchModeToTarget) {
        setCaptionMode(targetLang);
      }
      if (!videoDetail) return;
      if (translatedCuesMap[targetLang]?.length) return;

      setCaptionLoading(true);
      try {
        const cues = await fetchListeningCaptions(videoDetail.id, videoDetail.slug, targetLang);
        setTranslatedCuesMap((prev) => ({ ...prev, [targetLang]: cues }));
      } catch {
        onToast('تعذر تحميل هذه الترجمة حالياً');
      } finally {
        setCaptionLoading(false);
      }
    },
    [videoDetail, translatedCuesMap, onToast]
  );

  const handleSpeedChange = useCallback((rate: number) => {
    setPlaybackRate(rate);
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
  }, []);

  const seekBy = useCallback((deltaSec: number) => {
    const el = videoRef.current;
    if (!el) return;
    el.currentTime = Math.max(0, Math.min(el.duration || 9999, el.currentTime + deltaSec));
    setCurrentTime(el.currentTime);
  }, []);

  const jumpToSec = useCallback((sec: number) => {
    const el = videoRef.current;
    if (!el) return;
    el.currentTime = Math.max(0, sec);
    setCurrentTime(el.currentTime);
    void el.play().catch(() => {});
  }, []);

  // Active cues synced to video playback time
  const activeEnCue = useMemo(() => {
    if (!videoDetail?.enCues?.length) return null;
    return getActiveListeningCue(videoDetail.enCues, currentTime);
  }, [videoDetail, currentTime]);

  const activeTranslatedCue = useMemo(() => {
    const cues = translatedCuesMap[captionTransLang];
    if (!cues?.length) return null;
    return getActiveListeningCue(cues, currentTime);
  }, [translatedCuesMap, captionTransLang, currentTime]);

  // Quiz answer & completion handlers
  const handleSelectQuizOption = (optIndex: number) => {
    if (selectedOption !== null) return;
    setSelectedOption(optIndex);
    const currentQ = quizQuestions[quizIdx];
    if (currentQ && optIndex === currentQ.correctIndex) {
      setAnsweredCorrectCount((c) => c + 1);
    }
  };

  const handleAdvanceQuiz = () => {
    if (quizIdx + 1 < quizQuestions.length) {
      setQuizIdx((i) => i + 1);
      setSelectedOption(null);
      return;
    }
    setQuizFinished(true);
    if (activeItem && videoDetail && quizQuestions.length > 0) {
      const pct = Math.round((answeredCorrectCount / quizQuestions.length) * 100);
      if (pct >= 60) {
        onRecordListeningComplete(activeItem.band, activeItem.id, videoDetail.durationSec, pct);
        onEarnXp(25);
        onToast(`${s.completedBadge} · +25 XP`);
      }
    }
  };

  const handleResetQuiz = () => {
    setQuizIdx(0);
    setSelectedOption(null);
    setAnsweredCorrectCount(0);
    setQuizFinished(false);
  };

  const handleOpenNextVideo = () => {
    if (!catalog || !activeItem) return;
    const idx = catalog.videos.findIndex((v) => v.slug === activeItem.slug);
    const next = catalog.videos[idx + 1] || catalog.videos[0];
    if (next) {
      void openVideo(next);
    }
  };

  // Filtered catalog list
  const completedSet = useMemo(() => {
    if (!selectedBand) return new Set<string>();
    return new Set(settings.listeningProgress?.[selectedBand]?.completedVideoIds || []);
  }, [selectedBand, settings.listeningProgress]);

  const filteredVideos = useMemo(() => {
    if (!catalog) return [];
    const q = searchQuery.trim().toLowerCase();
    return catalog.videos.filter((v) => {
      const done = completedSet.has(v.id);
      if (statusFilter === 'done' && !done) return false;
      if (statusFilter === 'todo' && done) return false;
      if (q) {
        return (
          v.title.toLowerCase().includes(q) ||
          v.speaker.toLowerCase().includes(q) ||
          (v.topicTag || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [catalog, searchQuery, statusFilter, completedSet]);

  // ───────────────────────────────────────────────────────────────────────────
  // VIEW 3: CINEMA VIDEO PLAYER + 11-LANGUAGE CAPTIONS + POST-VIDEO QUIZ
  // ───────────────────────────────────────────────────────────────────────────
  if (selectedBand && activeItem) {
    const isRtlCaption = captionTransLang === 'ar';
    const currentQ = quizQuestions[quizIdx];
    const finalPct =
      quizQuestions.length > 0 ? Math.round((answeredCorrectCount / quizQuestions.length) * 100) : 0;
    const passedQuiz = finalPct >= 60;
    const isAlreadyCompleted = completedSet.has(activeItem.id);
    const selectedLangObj =
      languages.find((l) => l.code === captionTransLang) || currentLangOption;

    return (
      <section data-testid="listening-player-view" className="mx-auto max-w-5xl space-y-6">
        {/* Top breadcrumb bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              setActiveItem(null);
              setVideoDetail(null);
            }}
            className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-800 dark:bg-[#111b2e] dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
            <span>
              {s.backToVideos} ({selectedBand})
            </span>
          </button>

          <div className="flex items-center gap-3 text-xs font-semibold text-slate-500 dark:text-slate-400">
            <span className="font-en font-extrabold text-indigo-600 dark:text-indigo-400">
              {selectedBand}
            </span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{formatDurationMMSS(activeItem.durationSec)}</span>
            {isAlreadyCompleted && (
              <>
                <span aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1 font-bold text-emerald-600 dark:text-emerald-400">
                  <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                  {s.completedBadge}
                </span>
              </>
            )}
          </div>
        </div>

        {/* Main Video Stage */}
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs dark:border-slate-800 dark:bg-[#111b2e]">
          {videoLoading ? (
            <div className="flex aspect-video flex-col items-center justify-center gap-3 bg-slate-950 text-slate-200">
              <Loader2 className="h-8 w-8 animate-spin text-sky-400" aria-hidden="true" />
              <p className="text-sm font-semibold">{s.loadingVideo}</p>
            </div>
          ) : videoError || !videoDetail ? (
            <div className="flex aspect-video flex-col items-center justify-center gap-4 bg-slate-950 p-6 text-center text-slate-200">
              <p className="max-w-md text-sm font-semibold text-rose-300">
                {videoError || 'تعذر تحميل هذا الفيديو.'}
              </p>
              <button
                type="button"
                onClick={handleOpenNextVideo}
                className="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-4 text-sm font-bold text-white hover:bg-indigo-500"
              >
                <SkipForward className="h-4 w-4" aria-hidden="true" />
                <span>{s.quizNextVideoBtn}</span>
              </button>
            </div>
          ) : (
            <>
              <div className="relative aspect-video w-full bg-black">
                <video
                  key={`${videoDetail.slug}-${videoUseProxy ? 'px' : 'dir'}`}
                  ref={videoRef}
                  src={
                    videoUseProxy
                      ? `/api/video-proxy?url=${encodeURIComponent(videoDetail.videoUrl)}`
                      : videoDetail.videoUrl
                  }
                  poster={videoDetail.posterUrl || activeItem.posterUrl || undefined}
                  controls
                  playsInline
                  preload="metadata"
                  onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
                  onLoadedMetadata={(e) => {
                    e.currentTarget.playbackRate = playbackRate;
                  }}
                  onError={() => {
                    if (!videoUseProxy && videoDetail.videoUrl.startsWith('https://')) {
                      setVideoUseProxy(true);
                    } else {
                      setVideoError('تعذر تشغيل هذا الفيديو مباشرة، يمكنك الانتقال للفيديو التالي.');
                    }
                  }}
                  className="h-full w-full object-contain"
                />

                {/* Synchronized Multi-Language Caption Overlay */}
                {captionMode !== 'off' && (
                  <div
                    data-testid="listening-caption-overlay"
                    className="pointer-events-none absolute inset-x-3 bottom-14 z-10 flex flex-col items-center gap-1.5 text-center sm:inset-x-8 sm:bottom-16"
                  >
                    {(captionMode === 'en' || captionMode === 'dual') && activeEnCue && (
                      <div
                        dir="ltr"
                        className="max-w-3xl rounded-lg bg-slate-950/85 px-3.5 py-1.5 font-en text-sm font-semibold leading-snug text-white shadow-lg backdrop-blur-xs sm:text-base"
                      >
                        {activeEnCue.text}
                      </div>
                    )}
                    {captionMode !== 'en' && activeTranslatedCue && (
                      <div
                        dir={isRtlCaption ? 'rtl' : 'ltr'}
                        className="max-w-3xl rounded-lg bg-indigo-950/90 px-3.5 py-1.5 text-sm font-bold leading-snug text-sky-100 shadow-lg backdrop-blur-xs sm:text-base"
                      >
                        {activeTranslatedCue.text}
                      </div>
                    )}
                    {captionMode !== 'en' && !activeTranslatedCue && captionLoading && (
                      <div className="rounded-lg bg-slate-950/80 px-3 py-1 text-xs font-semibold text-sky-300">
                        {s.loadingVideo}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Video Title + Controls + 11-Language Caption Bar */}
              <div className="space-y-4 p-4 sm:p-6">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 flex-1 space-y-1">
                    <h2 className="text-start font-en text-lg font-extrabold leading-snug text-slate-900 dark:text-white sm:text-xl">
                      <span dir="ltr" className="inline-block">
                        {videoDetail.title}
                      </span>
                    </h2>
                    <p className="text-start text-xs font-semibold text-slate-500 dark:text-slate-400">
                      <span>{videoDetail.speaker}</span>
                      <span aria-hidden="true"> · </span>
                      <span className="tabular-nums">
                        {formatDurationMMSS(videoDetail.durationSec)}
                      </span>
                    </p>
                  </div>

                  {/* Quick Seek & Playback Speed */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => seekBy(-10)}
                      aria-label="-10s"
                      className="inline-flex h-9 items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                    >
                      <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                      <span className="tabular-nums">10s</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => seekBy(10)}
                      aria-label="+10s"
                      className="inline-flex h-9 items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                    >
                      <RotateCw className="h-3.5 w-3.5" aria-hidden="true" />
                      <span className="tabular-nums">10s</span>
                    </button>
                    <div className="flex items-center rounded-lg border border-slate-200 bg-slate-50 p-0.5 dark:border-slate-700 dark:bg-slate-800">
                      {SPEEDS.map((spd) => (
                        <button
                          key={spd}
                          type="button"
                          onClick={() => handleSpeedChange(spd)}
                          className={`rounded-md px-2 py-1 text-xs font-bold tabular-nums transition-colors ${
                            playbackRate === spd
                              ? 'bg-indigo-600 text-white'
                              : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
                          }`}
                        >
                          {spd}x
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 11-Language Caption Control Bar */}
                <div
                  data-testid="listening-caption-controls"
                  className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 pt-4 dark:border-slate-800"
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 dark:text-slate-300">
                      <Captions className="h-4 w-4 text-indigo-500" aria-hidden="true" />
                      <span>{s.captionsLabel}:</span>
                    </span>

                    <div className="flex flex-wrap items-center gap-1 rounded-xl bg-slate-100 p-1 dark:bg-slate-900">
                      <button
                        type="button"
                        data-testid="caption-btn-off"
                        onClick={() => setCaptionMode('off')}
                        className={`rounded-lg px-2.5 py-1.5 text-xs font-bold whitespace-nowrap transition-colors ${
                          captionMode === 'off'
                            ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                            : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                        }`}
                      >
                        {s.captionsOff}
                      </button>
                      <button
                        type="button"
                        data-testid="caption-btn-en"
                        onClick={() => setCaptionMode('en')}
                        className={`rounded-lg px-2.5 py-1.5 text-xs font-bold whitespace-nowrap transition-colors ${
                          captionMode === 'en'
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                        }`}
                      >
                        {s.captionsEnglish}
                      </button>
                      <button
                        type="button"
                        data-testid="caption-btn-native"
                        onClick={() => void handleSelectTranslationLang(captionTransLang, true)}
                        className={`rounded-lg px-2.5 py-1.5 text-xs font-bold whitespace-nowrap transition-colors ${
                          captionMode === captionTransLang
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                        }`}
                      >
                        {selectedLangObj.flag} {selectedLangObj.nativeName}
                      </button>
                      <button
                        type="button"
                        data-testid="caption-btn-dual"
                        onClick={() => {
                          setCaptionMode('dual');
                          void handleSelectTranslationLang(captionTransLang, false);
                        }}
                        className={`rounded-lg px-2.5 py-1.5 text-xs font-bold whitespace-nowrap transition-colors ${
                          captionMode === 'dual'
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                        }`}
                      >
                        {s.captionsDual}
                      </button>
                    </div>
                  </div>

                  {/* All 10 Translation Languages Selector */}
                  <div className="flex items-center gap-2">
                    <label
                      htmlFor="listening-caption-lang-select"
                      className="sr-only"
                    >
                      {s.captionsAllLanguages}
                    </label>
                    <select
                      id="listening-caption-lang-select"
                      data-testid="caption-lang-select"
                      value={captionTransLang}
                      onChange={(e) => {
                        const chosen = e.target.value as UiLanguageCode;
                        void handleSelectTranslationLang(chosen, captionMode !== 'dual');
                      }}
                      className="h-9 rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs font-bold text-slate-800 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                    >
                      {languages.map((opt) => (
                        <option key={opt.code} value={opt.code}>
                          {opt.flag} {opt.nativeName}
                        </option>
                      ))}
                    </select>
                    {captionLoading && (
                      <Loader2 className="h-4 w-4 animate-spin text-indigo-500" aria-hidden="true" />
                    )}
                  </div>
                </div>

                {/* Collapsible Interactive Transcript */}
                {videoDetail.enCues.length > 0 && (
                  <div className="border-t border-slate-200 pt-3 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => setShowTranscript((v) => !v)}
                      aria-expanded={showTranscript}
                      className="flex w-full items-center justify-between text-xs font-bold text-slate-600 hover:text-indigo-600 dark:text-slate-300 dark:hover:text-indigo-400"
                    >
                      <span>
                        {s.transcriptTitle} ({videoDetail.enCues.length})
                      </span>
                      {showTranscript ? (
                        <ChevronUp className="h-4 w-4" aria-hidden="true" />
                      ) : (
                        <ChevronDown className="h-4 w-4" aria-hidden="true" />
                      )}
                    </button>

                    {showTranscript && (
                      <div className="mt-3 max-h-60 space-y-1.5 overflow-y-auto rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-900/60">
                        {videoDetail.enCues.map((cue, idx) => {
                          const isActive = activeEnCue?.startSec === cue.startSec;
                          const trCue = translatedCuesMap[captionTransLang]?.[idx];
                          return (
                            <button
                              key={`${cue.startSec}-${idx}`}
                              type="button"
                              onClick={() => jumpToSec(cue.startSec)}
                              className={`flex w-full flex-col gap-0.5 rounded-lg px-3 py-2 text-start transition-colors ${
                                isActive
                                  ? 'bg-indigo-600/15 text-indigo-900 dark:bg-indigo-500/20 dark:text-white'
                                  : 'hover:bg-slate-200/70 dark:hover:bg-slate-800'
                              }`}
                            >
                              <div className="flex items-baseline justify-between gap-2">
                                <span dir="ltr" className="font-en text-xs font-semibold sm:text-sm">
                                  {cue.text}
                                </span>
                                <span className="shrink-0 font-code text-[11px] text-slate-400 tabular-nums">
                                  {formatDurationMMSS(cue.startSec)}
                                </span>
                              </div>
                              {captionMode !== 'off' && captionMode !== 'en' && trCue && (
                                <span
                                  dir={isRtlCaption ? 'rtl' : 'ltr'}
                                  className="text-xs text-slate-600 dark:text-slate-300"
                                >
                                  {trCue.text}
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        {/* Post-Video Multiple-Choice Comprehension Quiz */}
        <div
          data-testid="listening-quiz-card"
          className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-[#111b2e] sm:p-6"
        >
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white sm:text-lg">
                {s.quizTitle}
              </h3>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{s.quizSubtitle}</p>
            </div>
            {quizQuestions.length > 0 && !quizFinished && (
              <span className="font-code text-xs font-bold text-indigo-600 tabular-nums dark:text-indigo-400">
                {quizIdx + 1} / {quizQuestions.length}
              </span>
            )}
          </div>

          {quizLoading ? (
            <div className="flex items-center gap-3 py-6 text-sm font-semibold text-slate-500 dark:text-slate-400">
              <Loader2 className="h-5 w-5 animate-spin text-indigo-500" aria-hidden="true" />
              <span>{s.loadingVideo}</span>
            </div>
          ) : quizQuestions.length === 0 ? (
            <p className="py-4 text-sm text-slate-500 dark:text-slate-400">
              {s.quizSubtitle}
            </p>
          ) : quizFinished ? (
            <div className="space-y-4 rounded-xl border border-slate-200 bg-slate-50 p-5 dark:border-slate-800 dark:bg-slate-900/60">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  {passedQuiz ? (
                    <CheckCircle2 className="h-6 w-6 text-emerald-500" aria-hidden="true" />
                  ) : (
                    <XCircle className="h-6 w-6 text-amber-500" aria-hidden="true" />
                  )}
                  <span className="text-lg font-extrabold text-slate-900 tabular-nums dark:text-white">
                    {answeredCorrectCount} / {quizQuestions.length} ({finalPct}%)
                  </span>
                </div>
              </div>
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                {passedQuiz ? s.quizPassedMsg : s.quizTryAgainMsg}
              </p>
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={handleResetQuiz}
                  className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 text-sm font-bold text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  <span>{s.quizRetryBtn}</span>
                </button>
                <button
                  type="button"
                  onClick={handleOpenNextVideo}
                  className="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-4 text-sm font-bold text-white hover:bg-indigo-500"
                >
                  <SkipForward className="h-4 w-4" aria-hidden="true" />
                  <span>{s.quizNextVideoBtn}</span>
                </button>
              </div>
            </div>
          ) : currentQ ? (
            <div className="space-y-4">
              <p
                dir="ltr"
                className="whitespace-pre-line font-en text-sm font-bold leading-relaxed text-slate-900 dark:text-slate-100 sm:text-base"
              >
                {currentQ.question}
              </p>

              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                {currentQ.options.map((opt, idx) => {
                  const isSelected = selectedOption === idx;
                  const isCorrect = idx === currentQ.correctIndex;
                  let cls =
                    'border-slate-200 bg-slate-50 text-slate-800 hover:border-indigo-400 hover:bg-indigo-50/60 dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-100 dark:hover:border-indigo-500';
                  if (selectedOption !== null) {
                    if (isCorrect) {
                      cls =
                        'border-emerald-500 bg-emerald-500/15 text-emerald-800 dark:text-emerald-200';
                    } else if (isSelected) {
                      cls = 'border-rose-500 bg-rose-500/15 text-rose-800 dark:text-rose-200';
                    } else {
                      cls =
                        'border-slate-200 bg-slate-50/50 text-slate-400 dark:border-slate-800 dark:bg-slate-900/30 dark:text-slate-500';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      type="button"
                      data-testid={`listening-quiz-opt-${idx}`}
                      disabled={selectedOption !== null}
                      onClick={() => handleSelectQuizOption(idx)}
                      dir="ltr"
                      className={`flex min-h-[48px] items-center justify-between gap-2 rounded-xl border px-4 py-3 text-left font-en text-sm font-semibold transition-colors ${cls}`}
                    >
                      <span>{opt}</span>
                      {selectedOption !== null && isCorrect && (
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" aria-hidden="true" />
                      )}
                      {selectedOption !== null && isSelected && !isCorrect && (
                        <XCircle className="h-4 w-4 shrink-0 text-rose-500" aria-hidden="true" />
                      )}
                    </button>
                  );
                })}
              </div>

              {selectedOption !== null && (
                <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900/70">
                  <p dir="ltr" className="flex-1 font-en text-xs leading-relaxed text-slate-700 dark:text-slate-300 sm:text-sm">
                    {currentQ.explanation}
                  </p>
                  <button
                    type="button"
                    data-testid="listening-quiz-next-btn"
                    onClick={handleAdvanceQuiz}
                    className="inline-flex h-10 shrink-0 items-center gap-1.5 rounded-xl bg-indigo-600 px-4 text-sm font-bold text-white hover:bg-indigo-500"
                  >
                    <span>
                      {quizIdx + 1 < quizQuestions.length
                        ? s.grammarNextQuestion
                        : s.quizSubmitBtn}
                    </span>
                  </button>
                </div>
              )}
            </div>
          ) : null}
        </div>
      </section>
    );
  }

  // ───────────────────────────────────────────────────────────────────────────
  // VIEW 2: CEFR LEVEL VIDEO CATALOG (Total Hours >= Required Hours to Advance)
  // ───────────────────────────────────────────────────────────────────────────
  if (selectedBand) {
    const cfg = LISTENING_LEVEL_MAP[selectedBand];
    const prog = computeListeningLevelProgress(cfg, settings.listeningProgress?.[selectedBand]);

    return (
      <section data-testid="listening-catalog-view" className="space-y-6">
        {/* Top bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setSelectedBand(null)}
            className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-[#111b2e] dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
            <span>{s.backToLevels}</span>
          </button>

          <div className="text-sm font-bold text-slate-600 dark:text-slate-300">
            <span className="font-en text-base font-extrabold text-indigo-600 dark:text-indigo-400">
              {selectedBand}
            </span>
            <span aria-hidden="true"> · </span>
            <span>{cfg.titleAr}</span>
          </div>
        </div>

        {/* Hours Progress & Catalog Summary Card */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-[#111b2e] sm:p-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="space-y-1">
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
                {selectedBand} — {cfg.titleAr}
              </h2>
              <p className="max-w-2xl text-sm text-slate-600 dark:text-slate-300">
                {cfg.nextBand
                  ? `${cfg.requiredHours} ${s.hoursToNext} ${cfg.nextBand}`
                  : `${cfg.requiredHours} ${s.hoursMastery}`}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-5 text-sm">
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {s.catalogHoursLabel}
                </div>
                <div className="font-code text-lg font-extrabold text-indigo-600 tabular-nums dark:text-indigo-400">
                  {catalog ? `${formatTotalHours(catalog.totalDurationSec)}h` : `${cfg.requiredHours}.0h`}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {s.videosCountLabel}
                </div>
                <div className="font-code text-lg font-extrabold text-slate-900 tabular-nums dark:text-white">
                  {catalog ? catalog.videos.length : '—'}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {s.watchedHoursLabel}
                </div>
                <div className="font-code text-lg font-extrabold text-emerald-600 tabular-nums dark:text-emerald-400">
                  {prog.watchedHours}h / {prog.requiredHours}h
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 space-y-1.5">
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
              <div
                className="h-full rounded-full bg-indigo-600 transition-all duration-300 dark:bg-sky-400"
                style={{ width: `${prog.percent}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 tabular-nums dark:text-slate-400">
              <span>{prog.percent}%</span>
              <span>
                {s.remainingLabel}: {prog.remainingHours}h
              </span>
            </div>
          </div>
        </div>

        {/* Search & Status Filter */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search
              className="pointer-events-none absolute start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={s.searchVideosPlaceholder}
              aria-label={s.searchVideosPlaceholder}
              className="h-11 w-full rounded-xl border border-slate-200 bg-white ps-10 pe-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-[#111b2e] dark:text-white"
            />
          </div>

          <div className="flex items-center gap-1 rounded-xl bg-slate-200/70 p-1 dark:bg-slate-800/80">
            {(['all', 'todo', 'done'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setStatusFilter(tab)}
                className={`rounded-lg px-3 py-1.5 text-xs font-bold transition-colors ${
                  statusFilter === tab
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
                }`}
              >
                {tab === 'all'
                  ? s.grammarAllCategories.split(' ')[0]
                  : tab === 'done'
                    ? s.completedBadge
                    : 'غير مكتمل'}
              </button>
            ))}
          </div>
        </div>

        {/* Catalog Grid */}
        {catalogLoading ? (
          <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-slate-200 bg-white py-16 dark:border-slate-800 dark:bg-[#111b2e]">
            <Loader2 className="h-8 w-8 animate-spin text-indigo-500" aria-hidden="true" />
            <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">
              {s.loadingCatalog}
            </p>
          </div>
        ) : catalogError ? (
          <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 p-6 text-center">
            <p className="text-sm font-bold text-rose-600 dark:text-rose-300">{catalogError}</p>
            <button
              type="button"
              onClick={() => void loadBandCatalog(selectedBand)}
              className="mt-3 inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-4 text-sm font-bold text-white"
            >
              {s.quizRetryBtn}
            </button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {filteredVideos.slice(0, visibleCount).map((vid, index) => {
                const isDone = completedSet.has(vid.id);
                return (
                  <button
                    key={vid.slug}
                    type="button"
                    data-testid={`listening-video-card-${index}`}
                    onClick={() => void openVideo(vid)}
                    className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white text-start transition-colors hover:border-indigo-400 dark:border-slate-800 dark:bg-[#111b2e] dark:hover:border-indigo-500"
                  >
                    <div className="relative aspect-video w-full overflow-hidden bg-slate-900">
                      {vid.posterUrl ? (
                        <img
                          src={vid.posterUrl}
                          alt={vid.title}
                          loading="lazy"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                          }}
                          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-slate-800 to-indigo-950">
                          <Headphones className="h-10 w-10 text-sky-400/70" aria-hidden="true" />
                        </div>
                      )}
                      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent" />

                      <div className="absolute bottom-2.5 end-2.5 rounded-md bg-slate-950/85 px-2 py-0.5 font-code text-xs font-bold text-white tabular-nums">
                        {formatDurationMMSS(vid.durationSec)}
                      </div>

                      <div className="absolute bottom-2.5 start-2.5 flex h-8 w-8 items-center justify-center rounded-full bg-indigo-600/95 text-white shadow-md">
                        <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                      </div>
                    </div>

                    <div className="flex flex-1 flex-col justify-between gap-2 p-4">
                      <h3
                        dir="ltr"
                        className="line-clamp-2 font-en text-sm font-bold leading-snug text-slate-900 group-hover:text-indigo-600 dark:text-slate-100 dark:group-hover:text-sky-300"
                      >
                        {vid.title}
                      </h3>

                      <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <span className="truncate">{vid.speaker}</span>
                        {isDone && (
                          <span className="inline-flex shrink-0 items-center gap-1 font-bold text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                            {s.completedBadge}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {filteredVideos.length > visibleCount && (
              <div className="flex justify-center pt-2">
                <button
                  type="button"
                  onClick={() => setVisibleCount((n) => n + 24)}
                  className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-300 bg-white px-6 text-sm font-bold text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:bg-[#111b2e] dark:text-slate-100 dark:hover:bg-slate-800"
                >
                  <span>
                    + {Math.min(24, filteredVideos.length - visibleCount)} {s.videosCountLabel}
                  </span>
                </button>
              </div>
            )}
          </>
        )}
      </section>
    );
  }

  // ───────────────────────────────────────────────────────────────────────────
  // VIEW 1: 7 CEFR LISTENING LEVELS OVERVIEW (A0 -> C2 + REQUIRED HOURS)
  // ───────────────────────────────────────────────────────────────────────────
  const totalRequiredAllLevels = LISTENING_LEVELS.reduce((sum, l) => sum + l.requiredHours, 0);
  const totalWatchedSecAll = LISTENING_LEVELS.reduce(
    (sum, l) => sum + (settings.listeningProgress?.[l.band]?.watchedSec || 0),
    0
  );

  return (
    <section className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-[#111b2e] sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-2xl space-y-2">
            <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
              {s.listeningTitle}
            </h1>
            <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              {s.listeningDesc}
            </p>
          </div>

          <div className="flex items-center gap-5 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-800 dark:bg-slate-900/70">
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">{s.watchedHoursLabel}</div>
              <div className="font-code text-xl font-extrabold text-indigo-600 tabular-nums dark:text-sky-400">
                {(totalWatchedSecAll / 3600).toFixed(1)}h
              </div>
            </div>
            <div className="h-8 w-px bg-slate-200 dark:bg-slate-700" aria-hidden="true" />
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">A0 → C2</div>
              <div className="font-code text-xl font-extrabold text-slate-900 tabular-nums dark:text-white">
                {totalRequiredAllLevels}h
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 7 CEFR Levels Grid */}
      <div
        data-testid="listening-levels-grid"
        className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3"
      >
        {LISTENING_LEVELS.map((lvl) => {
          const prog = computeListeningLevelProgress(lvl, settings.listeningProgress?.[lvl.band]);
          const meta = BAND_META[lvl.band];

          return (
            <button
              key={lvl.band}
              type="button"
              data-testid={`listening-level-${lvl.band}`}
              onClick={() => void loadBandCatalog(lvl.band)}
              className="group flex flex-col justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-5 text-start transition-colors hover:border-indigo-400 dark:border-slate-800 dark:bg-[#111b2e] dark:hover:border-indigo-500"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span
                      className="flex h-11 w-11 items-center justify-center rounded-xl font-en text-base font-black text-white shadow-xs"
                      style={{ backgroundColor: meta?.color || '#4f46e5' }}
                    >
                      {lvl.band}
                    </span>
                    <div>
                      <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
                        {lvl.titleAr}
                      </h2>
                      <div className="flex items-center gap-1 text-xs font-bold text-indigo-600 dark:text-sky-400">
                        <Clock className="h-3.5 w-3.5" aria-hidden="true" />
                        <span className="tabular-nums">
                          {lvl.nextBand
                            ? `${lvl.requiredHours} ${s.hoursToNext} ${lvl.nextBand}`
                            : `${lvl.requiredHours} ${s.hoursMastery}`}
                        </span>
                      </div>
                    </div>
                  </div>

                  <ChevronLeft
                    className="h-5 w-5 text-slate-400 transition-transform group-hover:-translate-x-0.5 group-hover:text-indigo-500"
                    aria-hidden="true"
                  />
                </div>

                <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                  {lvl.descAr}
                </p>
              </div>

              <div className="space-y-2 border-t border-slate-100 pt-3 dark:border-slate-800/80">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-500 tabular-nums dark:text-slate-400">
                  <span>
                    {prog.watchedHours}h / {prog.requiredHours}h
                  </span>
                  <span>{prog.percent}%</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${prog.percent}%`,
                      backgroundColor: meta?.color || '#4f46e5',
                    }}
                  />
                </div>
                <div className="flex items-center justify-between pt-1 text-xs font-bold text-indigo-600 dark:text-sky-400">
                  <span className="inline-flex items-center gap-1">
                    <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>11 لغة كابشن + اختبار</span>
                  </span>
                  <span>{s.openLevelBtn}</span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
