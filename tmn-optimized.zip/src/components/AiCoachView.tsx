import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  BookOpen,
  CheckCircle2,
  Eye,
  EyeOff,
  Image as ImageIcon,
  Lightbulb,
  MessageSquare,
  Mic,
  Play,
  RotateCcw,
  Send,
  Sparkles,
  Square,
  Volume2,
} from 'lucide-react';
import type {
  AiCoachModeId,
  AiCoachTurn,
  AiProviderPref,
  ArticleItem,
  CefrBand,
  CoachScenarioId,
} from '../types';
import { blobToBase64, sendAiCoachTurn } from '../utils/aiApi';
import { speakEn } from '../utils/audio';
import { useI18n } from '../contexts/LanguageContext';
import { AiCoachStudioPanel } from './AiCoachStudioPanel';

interface AiCoachViewProps {
  ttsRate: number;
  defaultBand: CefrBand;
  unsplashKey: string;
  initialMode?: AiCoachModeId;
  summaryArticle?: ArticleItem | null;
  onOpenArticles: () => void;
  onToast: (msg: string) => void;
}

interface ScenarioMeta {
  id: CoachScenarioId;
  label: string;
  greetingEn: string;
  greetingAr: string;
  starters: string[];
}

const SCENARIOS: ScenarioMeta[] = [
  {
    id: 'free',
    label: 'محادثة حرة',
    greetingEn: 'Hello! I am your English speaking coach. How was your day today, and what would you like to talk about?',
    greetingAr: 'مرحباً! أنا مدربك للمحادثة باللغة الإنجليزية. كيف كان يومك اليوم، وعن ماذا تحب أن نتحدث؟',
    starters: [
      'My day was good, I want to practice speaking.',
      'I am learning English to improve my career.',
    ],
  },
  {
    id: 'travel',
    label: 'السفر والمطار',
    greetingEn: 'Welcome to the check-in desk! May I see your passport and know where you are flying today?',
    greetingAr: 'أهلاً بك في مكتب تسجيل الوصول! هل يمكنني رؤية جواز سفرك ومعرفة وجهتك اليوم؟',
    starters: [
      'Here is my passport. I am flying to London.',
      'I would like a window seat, please.',
    ],
  },
  {
    id: 'interview',
    label: 'مقابلة عمل',
    greetingEn: 'Nice to meet you! Thank you for coming today. Could you start by telling me a little about yourself?',
    greetingAr: 'سعدت بلقائك! شكراً لحضورك اليوم. هل يمكنك البدء بالتعريف عن نفسك باختصار؟',
    starters: [
      'Thank you for having me. I have three years of experience.',
      'I am a hard-working person who loves learning new skills.',
    ],
  },
  {
    id: 'restaurant',
    label: 'المطعم والمقهى',
    greetingEn: 'Good evening! Welcome to our restaurant. Would you like to start with something to drink?',
    greetingAr: 'مساء الخير! أهلاً بك في مطعمنا. هل تود أن تبدأ بمشروب ما؟',
    starters: [
      'Yes, I would like a glass of orange juice, please.',
      'Could I see the menu first, please?',
    ],
  },
  {
    id: 'shopping',
    label: 'التسوق',
    greetingEn: 'Hi there! Welcome to our store. Are you looking for anything specific today?',
    greetingAr: 'أهلاً بك في متجرنا! هل تبحث عن شيء محدد اليوم؟',
    starters: [
      'I am looking for a blue jacket in medium size.',
      'How much does this shirt cost?',
    ],
  },
  {
    id: 'doctor',
    label: 'عند الطبيب',
    greetingEn: 'Hello! Please have a seat. What brings you to the clinic today? How are you feeling?',
    greetingAr: 'مرحباً! تفضل بالجلوس. ما الذي أتى بك إلى العيادة اليوم؟ كيف تشعر؟',
    starters: [
      'I have had a headache and a sore throat since yesterday.',
      'I feel very tired and I have a mild fever.',
    ],
  },
  {
    id: 'hotel',
    label: 'في الفندق',
    greetingEn: 'Good afternoon! Welcome to Grand Hotel. Do you have a reservation with us today?',
    greetingAr: 'طاب مساؤك! أهلاً بك في فندق غراند. هل لديك حجز معنا اليوم؟',
    starters: [
      'Yes, I booked a single room for three nights.',
      'Could I check in early and get a quiet room?',
    ],
  },
  {
    id: 'friends',
    label: 'التعارف والأصدقاء',
    greetingEn: 'Hey! Nice to meet you! Where are you from and what do you enjoy doing in your free time?',
    greetingAr: 'أهلاً! سررت بالتعرف عليك! من أين أنت وماذا تحب أن تفعل في وقت فراغك؟',
    starters: [
      'Nice to meet you too! I love reading and traveling.',
      'I enjoy watching movies and learning English.',
    ],
  },
];

const COACH_LEVELS: CefrBand[] = ['A1', 'A2', 'B1', 'B2', 'C1'];

const PROVIDER_OPTIONS: Array<{ id: AiProviderPref; label: string }> = [
  { id: 'auto', label: 'تلقائي مجاني (الأسرع)' },
  { id: 'open', label: 'نموذج مفتوح (GPT-OSS)' },
  { id: 'gemini', label: 'Gemini السريع' },
];

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}
interface SpeechRecognitionResultLike {
  0: SpeechRecognitionAlternativeLike;
}
interface SpeechRecognitionEventLike {
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}
interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
}
type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

function getSpeechRec(): SpeechRecognitionCtor | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

function makeInitialTurn(scenarioId: CoachScenarioId): AiCoachTurn {
  const sc = SCENARIOS.find((s) => s.id === scenarioId) || SCENARIOS[0];
  return {
    id: `init-${scenarioId}-${Date.now()}`,
    role: 'model',
    textEn: sc.greetingEn,
    textAr: sc.greetingAr,
    suggestions: sc.starters,
    timestamp: Date.now(),
  };
}

export function AiCoachView({
  ttsRate,
  defaultBand,
  unsplashKey,
  initialMode = 'chat',
  summaryArticle = null,
  onOpenArticles,
  onToast,
}: AiCoachViewProps) {
  const { t } = useI18n();
  const [coachMode, setCoachMode] = useState<AiCoachModeId>(
    initialMode === 'article_summary' && summaryArticle ? 'article_summary' : initialMode
  );
  const [scenario, setScenario] = useState<CoachScenarioId>('free');
  const [level, setLevel] = useState<CefrBand>(
    COACH_LEVELS.includes(defaultBand) ? defaultBand : 'A2'
  );
  const [provider, setProvider] = useState<AiProviderPref>('auto');
  const [autoSpeakReply, setAutoSpeakReply] = useState(true);
  const [showArabic, setShowArabic] = useState(true);

  useEffect(() => {
    if (initialMode === 'article_summary' && summaryArticle) {
      setCoachMode('article_summary');
    } else if (initialMode) {
      setCoachMode(initialMode);
    }
  }, [initialMode, summaryArticle]);

  const [turns, setTurns] = useState<AiCoachTurn[]>(() => [makeInitialTurn('free')]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Voice recording state
  const [recording, setRecording] = useState(false);
  const [liveSpeech, setLiveSpeech] = useState('');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const speechRecRef = useRef<SpeechRecognitionLike | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const transcriptRef = useRef('');
  const audioUrlsRef = useRef<string[]>([]);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [turns, sending]);

  useEffect(() => {
    return () => {
      try {
        speechRecRef.current?.stop();
      } catch {
        // Ignore
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        try {
          mediaRecorderRef.current.stop();
        } catch {
          // Ignore
        }
      }
      mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
      audioUrlsRef.current.forEach((u) => URL.revokeObjectURL(u));
    };
  }, []);

  const resetConversation = (nextScenario: CoachScenarioId) => {
    setScenario(nextScenario);
    setTurns([makeInitialTurn(nextScenario)]);
    setInput('');
    setErrorMsg('');
    setLiveSpeech('');
  };

  const submitTurn = useCallback(
    async (opts: { text?: string; audioBlob?: Blob; audioMimeType?: string }) => {
      const cleanText = (opts.text || '').trim();
      if (!cleanText && !opts.audioBlob) return;
      if (sending) return;

      setSending(true);
      setErrorMsg('');

      const audioUrl =
        opts.audioBlob && opts.audioBlob.size > 0
          ? URL.createObjectURL(opts.audioBlob)
          : undefined;
      if (audioUrl) audioUrlsRef.current.push(audioUrl);

      const userTurnId = `user-${Date.now()}`;
      const historyPayload = turns.slice(-12).map((t) => ({
        role: t.role,
        text: t.textEn,
      }));

      // Optimistically render learner's message
      const optimisticUserTurn: AiCoachTurn = {
        id: userTurnId,
        role: 'user',
        textEn: cleanText || 'رسالة صوتية — جاري الاستماع والتفريغ...',
        audioUrl,
        timestamp: Date.now(),
      };
      setTurns((prev) => [...prev, optimisticUserTurn]);
      setInput('');
      setLiveSpeech('');

      try {
        const audioBase64 =
          opts.audioBlob && opts.audioBlob.size > 0
            ? await blobToBase64(opts.audioBlob)
            : undefined;

        const resp = await sendAiCoachTurn({
          scenario,
          level,
          provider,
          history: historyPayload,
          userText: cleanText || undefined,
          audioBase64,
          audioMimeType: opts.audioMimeType || opts.audioBlob?.type || 'audio/webm',
        });

        setTurns((prev) => {
          const updated = prev.map((t) =>
            t.id === userTurnId
              ? {
                  ...t,
                  textEn: resp.userTranscript || cleanText || t.textEn,
                  correction: {
                    hasErrors: resp.hasErrors,
                    correctedEn: resp.correctedEn,
                    explanationAr: resp.explanationAr,
                    betterPhrasing: resp.betterPhrasing,
                    score: resp.score,
                  },
                }
              : t
          );

          const modelTurn: AiCoachTurn = {
            id: `model-${Date.now()}`,
            role: 'model',
            textEn: resp.replyEn,
            textAr: resp.replyAr,
            suggestions: resp.suggestions,
            providerLabel: resp.providerLabel,
            timestamp: Date.now(),
          };
          return [...updated, modelTurn];
        });

        if (autoSpeakReply && resp.replyEn) {
          speakEn(resp.replyEn, ttsRate);
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'تعذر الاتصال بالمدرب الذكي.';
        setErrorMsg(msg);
        // Remove optimistic turn if no text was sent and request failed
        setTurns((prev) => prev.filter((t) => t.id !== userTurnId));
        if (cleanText) setInput(cleanText);
      } finally {
        setSending(false);
      }
    },
    [sending, turns, scenario, level, provider, autoSpeakReply, ttsRate]
  );

  const stopVoiceCapture = useCallback(() => {
    try {
      speechRecRef.current?.stop();
    } catch {
      // Ignore
    }
    speechRecRef.current = null;

    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      recorder.stop();
    } else {
      mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
      setRecording(false);
      const text = transcriptRef.current.trim();
      if (text) {
        void submitTurn({ text });
      }
    }
  }, [submitTurn]);

  const startVoiceCapture = useCallback(async () => {
    if (recording) {
      stopVoiceCapture();
      return;
    }
    if (sending) return;

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    transcriptRef.current = '';
    chunksRef.current = [];
    setLiveSpeech('');
    setErrorMsg('');
    setRecording(true);

    const SR = getSpeechRec();
    if (SR) {
      try {
        const rec = new SR();
        rec.lang = 'en-US';
        rec.continuous = true;
        rec.interimResults = true;
        rec.onresult = (ev) => {
          let text = '';
          for (let i = 0; i < ev.results.length; i++) {
            text += ev.results[i][0].transcript + ' ';
          }
          const clean = text.trim();
          transcriptRef.current = clean;
          setLiveSpeech(clean);
        };
        rec.onerror = () => {
          // MediaRecorder handles audio fallback seamlessly
        };
        rec.start();
        speechRecRef.current = rec;
      } catch {
        speechRecRef.current = null;
      }
    }

    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaStreamRef.current = stream;

        const preferredMime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
          ? 'audio/webm;codecs=opus'
          : MediaRecorder.isTypeSupported('audio/webm')
            ? 'audio/webm'
            : MediaRecorder.isTypeSupported('audio/mp4')
              ? 'audio/mp4'
              : '';

        const recorder = preferredMime
          ? new MediaRecorder(stream, { mimeType: preferredMime })
          : new MediaRecorder(stream);

        const actualMime = (recorder.mimeType || preferredMime || 'audio/webm').split(';')[0];

        recorder.ondataavailable = (ev) => {
          if (ev.data && ev.data.size > 0) chunksRef.current.push(ev.data);
        };

        recorder.onstop = () => {
          const blob = new Blob(chunksRef.current, { type: actualMime });
          chunksRef.current = [];
          mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
          mediaStreamRef.current = null;
          mediaRecorderRef.current = null;
          setRecording(false);

          const spoken = transcriptRef.current.trim();
          if (blob.size > 500 || spoken) {
            void submitTurn({
              text: spoken || undefined,
              audioBlob: blob.size > 500 ? blob : undefined,
              audioMimeType: actualMime,
            });
          } else {
            onToast('لم يتم التقاط صوت واضح، حاول مجدداً.');
          }
        };

        mediaRecorderRef.current = recorder;
        recorder.start();
      } catch {
        if (!speechRecRef.current) {
          setRecording(false);
          onToast('يرجى السماح بصلاحية الميكروفون للتحدث مع المدرب الذكي.');
        }
      }
    } else if (!speechRecRef.current) {
      setRecording(false);
      onToast('التسجيل الصوتي غير مدعوم في هذا المتصفح، يمكنك الكتابة أدناه.');
    }
  }, [recording, sending, stopVoiceCapture, submitTurn, onToast]);

  const lastModelIdx = (() => {
    for (let i = turns.length - 1; i >= 0; i--) {
      if (turns[i].role === 'model') return i;
    }
    return -1;
  })();

  return (
    <div className="space-y-4">
      {/* Coach Header & Mode Switcher */}
      <section className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#162032] sm:p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
              <h1 className="text-lg font-extrabold text-slate-900 dark:text-slate-100 sm:text-xl">
                التدريب والمحادثة مع الذكاء الاصطناعي
              </h1>
            </div>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 sm:text-sm">
              {t.coachDesc}
            </p>
          </div>

          {coachMode === 'chat' && (
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setAutoSpeakReply((v) => !v)}
                className={`inline-flex h-9 items-center gap-1.5 rounded-lg border px-3 text-xs font-bold transition-colors ${
                  autoSpeakReply
                    ? 'border-indigo-500 bg-indigo-50 text-indigo-700 dark:border-indigo-500/60 dark:bg-indigo-950/50 dark:text-indigo-300'
                    : 'border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
                }`}
              >
                <Volume2 className="h-3.5 w-3.5" />
                {t.autoSpeakLabel}
              </button>

              <button
                type="button"
                onClick={() => setShowArabic((v) => !v)}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-600 hover:text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
              >
                {showArabic ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
                الترجمة
              </button>

              <button
                type="button"
                onClick={() => resetConversation(scenario)}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-600 hover:border-rose-300 hover:text-rose-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                {t.retry}
              </button>
            </div>
          )}
        </div>

        {/* 4 Training Modes Tabs */}
        <div
          role="tablist"
          aria-label={t.coachTitle}
          className="mt-4 grid grid-cols-2 gap-2 border-t border-slate-100 pt-3.5 dark:border-slate-800 sm:grid-cols-4"
        >
          {(
            [
              {
                id: 'chat' as const,
                label: t.coachModeChat,
                sub: 'Voice & Chat',
                Icon: MessageSquare,
              },
              {
                id: 'picture' as const,
                label: t.coachModePicture,
                sub: 'Describe Photo',
                Icon: ImageIcon,
              },
              {
                id: 'topic' as const,
                label: t.coachModeTopic,
                sub: 'Guided Writing',
                Icon: Lightbulb,
              },
              {
                id: 'article_summary' as const,
                label: t.coachModeSummary,
                sub: summaryArticle ? summaryArticle.title.slice(0, 22) : t.navReading,
                Icon: BookOpen,
              },
            ] as const
          ).map(({ id, label, sub, Icon }) => {
            const active = coachMode === id;
            return (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setCoachMode(id)}
                className={`flex items-center gap-2 rounded-xl border p-2.5 text-right transition-all sm:gap-2.5 sm:p-3 ${
                  active
                    ? 'border-indigo-500 bg-indigo-600 text-white shadow-xs'
                    : 'border-slate-200 bg-slate-50 text-slate-800 hover:border-indigo-300 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <div
                  className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg sm:h-9 sm:w-9 ${
                    active
                      ? 'bg-white/20 text-white'
                      : 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-400'
                  }`}
                >
                  <Icon className="h-4 w-4" aria-hidden="true" />
                </div>
                <div className="min-w-0">
                  <div className="text-[11px] leading-snug font-extrabold sm:text-sm">{label}</div>
                  <div
                    className={`truncate text-[10px] font-medium ${
                      active ? 'text-indigo-100' : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {sub}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Scenario Selector (Chat Mode Only) */}
        {coachMode === 'chat' && (
          <div className="mt-3.5 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-3.5 dark:border-slate-800">
            <div className="flex flex-wrap items-center gap-1.5">
              {SCENARIOS.map((sc) => (
                <button
                  key={sc.id}
                  type="button"
                  onClick={() => resetConversation(sc.id)}
                  className={`rounded-lg border px-3 py-1.5 text-xs font-bold transition-colors ${
                    scenario === sc.id
                      ? 'border-indigo-500 bg-indigo-600 text-white'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900/50 dark:text-slate-300'
                  }`}
                >
                  {sc.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Model (Chat Mode) & Level Controls (All Modes) */}
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-3 dark:border-slate-800">
          {coachMode === 'chat' ? (
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">النموذج المجاني:</span>
              {PROVIDER_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setProvider(opt.id)}
                  className={`h-8 rounded-md border px-2.5 text-xs font-bold transition-colors ${
                    provider === opt.id
                      ? 'border-emerald-500 bg-emerald-600 text-white'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-emerald-400 dark:border-slate-700 dark:bg-slate-900/50 dark:text-slate-300'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          ) : (
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              اختر مستواك ليتم ضبط التصحيح والأفكار حسب قدراتك:
            </div>
          )}

          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">المستوى:</span>
            {COACH_LEVELS.map((lv) => (
              <button
                key={lv}
                type="button"
                onClick={() => setLevel(lv)}
                className={`font-code h-8 w-9 rounded-md border text-xs font-bold transition-colors ${
                  level === lv
                    ? 'border-indigo-500 bg-indigo-600 text-white'
                    : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900/50 dark:text-slate-300'
                }`}
              >
                {lv}
              </button>
            ))}
          </div>
        </div>
      </section>

      {coachMode !== 'chat' ? (
        <AiCoachStudioPanel
          mode={coachMode}
          level={level}
          ttsRate={ttsRate}
          unsplashKey={unsplashKey}
          activeArticle={summaryArticle}
          onOpenArticles={onOpenArticles}
          onToast={onToast}
        />
      ) : (
      /* Conversation Stream */
      <section className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#162032] sm:p-5">
        <div className="space-y-4">
          {turns.map((turn, idx) => {
            if (turn.role === 'model') {
              const isLatestModel = idx === lastModelIdx && !sending;
              return (
                <div key={turn.id} className="space-y-2">
                  <div className="max-w-2xl rounded-2xl rounded-tr-sm border border-slate-200 bg-slate-50 p-4 dark:border-slate-700/80 dark:bg-slate-900/70">
                    <div className="mb-1.5 flex items-center justify-between gap-2">
                      <span className="text-[11px] font-extrabold text-indigo-600 dark:text-indigo-400">
                        المدرب الذكي ({level}){turn.providerLabel ? ` · ${turn.providerLabel}` : ''}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => speakEn(turn.textEn, ttsRate, onToast)}
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-200 bg-white px-2.5 text-[11px] font-bold text-slate-700 hover:border-indigo-400 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                        >
                          <Volume2 className="h-3.5 w-3.5" />
                          استمع
                        </button>
                        <button
                          type="button"
                          onClick={() => speakEn(turn.textEn, 0.68, onToast)}
                          className="inline-flex h-8 items-center rounded-md border border-slate-200 bg-white px-2 text-[11px] font-semibold text-slate-500 hover:text-slate-800 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                        >
                          بطيء
                        </button>
                      </div>
                    </div>

                    <p
                      dir="ltr"
                      className="text-left text-sm font-bold leading-relaxed text-slate-900 dark:text-slate-100 sm:text-base"
                    >
                      {turn.textEn}
                    </p>

                    {showArabic && turn.textAr && (
                      <p className="mt-2 border-t border-slate-200/70 pt-2 text-xs font-medium text-slate-600 dark:border-slate-700/70 dark:text-slate-300 sm:text-sm">
                        {turn.textAr}
                      </p>
                    )}
                  </div>

                  {/* Quick Suggested Replies */}
                  {isLatestModel && turn.suggestions && turn.suggestions.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 pr-1">
                      <span className="text-[11px] font-bold text-slate-400">اقتراحات للرد:</span>
                      {turn.suggestions.map((sug, sIdx) => (
                        <button
                          key={`${turn.id}-sug-${sIdx}`}
                          type="button"
                          onClick={() => void submitTurn({ text: sug })}
                          dir="ltr"
                          className="rounded-lg border border-indigo-200 bg-indigo-50/70 px-3 py-1.5 text-left text-xs font-semibold text-indigo-800 transition-colors hover:bg-indigo-100 dark:border-indigo-800/60 dark:bg-indigo-950/40 dark:text-indigo-200 dark:hover:bg-indigo-900/50"
                        >
                          {sug}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            }

            // Learner message + Inline Grammar Correction Card
            return (
              <div key={turn.id} className="flex flex-col items-end space-y-2">
                <div className="max-w-2xl rounded-2xl rounded-tl-sm bg-indigo-600 px-4 py-3 text-white">
                  <div className="mb-1 flex items-center justify-between gap-3 text-[11px] font-semibold text-indigo-100">
                    <span>أنت</span>
                    {turn.audioUrl && (
                      <button
                        type="button"
                        onClick={() => {
                          const a = new Audio(turn.audioUrl!);
                          void a.play();
                        }}
                        className="inline-flex items-center gap-1 rounded bg-white/15 px-2 py-0.5 text-[11px] font-bold text-white hover:bg-white/25"
                      >
                        <Play className="h-3 w-3 fill-current" />
                        اسمع صوتك
                      </button>
                    )}
                  </div>
                  <p dir="ltr" className="text-left text-sm font-semibold leading-relaxed sm:text-base">
                    {turn.textEn}
                  </p>
                </div>

                {/* Inline Grammar / Phrasing Feedback Card */}
                {turn.correction && (
                  <div
                    className={`w-full max-w-2xl rounded-xl border p-3.5 text-xs sm:text-sm ${
                      turn.correction.hasErrors
                        ? 'border-amber-300 bg-amber-50/80 dark:border-amber-700/70 dark:bg-amber-950/30'
                        : 'border-emerald-200 bg-emerald-50/80 dark:border-emerald-800/60 dark:bg-emerald-950/25'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 font-extrabold">
                        {turn.correction.hasErrors ? (
                          <>
                            <AlertCircle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                            <span className="text-amber-900 dark:text-amber-200">
                              تصحيح وتحسين الجملة
                            </span>
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                            <span className="text-emerald-800 dark:text-emerald-300">
                              ممتاز! جملتك صحيحة تماماً
                            </span>
                          </>
                        )}
                      </div>
                      <span className="font-code rounded bg-white/80 px-2 py-0.5 text-[11px] font-bold text-slate-700 tabular-nums dark:bg-slate-900/70 dark:text-slate-200">
                        الدقة {turn.correction.score}%
                      </span>
                    </div>

                    {turn.correction.hasErrors && turn.correction.correctedEn && (
                      <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-amber-200/80 bg-white px-3 py-2 dark:border-amber-800/50 dark:bg-slate-900/70">
                        <div>
                          <div className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400">
                            الصياغة الصحيحة:
                          </div>
                          <p
                            dir="ltr"
                            className="text-left text-sm font-bold text-slate-900 dark:text-slate-100"
                          >
                            {turn.correction.correctedEn}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => speakEn(turn.correction!.correctedEn, ttsRate, onToast)}
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-200 bg-slate-50 px-2.5 text-[11px] font-bold text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                        >
                          <Volume2 className="h-3.5 w-3.5" />
                          استمع
                        </button>
                      </div>
                    )}

                    {turn.correction.explanationAr && (
                      <p className="mt-2 leading-relaxed text-slate-700 dark:text-slate-200">
                        <span className="font-bold">الملاحظة: </span>
                        {turn.correction.explanationAr}
                      </p>
                    )}

                    {turn.correction.betterPhrasing &&
                      turn.correction.betterPhrasing.toLowerCase() !==
                        turn.correction.correctedEn.toLowerCase() && (
                        <div className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                          <span className="font-bold">طريقة أكثر طبيعية: </span>
                          <span dir="ltr" className="inline-block font-semibold text-indigo-700 dark:text-indigo-300">
                            {turn.correction.betterPhrasing}
                          </span>
                        </div>
                      )}
                  </div>
                )}
              </div>
            );
          })}

          {sending && (
            <div className="max-w-xs rounded-2xl rounded-tr-sm border border-slate-200 bg-slate-50 px-4 py-3 text-xs font-bold text-indigo-600 dark:border-slate-700 dark:bg-slate-900/70 dark:text-indigo-300">
              المدرب الذكي يراجع جملتك ويكتب الرد...
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs font-bold text-rose-700 dark:border-rose-800/70 dark:bg-rose-950/40 dark:text-rose-300">
            <span>{errorMsg}</span>
            {input.trim() && (
              <button
                type="button"
                onClick={() => void submitTurn({ text: input })}
                className="rounded-md bg-rose-600 px-3 py-1 text-xs font-bold text-white hover:bg-rose-700"
              >
                إعادة الإرسال
              </button>
            )}
          </div>
        )}

        {/* Active Recording Indicator */}
        {recording && (
          <div className="mt-4 rounded-lg border border-rose-300 bg-rose-50 p-3 dark:border-rose-800 dark:bg-rose-950/40">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-bold text-rose-700 dark:text-rose-300">
                <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-rose-600" />
                جاري الاستماع لك بالإنجليزية... اضغط «إرسال الصوت» عند الانتهاء
              </div>
              <button
                type="button"
                onClick={stopVoiceCapture}
                className="inline-flex h-8 items-center gap-1.5 rounded-md bg-rose-600 px-3 text-xs font-bold text-white hover:bg-rose-700"
              >
                <Square className="h-3 w-3 fill-current" />
                إرسال الصوت
              </button>
            </div>
            {liveSpeech && (
              <p dir="ltr" className="mt-2 text-left text-xs font-semibold text-slate-800 dark:text-slate-200">
                {liveSpeech}
              </p>
            )}
          </div>
        )}

        {/* Composer Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (input.trim()) {
              void submitTurn({ text: input });
            }
          }}
          className="mt-4 flex items-center gap-2 border-t border-slate-100 pt-4 dark:border-slate-800"
        >
          <button
            type="button"
            disabled={sending}
            onClick={() => void startVoiceCapture()}
            aria-label={recording ? 'إيقاف وإرسال الصوت' : 'تحدث بالإنجليزية بالميكروفون'}
            className={`inline-flex h-11 shrink-0 items-center gap-1.5 rounded-xl px-3.5 text-xs font-bold text-white transition-colors disabled:opacity-50 ${
              recording
                ? 'bg-rose-600 hover:bg-rose-700'
                : 'bg-emerald-600 hover:bg-emerald-700'
            }`}
          >
            {recording ? (
              <>
                <Square className="h-3.5 w-3.5 fill-current" />
                <span className="hidden sm:inline">إرسال الصوت</span>
              </>
            ) : (
              <>
                <Mic className="h-4 w-4" />
                <span className="hidden sm:inline">تحدث</span>
              </>
            )}
          </button>

          <input
            type="text"
            dir="ltr"
            value={input}
            disabled={sending || recording}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Write your reply in English or tap the mic..."
            className="h-11 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-left text-sm text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none disabled:opacity-60 dark:border-slate-700 dark:bg-slate-900/70 dark:text-slate-100 dark:focus:border-indigo-400 dark:focus:bg-slate-900"
          />

          <button
            type="submit"
            disabled={sending || recording || !input.trim()}
            aria-label="إرسال"
            className="inline-flex h-11 shrink-0 items-center gap-1.5 rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white transition-colors hover:bg-indigo-700 disabled:opacity-40"
          >
            <Send className="h-4 w-4" />
            <span className="hidden sm:inline">إرسال</span>
          </button>
        </form>
      </section>
      )}
    </div>
  );
}
