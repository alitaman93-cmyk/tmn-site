import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Award,
  BookOpen,
  CheckCircle2,
  Headphones,
  MessageSquare,
  Mic,
  PenTool,
  RotateCcw,
  Square,
  TrendingUp,
  Volume2,
  X,
} from 'lucide-react';
import type { CefrBand, PlacementResult, PlacementSkillId } from '../types';
import { useI18n } from '../contexts/LanguageContext';
import {
  computePlacementResult,
  PLACEMENT_LISTENING_ITEMS,
  PLACEMENT_READING_ITEMS,
  PLACEMENT_SENTENCE_ITEMS,
  PLACEMENT_SPEAKING_PROMPTS,
  PLACEMENT_VOCAB_ITEMS,
  PLACEMENT_WRITING_PROMPT,
  scoreWritingResponse,
} from '../utils/placementLogic';
import { evaluateSpokenMatch } from '../utils/sentenceLogic';
import { playSfx, speakEn } from '../utils/audio';

interface PlacementTestModalProps {
  open: boolean;
  sfxEnabled: boolean;
  ttsRate: number;
  existingResult?: PlacementResult | null;
  onClose: () => void;
  onComplete: (result: PlacementResult) => void;
}

type Stage =
  | 'intro'
  | 'vocabulary'
  | 'sentences'
  | 'reading'
  | 'writing'
  | 'listening'
  | 'speaking'
  | 'result';

const STAGES: Stage[] = [
  'vocabulary',
  'sentences',
  'reading',
  'writing',
  'listening',
  'speaking',
];

const BAND_COLORS: Record<CefrBand, string> = {
  A0: 'from-slate-500 to-slate-700',
  A1: 'from-emerald-500 to-teal-600',
  A2: 'from-teal-500 to-cyan-600',
  B1: 'from-sky-500 to-blue-600',
  B2: 'from-indigo-500 to-violet-600',
  C1: 'from-purple-500 to-fuchsia-600',
  C2: 'from-amber-400 to-orange-500',
};

export function PlacementTestModal({
  open,
  sfxEnabled,
  ttsRate,
  existingResult,
  onClose,
  onComplete,
}: PlacementTestModalProps) {
  const { t } = useI18n();
  const [stage, setStage] = useState<Stage>('intro');
  const [vocabAnswers, setVocabAnswers] = useState<Record<string, number>>({});
  const [sentAnswers, setSentAnswers] = useState<Record<string, number>>({});
  const [readAnswers, setReadAnswers] = useState<Record<string, number>>({});
  const [listenAnswers, setListenAnswers] = useState<Record<string, number>>({});
  const [writingText, setWritingText] = useState('');
  const [speakingScore, setSpeakingScore] = useState<number | null>(null);
  const [speakingHeard, setSpeakingHeard] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [result, setResult] = useState<PlacementResult | null>(existingResult || null);

  const recRef = useRef<{ stop: () => void } | null>(null);

  useEffect(() => {
    if (open) {
      if (existingResult) {
        setResult(existingResult);
        setStage('result');
      } else {
        setStage('intro');
      }
    }
    return () => {
      try {
        recRef.current?.stop();
      } catch {
        // Ignore
      }
    };
  }, [open, existingResult]);

  const resetTest = useCallback(() => {
    setVocabAnswers({});
    setSentAnswers({});
    setReadAnswers({});
    setListenAnswers({});
    setWritingText('');
    setSpeakingScore(null);
    setSpeakingHeard('');
    setResult(null);
    setStage('vocabulary');
  }, []);

  if (!open) return null;

  const skillLabel = (skill: PlacementSkillId): string => {
    switch (skill) {
      case 'vocabulary':
        return t.placementSkillVocab;
      case 'sentences':
        return t.placementSkillSentences;
      case 'reading':
        return t.placementSkillReading;
      case 'writing':
        return t.placementSkillWriting;
      case 'listening':
        return t.placementSkillListening;
      case 'speaking':
        return t.placementSkillSpeaking;
    }
  };

  const finishPlacement = (overrideSpeakScore?: number) => {
    const scoreMcq = (items: typeof PLACEMENT_VOCAB_ITEMS, ans: Record<string, number>) => {
      const correct = items.filter((it) => ans[it.id] === it.correctIndex).length;
      return Math.round((correct / items.length) * 100);
    };

    const computed = computePlacementResult({
      vocabulary: scoreMcq(PLACEMENT_VOCAB_ITEMS, vocabAnswers),
      sentences: scoreMcq(PLACEMENT_SENTENCE_ITEMS, sentAnswers),
      reading: scoreMcq(PLACEMENT_READING_ITEMS, readAnswers),
      writing: scoreWritingResponse(writingText),
      listening: scoreMcq(PLACEMENT_LISTENING_ITEMS, listenAnswers),
      speaking: overrideSpeakScore ?? speakingScore ?? 55,
    });

    setResult(computed);
    setStage('result');
    playSfx('win', sfxEnabled);
  };

  const startVoiceCheck = () => {
    const target = PLACEMENT_SPEAKING_PROMPTS[0].sentenceEn;
    const win = window as unknown as {
      SpeechRecognition?: new () => {
        lang: string;
        interimResults: boolean;
        maxAlternatives: number;
        onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
        onerror: (() => void) | null;
        onend: (() => void) | null;
        start: () => void;
        stop: () => void;
      };
      webkitSpeechRecognition?: new () => {
        lang: string;
        interimResults: boolean;
        maxAlternatives: number;
        onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
        onerror: (() => void) | null;
        onend: (() => void) | null;
        start: () => void;
        stop: () => void;
      };
    };
    const Ctor = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!Ctor) {
      setSpeakingHeard('Speech recognition is not supported on this browser — use self-rating below.');
      return;
    }
    try {
      const rec = new Ctor();
      rec.lang = 'en-US';
      rec.interimResults = false;
      rec.maxAlternatives = 1;
      rec.onresult = (ev) => {
        const transcript = ev.results?.[0]?.[0]?.transcript || '';
        setSpeakingHeard(transcript);
        const evalRes = evaluateSpokenMatch(target, transcript);
        setSpeakingScore(evalRes.score);
        playSfx(evalRes.score >= 70 ? 'ok' : 'tap', sfxEnabled);
      };
      rec.onerror = () => {
        setIsRecording(false);
      };
      rec.onend = () => {
        setIsRecording(false);
      };
      recRef.current = rec;
      setIsRecording(true);
      rec.start();
    } catch {
      setIsRecording(false);
    }
  };

  const stopVoiceCheck = () => {
    try {
      recRef.current?.stop();
    } catch {
      // Ignore
    }
    setIsRecording(false);
  };

  const stepIndex = STAGES.indexOf(stage);
  const progressPct = stepIndex >= 0 ? Math.round(((stepIndex + 1) / STAGES.length) * 100) : 0;

  return (
    <div
      data-testid="placement-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-3 backdrop-blur-sm sm:p-4"
      onClick={onClose}
    >
      <div
        className="relative flex max-h-[92vh] w-full max-w-2xl flex-col overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--card)] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-2 border-b border-[var(--border)] bg-[var(--card2)] px-5 py-3.5">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-500/15 text-sky-400">
              <Award className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-[var(--ink)] sm:text-base">{t.placementTitle}</h2>
              {stepIndex >= 0 && (
                <p className="text-[11px] font-bold text-sky-400">
                  {t.placementStepOf} {stepIndex + 1} / {STAGES.length}
                </p>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="flex h-8 w-8 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--card)] text-[var(--muted)] hover:text-[var(--ink)]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Progress Bar */}
        {stepIndex >= 0 && (
          <div className="h-1.5 w-full bg-[var(--card2)]">
            <div
              className="h-full bg-gradient-to-l from-sky-400 to-indigo-500 transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        )}

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5">
          {/* INTRO */}
          {stage === 'intro' && (
            <div className="space-y-5 text-center">
              <p className="mx-auto max-w-lg text-sm leading-relaxed text-[var(--muted)]">
                {t.placementSubtitle}
              </p>
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                {[
                  { icon: BookOpen, label: t.placementSkillVocab },
                  { icon: MessageSquare, label: t.placementSkillSentences },
                  { icon: BookOpen, label: t.placementSkillReading },
                  { icon: PenTool, label: t.placementSkillWriting },
                  { icon: Headphones, label: t.placementSkillListening },
                  { icon: Mic, label: t.placementSkillSpeaking },
                ].map((s, i) => (
                  <div
                    key={i}
                    className="flex flex-col items-center gap-1.5 rounded-2xl border border-[var(--border)] bg-[var(--card2)] p-3"
                  >
                    <s.icon className="h-5 w-5 text-sky-400" />
                    <span className="text-xs font-extrabold text-[var(--ink)]">{s.label}</span>
                  </div>
                ))}
              </div>
              <button
                type="button"
                data-testid="placement-start-btn"
                onClick={() => setStage('vocabulary')}
                className="inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-sky-500 to-indigo-600 px-8 py-3.5 text-sm font-black text-white shadow-lg"
              >
                <Award className="h-4 w-4" />
                <span>{t.placementStart}</span>
              </button>
            </div>
          )}

          {/* VOCABULARY */}
          {stage === 'vocabulary' && (
            <div className="space-y-4">
              <h3 className="text-sm font-black text-sky-400">1. {t.placementSkillVocab}</h3>
              {PLACEMENT_VOCAB_ITEMS.map((item, idx) => (
                <div
                  key={item.id}
                  className="rounded-2xl border border-[var(--border)] bg-[var(--card2)] p-4"
                >
                  <p dir="ltr" className="mb-3 text-left text-sm font-bold text-[var(--ink)]">
                    {idx + 1}. {item.promptEn}
                  </p>
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                    {item.options.map((opt, oi) => (
                      <button
                        key={oi}
                        type="button"
                        dir="ltr"
                        data-testid={`placement-${item.id}-opt-${oi}`}
                        onClick={() => setVocabAnswers((p) => ({ ...p, [item.id]: oi }))}
                        className={`rounded-xl border px-3 py-2 text-left text-xs font-bold transition ${
                          vocabAnswers[item.id] === oi
                            ? 'border-sky-400 bg-sky-500/20 text-sky-200'
                            : 'border-[var(--border)] bg-[var(--card)] text-[var(--ink)] hover:border-sky-400/50'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              <div className="flex justify-end">
                <button
                  type="button"
                  data-testid="placement-next-btn"
                  onClick={() => setStage('sentences')}
                  className="rounded-xl bg-sky-500 px-6 py-2.5 text-xs font-black text-slate-950"
                >
                  {t.next}
                </button>
              </div>
            </div>
          )}

          {/* SENTENCES */}
          {stage === 'sentences' && (
            <div className="space-y-4">
              <h3 className="text-sm font-black text-sky-400">2. {t.placementSkillSentences}</h3>
              {PLACEMENT_SENTENCE_ITEMS.map((item, idx) => (
                <div
                  key={item.id}
                  className="rounded-2xl border border-[var(--border)] bg-[var(--card2)] p-4"
                >
                  <p dir="ltr" className="mb-3 text-left text-sm font-bold text-[var(--ink)]">
                    {idx + 1}. {item.promptEn}
                  </p>
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                    {item.options.map((opt, oi) => (
                      <button
                        key={oi}
                        type="button"
                        dir="ltr"
                        data-testid={`placement-${item.id}-opt-${oi}`}
                        onClick={() => setSentAnswers((p) => ({ ...p, [item.id]: oi }))}
                        className={`rounded-xl border px-3 py-2 text-left text-xs font-bold transition ${
                          sentAnswers[item.id] === oi
                            ? 'border-sky-400 bg-sky-500/20 text-sky-200'
                            : 'border-[var(--border)] bg-[var(--card)] text-[var(--ink)] hover:border-sky-400/50'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => setStage('vocabulary')}
                  className="rounded-xl border border-[var(--border)] px-4 py-2 text-xs font-bold text-[var(--muted)]"
                >
                  {t.back}
                </button>
                <button
                  type="button"
                  data-testid="placement-next-btn"
                  onClick={() => setStage('reading')}
                  className="rounded-xl bg-sky-500 px-6 py-2.5 text-xs font-black text-slate-950"
                >
                  {t.next}
                </button>
              </div>
            </div>
          )}

          {/* READING */}
          {stage === 'reading' && (
            <div className="space-y-4">
              <h3 className="text-sm font-black text-sky-400">3. {t.placementSkillReading}</h3>
              {PLACEMENT_READING_ITEMS.map((item, idx) => (
                <div
                  key={item.id}
                  className="rounded-2xl border border-[var(--border)] bg-[var(--card2)] p-4"
                >
                  {item.passageEn && (
                    <p
                      dir="ltr"
                      className="mb-3 rounded-xl border border-sky-500/20 bg-[var(--card)] p-3 text-left text-xs leading-relaxed text-[var(--ink)]"
                    >
                      {item.passageEn}
                    </p>
                  )}
                  <p dir="ltr" className="mb-2.5 text-left text-sm font-bold text-[var(--ink)]">
                    {idx + 1}. {item.promptEn}
                  </p>
                  <div className="grid grid-cols-1 gap-2">
                    {item.options.map((opt, oi) => (
                      <button
                        key={oi}
                        type="button"
                        dir="ltr"
                        data-testid={`placement-${item.id}-opt-${oi}`}
                        onClick={() => setReadAnswers((p) => ({ ...p, [item.id]: oi }))}
                        className={`rounded-xl border px-3 py-2 text-left text-xs font-bold transition ${
                          readAnswers[item.id] === oi
                            ? 'border-sky-400 bg-sky-500/20 text-sky-200'
                            : 'border-[var(--border)] bg-[var(--card)] text-[var(--ink)] hover:border-sky-400/50'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => setStage('sentences')}
                  className="rounded-xl border border-[var(--border)] px-4 py-2 text-xs font-bold text-[var(--muted)]"
                >
                  {t.back}
                </button>
                <button
                  type="button"
                  data-testid="placement-next-btn"
                  onClick={() => setStage('writing')}
                  className="rounded-xl bg-sky-500 px-6 py-2.5 text-xs font-black text-slate-950"
                >
                  {t.next}
                </button>
              </div>
            </div>
          )}

          {/* WRITING */}
          {stage === 'writing' && (
            <div className="space-y-4">
              <h3 className="text-sm font-black text-sky-400">4. {t.placementSkillWriting}</h3>
              <div className="rounded-2xl border border-[var(--border)] bg-[var(--card2)] p-4">
                <p dir="ltr" className="mb-3 text-left text-sm font-bold text-[var(--ink)]">
                  {PLACEMENT_WRITING_PROMPT.promptEn}
                </p>
                <textarea
                  data-testid="placement-writing-input"
                  dir="ltr"
                  rows={4}
                  value={writingText}
                  onChange={(e) => setWritingText(e.target.value)}
                  placeholder="Example: Every morning I drink coffee and study English for thirty minutes because I want to travel and work internationally."
                  className="w-full rounded-xl border border-[var(--border)] bg-[var(--card)] p-3 text-left text-sm text-[var(--ink)] outline-none focus:border-sky-400"
                />
                <div className="mt-2 flex items-center justify-between text-[11px] font-bold text-[var(--muted)]">
                  <span>
                    Words: {(writingText.match(/[A-Za-z]+/g) || []).length} / {PLACEMENT_WRITING_PROMPT.minWords}+
                  </span>
                  <span>Live rubric score: {scoreWritingResponse(writingText)}%</span>
                </div>
              </div>
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => setStage('reading')}
                  className="rounded-xl border border-[var(--border)] px-4 py-2 text-xs font-bold text-[var(--muted)]"
                >
                  {t.back}
                </button>
                <button
                  type="button"
                  data-testid="placement-next-btn"
                  onClick={() => setStage('listening')}
                  className="rounded-xl bg-sky-500 px-6 py-2.5 text-xs font-black text-slate-950"
                >
                  {t.next}
                </button>
              </div>
            </div>
          )}

          {/* LISTENING */}
          {stage === 'listening' && (
            <div className="space-y-4">
              <h3 className="text-sm font-black text-sky-400">5. {t.placementSkillListening}</h3>
              {PLACEMENT_LISTENING_ITEMS.map((item, idx) => (
                <div
                  key={item.id}
                  className="rounded-2xl border border-[var(--border)] bg-[var(--card2)] p-4"
                >
                  <div className="mb-3 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => speakEn(item.audioEn || '', ttsRate)}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-sky-500 px-3.5 py-2 text-xs font-black text-slate-950"
                    >
                      <Volume2 className="h-4 w-4" />
                      <span>{t.listen} #{idx + 1}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => speakEn(item.audioEn || '', 0.72)}
                      className="inline-flex items-center gap-1 rounded-xl border border-[var(--border)] bg-[var(--card)] px-3 py-2 text-xs font-bold text-[var(--ink)]"
                    >
                      <span>{t.slow}</span>
                    </button>
                  </div>
                  <p dir="ltr" className="mb-2.5 text-left text-sm font-bold text-[var(--ink)]">
                    {item.promptEn}
                  </p>
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                    {item.options.map((opt, oi) => (
                      <button
                        key={oi}
                        type="button"
                        dir="ltr"
                        data-testid={`placement-${item.id}-opt-${oi}`}
                        onClick={() => setListenAnswers((p) => ({ ...p, [item.id]: oi }))}
                        className={`rounded-xl border px-3 py-2 text-left text-xs font-bold transition ${
                          listenAnswers[item.id] === oi
                            ? 'border-sky-400 bg-sky-500/20 text-sky-200'
                            : 'border-[var(--border)] bg-[var(--card)] text-[var(--ink)] hover:border-sky-400/50'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => setStage('writing')}
                  className="rounded-xl border border-[var(--border)] px-4 py-2 text-xs font-bold text-[var(--muted)]"
                >
                  {t.back}
                </button>
                <button
                  type="button"
                  data-testid="placement-next-btn"
                  onClick={() => setStage('speaking')}
                  className="rounded-xl bg-sky-500 px-6 py-2.5 text-xs font-black text-slate-950"
                >
                  {t.next}
                </button>
              </div>
            </div>
          )}

          {/* SPEAKING */}
          {stage === 'speaking' && (
            <div className="space-y-4">
              <h3 className="text-sm font-black text-sky-400">6. {t.placementSkillSpeaking}</h3>
              <div className="rounded-2xl border border-[var(--border)] bg-[var(--card2)] p-4">
                <p
                  dir="ltr"
                  className="mb-3 rounded-xl border border-sky-500/25 bg-[var(--card)] p-3.5 text-left text-base font-extrabold text-[var(--ink)]"
                >
                  “{PLACEMENT_SPEAKING_PROMPTS[0].sentenceEn}”
                </p>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => speakEn(PLACEMENT_SPEAKING_PROMPTS[0].sentenceEn, ttsRate)}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-[var(--border)] bg-[var(--card)] px-3.5 py-2 text-xs font-bold text-[var(--ink)]"
                  >
                    <Volume2 className="h-4 w-4 text-sky-400" />
                    <span>{t.listen}</span>
                  </button>

                  {!isRecording ? (
                    <button
                      type="button"
                      onClick={startVoiceCheck}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-rose-500 px-4 py-2 text-xs font-black text-white"
                    >
                      <Mic className="h-4 w-4" />
                      <span>Record / سجّل</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={stopVoiceCheck}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-amber-500 px-4 py-2 text-xs font-black text-slate-950"
                    >
                      <Square className="h-4 w-4" />
                      <span>Stop</span>
                    </button>
                  )}
                </div>

                {speakingHeard && (
                  <p dir="ltr" className="mt-3 text-left text-xs font-semibold text-sky-300">
                    Heard: “{speakingHeard}” {speakingScore !== null ? `(${speakingScore}%)` : ''}
                  </p>
                )}

                {/* Accessible self-rating fallback when mic is unavailable */}
                <div className="mt-4 border-t border-[var(--border)] pt-3">
                  <p className="mb-2 text-xs font-bold text-[var(--muted)]">{t.placementSpeakSkip}</p>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { label: 'A1–A2 (35%)', score: 35 },
                      { label: 'B1–B2 (70%)', score: 70 },
                      { label: 'C1–C2 (92%)', score: 92 },
                    ].map((opt) => (
                      <button
                        key={opt.score}
                        type="button"
                        data-testid={`placement-speak-self-${opt.score}`}
                        onClick={() => setSpeakingScore(opt.score)}
                        className={`rounded-xl border px-2.5 py-2 text-xs font-extrabold transition ${
                          speakingScore === opt.score
                            ? 'border-emerald-400 bg-emerald-500/20 text-emerald-300'
                            : 'border-[var(--border)] bg-[var(--card)] text-[var(--ink)]'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => setStage('listening')}
                  className="rounded-xl border border-[var(--border)] px-4 py-2 text-xs font-bold text-[var(--muted)]"
                >
                  {t.back}
                </button>
                <button
                  type="button"
                  data-testid="placement-finish-btn"
                  onClick={() => finishPlacement()}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-500 px-6 py-2.5 text-xs font-black text-slate-950"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>{t.check}</span>
                </button>
              </div>
            </div>
          )}

          {/* RESULT DASHBOARD */}
          {stage === 'result' && result && (
            <div data-testid="placement-result" className="space-y-4">
              <div
                className={`rounded-3xl bg-gradient-to-br ${BAND_COLORS[result.cefrBand]} p-5 text-white shadow-lg`}
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="text-xs font-bold uppercase tracking-wider text-white/80">
                      {t.placementYourLevel}
                    </div>
                    <div className="mt-1 flex items-baseline gap-2.5">
                      <span
                        data-testid="placement-cefr-badge"
                        className="text-4xl font-black tracking-tight"
                      >
                        {result.cefrBand}
                      </span>
                      <span className="text-sm font-bold text-white/90">
                        ({result.overallScore} / 100)
                      </span>
                    </div>
                  </div>
                  <div className="rounded-2xl bg-black/25 px-4 py-2.5 text-xs font-extrabold backdrop-blur-sm">
                    {result.nextBand ? (
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-amber-300" />
                        <span>
                          {t.placementNextTarget}:{' '}
                          <strong className="text-amber-300">
                            +{result.pointsToNext}% → {result.nextBand}
                          </strong>
                        </span>
                      </div>
                    ) : (
                      <span>{t.placementTopLevel}</span>
                    )}
                  </div>
                </div>

                {/* Progress toward next band */}
                {result.nextBand && (
                  <div className="mt-4">
                    <div className="mb-1 flex justify-between text-[11px] font-bold text-white/85">
                      <span>{result.cefrBand}</span>
                      <span>{result.progressInBandPct}%</span>
                      <span>{result.nextBand}</span>
                    </div>
                    <div className="h-2.5 w-full overflow-hidden rounded-full bg-black/30">
                      <div
                        className="h-full rounded-full bg-white transition-all"
                        style={{ width: `${Math.max(8, result.progressInBandPct)}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* 6-Skill Breakdown */}
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                {(Object.keys(result.skillScores) as PlacementSkillId[]).map((sk) => {
                  const val = result.skillScores[sk];
                  const isWeak = result.weakestSkills.includes(sk);
                  return (
                    <div
                      key={sk}
                      className={`rounded-2xl border p-3 ${
                        isWeak
                          ? 'border-amber-500/35 bg-amber-500/5'
                          : 'border-[var(--border)] bg-[var(--card2)]'
                      }`}
                    >
                      <div className="mb-1.5 flex items-center justify-between text-xs font-extrabold">
                        <span className="text-[var(--ink)]">{skillLabel(sk)}</span>
                        <span className={val >= 70 ? 'text-emerald-400' : 'text-amber-400'}>
                          {val}%
                        </span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-[var(--card)]">
                        <div
                          className={`h-full rounded-full ${
                            val >= 70 ? 'bg-emerald-500' : 'bg-amber-400'
                          }`}
                          style={{ width: `${Math.max(6, val)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                <button
                  type="button"
                  onClick={resetTest}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-[var(--border)] bg-[var(--card2)] px-4 py-2.5 text-xs font-bold text-[var(--ink)]"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>{t.placementRetake}</span>
                </button>
                <button
                  type="button"
                  data-testid="placement-apply-btn"
                  onClick={() => {
                    onComplete(result);
                    onClose();
                  }}
                  className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-l from-sky-500 to-indigo-600 px-6 py-3 text-xs font-black text-white shadow-lg"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>{t.placementApplyLevel}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
