import { useEffect, useMemo, useState } from 'react';
import {
  Brain,
  Eye,
  Image as ImageIcon,
  Star,
  Trophy,
  Volume2,
} from 'lucide-react';
import { BAND_META } from '../data/constants';
import type { PersistedSettings, SrsRating, VocabStore } from '../types';
import {
  formatIntervalAr,
  orderPoolForSrs,
  previewSrsIntervals,
} from '../utils/srsLogic';
import { prefetchWordsBatch } from '../utils/prefetchEngine';

interface StudyArenaProps {
  store: VocabStore;
  settings: PersistedSettings;
  indices: number[];
  autoSpeak: boolean;
  favoritesSet: Set<number>;
  onSpeak: (text: string) => void;
  onSfx: (type: 'ok' | 'err' | 'tap' | 'win') => void;
  onReviewSrsCard: (wordIdx: number, rating: SrsRating) => void;
  onToggleFavorite: (wordIdx: number) => void;
  onOpenWordDetail: (wordIdx: number) => void;
  onHudChange: (hud: { current: number; total: number; correct: number; wrong: number }) => void;
  onDone: () => void;
}

export function StudyArena({
  store,
  settings,
  indices,
  autoSpeak,
  favoritesSet,
  onSpeak,
  onSfx,
  onReviewSrsCard,
  onToggleFavorite,
  onOpenWordDetail,
  onHudChange,
  onDone,
}: StudyArenaProps) {
  const [queue, setQueue] = useState<number[]>(() =>
    orderPoolForSrs(indices, settings.srsCards || {})
  );
  const [pos, setPos] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [reviewedCount, setReviewedCount] = useState(0);
  const [againCount, setAgainCount] = useState(0);
  const [finished, setFinished] = useState(false);

  const idx = queue[pos];
  const word = idx !== undefined ? store.words[idx] : undefined;
  const srsCard = word ? (settings.srsCards || {})[word.id] : undefined;

  const intervalLabels = useMemo(
    () => (word ? previewSrsIntervals(srsCard, word.id) : null),
    [word?.id, srsCard]
  );

  useEffect(() => {
    onHudChange({
      current: Math.min(pos + 1, Math.max(1, queue.length)),
      total: queue.length,
      correct: reviewedCount,
      wrong: againCount,
    });
  }, [pos, queue.length, reviewedCount, againCount, onHudChange]);

  useEffect(() => {
    if (autoSpeak && word && !finished) {
      const t = setTimeout(() => onSpeak(word.en), 120);
      return () => clearTimeout(t);
    }
  }, [pos, autoSpeak, word?.en, finished]);

  useEffect(() => {
    if (finished) return;
    const upcoming = queue
      .slice(pos + 1, pos + 4)
      .map((id) => store.words[id])
      .filter((w): w is NonNullable<typeof w> => Boolean(w));
    if (upcoming.length > 0) {
      prefetchWordsBatch(
        upcoming,
        {
          backendUrl: settings.backendUrl,
          pixabayKey: settings.pixabayKey,
          unsplashKey: settings.unsplashKey,
        },
        3,
        false
      );
    }
  }, [
    finished,
    queue,
    pos,
    store.words,
    settings.backendUrl,
    settings.pixabayKey,
    settings.unsplashKey,
  ]);

  if (finished) {
    return (
      <div className="mx-auto max-w-2xl space-y-5 pb-20">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-400">
            <Trophy className="h-7 w-7" aria-hidden="true" />
          </div>
          <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
            أنهيت جلسة التكرار المتباعد (أنكي)!
          </h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            تم جدولة كل بطاقة ذكياً حسب تقييمك لتظهر مجدداً في الوقت الأمثل لترسيخها في الذاكرة.
          </p>
          <div className="mt-4 flex flex-wrap items-center justify-center gap-4 text-sm font-bold">
            <span className="text-emerald-600 dark:text-emerald-400">
              بطاقات محفوظة: {reviewedCount}
            </span>
            <span aria-hidden="true">·</span>
            <span className="text-amber-600 dark:text-amber-400">
              أُعيدت للتكرار: {againCount}
            </span>
          </div>
          <button
            type="button"
            onClick={onDone}
            className="mt-6 inline-flex h-11 items-center justify-center rounded-xl bg-indigo-600 px-6 text-sm font-bold text-white hover:bg-indigo-700"
          >
            العودة
          </button>
        </div>
      </div>
    );
  }

  if (!word || !intervalLabels) return null;

  const pct = Math.round(((pos + (flipped ? 0.5 : 0)) / Math.max(1, queue.length)) * 100);
  const isFav = favoritesSet.has(word.id);

  const cardStatusLabel = !srsCard || srsCard.lastReviewedAt === 0
    ? 'بطاقة جديدة'
    : srsCard.dueAt <= Date.now()
      ? 'مستحقة للمراجعة'
      : `مراجعة · الفاصل الحالي: ${formatIntervalAr(srsCard.intervalDays)}`;

  const handleRate = (rating: SrsRating) => {
    onReviewSrsCard(word.id, rating);

    if (rating === 'again') {
      onSfx('err');
      setAgainCount((c) => c + 1);
      // Re-insert the card a few slots ahead inside this Anki session so the user practices it again!
      setQueue((prev) => {
        const next = prev.slice();
        const insertAt = Math.min(next.length, pos + 3);
        next.splice(insertAt, 0, word.id);
        return next;
      });
      setPos((p) => p + 1);
      setFlipped(false);
      return;
    }

    onSfx('ok');
    setReviewedCount((c) => c + 1);
    if (pos >= queue.length - 1) {
      onSfx('win');
      setFinished(true);
    } else {
      setPos((p) => p + 1);
      setFlipped(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-5 pb-36">
      {/* Progress & Anki SRS Status Header */}
      <div className="space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold">
          <span className="inline-flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400">
            <Brain className="h-4 w-4" aria-hidden="true" />
            <span>نظام أنكي للتكرار المتباعد (SM-2)</span>
          </span>
          <span className="rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-[11px] text-slate-600 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-300">
            {cardStatusLabel}
          </span>
        </div>
        <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
          <div
            className="h-full rounded-full bg-indigo-600 transition-all duration-200 dark:bg-indigo-500"
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>

      {/* Flashcard */}
      <button
        type="button"
        onClick={() => {
          setFlipped((f) => !f);
          onSfx('tap');
        }}
        className="flex min-h-[280px] w-full flex-col items-center justify-center rounded-2xl border-2 border-slate-200 bg-white p-8 text-center transition-colors hover:border-indigo-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 dark:border-slate-700 dark:bg-[#131c2e] dark:hover:border-indigo-500"
      >
        <div className="mb-3 flex items-center gap-2">
          <span
            className={`flex h-7 w-10 items-center justify-center rounded-lg font-en text-xs font-extrabold text-white ${BAND_META[word.band].bgClass}`}
          >
            {word.band}
          </span>
          {srsCard && srsCard.repetitions > 0 && (
            <span className="rounded-lg bg-slate-100 px-2 py-1 font-code text-[11px] font-bold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
              مراجعات: {srsCard.repetitions} · EF {srsCard.easeFactor.toFixed(2)}
            </span>
          )}
        </div>

        <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
          {flipped ? 'المعنى بالعربية — قيّم مدى تذكرك أدناه' : 'تذكّر المعنى ثم اضغط لإظهار الإجابة'}
        </span>

        <div
          className={`mt-3 text-3xl font-extrabold text-slate-900 dark:text-slate-100 sm:text-4xl ${
            flipped ? '' : 'font-en'
          }`}
          dir={flipped ? 'rtl' : 'ltr'}
        >
          {flipped ? word.ar : word.en}
        </div>

        {flipped && (
          <div
            className="mt-2 font-en text-base font-semibold text-slate-500 dark:text-slate-400"
            dir="ltr"
          >
            {word.en}
          </div>
        )}
      </button>

      {/* Secondary Actions */}
      <div className="flex flex-wrap items-center justify-center gap-2.5">
        <button
          type="button"
          onClick={() => onOpenWordDetail(word.id)}
          className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-200 dark:hover:bg-slate-800"
        >
          <ImageIcon className="h-4 w-4" aria-hidden="true" />
          <span>التفاصيل والنطق</span>
        </button>
        <button
          type="button"
          onClick={() => onSpeak(word.en)}
          className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-200 dark:hover:bg-slate-800"
        >
          <Volume2 className="h-4 w-4" aria-hidden="true" />
          <span>اسمع النطق</span>
        </button>
        <button
          type="button"
          onClick={() => onToggleFavorite(word.id)}
          className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-200 dark:hover:bg-slate-800"
        >
          <Star
            className={`h-4 w-4 ${isFav ? 'fill-amber-400 text-amber-500' : ''}`}
            aria-hidden="true"
          />
          <span>{isFav ? 'في المفضلة' : 'مفضلة'}</span>
        </button>
      </div>

      {/* Bottom Anki Rating Dock */}
      <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-200 bg-white/95 p-3 backdrop-blur-md dark:border-slate-800 dark:bg-[#0f172a]/95">
        <div className="mx-auto max-w-2xl">
          {!flipped ? (
            <button
              type="button"
              onClick={() => {
                setFlipped(true);
                onSfx('tap');
              }}
              className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 px-6 text-sm font-bold text-white transition-colors hover:bg-indigo-700"
            >
              <Eye className="h-4 w-4" aria-hidden="true" />
              <span>أظهر الإجابة</span>
            </button>
          ) : (
            <div className="grid grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => handleRate('again')}
                className="flex min-h-[54px] flex-col items-center justify-center rounded-xl border border-rose-500/40 bg-rose-50 px-2 py-1.5 text-rose-700 transition-colors hover:bg-rose-100 dark:bg-rose-500/15 dark:text-rose-300 dark:hover:bg-rose-500/25"
              >
                <span className="text-xs font-extrabold sm:text-sm">مرة أخرى</span>
                <span className="mt-0.5 text-[10px] font-semibold opacity-80">
                  {intervalLabels.again}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleRate('hard')}
                className="flex min-h-[54px] flex-col items-center justify-center rounded-xl border border-amber-500/40 bg-amber-50 px-2 py-1.5 text-amber-700 transition-colors hover:bg-amber-100 dark:bg-amber-500/15 dark:text-amber-300 dark:hover:bg-amber-500/25"
              >
                <span className="text-xs font-extrabold sm:text-sm">صعب</span>
                <span className="mt-0.5 text-[10px] font-semibold opacity-80">
                  {intervalLabels.hard}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleRate('good')}
                className="flex min-h-[54px] flex-col items-center justify-center rounded-xl border border-emerald-500/40 bg-emerald-600 px-2 py-1.5 text-white transition-colors hover:bg-emerald-700"
              >
                <span className="text-xs font-extrabold sm:text-sm">جيد</span>
                <span className="mt-0.5 text-[10px] font-semibold text-emerald-100">
                  {intervalLabels.good}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleRate('easy')}
                className="flex min-h-[54px] flex-col items-center justify-center rounded-xl border border-sky-500/40 bg-sky-600 px-2 py-1.5 text-white transition-colors hover:bg-sky-700"
              >
                <span className="text-xs font-extrabold sm:text-sm">سهل</span>
                <span className="mt-0.5 text-[10px] font-semibold text-sky-100">
                  {intervalLabels.easy}
                </span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
