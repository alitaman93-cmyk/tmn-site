import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Keyboard,
  Lightbulb,
  Link2,
  Loader2,
  Mic,
  RefreshCw,
  Send,
  Sparkles,
  Square,
  Volume2,
  XCircle,
} from 'lucide-react';
import type { PatternSwapEvalResult, PatternSwapSlotType, SentenceEntry } from '../types';
import { blobToBase64, evaluateSentenceSwapWithAi, translateSentencesBatch } from '../utils/aiApi';
import {
  buildPatternSwapChain,
  buildPatternSwapRound,
  evaluatePatternSwapOffline,
  SLOT_META,
  type PatternSwapItem,
} from '../utils/patternSwapLogic';
import {
  parseSentencesTSV,
  SENTENCE_SECTIONS,
  STARTER_AR_TRANSLATIONS,
  STARTER_SENTENCES_TSV,
} from '../utils/sentenceLogic';
import { splitSentenceTokens } from '../utils/sentenceProGamesLogic';
import {
  idbGetDataset,
  idbGetSentenceTranslations,
  idbSetDataset,
  idbSetSentenceTranslations,
} from '../utils/storage';

interface SentencePatternSwapGameProps {
  onSpeak: (text: string) => void;
  onSpeakSlow: (text: string) => void;
  onSfx: (type: 'ok' | 'err' | 'tap' | 'win') => void;
  onEarnXp: (xpDelta: number) => void;
  onMarkPracticedSentence: (num: number) => void;
  onHudChange: (hud: { current: number; total: number; correct: number; wrong: number }) => void;
  onRoundComplete?: () => void;
  onExit: () => void;
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((e: {
    resultIndex: number;
    results: { length: number; [i: number]: { 0: { transcript: string } } };
  }) => void) | null;
  onerror: ((e: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

function getSpeechRecCtor(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

const SECTION_QUICK_IDS = [
  'all',
  'daily_chat',
  'travel',
  'shopping',
  'basics',
  'modals',
  'plans',
  'opinions',
  'tech_work',
  'time_schedule',
];

const SLOT_FILTER_OPTIONS: Array<{ id: PatternSwapSlotType | 'all'; label: string }> = [
  { id: 'all', label: 'كل الأنماط' },
  { id: 'subject', label: 'الفاعل' },
  { id: 'verb', label: 'الفعل' },
  { id: 'object', label: 'المفعول به' },
  { id: 'preposition', label: 'حرف الجر/الوقت' },
  { id: 'free', label: 'تبديل حر' },
];

export function SentencePatternSwapGame({
  onSpeak,
  onSpeakSlow,
  onSfx,
  onEarnXp,
  onMarkPracticedSentence,
  onHudChange,
  onRoundComplete,
  onExit,
}: SentencePatternSwapGameProps) {
  const [sentences, setSentences] = useState<SentenceEntry[]>(() =>
    parseSentencesTSV(STARTER_SENTENCES_TSV)
  );
  const [arMap, setArMap] = useState<Record<string, string>>(() => ({
    ...STARTER_AR_TRANSLATIONS,
  }));

  const [sectionId, setSectionId] = useState<string>('all');
  const [slotFilter, setSlotFilter] = useState<PatternSwapSlotType | 'all'>('all');
  const [chainMode, setChainMode] = useState(false);
  const [seed, setSeed] = useState(() => Date.now());

  const [itemIdx, setItemIdx] = useState(0);
  const [chainStep, setChainStep] = useState(0);
  const [hintsOpen, setHintsOpen] = useState(false);
  const [showTyping, setShowTyping] = useState(false);
  const [typedSentence, setTypedSentence] = useState('');

  const [recording, setRecording] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [evaluating, setEvaluating] = useState(false);
  const [result, setResult] = useState<PatternSwapEvalResult | null>(null);

  const [validCount, setValidCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);

  const speechRecRef = useRef<SpeechRecognitionLike | null>(null);
  const mediaRecRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const transcriptRef = useRef('');

  // Load 21k sentence corpus offline-first
  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const cached = await idbGetDataset('sentences-21k');
        if (active && cached && cached.length > 1000) {
          const parsed = parseSentencesTSV(cached);
          if (active && parsed.length > 50) setSentences(parsed);
        }
      } catch {
        // Ignore IDB miss
      }
      try {
        const res = await fetch('/sentences-21k.tsv');
        if (res.ok) {
          const txt = await res.text();
          const parsed = parseSentencesTSV(txt);
          if (active && parsed.length > 50) {
            setSentences(parsed);
            void idbSetDataset('sentences-21k', txt);
          }
        }
      } catch {
        // Offline resilient
      }
    };
    void load();
    return () => {
      active = false;
    };
  }, []);

  const roundItems = useMemo(
    () =>
      buildPatternSwapRound(
        sentences,
        arMap,
        sectionId,
        12,
        seed,
        slotFilter === 'all' ? undefined : slotFilter
      ),
    [sentences, arMap, sectionId, seed, slotFilter]
  );

  // Prefetch Arabic translations for dynamic corpus items lacking translations
  useEffect(() => {
    const missing = roundItems
      .filter((it) => !it.sentenceAr && !arMap[it.sentenceEn])
      .map((it) => it.sentenceEn);
    if (!missing.length) return;
    let active = true;
    const run = async () => {
      try {
        const cached = await idbGetSentenceTranslations(missing);
        if (active && Object.keys(cached).length > 0) {
          setArMap((prev) => ({ ...prev, ...cached }));
        }
        const stillMissing = missing.filter((en) => !cached[en]);
        if (stillMissing.length > 0) {
          const fresh = await translateSentencesBatch(stillMissing.slice(0, 8), undefined, 'ar');
          if (active && Object.keys(fresh).length > 0) {
            setArMap((prev) => ({ ...prev, ...fresh }));
            void idbSetSentenceTranslations(fresh);
          }
        }
      } catch {
        // Offline safe
      }
    };
    void run();
    return () => {
      active = false;
    };
  }, [roundItems, arMap]);

  const baseItem: PatternSwapItem | undefined = roundItems[itemIdx % Math.max(1, roundItems.length)];
  const activeChain = useMemo(
    () => (baseItem ? buildPatternSwapChain(baseItem) : []),
    [baseItem]
  );
  const currentItem: PatternSwapItem | undefined = chainMode
    ? activeChain[Math.min(2, chainStep)]
    : baseItem;

  useEffect(() => {
    onHudChange({
      current: Math.min(roundItems.length, itemIdx + 1),
      total: Math.max(1, roundItems.length),
      correct: validCount,
      wrong: wrongCount,
    });
  }, [itemIdx, roundItems.length, validCount, wrongCount, onHudChange]);

  // Cleanup active media stream on unmount
  useEffect(() => {
    return () => {
      try {
        speechRecRef.current?.stop();
      } catch {
        // Ignore
      }
      if (mediaRecRef.current && mediaRecRef.current.state !== 'inactive') {
        try {
          mediaRecRef.current.stop();
        } catch {
          // Ignore
        }
      }
      mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const runEvaluation = useCallback(
    async (userText: string, audioBlob?: Blob, audioMimeType?: string) => {
      if (!currentItem) return;
      const trimmed = userText.trim();
      if (!trimmed && !audioBlob) return;

      setEvaluating(true);
      setResult(null);

      let evalOutcome: PatternSwapEvalResult | null = null;
      try {
        const audioBase64 = audioBlob ? await blobToBase64(audioBlob) : undefined;
        evalOutcome = await evaluateSentenceSwapWithAi({
          originalSentence: currentItem.sentenceEn,
          targetSlotType: currentItem.slotType,
          targetSlotText: currentItem.slotText,
          userSentence: trimmed || undefined,
          audioBase64,
          audioMimeType,
        });
      } catch {
        // Seamless silent fallback to 100% offline structural evaluator (zero error screen!)
        evalOutcome = evaluatePatternSwapOffline({
          originalSentence: currentItem.sentenceEn,
          targetSlotType: currentItem.slotType,
          targetSlotText: currentItem.slotText,
          userSentence: trimmed || currentItem.sentenceEn,
        });
      }

      setEvaluating(false);
      setResult(evalOutcome);

      if (evalOutcome.swappedCorrectly && evalOutcome.score >= 70) {
        onSfx('win');
        setValidCount((c) => c + 1);
        const isChainComplete = chainMode && chainStep === 2;
        onEarnXp(isChainComplete ? 30 : 15);
        onMarkPracticedSentence(itemIdx + 1);
        if (isChainComplete) onRoundComplete?.();
      } else {
        onSfx('err');
        setWrongCount((w) => w + 1);
      }
    },
    [
      currentItem,
      chainMode,
      chainStep,
      itemIdx,
      onSfx,
      onEarnXp,
      onMarkPracticedSentence,
      onRoundComplete,
    ]
  );

  const stopRecordingAndEvaluate = useCallback(() => {
    setRecording(false);
    try {
      speechRecRef.current?.stop();
    } catch {
      // Ignore
    }

    const mr = mediaRecRef.current;
    if (mr && mr.state !== 'inactive') {
      mr.onstop = () => {
        const mime = mr.mimeType || 'audio/webm';
        const blob =
          audioChunksRef.current.length > 0
            ? new Blob(audioChunksRef.current, { type: mime })
            : undefined;
        mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
        mediaStreamRef.current = null;
        void runEvaluation(transcriptRef.current, blob, mime);
      };
      try {
        mr.stop();
      } catch {
        void runEvaluation(transcriptRef.current);
      }
    } else {
      mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
      if (transcriptRef.current.trim()) {
        void runEvaluation(transcriptRef.current);
      }
    }
  }, [runEvaluation]);

  const startRecording = async () => {
    if (recording || evaluating) return;
    setResult(null);
    setLiveTranscript('');
    transcriptRef.current = '';
    audioChunksRef.current = [];
    setRecording(true);
    onSfx('tap');

    // Start Web SpeechRecognition if available
    const Ctor = getSpeechRecCtor();
    if (Ctor) {
      try {
        const rec = new Ctor();
        rec.lang = 'en-US';
        rec.continuous = true;
        rec.interimResults = true;
        rec.onresult = (e) => {
          let txt = '';
          for (let i = 0; i < e.results.length; i++) {
            txt += e.results[i][0].transcript + ' ';
          }
          transcriptRef.current = txt.trim();
          setLiveTranscript(transcriptRef.current);
        };
        rec.onerror = () => {
          // MediaRecorder fallback remains active
        };
        speechRecRef.current = rec;
        rec.start();
      } catch {
        // Proceed with MediaRecorder
      }
    }

    // Start MediaRecorder fallback for universal mobile/Safari support
    if (typeof navigator !== 'undefined' && navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaStreamRef.current = stream;
        if (typeof MediaRecorder !== 'undefined') {
          const mr = new MediaRecorder(stream);
          mr.ondataavailable = (ev) => {
            if (ev.data && ev.data.size > 0) audioChunksRef.current.push(ev.data);
          };
          mediaRecRef.current = mr;
          mr.start();
        }
      } catch {
        if (!Ctor) {
          setRecording(false);
          setShowTyping(true);
        }
      }
    } else if (!Ctor) {
      setRecording(false);
      setShowTyping(true);
    }
  };

  const handleNextSentence = () => {
    setResult(null);
    setTypedSentence('');
    setLiveTranscript('');
    setHintsOpen(false);
    if (chainMode && chainStep < 2) {
      setChainStep((s) => s + 1);
    } else {
      setChainStep(0);
      setItemIdx((i) => i + 1);
    }
  };

  const handleAnotherSwapSameSentence = () => {
    setResult(null);
    setTypedSentence('');
    setLiveTranscript('');
    setHintsOpen(false);
    if (!chainMode) {
      setChainMode(true);
      setChainStep(1);
    } else {
      setChainStep((s) => (s + 1) % 3);
    }
  };

  if (!currentItem) return null;

  const slotMeta = SLOT_META[currentItem.slotType];
  const tokens = splitSentenceTokens(currentItem.sentenceEn);
  const displayAr = currentItem.sentenceAr || arMap[currentItem.sentenceEn] || '';

  // Compute inline word diff between original and user's heardText
  const origWordSet = new Set(
    currentItem.sentenceEn
      .toLowerCase()
      .replace(/[^a-z0-9'\s]/g, ' ')
      .split(/\s+/)
      .filter(Boolean)
  );
  const wrongTokenSet = new Set(
    (result?.wrongParts || [])
      .flatMap((wp) => wp.wrong.toLowerCase().split(/\s+/))
      .filter(Boolean)
  );

  return (
    <div data-testid="pattern-swap-game" className="mx-auto max-w-2xl space-y-5">
      {/* Header Row */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-xs">
            <RefreshCw className="h-5 w-5" aria-hidden="true" />
          </div>
          <div>
            <h1 className="text-lg font-extrabold text-slate-900 dark:text-white sm:text-xl">
              تحدي تبديل الأنماط (Pattern Swap)
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              درّب عقلك على التحدث بعفوية عبر تبديل جزء واحد من الجملة الإنجليزية
            </p>
          </div>
        </div>

        <button
          type="button"
          data-testid="pattern-swap-exit-btn"
          onClick={onExit}
          className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 text-xs font-bold text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-[#11192b] dark:text-slate-200"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>خروج</span>
        </button>
      </div>

      {/* Topic & Mode Toolbar */}
      <div className="tmn-card space-y-3 rounded-2xl p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5">
            {SLOT_FILTER_OPTIONS.map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => {
                  setSlotFilter(opt.id);
                  setItemIdx(0);
                  setChainStep(0);
                  setResult(null);
                }}
                className={`rounded-lg px-2.5 py-1 text-xs font-bold transition-colors ${
                  slotFilter === opt.id
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* 3x Chain Mode Toggle */}
          <button
            type="button"
            data-testid="pattern-swap-chain-toggle"
            onClick={() => {
              setChainMode((c) => !c);
              setChainStep(0);
              setResult(null);
            }}
            className={`inline-flex h-9 items-center gap-1.5 rounded-xl border px-3 text-xs font-extrabold transition-colors ${
              chainMode
                ? 'border-emerald-500 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                : 'border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
            }`}
          >
            <Link2 className="h-3.5 w-3.5" aria-hidden="true" />
            <span>سلسلة 3 تحويلات</span>
          </button>
        </div>

        {/* Sentence Topic Selector */}
        <div className="flex items-center gap-1.5 overflow-x-auto border-t border-slate-200/70 pt-2.5 pb-1 dark:border-slate-800">
          {SECTION_QUICK_IDS.map((secId) => {
            const label =
              secId === 'all'
                ? 'كل المواضيع'
                : SENTENCE_SECTIONS.find((s) => s.id === secId)?.label || secId;
            return (
              <button
                key={secId}
                type="button"
                onClick={() => {
                  setSectionId(secId);
                  setSeed(Date.now());
                  setItemIdx(0);
                  setChainStep(0);
                  setResult(null);
                }}
                className={`shrink-0 whitespace-nowrap rounded-md px-2.5 py-1 text-[11px] font-bold transition-colors ${
                  sectionId === secId
                    ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950'
                    : 'text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>
      </div>

      {/* 3x Chain Stepper (when Chain Mode enabled) */}
      {chainMode && (
        <div
          data-testid="pattern-swap-chain-bar"
          className="tmn-card flex items-center justify-between gap-3 rounded-2xl px-4 py-3"
        >
          <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400">
            سلسلة 3 تحويلات لنفس الجملة (+30 XP عند الإتمام)
          </span>
          <div className="flex items-center gap-1.5">
            {activeChain.map((step, sIdx) => (
              <span
                key={step.id}
                className={`rounded-lg px-2.5 py-1 text-[11px] font-bold ${
                  sIdx < chainStep
                    ? 'bg-emerald-600 text-white'
                    : sIdx === chainStep
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
                }`}
              >
                {sIdx + 1}. {SLOT_META[step.slotType].shortAr}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Model Sentence Card */}
      <div className="tmn-card rounded-3xl p-6 sm:p-7">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span
            className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-1 text-xs font-extrabold ${slotMeta.badgeClass}`}
          >
            <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{slotMeta.labelAr}</span>
          </span>
          <span className="font-code text-xs font-bold text-slate-400">
            CEFR {currentItem.band}
          </span>
        </div>

        {/* Mission Banner */}
        <p className="mt-3 text-sm font-bold text-slate-700 dark:text-slate-200">
          {currentItem.missionAr}
        </p>

        {/* Highlighted English Model Sentence */}
        <div
          dir="ltr"
          data-testid="pattern-swap-model-sentence"
          className="mt-4 rounded-2xl border border-slate-200/80 bg-slate-50/90 p-4 font-en text-xl font-extrabold leading-relaxed text-slate-900 dark:border-slate-800 dark:bg-[#0d1424] dark:text-white sm:text-2xl"
        >
          {tokens.map((tok, i) => {
            const isHighlighted =
              i >= currentItem.slotStartWordIdx && i <= currentItem.slotEndWordIdx;
            return (
              <span key={i} className="inline">
                {i > 0 ? ' ' : ''}
                {isHighlighted ? (
                  <span className={slotMeta.highlightClass}>{tok.raw}</span>
                ) : (
                  tok.raw
                )}
              </span>
            );
          })}
        </div>

        {displayAr && (
          <p className="mt-2.5 text-sm font-semibold text-slate-500 dark:text-slate-400">
            {displayAr}
          </p>
        )}

        {/* Audio & Collapsible Hidden Hints Row */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onSpeak(currentItem.sentenceEn)}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              <Volume2 className="h-4 w-4 text-indigo-500" aria-hidden="true" />
              <span>استمع للنطق</span>
            </button>
            <button
              type="button"
              onClick={() => onSpeakSlow(currentItem.sentenceEn)}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              <span>نطق بطيء 0.7x</span>
            </button>
          </div>

          <button
            type="button"
            data-testid="pattern-swap-hints-btn"
            aria-expanded={hintsOpen}
            onClick={() => setHintsOpen((o) => !o)}
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-amber-400/40 bg-amber-500/10 px-3 text-xs font-bold text-amber-700 hover:bg-amber-500/20 dark:text-amber-300"
          >
            <Lightbulb className="h-3.5 w-3.5" aria-hidden="true" />
            <span>أفكار مساعدة</span>
            {hintsOpen ? (
              <ChevronUp className="h-3.5 w-3.5" aria-hidden="true" />
            ) : (
              <ChevronDown className="h-3.5 w-3.5" aria-hidden="true" />
            )}
          </button>
        </div>

        {/* Collapsible Replacement Hints (collapsed by default) */}
        {hintsOpen && (
          <div
            data-testid="pattern-swap-hints-panel"
            className="mt-3 rounded-2xl border border-amber-400/30 bg-amber-500/8 p-3.5"
          >
            <div className="mb-2 text-xs font-bold text-amber-700 dark:text-amber-300">
              أفكار سريعة لاستبدال «{currentItem.slotText}»:
            </div>
            <div dir="ltr" className="flex flex-wrap gap-2">
              {currentItem.hints.map((h, hIdx) => (
                <span
                  key={hIdx}
                  className="rounded-lg border border-amber-400/30 bg-white/80 px-2.5 py-1 font-en text-xs font-bold text-slate-800 dark:bg-slate-900 dark:text-amber-200"
                >
                  {h}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Voice-First + Typing Input Panel */}
      <div className="tmn-card rounded-3xl p-6 text-center">
        <div className="flex flex-col items-center">
          <button
            type="button"
            data-testid="pattern-swap-mic-btn"
            disabled={evaluating}
            onClick={() => (recording ? stopRecordingAndEvaluate() : void startRecording())}
            aria-label={recording ? 'إيقاف التسجيل وتقييم الجملة' : 'ابدأ التحدث بجملتك الجديدة'}
            className={`flex h-20 w-20 items-center justify-center rounded-full shadow-lg transition-transform active:scale-95 disabled:opacity-50 ${
              recording
                ? 'bg-rose-600 text-white ring-8 ring-rose-500/25'
                : 'bg-indigo-600 text-white hover:bg-indigo-700 ring-8 ring-indigo-500/15'
            }`}
          >
            {evaluating ? (
              <Loader2 className="h-7 w-7 animate-spin" aria-hidden="true" />
            ) : recording ? (
              <Square className="h-7 w-7" aria-hidden="true" />
            ) : (
              <Mic className="h-8 w-8" aria-hidden="true" />
            )}
          </button>

          <span className="mt-3 text-xs font-bold text-slate-500 dark:text-slate-400">
            {evaluating
              ? 'جاري تحليل جملتك وتوافق القواعد...'
              : recording
                ? 'تكلّم الآن بالإنجليزية ثم اضغط لإيقاف التقييم'
                : 'اضغط الميكروفون وانطق جملتك الجديدة بصوتك'}
          </span>

          {liveTranscript && (
            <div
              dir="ltr"
              className="mt-3 rounded-xl bg-slate-100 px-3.5 py-2 font-en text-sm font-bold text-slate-800 dark:bg-slate-900 dark:text-slate-100"
            >
              “{liveTranscript}”
            </div>
          )}
        </div>

        {/* Toggle Typing Mode */}
        <div className="mt-4 flex justify-center">
          <button
            type="button"
            data-testid="pattern-swap-type-toggle"
            onClick={() => setShowTyping((s) => !s)}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:underline dark:text-indigo-400"
          >
            <Keyboard className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{showTyping ? 'إخفاء الكتابة' : 'أو اكتب جملتك الجديدة (للمكان الهادئ)'}</span>
          </button>
        </div>

        {showTyping && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (typedSentence.trim()) void runEvaluation(typedSentence);
            }}
            className="mt-3 flex flex-col gap-2 sm:flex-row"
          >
            <input
              type="text"
              dir="ltr"
              data-testid="pattern-swap-text-input"
              value={typedSentence}
              onChange={(e) => setTypedSentence(e.target.value)}
              placeholder="Write your new transformed English sentence..."
              className="h-11 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3.5 font-en text-sm font-semibold text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-[#0d1424] dark:text-white"
            />
            <button
              type="submit"
              data-testid="pattern-swap-submit-btn"
              disabled={evaluating || !typedSentence.trim()}
              className="inline-flex h-11 items-center justify-center gap-1.5 rounded-xl bg-indigo-600 px-5 text-xs font-extrabold text-white hover:bg-indigo-700 disabled:opacity-50"
            >
              <Send className="h-4 w-4" aria-hidden="true" />
              <span>تقييم الجملة</span>
            </button>
          </form>
        )}
      </div>

      {/* Rich Evaluation Feedback & Audio Reinforcement */}
      {result && (
        <div
          data-testid="pattern-swap-feedback"
          className="tmn-card space-y-4 rounded-3xl p-6"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-base font-extrabold">
              {result.swappedCorrectly && result.isGrammaticallyCorrect ? (
                <span className="inline-flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                  <CheckCircle2 className="h-5 w-5" aria-hidden="true" />
                  تحويل رائع وصحيح قواعدياً!
                </span>
              ) : result.swappedCorrectly ? (
                <span className="inline-flex items-center gap-1.5 text-amber-600 dark:text-amber-400">
                  <Sparkles className="h-5 w-5" aria-hidden="true" />
                  تبديل ذكي مع ملاحظة قواعدية بسيطة
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-rose-600 dark:text-rose-400">
                  <XCircle className="h-5 w-5" aria-hidden="true" />
                  جرّب تعديل الجزء المظلّل مجدداً
                </span>
              )}
            </div>
            <span className="font-code text-lg font-extrabold tabular-nums text-indigo-600 dark:text-indigo-400">
              {result.score}/100
            </span>
          </div>

          {/* Inline Diff Highlighting Changed Words (green) & Grammar Slips (red) */}
          {result.heardText && (
            <div>
              <div className="mb-1 text-xs font-bold text-slate-400">جملتك:</div>
              <div
                dir="ltr"
                className="flex flex-wrap gap-1.5 rounded-2xl bg-slate-50 p-3.5 font-en text-base font-bold dark:bg-[#0d1424]"
              >
                {result.heardText.split(/\s+/).map((w, i) => {
                  const clean = w.toLowerCase().replace(/[^a-z0-9']/g, '');
                  const isWrong = wrongTokenSet.has(clean);
                  const isChanged = !origWordSet.has(clean);
                  return (
                    <span
                      key={i}
                      className={`rounded-md px-1.5 py-0.5 ${
                        isWrong
                          ? 'bg-rose-500/20 text-rose-600 underline decoration-rose-500 dark:text-rose-300'
                          : isChanged
                            ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300'
                            : 'text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      {w}
                    </span>
                  );
                })}
              </div>
            </div>
          )}

          {/* Warm Arabic Explanation */}
          <p className="text-sm font-semibold leading-relaxed text-slate-700 dark:text-slate-200">
            {result.feedbackAr}
          </p>

          {result.wrongParts.length > 0 && (
            <div className="space-y-1.5 rounded-2xl border border-rose-500/25 bg-rose-500/8 p-3.5 text-xs">
              {result.wrongParts.map((wp, idx) => (
                <div key={idx} className="flex flex-wrap items-center gap-2">
                  <span dir="ltr" className="font-en font-bold text-rose-600 line-through dark:text-rose-300">
                    {wp.wrong}
                  </span>
                  <span>←</span>
                  <span dir="ltr" className="font-en font-extrabold text-emerald-600 dark:text-emerald-300">
                    {wp.right}
                  </span>
                  {wp.reasonAr && (
                    <span className="text-slate-600 dark:text-slate-300">· {wp.reasonAr}</span>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Natural Corrected Version + Audio Reinforcement */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4">
            <div className="min-w-0 flex-1">
              <div className="text-xs font-bold text-emerald-700 dark:text-emerald-300">
                الصياغة الطبيعية الصحيحة:
              </div>
              <div dir="ltr" className="mt-1 font-en text-lg font-extrabold text-slate-900 dark:text-white">
                {result.correctedEn}
              </div>
              {result.newSentenceAr && (
                <div className="mt-1 text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {result.newSentenceAr}
                </div>
              )}
            </div>
            <button
              type="button"
              data-testid="pattern-swap-listen-new-btn"
              onClick={() => onSpeak(result.correctedEn)}
              className="inline-flex h-10 shrink-0 items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 text-xs font-extrabold text-white hover:bg-emerald-700"
            >
              <Volume2 className="h-4 w-4" aria-hidden="true" />
              <span>اسمع جملتك الجديدة</span>
            </button>
          </div>

          {/* Explicit Next & Another Swap Buttons */}
          <div className="flex flex-wrap items-center justify-end gap-2.5 pt-1">
            <button
              type="button"
              data-testid="pattern-swap-another-btn"
              onClick={handleAnotherSwapSameSentence}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-indigo-400/40 bg-indigo-500/10 px-4 text-xs font-extrabold text-indigo-700 hover:bg-indigo-500/20 dark:text-indigo-300"
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>تحويل آخر لنفس الجملة</span>
            </button>
            <button
              type="button"
              data-testid="pattern-swap-next-btn"
              onClick={handleNextSentence}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-indigo-600 px-5 text-xs font-extrabold text-white hover:bg-indigo-700"
            >
              <span>{chainMode && chainStep < 2 ? 'التحويل التالي في السلسلة' : 'الجملة التالية'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
