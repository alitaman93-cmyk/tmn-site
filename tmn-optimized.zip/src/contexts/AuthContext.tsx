import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import {
  createUserWithEmailAndPassword,
  getRedirectResult,
  onAuthStateChanged,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
  signOut,
  updateProfile,
  type User,
} from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import type { UiLanguageCode } from '../types';
import {
  extractFirebaseErrorCode,
  parseFirebaseAuthError,
  shouldUseRedirectFallback,
} from '../utils/authErrorLogic';

interface AuthContextValue {
  user: User | null;
  authReady: boolean;
  signingIn: boolean;
  authError: string;
  authErrorCode: string;
  authErrorHostname: string;
  signInWithGoogle: () => Promise<boolean>;
  signUpWithEmail: (name: string, email: string, password: string) => Promise<boolean>;
  signInWithEmail: (email: string, password: string) => Promise<boolean>;
  signOutUser: () => Promise<void>;
  clearAuthError: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function getActiveUiLang(): UiLanguageCode {
  try {
    const raw = (document.documentElement.lang || 'ar').slice(0, 2).toLowerCase();
    const supported = new Set(['ar', 'hi', 'zh', 'ru', 'de', 'fr', 'es', 'it', 'pt', 'sv']);
    return (supported.has(raw) ? raw : 'ar') as UiLanguageCode;
  } catch {
    return 'ar';
  }
}

function getCurrentHostname(): string {
  try {
    return window.location.hostname || '';
  } catch {
    return '';
  }
}

function isRunningInIframe(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [signingIn, setSigningIn] = useState(false);
  const [authError, setAuthError] = useState('');
  const [authErrorCode, setAuthErrorCode] = useState('');
  const [authErrorHostname, setAuthErrorHostname] = useState('');

  const applyAuthError = useCallback((err: unknown) => {
    const parsed = parseFirebaseAuthError(err, getActiveUiLang(), getCurrentHostname());
    if (parsed.code) {
      console.error('[TMN Auth] error:', parsed.code, err);
    }
    setAuthError(parsed.message);
    setAuthErrorCode(parsed.message ? parsed.code : '');
    setAuthErrorHostname(parsed.isUnauthorizedDomain ? parsed.hostname : '');
  }, []);

  const clearAuthError = useCallback(() => {
    setAuthError('');
    setAuthErrorCode('');
    setAuthErrorHostname('');
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      setAuthReady(true);
    });

    // Capture Google sign-in results if a top-level mobile/PWA session completed via redirect fallback
    void getRedirectResult(auth)
      .then((result) => {
        if (result?.user) {
          setUser(result.user);
          clearAuthError();
        }
      })
      .catch((err) => {
        const code = extractFirebaseErrorCode(err);
        if (code && code !== 'auth/no-auth-event') {
          applyAuthError(err);
        }
      });

    return () => unsub();
  }, [applyAuthError, clearAuthError]);

  const signInWithGoogle = useCallback(async (): Promise<boolean> => {
    setSigningIn(true);
    clearAuthError();
    try {
      auth.languageCode = getActiveUiLang();
      const cred = await signInWithPopup(auth, googleProvider);
      if (cred?.user) {
        setUser(cred.user);
      }
      return true;
    } catch (err) {
      const code = extractFirebaseErrorCode(err);
      // Outside iframes (deployed Cloud Run / installed mobile PWA), smoothly fall back to redirect if popup is blocked
      if (shouldUseRedirectFallback(code, isRunningInIframe())) {
        try {
          await signInWithRedirect(auth, googleProvider);
          return true;
        } catch (redirectErr) {
          applyAuthError(redirectErr);
          return false;
        }
      }
      applyAuthError(err);
      return false;
    } finally {
      setSigningIn(false);
    }
  }, [applyAuthError, clearAuthError]);

  const signUpWithEmail = useCallback(
    async (name: string, email: string, password: string): Promise<boolean> => {
      const cleanEmail = email.trim();
      const cleanName = name.trim();
      if (!cleanEmail || !password) {
        applyAuthError({ code: 'auth/invalid-email' });
        return false;
      }
      if (password.length < 6) {
        applyAuthError({ code: 'auth/weak-password' });
        return false;
      }
      setSigningIn(true);
      clearAuthError();
      try {
        const cred = await createUserWithEmailAndPassword(auth, cleanEmail, password);
        if (cleanName) {
          try {
            await updateProfile(cred.user, { displayName: cleanName });
          } catch {
            // Non-critical profile update failure
          }
        }
        try {
          await sendEmailVerification(cred.user);
        } catch {
          // Non-critical email verification dispatch failure
        }
        setUser(cred.user);
        return true;
      } catch (err) {
        applyAuthError(err);
        return false;
      } finally {
        setSigningIn(false);
      }
    },
    [applyAuthError, clearAuthError]
  );

  const signInWithEmail = useCallback(
    async (email: string, password: string): Promise<boolean> => {
      const cleanEmail = email.trim();
      if (!cleanEmail || !password) {
        applyAuthError({ code: 'auth/invalid-credential' });
        return false;
      }
      setSigningIn(true);
      clearAuthError();
      try {
        const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
        if (cred?.user) {
          setUser(cred.user);
        }
        return true;
      } catch (err) {
        applyAuthError(err);
        return false;
      } finally {
        setSigningIn(false);
      }
    },
    [applyAuthError, clearAuthError]
  );

  const signOutUser = useCallback(async () => {
    try {
      await signOut(auth);
    } catch {
      // Ignore sign-out errors
    }
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      authReady,
      signingIn,
      authError,
      authErrorCode,
      authErrorHostname,
      signInWithGoogle,
      signUpWithEmail,
      signInWithEmail,
      signOutUser,
      clearAuthError,
    }),
    [
      user,
      authReady,
      signingIn,
      authError,
      authErrorCode,
      authErrorHostname,
      signInWithGoogle,
      signUpWithEmail,
      signInWithEmail,
      signOutUser,
      clearAuthError,
    ]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}


