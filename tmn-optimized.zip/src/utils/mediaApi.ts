import { BAD_PHOTO_TERMS, POS_AR } from '../data/constants';
import type {
  WordClipsPageResponse,
  WordExampleSentence,
  WordInfoData,
  WordPhotoData,
} from '../types';
import { hotCacheGet, hotCacheSet, idbMediaGet, idbMediaSet } from './storage';
import { splitTargetHighlight } from './vocabLogic';

/**
 * Concrete visual search queries for common simple/function/abstract words
 * so Unsplash and Wikimedia always return meaningful, recognizable photos
 * even for A0-A1 words like "the", "and", "in", "on", "to", "yes", "no".
 */
export const VISUAL_QUERY_MAP: Record<string, string> = {
  the: 'english dictionary open book',
  a: 'single red apple minimalist',
  an: 'wooden alphabet letter blocks',
  to: 'road direction arrow sign',
  of: 'wooden puzzle pieces connected',
  and: 'two hands shaking friendship',
  in: 'cat inside cardboard box',
  into: 'jumping into swimming pool',
  inside: 'cozy living room interior',
  on: 'coffee cup on wooden table',
  onto: 'cat jumping onto sofa',
  upon: 'book resting on desk',
  at: 'map pin location street',
  by: 'person walking by river',
  for: 'gift box wrapped ribbon',
  with: 'friends walking together park',
  from: 'airplane taking off airport',
  or: 'fork in road two paths',
  but: 'two different doors choice',
  nor: 'empty desert road horizon',
  yet: 'hourglass sand waiting time',
  so: 'dominoes falling chain reaction',
  as: 'reflection in calm lake mirror',
  if: 'crossroads decision path forest',
  than: 'two mountains tall comparison',
  that: 'finger pointing distant mountain',
  this: 'hand holding glowing sphere',
  these: 'colorful pencils arranged desk',
  those: 'distant city skyline sunset',
  which: 'choosing between two paths',
  who: 'diverse smiling portraits people',
  whom: 'people talking conversation cafe',
  whose: 'lost keys on wooden table',
  what: 'curious person looking magnifying glass',
  where: 'world map compass travel',
  when: 'wall clock calendar schedule',
  why: 'person thinking lightbulb idea',
  how: 'blueprint tools workshop crafting',
  it: 'colorful rubik cube desk',
  its: 'bird nest tree branch',
  i: 'person smiling portrait sunlight',
  me: 'mirror reflection portrait person',
  my: 'person holding favorite notebook',
  mine: 'hand holding house keys',
  you: 'friendly person smiling camera',
  your: 'giving coffee cup hand',
  yours: 'gift box offered hands',
  he: 'smiling young man portrait',
  him: 'man walking city street',
  his: 'mens watch leather wallet desk',
  she: 'smiling young woman portrait',
  her: 'woman reading book park',
  hers: 'handbag sunglasses table',
  we: 'happy group friends smiling',
  us: 'team hands together circle',
  our: 'family home cozy house',
  they: 'group people walking city',
  them: 'crowd friends celebrating outdoors',
  their: 'neighborhood houses street view',
  be: 'peaceful sunrise mountain meditation',
  is: 'clear blue sky sunlight',
  am: 'confident smiling person morning',
  are: 'group students classroom learning',
  was: 'vintage clock antique pocket watch',
  were: 'historic old town architecture',
  been: 'footprints in beach sand',
  being: 'person breathing fresh nature air',
  have: 'hands holding fresh apples',
  has: 'child holding backpack school',
  had: 'old photo album memories',
  do: 'person working laptop notebook',
  does: 'chef cooking kitchen action',
  did: 'finished checklist notebook pen',
  make: 'pottery hands shaping clay',
  will: 'runner starting line track',
  would: 'dreaming looking out window clouds',
  shall: 'compass pointing north map',
  should: 'traffic signal green crosswalk',
  can: 'climber reaching mountain top',
  could: 'open door bright light',
  may: 'spring flowers blooming sunlight',
  might: 'partly cloudy sky sunbeams',
  must: 'important red stamp checklist',
  not: 'red stop sign street',
  no: 'red stop sign road',
  yes: 'thumbs up happy smile',
  very: 'tall skyscraper city clouds',
  too: 'overflowing coffee cup desk',
  also: 'stack colorful books library',
  just: 'single water drop leaf',
  only: 'lone tree green hill',
  even: 'balanced stones zen garden',
  still: 'calm lake reflection morning',
  already: 'finished trophy medal desk',
  although: 'flower growing through concrete',
  though: 'sun shining through rain clouds',
  however: 'curved winding mountain road',
  therefore: 'chess checkmate strategy board',
  unless: 'umbrella rain storm street',
  whereas: 'day and night contrast sky',
  meanwhile: 'busy city train station clock',
  because: 'sprout growing from seed water',
  up: 'hot air balloons rising sky',
  down: 'waterfall flowing down rocks',
  out: 'walking out open door garden',
  off: 'light switch turned off wall',
  over: 'bridge arching over river',
  under: 'sitting under shady tree',
  above: 'airplane flying above clouds',
  below: 'coral reef underwater ocean',
  between: 'narrow path between tall trees',
  through: 'train tunnel mountain sunlight',
  about: 'open encyclopedia book pages',
  after: 'rainbow after rain sky',
  before: 'sunrise dawn early morning',
  again: 'circular running track loop',
  here: 'gps pin on map hand',
  there: 'distant lighthouse coast horizon',
  now: 'digital watch showing time',
  then: 'vintage hourglass antique desk',
  all: 'earth globe planet space',
  some: 'handful fresh berries bowl',
  any: 'assorted colorful candies jar',
  each: 'row identical coffee cups',
  every: 'grid colorful windows building',
  other: 'two contrasting colored doors',
  such: 'bright rainbow sky nature',
  same: 'twin matching coffee mugs',
  different: 'red umbrella among black umbrellas',
  more: 'growing stack coins graph',
  most: 'highest snow mountain peak',
  much: 'vast ocean waves horizon',
  many: 'colorful balloons floating sky',
  good: 'smiling happy person sunshine',
  bad: 'dark storm clouds lightning',
  big: 'giant african elephant savanna',
  small: 'tiny ladybug on green leaf',
  go: 'green traffic light city street',
  get: 'receiving package delivery hands',
  see: 'binoculars looking at mountain view',
  say: 'two people talking cafe',
  know: 'library shelves glowing books',
  take: 'hand picking fresh apple tree',
  come: 'welcoming open front door',
  think: 'person thinking notebook coffee',
  look: 'person looking telescope stars',
  want: 'child looking toy shop window',
  give: 'hands giving wrapped gift',
  use: 'hands typing keyboard laptop',
  find: 'magnifying glass treasure map',
  tell: 'parent reading story to child',
  ask: 'student raising hand classroom',
  work: 'modern desk laptop coffee workspace',
  seem: 'mirage reflection desert lake',
  feel: 'hands touching warm sunlight grass',
  try: 'person climbing bouldering wall',
  leave: 'suitcase waiting train platform',
  call: 'person talking on smartphone',
};

const STOPWORDS = new Set([
  'the', 'a', 'an', 'of', 'to', 'in', 'on', 'for', 'with', 'by', 'from', 'as', 'at', 'or', 'and',
  'is', 'are', 'was', 'were', 'be', 'been', 'being', 'that', 'this', 'which', 'who', 'whom',
  'someone', 'something', 'person', 'thing', 'act', 'state', 'quality', 'condition', 'manner',
  'having', 'making', 'relating', 'used', 'used', 'one', 'not', 'very', 'more', 'most', 'into',
  'over', 'under', 'about', 'after', 'before', 'between', 'through', 'during', 'without', 'within',
  'especially', 'usually', 'often', 'typically', 'generally', 'particular', 'certain', 'specific',
]);

const CURATED_FALLBACK_TOPICS = [
  'open book coffee desk study',
  'notebook pen writing learning',
  'world map compass adventure',
  'modern architecture sunlight city',
  'calm nature landscape morning',
  'library bookshelves warm light',
  'people conversation coffee shop',
  'minimalist workspace desk lamp',
  'mountain sunrise clear sky',
  'botanical green leaves sunlight',
];

const photoMemCache = new Map<string, WordPhotoData>();
let unsplashRateLimitedUntil = 0;

function hashWord(word: string): number {
  let h = 2166136261;
  for (let i = 0; i < word.length; i++) {
    h ^= word.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

export function buildVisualQuery(word: string): string {
  const clean = (word || '').trim().toLowerCase();
  if (!clean) return 'open book learning';
  if (VISUAL_QUERY_MAP[clean]) return VISUAL_QUERY_MAP[clean];
  // If multi-word phrase starts with "to " (infinitive), strip "to "
  if (clean.startsWith('to ') && clean.length > 4) {
    const bare = clean.slice(3).trim();
    return VISUAL_QUERY_MAP[bare] || bare;
  }
  return clean;
}

export function extractVisualKeywordsFromText(definition: string, excludeWord = ''): string {
  const ex = excludeWord.toLowerCase().trim();
  const tokens = (definition || '')
    .toLowerCase()
    .replace(/[^a-z\s]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length >= 4 && t !== ex && !STOPWORDS.has(t));
  return tokens.slice(0, 2).join(' ');
}

function escapeXml(str: string): string {
  return (str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function buildOfflineVisualCard(word: string, ar?: string, band?: string): WordPhotoData {
  const h = hashWord(word.toLowerCase());
  const palettes: Array<[string, string, string]> = [
    ['#312e81', '#1d4ed8', '#38bdf8'],
    ['#064e3b', '#0f766e', '#34d399'],
    ['#4c1d95', '#6d28d9', '#a78bfa'],
    ['#7c2d12', '#c2410c', '#fb923c'],
    ['#1e293b', '#334155', '#818cf8'],
    ['#831843', '#be185d', '#f472b6'],
  ];
  const [c1, c2, c3] = palettes[h % palettes.length];
  const safeWord = escapeXml(word);
  const safeAr = escapeXml(ar || '');
  const safeBand = escapeXml(band || 'CEFR');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 400" width="640" height="400">
  <defs>
    <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="100%" stop-color="${c2}"/>
    </linearGradient>
  </defs>
  <rect width="640" height="400" fill="url(#g)"/>
  <circle cx="530" cy="80" r="110" fill="${c3}" fill-opacity="0.16"/>
  <circle cx="110" cy="340" r="130" fill="${c3}" fill-opacity="0.12"/>
  <rect x="268" y="64" width="104" height="36" rx="18" fill="#0f172a" fill-opacity="0.35"/>
  <text x="320" y="88" text-anchor="middle" fill="#e2e8f0" font-family="system-ui,Segoe UI,Arial,sans-serif" font-weight="800" font-size="18">${safeBand}</text>
  <text x="320" y="210" text-anchor="middle" fill="#ffffff" font-family="system-ui,Segoe UI,Arial,sans-serif" font-weight="800" font-size="52">${safeWord}</text>
  ${
    safeAr
      ? `<text x="320" y="274" text-anchor="middle" fill="#e0f2fe" font-family="system-ui,Tahoma,Arial,sans-serif" font-weight="700" font-size="30">${safeAr}</text>`
      : ''
  }
</svg>`;
  const dataUrl = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  return {
    found: true,
    isFallbackCard: true,
    providerLabel: 'بطاقة بصرية',
    imageUrl: dataUrl,
    thumbUrl: dataUrl,
    alt: word,
    photographer: 'قاموس الألعاب',
    photographerUrl: '#',
    photoPageUrl: '#',
    providerHomeUrl: '#',
    ttl: 5 * 60 * 1000,
  };
}

async function queryUnsplash(
  query: string,
  page: number,
  unsKey: string,
  altWord: string
): Promise<{ data: WordPhotoData | null; rateLimited: boolean }> {
  const cleanKey = (unsKey || '').trim();
  if (
    !cleanKey ||
    cleanKey === 'GEMINI_API_KEY' ||
    cleanKey.length < 20 ||
    Date.now() < unsplashRateLimitedUntil
  ) {
    return { data: null, rateLimited: Date.now() < unsplashRateLimitedUntil };
  }
  try {
    const r = await fetch(
      `https://api.unsplash.com/search/photos?query=${encodeURIComponent(
        query
      )}&page=${page}&per_page=10&orientation=landscape&content_filter=high&client_id=${encodeURIComponent(
        cleanKey
      )}`
    );
    if (r.status === 401 || r.status === 403 || r.status === 429) {
      unsplashRateLimitedUntil = Date.now() + 30 * 60 * 1000;
      return { data: null, rateLimited: true };
    }
    if (!r.ok) return { data: null, rateLimited: false };
    const j = (await r.json()) as {
      results?: Array<{
        alt_description?: string;
        description?: string;
        urls?: { regular?: string; small?: string };
        user?: { name?: string; links?: { html?: string } };
        links?: { html?: string };
      }>;
    };
    const results = (j.results || []).filter((ph) => ph.urls?.small || ph.urls?.regular);
    if (!results.length) return { data: null, rateLimited: false };

    const cleanHit = results.find((ph) => {
      const desc = `${ph.alt_description || ''} ${ph.description || ''}`.toLowerCase();
      return !BAD_PHOTO_TERMS.some((t) => desc.includes(t));
    });
    const hit = cleanHit || results[0];
    const utm = 'utm_source=smart_vocab_cefr&utm_medium=referral';
    const un = hit.user?.name || 'Unsplash';
    const up = hit.user?.links?.html || 'https://unsplash.com';
    const pp = hit.links?.html || 'https://unsplash.com';
    return {
      rateLimited: false,
      data: {
        found: true,
        providerLabel: 'Unsplash',
        imageUrl: hit.urls?.regular || hit.urls?.small || '',
        thumbUrl: hit.urls?.small || hit.urls?.regular || '',
        alt: hit.alt_description || altWord,
        photographer: un,
        photographerUrl: `${up}?${utm}`,
        photoPageUrl: `${pp}?${utm}`,
        providerHomeUrl: `https://unsplash.com/?${utm}`,
        ttl: 14 * 864e5,
      },
    };
  } catch {
    return { data: null, rateLimited: false };
  }
}

async function queryWikipediaSummary(word: string): Promise<WordPhotoData | null> {
  try {
    const r = await fetch(
      `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(word)}`
    );
    if (!r.ok) return null;
    const j = (await r.json()) as {
      type?: string;
      title?: string;
      thumbnail?: { source?: string };
      content_urls?: { desktop?: { page?: string } };
    };
    if (j.type === 'disambiguation' || !j.thumbnail?.source) return null;
    const src = j.thumbnail.source;
    if (src.endsWith('.svg') || src.endsWith('.svg.png')) return null;
    const pageUrl =
      j.content_urls?.desktop?.page || `https://en.wikipedia.org/wiki/${encodeURIComponent(word)}`;
    return {
      found: true,
      providerLabel: 'Wikipedia',
      imageUrl: src,
      thumbUrl: src,
      alt: j.title || word,
      photographer: 'Wikimedia',
      photographerUrl: pageUrl,
      photoPageUrl: pageUrl,
      providerHomeUrl: 'https://en.wikipedia.org/',
      ttl: 14 * 864e5,
    };
  } catch {
    return null;
  }
}

async function queryWikimediaCommons(query: string, page: number, altWord: string): Promise<WordPhotoData | null> {
  try {
    const offset = Math.max(0, (page - 1) * 5);
    const r = await fetch(
      `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(
        query
      )}&gsrnamespace=6&gsrlimit=6&gsroffset=${offset}&prop=imageinfo&iiprop=url|mime|extmetadata&iiurlwidth=640&format=json&origin=*`
    );
    if (!r.ok) return null;
    const j = (await r.json()) as {
      query?: {
        pages?: Record<
          string,
          {
            title?: string;
            imageinfo?: Array<{
              thumburl?: string;
              url?: string;
              mime?: string;
              descriptionurl?: string;
              extmetadata?: { Artist?: { value?: string } };
            }>;
          }
        >;
      };
    };
    const pages = Object.values(j.query?.pages || {});
    for (const pg of pages) {
      const info = pg.imageinfo?.[0];
      if (!info) continue;
      const mime = (info.mime || '').toLowerCase();
      if (!mime.includes('jpeg') && !mime.includes('jpg') && !mime.includes('webp') && !mime.includes('png')) {
        continue;
      }
      const imgUrl = info.thumburl || info.url;
      if (!imgUrl) continue;
      const rawArtist = info.extmetadata?.Artist?.value || 'Wikimedia Commons';
      const cleanArtist = rawArtist.replace(/<[^>]+>/g, '').trim().slice(0, 40) || 'Wikimedia';
      const pageUrl = info.descriptionurl || 'https://commons.wikimedia.org/';
      return {
        found: true,
        providerLabel: 'Wikimedia',
        imageUrl: imgUrl,
        thumbUrl: imgUrl,
        alt: altWord,
        photographer: cleanArtist,
        photographerUrl: pageUrl,
        photoPageUrl: pageUrl,
        providerHomeUrl: 'https://commons.wikimedia.org/',
        ttl: 14 * 864e5,
      };
    }
    return null;
  } catch {
    return null;
  }
}

async function fetchDefinitionKeywords(word: string): Promise<string> {
  try {
    const r = await fetch(`/api/dictionary?word=${encodeURIComponent(word.toLowerCase())}`);
    if (!r.ok) return '';
    const entries = (await r.json()) as Array<{
      meanings?: Array<{ definitions?: Array<{ definition?: string }> }>;
    }>;
    for (const en of entries || []) {
      for (const m of en.meanings || []) {
        for (const d of m.definitions || []) {
          if (d?.definition) {
            const kw = extractVisualKeywordsFromText(d.definition, word);
            if (kw) return kw;
          }
        }
      }
    }
    return '';
  } catch {
    return '';
  }
}

export async function fetchWordInfo(
  word: string,
  backendUrl: string,
  force = false
): Promise<{ status: 'ready' | 'error'; data: WordInfoData | null; message?: string }> {
  const cacheKey = word.toLowerCase();
  if (!force) {
    const cached = await idbMediaGet<WordInfoData>('wordInfo', cacheKey);
    if (cached) return { status: 'ready', data: cached };
  }

  try {
    const srv = backendUrl.trim().replace(/\/+$/, '');
    if (srv) {
      const r = await fetch(`${srv}/api/word-info?word=${encodeURIComponent(word)}`);
      if (r.ok) {
        const j = await r.json();
        if (j.ok) {
          const examples: WordExampleSentence[] = (j.examples || []).map(
            (ex: { text: string; source?: string }) => ({
              text: ex.text,
              segments: splitTargetHighlight(ex.text, word).segments,
              source: ex.source || 'Dictionary',
            })
          );
          const out: WordInfoData = {
            phonetic: j.phonetic || '',
            posEn: j.partOfSpeech ? j.partOfSpeech.en : '',
            posAr: j.partOfSpeech ? j.partOfSpeech.ar : '',
            examples,
          };
          await idbMediaSet('wordInfo', cacheKey, out, examples.length ? 14 * 864e5 : 6 * 3600 * 1000);
          return { status: 'ready', data: out };
        }
      }
    }

    let phonetic = '';
    let pos = '';
    const examples: WordExampleSentence[] = [];

    const r = await fetch(`/api/dictionary?word=${encodeURIComponent(cacheKey)}`);
    if (r.ok) {
      const entries = (await r.json()) as Array<{
        phonetic?: string;
        phonetics?: Array<{ text?: string }>;
        meanings?: Array<{
          partOfSpeech?: string;
          definitions?: Array<{ example?: string }>;
        }>;
      }>;
      if (Array.isArray(entries)) {
        for (const en of entries) {
          if (!phonetic && en.phonetic) phonetic = en.phonetic;
          if (!phonetic && Array.isArray(en.phonetics)) {
            const ph = en.phonetics.find((p) => p && p.text);
            if (ph?.text) phonetic = ph.text;
          }
          for (const m of en.meanings || []) {
            if (!pos && m.partOfSpeech) pos = m.partOfSpeech.toLowerCase();
            for (const d of m.definitions || []) {
              if (d && d.example) {
                let t = d.example.trim();
                if (!/[.!?]$/.test(t)) t += '.';
                t = t.charAt(0).toUpperCase() + t.slice(1);
                const hl = splitTargetHighlight(t, word);
                if (hl.matched && t.split(/\s+/).length <= 18) {
                  examples.push({ text: t, segments: hl.segments, source: 'Free Dictionary' });
                }
              }
            }
          }
        }
      }
    }

    if (!examples.length || !pos) {
      try {
        const wr = await fetch(
          `https://en.wiktionary.org/api/rest_v1/page/definition/${encodeURIComponent(cacheKey)}`
        );
        if (wr.ok) {
          const wj = (await wr.json()) as {
            en?: Array<{
              partOfSpeech?: string;
              definitions?: Array<{
                parsedExamples?: Array<{ example?: string }>;
                examples?: string[];
              }>;
            }>;
          };
          for (const item of wj.en || []) {
            if (!pos && item.partOfSpeech) pos = item.partOfSpeech.toLowerCase();
            for (const def of (item.definitions || []).slice(0, 6)) {
              const arr = [
                ...(def.parsedExamples || []).map((x) => x && x.example),
                ...(def.examples || []),
              ];
              for (const rawEx of arr) {
                if (typeof rawEx !== 'string') continue;
                const ex = rawEx.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
                if (ex.length < 10 || ex.length > 120) continue;
                const hl = splitTargetHighlight(ex, word);
                if (hl.matched) {
                  examples.push({ text: ex, segments: hl.segments, source: 'Wiktionary' });
                }
              }
            }
          }
        }
      } catch {
        // Ignore Wiktionary fallback failure
      }
    }

    examples.sort(
      (a, b) => Math.abs(a.text.split(/\s+/).length - 8) - Math.abs(b.text.split(/\s+/).length - 8)
    );
    const out: WordInfoData = {
      phonetic,
      posEn: pos,
      posAr: POS_AR[pos] || pos,
      examples: examples.slice(0, 4),
    };
    await idbMediaSet('wordInfo', cacheKey, out, out.examples.length ? 14 * 864e5 : 6 * 3600 * 1000);
    return { status: 'ready', data: out };
  } catch {
    return {
      status: 'error',
      data: null,
      message: navigator.onLine ? 'تعذر جلب الجملة الآن.' : 'أنت غير متصل بالإنترنت.',
    };
  }
}

export function getHotWordPhoto(word: string, page = 1): WordPhotoData | null {
  const cacheKey = `v3::${(word || '').toLowerCase()}::p${page || 1}`;
  const mem = photoMemCache.get(cacheKey);
  if (mem && mem.found) return mem;
  const hot = hotCacheGet<WordPhotoData>('img', cacheKey);
  if (hot && hot.found && hot.imageUrl) {
    photoMemCache.set(cacheKey, hot);
    return hot;
  }
  return null;
}

export async function fetchWordPhoto(
  word: string,
  page: number,
  options: { backendUrl: string; pixabayKey: string; unsplashKey: string },
  force = false,
  extra?: { ar?: string; band?: string }
): Promise<{ status: 'ready' | 'empty' | 'nokey' | 'error'; data: WordPhotoData | null }> {
  const p = page || 1;
  const cacheKey = `v3::${word.toLowerCase()}::p${p}`;

  if (!force) {
    const hot = getHotWordPhoto(word, p);
    if (hot) {
      return { status: 'ready', data: hot };
    }
    const cached = await idbMediaGet<WordPhotoData>('images', cacheKey);
    if (cached && cached.found && cached.imageUrl) {
      photoMemCache.set(cacheKey, cached);
      if (!cached.isFallbackCard) hotCacheSet('img', cacheKey, cached, 14 * 864e5);
      return { status: 'ready', data: cached };
    }
  }

  const srv = options.backendUrl.trim().replace(/\/+$/, '');
  const pixKey = options.pixabayKey.trim();
  const unsKey = options.unsplashKey.trim();
  const visualQuery = buildVisualQuery(word);

  try {
    let out: WordPhotoData | null = null;
    let rateLimited = false;

    // 1. Optional custom backend proxy
    if (srv) {
      try {
        const r = await fetch(`${srv}/api/image?word=${encodeURIComponent(visualQuery)}&page=${p}`);
        const j = await r.json();
        if (r.ok && j.ok && j.found) {
          out = {
            ...j,
            thumbUrl: j.thumbUrl || j.imageUrl,
            ttl: j.provider === 'pixabay' ? 23 * 3600 * 1000 : 14 * 864e5,
          };
        }
      } catch {
        // Fall through
      }
    }

    // 2. Unsplash primary search (with concrete visual query mapping for simple/function words)
    if (!out && unsKey) {
      const res = await queryUnsplash(visualQuery, p, unsKey, word);
      out = res.data;
      rateLimited = res.rateLimited;
    }

    // 3. Optional Pixabay if configured
    if (!out && pixKey) {
      try {
        const r = await fetch(
          `https://pixabay.com/api/?key=${encodeURIComponent(pixKey)}&q=${encodeURIComponent(
            visualQuery
          )}&image_type=photo&safesearch=true&lang=en&per_page=8&page=${p}`,
          { mode: 'cors' }
        );
        if (r.ok) {
          const j = await r.json();
          const hits = (j.hits || []).filter((h: { webformatURL?: string }) => h.webformatURL);
          const cleanHit = hits.find((h: { tags?: string }) => {
            const tags = (h.tags || '').toLowerCase();
            return !BAD_PHOTO_TERMS.some((t) => tags.includes(t));
          });
          const hit = cleanHit || hits[0];
          if (hit) {
            out = {
              found: true,
              providerLabel: 'Pixabay',
              imageUrl: hit.webformatURL,
              thumbUrl: hit.previewURL || hit.webformatURL,
              alt: hit.tags || word,
              photographer: hit.user || 'Pixabay',
              photographerUrl: 'https://pixabay.com/',
              photoPageUrl: hit.pageURL || 'https://pixabay.com/',
              providerHomeUrl: 'https://pixabay.com/',
              ttl: 23 * 3600 * 1000,
            };
          }
        }
      } catch {
        // Fall through
      }
    }

    // 4. Wikipedia summary thumbnail (free, CORS-enabled, great for nouns/animals/concepts)
    if (!out && p === 1) {
      out = await queryWikipediaSummary(word);
    }

    // 5. Semantic definition keywords -> Unsplash (for abstract/rare C1-C2 words) or Wikimedia Commons
    if (!out) {
      const defKeywords = await fetchDefinitionKeywords(word);
      const semanticQuery = defKeywords || visualQuery;

      if (unsKey && !rateLimited && defKeywords) {
        const res = await queryUnsplash(defKeywords, p, unsKey, word);
        out = res.data;
        rateLimited = res.rateLimited;
      }

      if (!out) {
        out = await queryWikimediaCommons(semanticQuery, p, word);
      }
    }

    // 6. Curated topic Unsplash fallback (guaranteed real photograph even for archaic words)
    if (!out && unsKey && !rateLimited) {
      const topic =
        CURATED_FALLBACK_TOPICS[(hashWord(word.toLowerCase()) + p - 1) % CURATED_FALLBACK_TOPICS.length];
      const res = await queryUnsplash(topic, 1, unsKey, word);
      out = res.data;
    }

    // 7. Offline / network unreachable guaranteed visual card fallback (never empty)
    if (!out) {
      out = buildOfflineVisualCard(word, extra?.ar, extra?.band);
    }

    photoMemCache.set(cacheKey, out);
    if (!out.isFallbackCard) {
      hotCacheSet('img', cacheKey, out, out.ttl || 14 * 864e5);
    }
    await idbMediaSet('images', cacheKey, out, out.ttl || 14 * 864e5);
    return { status: 'ready', data: out };
  } catch {
    const fallback = buildOfflineVisualCard(word, extra?.ar, extra?.band);
    return { status: 'ready', data: fallback };
  }
}

const videoClipsMemCache = new Map<string, WordClipsPageResponse>();
const videoClipsInflight = new Map<string, Promise<WordClipsPageResponse>>();

export function getHotWordVideoClips(word: string, page = 0): WordClipsPageResponse | null {
  const cleanWord = (word || '').trim();
  if (!cleanWord) return null;
  const safePage = Math.max(0, Math.min(6, Math.floor(page)));
  const cacheKey = `v1::clips::${cleanWord.toLowerCase()}::p${safePage}`;
  const mem = videoClipsMemCache.get(cacheKey);
  if (mem && mem.clips?.length) return mem;
  const hot = hotCacheGet<WordClipsPageResponse>('clips', cacheKey);
  if (hot && Array.isArray(hot.clips) && hot.clips.length > 0) {
    videoClipsMemCache.set(cacheKey, hot);
    return hot;
  }
  return null;
}

/**
 * Fetches exact-timestamp (±3s) spoken English video clips for a word
 * with multi-tier caching (RAM -> localStorage Hot Cache -> IndexedDB 'videos' store -> /api/word-clips).
 */
export async function fetchWordVideoClips(
  word: string,
  page = 0,
  force = false
): Promise<WordClipsPageResponse> {
  const cleanWord = (word || '').trim();
  const safePage = Math.max(0, Math.min(6, Math.floor(page)));
  const cacheKey = `v1::clips::${cleanWord.toLowerCase()}::p${safePage}`;

  if (!cleanWord) {
    return { word: '', page: safePage, clips: [], hasMore: false, totalFound: 0 };
  }

  if (!force) {
    const hot = getHotWordVideoClips(cleanWord, safePage);
    if (hot) return hot;

    const inflight = videoClipsInflight.get(cacheKey);
    if (inflight) return inflight;

    const disk = await idbMediaGet<WordClipsPageResponse>('videos', cacheKey);
    if (disk && Array.isArray(disk.clips) && disk.clips.length > 0) {
      videoClipsMemCache.set(cacheKey, disk);
      hotCacheSet('clips', cacheKey, disk, 24 * 864e5);
      return disk;
    }
  }

  const reqPromise = (async (): Promise<WordClipsPageResponse> => {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 14_000);
    try {
      const res = await fetch(
        `/api/word-clips?word=${encodeURIComponent(cleanWord)}&page=${safePage}`,
        { signal: controller.signal }
      );
      if (!res.ok) {
        return { word: cleanWord, page: safePage, clips: [], hasMore: false, totalFound: 0 };
      }
      const data = (await res.json()) as WordClipsPageResponse;
      if (data && Array.isArray(data.clips) && data.clips.length > 0) {
        videoClipsMemCache.set(cacheKey, data);
        hotCacheSet('clips', cacheKey, data, 24 * 864e5);
        await idbMediaSet('videos', cacheKey, data, 24 * 864e5);
      }
      return data || { word: cleanWord, page: safePage, clips: [], hasMore: false, totalFound: 0 };
    } catch {
      return { word: cleanWord, page: safePage, clips: [], hasMore: false, totalFound: 0 };
    } finally {
      window.clearTimeout(timer);
      videoClipsInflight.delete(cacheKey);
    }
  })();

  videoClipsInflight.set(cacheKey, reqPromise);
  return reqPromise;
}

/**
 * Synchronous hot-cache lookup for full-sentence spoken video clips.
 */
export function getHotSentenceVideoClips(
  sentence: string,
  page = 0
): WordClipsPageResponse | null {
  const clean = (sentence || '').split('=')[0].trim();
  if (!clean) return null;
  const safePage = Math.max(0, Math.min(3, Math.floor(page)));
  const cacheKey = `v1::sclips::${clean.toLowerCase()}::p${safePage}`;
  const mem = videoClipsMemCache.get(cacheKey);
  if (mem && mem.clips?.length) return mem;
  const hot = hotCacheGet<WordClipsPageResponse>('clips', cacheKey);
  if (hot && Array.isArray(hot.clips) && hot.clips.length > 0) {
    videoClipsMemCache.set(cacheKey, hot);
    return hot;
  }
  return null;
}

/**
 * Fetches verified spoken video clips matching the COMPLETE English sentence
 * via /api/sentence-clips (RAM -> localStorage Hot Cache -> IndexedDB -> server).
 */
export async function fetchSentenceVideoClips(
  sentence: string,
  page = 0,
  force = false
): Promise<WordClipsPageResponse> {
  const cleanSentence = (sentence || '').split('=')[0].trim().slice(0, 160);
  const safePage = Math.max(0, Math.min(3, Math.floor(page)));
  const cacheKey = `v1::sclips::${cleanSentence.toLowerCase()}::p${safePage}`;

  if (!cleanSentence) {
    return { word: '', page: safePage, clips: [], hasMore: false, totalFound: 0 };
  }

  if (!force) {
    const hot = getHotSentenceVideoClips(cleanSentence, safePage);
    if (hot) return hot;

    const inflight = videoClipsInflight.get(cacheKey);
    if (inflight) return inflight;

    const disk = await idbMediaGet<WordClipsPageResponse>('videos', cacheKey);
    if (disk && Array.isArray(disk.clips) && disk.clips.length > 0) {
      videoClipsMemCache.set(cacheKey, disk);
      hotCacheSet('clips', cacheKey, disk, 24 * 864e5);
      return disk;
    }
  }

  const reqPromise = (async (): Promise<WordClipsPageResponse> => {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 15_000);
    try {
      const res = await fetch(
        `/api/sentence-clips?sentence=${encodeURIComponent(cleanSentence)}&page=${safePage}`,
        { signal: controller.signal }
      );
      if (!res.ok) {
        return { word: cleanSentence, page: safePage, clips: [], hasMore: false, totalFound: 0 };
      }
      const data = (await res.json()) as WordClipsPageResponse;
      if (data && Array.isArray(data.clips) && data.clips.length > 0) {
        videoClipsMemCache.set(cacheKey, data);
        hotCacheSet('clips', cacheKey, data, 24 * 864e5);
        await idbMediaSet('videos', cacheKey, data, 24 * 864e5);
      }
      return data || { word: cleanSentence, page: safePage, clips: [], hasMore: false, totalFound: 0 };
    } catch {
      return { word: cleanSentence, page: safePage, clips: [], hasMore: false, totalFound: 0 };
    } finally {
      window.clearTimeout(timer);
      videoClipsInflight.delete(cacheKey);
    }
  })();

  videoClipsInflight.set(cacheKey, reqPromise);
  return reqPromise;
}

