import { BANDS } from '../data/constants';
import type {
  CefrBand,
  DailyPaceMinutes,
  DailyPlanStepId,
  DailyPlanStepsState,
  LearningGoalId,
  PersistedSettings,
  SavedWordNote,
  VocabEntry,
  VocabStore,
} from '../types';

export const DAILY_PLAN_BONUS_XP = 50;
export const MISTAKE_FIXER_GRADUATION_XP = 15;

export function toIsoDate(date: Date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function parseIsoDateUtc(isoDate: string): Date {
  const [y, m, d] = isoDate.split('-').map((n) => Number(n));
  return new Date(Date.UTC(y || 2026, (m || 1) - 1, d || 1));
}

export function diffCalendarDays(fromIso: string, toIso: string): number {
  if (!fromIso || !toIso) return 0;
  const a = parseIsoDateUtc(fromIso).getTime();
  const b = parseIsoDateUtc(toIso).getTime();
  return Math.round((b - a) / 86_400_000);
}

/** ISO week key YYYY-Www for weekly free Streak Freeze replenishment */
export function getIsoWeekKey(isoDate: string): string {
  const dt = parseIsoDateUtc(isoDate);
  const day = dt.getUTCDay() || 7;
  dt.setUTCDate(dt.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(dt.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((dt.getTime() - yearStart.getTime()) / 86_400_000) + 1) / 7);
  return `${dt.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
}

export function paceToDailyGoal(pace: DailyPaceMinutes): number {
  if (pace === 5) return 10;
  if (pace === 20) return 40;
  return 20;
}

export function getGoalLabelAr(goal?: LearningGoalId): string {
  switch (goal) {
    case 'work_interviews':
      return 'العمل والمقابلات';
    case 'travel':
      return 'السفر والسياحة';
    case 'study_exams':
      return 'الدراسة والامتحانات';
    default:
      return 'المحادثة اليومية';
  }
}

export interface ActivityUpdateResult {
  settingsPatch: Partial<PersistedSettings>;
  usedStreakFreeze: boolean;
  replenishedFreeze: boolean;
}

/**
 * Records study activity for `isoDate` (YYYY-MM-DD), updates 30-day heatmap history,
 * auto-replenishes 1 free weekly Streak Freeze, and auto-protects streak if exactly 1 day was missed.
 */
export function recordDailyStudyActivity(
  settings: PersistedSettings,
  countDelta: number = 1,
  isoDate: string = toIsoDate()
): ActivityUpdateResult {
  const safeDelta = Math.max(1, Math.trunc(countDelta));
  const weekKey = getIsoWeekKey(isoDate);
  let freezes =
    typeof settings.streakFreezes === 'number' && Number.isFinite(settings.streakFreezes)
      ? Math.max(0, Math.min(3, Math.trunc(settings.streakFreezes)))
      : 1;
  let replenishedFreeze = false;

  if (settings.lastFreezeWeek !== weekKey) {
    if (freezes < 1) {
      freezes = 1;
      replenishedFreeze = true;
    }
  }

  const prevHistory = settings.studyHistory || {};
  const nextHistory: Record<string, number> = {
    ...prevHistory,
    [isoDate]: (prevHistory[isoDate] || 0) + safeDelta,
  };

  // Prune entries older than 90 days to keep localStorage lean
  const keys = Object.keys(nextHistory);
  if (keys.length > 95) {
    keys.sort();
    for (const k of keys.slice(0, keys.length - 90)) {
      delete nextHistory[k];
    }
  }

  let streak = settings.streak || 0;
  let bestStreak = settings.bestStreak || 0;
  let usedStreakFreeze = false;

  if (!settings.lastActiveDate) {
    streak = Math.max(1, streak);
  } else if (settings.lastActiveDate === isoDate) {
    streak = Math.max(1, streak);
  } else {
    const gapDays = diffCalendarDays(settings.lastActiveDate, isoDate);
    if (gapDays === 1) {
      streak = streak + 1;
    } else if (gapDays === 2 && freezes > 0) {
      // Missed exactly 1 single day — consume 1 Streak Freeze automatically!
      freezes -= 1;
      streak = streak + 1;
      usedStreakFreeze = true;
    } else if (gapDays > 1) {
      streak = 1;
    }
  }

  if (streak > bestStreak) {
    bestStreak = streak;
  }

  return {
    usedStreakFreeze,
    replenishedFreeze,
    settingsPatch: {
      studyHistory: nextHistory,
      streak,
      bestStreak,
      streakFreezes: freezes,
      lastFreezeWeek: weekKey,
      lastActiveDate: isoDate,
    },
  };
}

export interface DailyPlanStepItem {
  id: DailyPlanStepId;
  order: number;
  titleAr: string;
  subtitleAr: string;
  actionLabelAr: string;
  completed: boolean;
  metaLabel: string;
}

export interface DailyPlanModel {
  band: CefrBand;
  subLevelIndex: number;
  paceMinutes: DailyPaceMinutes;
  wordTargetCount: number;
  steps: DailyPlanStepItem[];
  completedCount: number;
  totalSteps: number;
  allCompleted: boolean;
  bonusClaimed: boolean;
  bonusXp: number;
}

export function buildDailyPlan(
  settings: PersistedSettings,
  srsDueCount: number,
  todayKey: string
): DailyPlanModel {
  const band: CefrBand = settings.lastBand || 'A0';
  const subLevelIndex = Math.max(0, settings.lastSubLevel || 0);
  const paceMinutes: DailyPaceMinutes = settings.dailyPaceMinutes || 10;
  const wordTargetCount = paceMinutes === 5 ? 5 : paceMinutes === 20 ? 15 : 10;
  const stepsState: DailyPlanStepsState =
    settings.dailyPlanDate === todayKey && settings.dailyPlanSteps ? settings.dailyPlanSteps : {};
  const dailySentencesDone =
    settings.dailyPlanDate === todayKey ? settings.dailySentencesCount || 0 : 0;

  const srsSubtitle =
    srsDueCount > 0
      ? `راجع ${Math.min(srsDueCount, 12)} بطاقة مستحقة اليوم لتثبيت الذاكرة`
      : 'إحماء سريع لـ 5 كلمات ببطاقات أنكي الذكية';

  const steps: DailyPlanStepItem[] = [
    {
      id: 'srs',
      order: 1,
      titleAr: srsDueCount > 0 ? 'مراجعة بطاقات أنكي المستحقة' : 'إحماء سريع (5 كلمات)',
      subtitleAr: srsSubtitle,
      actionLabelAr: 'ابدأ الآن',
      completed: Boolean(stepsState.srs),
      metaLabel: srsDueCount > 0 ? `${srsDueCount} مستحقة` : 'دقيقتان',
    },
    {
      id: 'words',
      order: 2,
      titleAr: `تعلّم ${wordTargetCount} كلمات من مستوى ${band}`,
      subtitleAr: `المستوى الفرعي #${subLevelIndex + 1} · تدريب تفاعلي منوّع`,
      actionLabelAr: 'ابدأ الآن',
      completed: Boolean(stepsState.words),
      metaLabel: `${band} · #${subLevelIndex + 1}`,
    },
    {
      id: 'sentences',
      order: 3,
      titleAr: 'تدرّب على 3 جمل استماعاً ونطقاً',
      subtitleAr:
        dailySentencesDone > 0 && !stepsState.sentences
          ? `أنجزت ${dailySentencesDone}/3 جمل اليوم — أكمل المتبقي`
          : 'استمع للجملة وردّدها بصوتك أو عبر تدريب الظل',
      actionLabelAr: 'ابدأ الآن',
      completed: Boolean(stepsState.sentences),
      metaLabel: `${Math.min(3, dailySentencesDone)}/3 جمل`,
    },
    {
      id: 'grammarOrListening',
      order: 4,
      titleAr: 'درس قواعد قصير أو مقطع استماع',
      subtitleAr: 'أكمل تمرين قاعدة واحدة أو شاهد مقطع استماع مع ترجمة',
      actionLabelAr: 'ابدأ الآن',
      completed: Boolean(stepsState.grammarOrListening),
      metaLabel: 'قواعد / استماع',
    },
  ];

  const completedCount = steps.filter((s) => s.completed).length;
  return {
    band,
    subLevelIndex,
    paceMinutes,
    wordTargetCount,
    steps,
    completedCount,
    totalSteps: steps.length,
    allCompleted: completedCount === steps.length,
    bonusClaimed: Boolean(stepsState.bonusClaimed),
    bonusXp: DAILY_PLAN_BONUS_XP,
  };
}

export interface DailyPlanStepUpdate {
  settingsPatch: Partial<PersistedSettings>;
  newlyCompletedStep: boolean;
  awardedDailyBonusXp: number;
}

export function markDailyPlanStep(
  settings: PersistedSettings,
  stepId: DailyPlanStepId,
  todayKey: string
): DailyPlanStepUpdate {
  const prevSteps: DailyPlanStepsState =
    settings.dailyPlanDate === todayKey && settings.dailyPlanSteps ? settings.dailyPlanSteps : {};

  if (prevSteps[stepId]) {
    return {
      settingsPatch: {},
      newlyCompletedStep: false,
      awardedDailyBonusXp: 0,
    };
  }

  const nextSteps: DailyPlanStepsState = {
    ...prevSteps,
    [stepId]: true,
  };

  const allFourDone = Boolean(
    nextSteps.srs && nextSteps.words && nextSteps.sentences && nextSteps.grammarOrListening
  );

  let awardedDailyBonusXp = 0;
  if (allFourDone && !nextSteps.bonusClaimed) {
    nextSteps.bonusClaimed = true;
    awardedDailyBonusXp = DAILY_PLAN_BONUS_XP;
  }

  return {
    newlyCompletedStep: true,
    awardedDailyBonusXp,
    settingsPatch: {
      dailyPlanDate: todayKey,
      dailyPlanSteps: nextSteps,
      ...(awardedDailyBonusXp > 0 ? { xp: (settings.xp || 0) + awardedDailyBonusXp } : {}),
    },
  };
}

export interface HeatmapDayCell {
  isoDate: string;
  count: number;
  level: 0 | 1 | 2 | 3 | 4;
  dayNumber: number;
  monthLabel: string;
}

const AR_MONTHS = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

export function build30DayHeatmap(
  studyHistory: Record<string, number> | undefined,
  todayIso: string = toIsoDate()
): HeatmapDayCell[] {
  const history = studyHistory || {};
  const todayUtc = parseIsoDateUtc(todayIso);
  const cells: HeatmapDayCell[] = [];

  for (let offset = 29; offset >= 0; offset--) {
    const dt = new Date(todayUtc.getTime() - offset * 86_400_000);
    const y = dt.getUTCFullYear();
    const m = String(dt.getUTCMonth() + 1).padStart(2, '0');
    const d = String(dt.getUTCDate()).padStart(2, '0');
    const iso = `${y}-${m}-${d}`;
    const count = history[iso] || 0;
    const level: 0 | 1 | 2 | 3 | 4 =
      count <= 0 ? 0 : count <= 3 ? 1 : count <= 10 ? 2 : count <= 20 ? 3 : 4;

    cells.push({
      isoDate: iso,
      count,
      level,
      dayNumber: dt.getUTCDate(),
      monthLabel: AR_MONTHS[dt.getUTCMonth()] || '',
    });
  }
  return cells;
}

export interface AchievementBadge {
  id: string;
  titleAr: string;
  descAr: string;
  unlocked: boolean;
  progressLabel: string;
}

export function computeAchievementBadges(
  settings: PersistedSettings
): AchievementBadge[] {
  const masteredCount = settings.mastered.length;
  const bestStreak = Math.max(settings.streak || 0, settings.bestStreak || 0);
  const srsCount = Object.keys(settings.srsCards || {}).length;
  const grammarCount = (settings.completedGrammarIds || []).length;
  const practicedSentences = (settings.practicedSentences || []).length;
  const listeningVideos = Object.values(settings.listeningProgress || {}).reduce(
    (sum, bp) => sum + (bp?.completedVideoIds?.length || 0),
    0
  );

  return [
    {
      id: 'first_10',
      titleAr: 'بداية قوية',
      descAr: 'أتقن أول 10 كلمات إنجليزية',
      unlocked: masteredCount >= 10,
      progressLabel: `${Math.min(masteredCount, 10)}/10`,
    },
    {
      id: 'streak_7',
      titleAr: 'التزام أسبوعي',
      descAr: 'حافظ على سلسلة تعلّم 7 أيام',
      unlocked: bestStreak >= 7,
      progressLabel: `${Math.min(bestStreak, 7)}/7`,
    },
    {
      id: 'words_100',
      titleAr: 'حافظ المئة كلمة',
      descAr: 'أتقن 100 كلمة من المنهج',
      unlocked: masteredCount >= 100,
      progressLabel: `${Math.min(masteredCount, 100)}/100`,
    },
    {
      id: 'anki_20',
      titleAr: 'ذاكرة أنكي',
      descAr: 'راجع 20 بطاقة بالتكرار المتباعد',
      unlocked: srsCount >= 20,
      progressLabel: `${Math.min(srsCount, 20)}/20`,
    },
    {
      id: 'sentences_15',
      titleAr: 'نطق واثق',
      descAr: 'تدرّب على 15 جملة بالصوت',
      unlocked: practicedSentences >= 15,
      progressLabel: `${Math.min(practicedSentences, 15)}/15`,
    },
    {
      id: 'grammar_5',
      titleAr: 'متقن القواعد',
      descAr: 'أكمل 5 دروس قواعد إنجليزية',
      unlocked: grammarCount >= 5,
      progressLabel: `${Math.min(grammarCount, 5)}/5`,
    },
    {
      id: 'listening_3',
      titleAr: 'أذن متمرّسة',
      descAr: 'أكمل 3 مقاطع استماع إنجليزية',
      unlocked: listeningVideos >= 3,
      progressLabel: `${Math.min(listeningVideos, 3)}/3`,
    },
    {
      id: 'xp_1000',
      titleAr: 'نجم الألف نقطة',
      descAr: 'اجمع 1,000 نقطة خبرة XP',
      unlocked: (settings.xp || 0) >= 1000,
      progressLabel: `${Math.min(settings.xp || 0, 1000)}/1000`,
    },
  ];
}

export interface UnlockedCertificateBand {
  band: CefrBand;
  reasonAr: string;
  masteredInBand: number;
  totalInBand: number;
}

export function getUnlockedCertificateBands(
  settings: PersistedSettings,
  store: VocabStore
): UnlockedCertificateBand[] {
  const masteredSet = new Set(settings.mastered);
  const unlocked: UnlockedCertificateBand[] = [];
  const placementBand = settings.placementResult?.cefrBand || null;

  for (const band of BANDS) {
    const ids = store.byBand[band] || [];
    let masteredInBand = 0;
    for (const id of ids) {
      if (masteredSet.has(id)) masteredInBand++;
    }
    const pct = ids.length > 0 ? masteredInBand / ids.length : 0;
    const isPlacementEarned =
      placementBand !== null && BANDS.indexOf(band) <= BANDS.indexOf(placementBand);

    if (pct >= 0.8 || isPlacementEarned) {
      unlocked.push({
        band,
        reasonAr:
          pct >= 0.8
            ? `إتمام ${Math.round(pct * 100)}% من كلمات ${band}`
            : `اجتياز اختبار تحديد المستوى (${placementBand})`,
        masteredInBand,
        totalInBand: ids.length,
      });
    }
  }

  // Always offer the learner's current active band as a Progress Certificate if none unlocked yet
  if (unlocked.length === 0) {
    const currentBand = settings.lastBand || 'A0';
    const ids = store.byBand[currentBand] || [];
    let masteredInBand = 0;
    for (const id of ids) {
      if (masteredSet.has(id)) masteredInBand++;
    }
    unlocked.push({
      band: currentBand,
      reasonAr: `شهادة تقدم فعّال في مستوى ${currentBand}`,
      masteredInBand,
      totalInBand: ids.length,
    });
  }

  return unlocked;
}

function escapeCsvCell(value: string): string {
  const clean = value.replace(/\r?\n/g, ' ').trim();
  if (clean.includes(',') || clean.includes('"') || clean.includes('\t')) {
    return `"${clean.replace(/"/g, '""')}"`;
  }
  return clean;
}

/**
 * Generates an Anki-ready UTF-8 BOM CSV string containing Front (EN), Back (AR), and Tags.
 */
export function buildAnkiCsvExport(
  favoriteWords: VocabEntry[],
  savedNotes: SavedWordNote[],
  favoriteSentences: Array<{ en: string; ar: string }>
): string {
  const rows: string[] = ['Front,Back,Tags'];

  for (const w of favoriteWords) {
    rows.push(
      [
        escapeCsvCell(w.en),
        escapeCsvCell(w.ar),
        escapeCsvCell(`TMN word ${w.band}`),
      ].join(',')
    );
  }

  for (const n of savedNotes) {
    const back = n.extra ? `${n.meaningAr} (${n.extra})` : n.meaningAr;
    rows.push(
      [
        escapeCsvCell(n.text),
        escapeCsvCell(back),
        escapeCsvCell(`TMN note ${n.kind} ${n.parentWord}`),
      ].join(',')
    );
  }

  for (const s of favoriteSentences) {
    rows.push(
      [
        escapeCsvCell(s.en),
        escapeCsvCell(s.ar || 'Favorite Sentence'),
        escapeCsvCell('TMN sentence'),
      ].join(',')
    );
  }

  return `\uFEFF${rows.join('\n')}`;
}

export type MistakeFixerPhase = 'listen' | 'choose' | 'type';

export interface MistakeFixerWordProgress {
  wordId: number;
  consecutiveCorrect: number;
  graduated: boolean;
}

export interface MistakeFixerState {
  queue: number[];
  progress: Record<number, MistakeFixerWordProgress>;
  stepCount: number;
  graduatedIds: number[];
  totalXpEarned: number;
}

const PHASE_ORDER: MistakeFixerPhase[] = ['listen', 'choose', 'type'];

export function createMistakeFixerSession(
  mistakeWordIds: number[],
  maxWords: number = 8
): MistakeFixerState {
  const uniqueIds = Array.from(new Set(mistakeWordIds)).slice(0, maxWords);
  const progress: Record<number, MistakeFixerWordProgress> = {};
  for (const id of uniqueIds) {
    progress[id] = { wordId: id, consecutiveCorrect: 0, graduated: false };
  }
  return {
    queue: uniqueIds,
    progress,
    stepCount: 0,
    graduatedIds: [],
    totalXpEarned: 0,
  };
}

export function getMistakeFixerPhase(state: MistakeFixerState): MistakeFixerPhase {
  return PHASE_ORDER[state.stepCount % PHASE_ORDER.length];
}

export function submitMistakeFixerAnswer(
  state: MistakeFixerState,
  isCorrect: boolean
): {
  nextState: MistakeFixerState;
  graduatedWordId: number | null;
  xpAwarded: number;
} {
  if (state.queue.length === 0) {
    return { nextState: state, graduatedWordId: null, xpAwarded: 0 };
  }

  const [currentId, ...rest] = state.queue;
  const currentProg = state.progress[currentId] || {
    wordId: currentId,
    consecutiveCorrect: 0,
    graduated: false,
  };

  let nextConsecutive = isCorrect ? currentProg.consecutiveCorrect + 1 : 0;
  let graduatedWordId: number | null = null;
  let xpAwarded = 0;
  let nextQueue = [...rest];

  if (nextConsecutive >= 2) {
    graduatedWordId = currentId;
    xpAwarded = MISTAKE_FIXER_GRADUATION_XP;
  } else if (isCorrect) {
    // Needs 1 more consecutive correct answer — place near the end of the queue
    nextQueue.push(currentId);
  } else {
    // Missed — re-insert sooner (after 1–2 cards) so it gets reinforced immediately
    const insertAt = Math.min(2, nextQueue.length);
    nextQueue.splice(insertAt, 0, currentId);
  }

  const nextProgress: Record<number, MistakeFixerWordProgress> = {
    ...state.progress,
    [currentId]: {
      wordId: currentId,
      consecutiveCorrect: nextConsecutive,
      graduated: graduatedWordId !== null,
    },
  };

  return {
    graduatedWordId,
    xpAwarded,
    nextState: {
      queue: nextQueue,
      progress: nextProgress,
      stepCount: state.stepCount + 1,
      graduatedIds:
        graduatedWordId !== null
          ? [...state.graduatedIds, graduatedWordId]
          : state.graduatedIds,
      totalXpEarned: state.totalXpEarned + xpAwarded,
    },
  };
}
