import { BANDS, BAND_META } from '../data/constants';
import { STANDALONE_HTML_PREFIX, STANDALONE_HTML_SUFFIX } from '../data/standaloneTemplate';
import type { BankTile, CefrBand, LetterSlot, VocabEntry, VocabStore } from '../types';

export function assignBandByIndex(i: number): CefrBand {
  if (i < 400) return 'A0';
  if (i < 900) return 'A1';
  if (i < 1800) return 'A2';
  if (i < 3000) return 'B1';
  if (i < 6000) return 'B2';
  if (i < 9000) return 'C1';
  return 'C2';
}

export function normalizeEn(str: string): string {
  return (str || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

export function normalizeAr(str: string): string {
  return (str || '')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/[^\u0600-\u06FFa-zA-Z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function stripAl(s: string): string {
  return s.startsWith('ال') && s.length > 4 ? s.slice(2) : s;
}

export function checkArabicMatch(userInput: string, targetAr: string): boolean {
  const uNorm = normalizeAr(userInput);
  if (!uNorm) return false;
  const tFull = normalizeAr(targetAr);
  if (uNorm === tFull || stripAl(uNorm) === stripAl(tFull)) return true;
  const parts = targetAr
    .split(/[-–—/،,;؛|()]+/)
    .map((p) => normalizeAr(p))
    .filter(Boolean);
  for (let i = 0; i < parts.length; i++) {
    if (uNorm === parts[i] || stripAl(uNorm) === stripAl(parts[i])) return true;
  }
  return false;
}

export function checkEnglishMatch(userInput: string, targetEn: string): boolean {
  const u = normalizeEn(userInput);
  const t = normalizeEn(targetEn);
  if (!u) return false;
  if (u === t) return true;
  return u.replace(/[-'\s]/g, '') === t.replace(/[-'\s]/g, '');
}

export function parseTSVToStore(tsvText: string): VocabStore {
  const words: VocabEntry[] = [];
  const byBand: Record<CefrBand, number[]> = {
    A0: [],
    A1: [],
    A2: [],
    B1: [],
    B2: [],
    C1: [],
    C2: [],
  };
  const normEn: string[] = [];
  const normAr: string[] = [];

  let start = 0;
  const len = tsvText.length;
  while (start < len) {
    let end = tsvText.indexOf('\n', start);
    if (end === -1) end = len;
    const rawLine = tsvText.slice(start, end);
    const line = rawLine.endsWith('\r') ? rawLine.slice(0, -1) : rawLine;
    if (line && !line.trimStart().startsWith('<!--')) {
      const t1 = line.indexOf('\t');
      if (t1 > 0) {
        const t2 = line.indexOf('\t', t1 + 1);
        let wBand: CefrBand;
        let wEn: string;
        let wAr: string;
        if (t2 > t1) {
          const maybeBand = line.slice(0, t1).trim().toUpperCase() as CefrBand;
          wBand = maybeBand in BAND_META ? maybeBand : assignBandByIndex(words.length);
          wEn = line.slice(t1 + 1, t2).trim();
          wAr = line.slice(t2 + 1).trim();
        } else {
          wBand = assignBandByIndex(words.length);
          wEn = line.slice(0, t1).trim();
          wAr = line.slice(t1 + 1).trim();
        }
        if (wEn && wAr) {
          const id = words.length;
          words.push({ id, band: wBand, en: wEn, ar: wAr });
          byBand[wBand].push(id);
          normEn.push(wEn.toLowerCase());
          normAr.push(normalizeAr(wAr));
        }
      }
    }
    start = end + 1;
  }

  return { words, byBand, normEn, normAr };
}

export function parseCSVTextToTSV(text: string): string {
  const rows: string[][] = [];
  let row: string[] = [];
  let cur = '';
  let inQ = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQ) {
      if (c === '"' && text[i + 1] === '"') {
        cur += '"';
        i++;
      } else if (c === '"') {
        inQ = false;
      } else {
        cur += c;
      }
    } else if (c === '"') {
      inQ = true;
    } else if (c === ',') {
      row.push(cur);
      cur = '';
    } else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(cur);
      cur = '';
      if (row.length >= 2) rows.push(row);
      row = [];
    } else {
      cur += c;
    }
  }
  if (cur || row.length) {
    row.push(cur);
    if (row.length >= 2) rows.push(row);
  }

  const seen = new Set<string>();
  const out: string[] = [];
  for (let i = 0; i < rows.length; i++) {
    let b: CefrBand;
    let en = '';
    let ar = '';
    const firstUpper = (rows[i][0] || '').trim().toUpperCase() as CefrBand;
    if (rows[i].length >= 3 && firstUpper in BAND_META) {
      b = firstUpper;
      en = (rows[i][1] || '').normalize('NFKC').trim().replace(/[\t\r\n]/g, ' ');
      ar = (rows[i][2] || '').trim().replace(/[\t\r\n]/g, ' ');
    } else {
      en = (rows[i][0] || '').normalize('NFKC').trim().replace(/[\t\r\n]/g, ' ');
      ar = (rows[i][1] || '').trim().replace(/[\t\r\n]/g, ' ');
      b = assignBandByIndex(out.length);
    }
    if (!en || !ar) continue;
    if (
      i === 0 &&
      (/^(band|level|cefr|english|word|term)$/i.test(en) ||
        /^(english|arabic|meaning|translation|word)$/i.test(ar))
    ) {
      continue;
    }
    const k = en.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(`${b}\t${en}\t${ar}`);
  }
  return out.join('\n');
}

export interface ExtractedVocabResult {
  found: boolean;
  sourceType: 'html_embedded' | 'tsv_raw' | 'csv' | 'none';
  rawVocabBlock: string;
  store: VocabStore;
}

/**
 * Losslessly extracts the exact vocabulary lines from:
 * 1. An HTML file containing <script ... id="embedded-vocab" ...>...</script>
 * 2. A raw TSV text file (lines with tab separators)
 * 3. A CSV file
 * Preserves every single line untouched when extracted from HTML or raw TSV.
 */
export function extractVocabFromInput(inputText: string): ExtractedVocabResult {
  const emptyStore = parseTSVToStore('');
  if (!inputText || !inputText.trim()) {
    return { found: false, sourceType: 'none', rawVocabBlock: '', store: emptyStore };
  }

  // 1. Check for <script ... id="embedded-vocab" ...>...</script>
  const scriptRegex =
    /<script\b[^>]*\bid\s*=\s*["']embedded-vocab["'][^>]*>([\s\S]*?)<\/script>/i;
  const match = scriptRegex.exec(inputText);
  if (match) {
    const inner = match[1].replace(/^\r?\n/, '').replace(/\r?\n$/, '');
    const store = parseTSVToStore(inner);
    return {
      found: store.words.length > 0,
      sourceType: 'html_embedded',
      rawVocabBlock: inner,
      store,
    };
  }

  // 2. Check if it is raw TSV (contains tabs on multiple lines or first valid line)
  if (inputText.includes('\t')) {
    const cleaned = inputText.replace(/^\uFEFF/, '').trim();
    const store = parseTSVToStore(cleaned);
    if (store.words.length > 0) {
      return {
        found: true,
        sourceType: 'tsv_raw',
        rawVocabBlock: cleaned,
        store,
      };
    }
  }

  // 3. Fallback to CSV
  const tsvFromCsv = parseCSVTextToTSV(inputText.replace(/^\uFEFF/, ''));
  const store = parseTSVToStore(tsvFromCsv);
  if (store.words.length > 0) {
    return {
      found: true,
      sourceType: 'csv',
      rawVocabBlock: tsvFromCsv,
      store,
    };
  }

  return { found: false, sourceType: 'none', rawVocabBlock: '', store: emptyStore };
}

/**
 * Produces the final merged standalone single-file index.html with the
 * exact vocabulary lines injected inside <script type="text/plain" id="embedded-vocab">.
 */
export function buildStandaloneHtml(
  rawVocabBlock: string,
  options?: { unsplashKey?: string; pixabayKey?: string }
): string {
  // Neutralize any accidental </script> sequence inside data just in case
  const safeBlock = rawVocabBlock.replace(/<\/script>/gi, '<\\/script>');
  let suffix = STANDALONE_HTML_SUFFIX;
  if (options?.unsplashKey !== undefined) {
    const escapedKey = options.unsplashKey.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    suffix = suffix.replace(
      "unsplashKey: (saved && saved.unsplashKey) || 'ofbUnj5e3vSjfGor04gqVKKkVBTUet-PqtFnRNqWPzI'",
      `unsplashKey: (saved && saved.unsplashKey) || '${escapedKey}'`
    );
  }
  if (options?.pixabayKey) {
    const escapedPix = options.pixabayKey.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    suffix = suffix.replace(
      "pixabayKey: (saved && saved.pixabayKey) || ''",
      `pixabayKey: (saved && saved.pixabayKey) || '${escapedPix}'`
    );
  }
  return STANDALONE_HTML_PREFIX + safeBlock + suffix;
}

export function getBandSubCount(store: VocabStore, band: CefrBand, levelSize: number): number {
  const arr = store.byBand[band] || [];
  return Math.max(1, Math.ceil(arr.length / Math.max(1, levelSize)));
}

export function getBandSubIndices(
  store: VocabStore,
  band: CefrBand,
  subIdx: number,
  levelSize: number
): number[] {
  const arr = store.byBand[band] || [];
  return arr.slice(subIdx * levelSize, (subIdx + 1) * levelSize);
}

export function lvlKey(band: CefrBand, subIdx: number): string {
  return `${band}:${subIdx}`;
}

export function getBandDoneCount(
  store: VocabStore,
  band: CefrBand,
  levelSize: number,
  completed: Record<string, number>
): number {
  const total = getBandSubCount(store, band, levelSize);
  let count = 0;
  for (let i = 0; i < total; i++) {
    if ((completed[lvlKey(band, i)] || 0) >= 80) count++;
  }
  return count;
}

export function shuffleArr<T>(arr: T[], rng: () => number = Math.random): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const t = a[i];
    a[i] = a[j];
    a[j] = t;
  }
  return a;
}

export function pickDistractors(
  store: VocabStore,
  targetIdx: number,
  count: number,
  checkByAr: boolean,
  rng: () => number = Math.random
): number[] {
  const target = store.words[targetIdx];
  if (!target) return [];
  const chosen = new Set<number>([targetIdx]);
  const targetKey = checkByAr ? normalizeAr(target.ar) : normalizeEn(target.en);
  const out: number[] = [];
  const bandArr = store.byBand[target.band] || [];

  let guard = 0;
  while (out.length < count && guard < 120 && bandArr.length > count + 2) {
    guard++;
    const r = bandArr[Math.floor(rng() * bandArr.length)];
    if (chosen.has(r)) continue;
    const cand = store.words[r];
    if (!cand) continue;
    const candKey = checkByAr ? normalizeAr(cand.ar) : normalizeEn(cand.en);
    if (candKey === targetKey) continue;
    chosen.add(r);
    out.push(r);
  }

  guard = 0;
  while (out.length < count && guard < 200 && store.words.length > out.length + 1) {
    guard++;
    const r = Math.floor(rng() * store.words.length);
    if (chosen.has(r)) continue;
    const cand = store.words[r];
    if (!cand) continue;
    const candKey = checkByAr ? normalizeAr(cand.ar) : normalizeEn(cand.en);
    if (candKey === targetKey) continue;
    chosen.add(r);
    out.push(r);
  }

  return out;
}

export function getRandomPool(
  store: VocabStore,
  band: CefrBand | null,
  levelSize: number,
  rng: () => number = Math.random
): number[] {
  const arr = band && store.byBand[band] && store.byBand[band].length > 0 ? store.byBand[band] : null;
  const maxAvailable = arr ? arr.length : store.words.length;
  const n = Math.min(levelSize, maxAvailable);
  const pool: number[] = [];
  const used = new Set<number>();
  let guard = 0;
  while (pool.length < n && guard < n * 20 + 50) {
    guard++;
    const r = arr ? arr[Math.floor(rng() * arr.length)] : Math.floor(rng() * store.words.length);
    if (!used.has(r)) {
      used.add(r);
      pool.push(r);
    }
  }
  return pool;
}

export function buildMissingLettersData(
  en: string,
  rng: () => number = Math.random
): { slots: LetterSlot[]; bank: BankTile[] } {
  const chars = Array.from(en);
  const letterPositions: number[] = [];
  chars.forEach((ch, i) => {
    if (/[a-zA-Z]/.test(ch)) letterPositions.push(i);
  });

  const L = letterPositions.length;
  const hideCount =
    L <= 2 ? 1 : L <= 4 ? 2 : L <= 7 ? Math.ceil(L * 0.45) : Math.min(Math.ceil(L * 0.5), 7);
  const hiddenSet = new Set(shuffleArr(letterPositions, rng).slice(0, hideCount));

  const slots: LetterSlot[] = chars.map((ch, i) => {
    if (!/[a-zA-Z]/.test(ch)) {
      return { type: 'punct', target: ch, value: ch, tileId: null };
    }
    if (hiddenSet.has(i)) {
      return { type: 'blank', target: ch.toLowerCase(), value: '', tileId: null };
    }
    return { type: 'fixed', target: ch, value: ch, tileId: null };
  });

  const missingChars = slots.filter((s) => s.type === 'blank').map((s) => s.target);
  const alpha = 'abcdefghijklmnopqrstuvwxyz';
  const decoyCount = Math.min(4, Math.max(2, 8 - missingChars.length));
  const decoys: string[] = [];
  for (let i = 0; i < decoyCount; i++) {
    decoys.push(alpha[Math.floor(rng() * alpha.length)]);
  }

  const bank: BankTile[] = shuffleArr([...missingChars, ...decoys], rng).map((ch, i) => ({
    id: i,
    ch,
    used: false,
  }));

  return { slots, bank };
}

export function buildScrambleData(
  en: string,
  rng: () => number = Math.random
): { slots: LetterSlot[]; bank: BankTile[] } {
  const slots: LetterSlot[] = Array.from(en).map((ch) =>
    /[a-zA-Z]/.test(ch)
      ? { type: 'blank', target: ch.toLowerCase(), value: '', tileId: null }
      : { type: 'punct', target: ch, value: ch, tileId: null }
  );

  const letters = slots.filter((s) => s.type === 'blank').map((s) => s.target);
  const tileChars = letters.slice();
  let hasDecoy = false;
  if (tileChars.length === 1) {
    hasDecoy = true;
    const alpha = 'aeiourstln';
    while (tileChars.length < 4) {
      const c = alpha[Math.floor(rng() * alpha.length)];
      if (!tileChars.includes(c)) tileChars.push(c);
    }
  }

  let scrambled = shuffleArr(tileChars, rng);
  if (new Set(tileChars).size > 1 && !hasDecoy) {
    let tries = 0;
    while (scrambled.join('') === letters.join('') && tries < 20) {
      scrambled = shuffleArr(tileChars, rng);
      tries++;
    }
  }

  const bank: BankTile[] = scrambled.map((ch, i) => ({
    id: i,
    ch,
    used: false,
  }));

  return { slots, bank };
}

export interface CharDiffPart {
  text: string;
  kind: 'ok' | 'bad' | 'expected';
}

export function computeCharDiff(userStr: string, targetStr: string): CharDiffPart[] {
  const u = Array.from(userStr);
  const t = Array.from(targetStr);
  const maxLen = Math.max(u.length, t.length);
  const parts: CharDiffPart[] = [];
  for (let i = 0; i < maxLen; i++) {
    const uc = u[i] || '';
    const tc = t[i] || '';
    if (uc.toLowerCase() === tc.toLowerCase() && tc) {
      parts.push({ text: tc, kind: 'ok' });
    } else {
      if (uc) parts.push({ text: uc, kind: 'bad' });
      if (tc) parts.push({ text: tc, kind: 'expected' });
    }
  }
  return parts;
}

export function buildTargetRx(word: string): RegExp | null {
  const clean = String(word || '').trim();
  if (!clean) return null;
  const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  if (/[\s-]/.test(clean)) {
    return new RegExp(
      `(^|[^a-zA-Z0-9])(${esc(clean).replace(/[\s-]+/g, '[\\s-]+')})(?=$|[^a-zA-Z0-9])`,
      'i'
    );
  }
  const l = clean.toLowerCase();
  const vars = [
    esc(l),
    esc(l + 's'),
    esc(l + 'es'),
    esc(l + 'ed'),
    esc(l + 'd'),
    esc(l + 'ing'),
    esc(l + 'er'),
    esc(l + 'est'),
    esc(l + 'ly'),
  ];
  if (l.endsWith('e') && l.length > 2) {
    const b = l.slice(0, -1);
    vars.push(esc(b + 'ing'), esc(b + 'ed'), esc(b + 'es'));
  }
  if (l.endsWith('y') && l.length > 2) {
    const b = l.slice(0, -1);
    vars.push(esc(b + 'ies'), esc(b + 'ied'));
  }
  vars.sort((a, b) => b.length - a.length);
  return new RegExp(`(^|[^a-zA-Z0-9])(${vars.join('|')})(?=$|[^a-zA-Z0-9])`, 'i');
}

export function splitTargetHighlight(
  text: string,
  word: string
): { matched: boolean; segments: Array<{ text: string; highlight: boolean }> } {
  const rx = buildTargetRx(word);
  if (!rx) return { matched: false, segments: [{ text, highlight: false }] };
  const m = rx.exec(text);
  if (!m) return { matched: false, segments: [{ text, highlight: false }] };
  const pre = m[1] ? m[1].length : 0;
  const start = m.index + pre;
  const end = start + m[2].length;
  const segments: Array<{ text: string; highlight: boolean }> = [];
  if (start > 0) segments.push({ text: text.slice(0, start), highlight: false });
  segments.push({ text: text.slice(start, end), highlight: true });
  if (end < text.length) segments.push({ text: text.slice(end), highlight: false });
  return { matched: true, segments };
}

export function searchVocab(
  store: VocabStore,
  query: string,
  bandFilter: CefrBand | 'ALL'
): number[] {
  const raw = (query || '').trim();
  if (!raw) return [];
  const qEn = raw.toLowerCase();
  const qAr = normalizeAr(raw);
  const isAr = /[\u0600-\u06FF]/.test(raw);
  const pool = bandFilter === 'ALL' ? null : store.byBand[bandFilter] || [];
  const matches: number[] = [];

  if (pool) {
    for (let k = 0; k < pool.length; k++) {
      const i = pool[k];
      if (isAr ? store.normAr[i].includes(qAr) : store.normEn[i].includes(qEn)) {
        matches.push(i);
      }
    }
  } else {
    for (let i = 0; i < store.words.length; i++) {
      if (isAr ? store.normAr[i].includes(qAr) : store.normEn[i].includes(qEn)) {
        matches.push(i);
      }
    }
  }
  return matches;
}

export function serializeStoreToTSV(store: VocabStore): string {
  return store.words.map((w) => `${w.band}\t${w.en}\t${w.ar}`).join('\n');
}

export function getBandCounts(store: VocabStore): Record<CefrBand, number> {
  const out = {} as Record<CefrBand, number>;
  for (const b of BANDS) {
    out[b] = store.byBand[b].length;
  }
  return out;
}
