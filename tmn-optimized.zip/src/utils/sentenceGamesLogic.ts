import type { SentenceEntry } from '../types';

export type SentenceErrorCategory = 'grammar' | 'spelling' | 'meaning';

export interface SentenceOrderTile {
  id: number;
  word: string;
}

export interface SentenceOrderQuestion {
  id: string;
  en: string;
  ar: string;
  targetWords: string[];
  tiles: SentenceOrderTile[];
}

export interface SentenceErrorQuestion {
  id: string;
  /** Display tokens containing the 1 deliberate erroneous word */
  tokens: string[];
  /** Exactly 4 distinct token indices that are underlined in the sentence */
  underlinedIndices: [number, number, number, number];
  /** Which token index (must be inside underlinedIndices) has the error */
  errorIndex: number;
  wrongWord: string;
  correctWord: string;
  correctSentence: string;
  ar: string;
  errorType: SentenceErrorCategory;
  explanationAr: string;
}

export const ERROR_TYPE_LABELS: Record<SentenceErrorCategory, string> = {
  grammar: 'خطأ قواعدي',
  spelling: 'خطأ إملائي',
  meaning: 'خطأ بالمعنى',
};

function seededRandom(seed: number): () => number {
  let s = (seed >>> 0) || 1;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

/**
 * Cleanly splits an English sentence into orderable word tokens.
 */
export function tokenizeSentenceForOrder(sentence: string): string[] {
  const primary = sentence.split('=')[0].trim();
  const cleaned = primary
    .replace(/[“”"()]/g, '')
    .replace(/([?.!,;:])/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!cleaned) return [];
  return cleaned.split(' ').filter((w) => w.length > 0);
}

export function buildSentenceOrderQuestion(
  entry: SentenceEntry,
  ar: string,
  seed = entry.num + 17
): SentenceOrderQuestion | null {
  const targetWords = tokenizeSentenceForOrder(entry.en);
  if (targetWords.length < 3 || targetWords.length > 14) return null;

  const rnd = seededRandom(seed);
  const tiles: SentenceOrderTile[] = targetWords.map((word, id) => ({ id, word }));

  // Fisher-Yates shuffle ensuring order differs from target whenever possible
  for (let i = tiles.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [tiles[i], tiles[j]] = [tiles[j], tiles[i]];
  }

  const sameOrder = tiles.every((t, idx) => t.word.toLowerCase() === targetWords[idx].toLowerCase());
  if (sameOrder && tiles.length >= 2) {
    [tiles[0], tiles[tiles.length - 1]] = [tiles[tiles.length - 1], tiles[0]];
  }

  return {
    id: `order-${entry.num}`,
    en: entry.en.split('=')[0].trim(),
    ar,
    targetWords,
    tiles,
  };
}

export function checkSentenceOrder(pickedWords: string[], targetWords: string[]): boolean {
  if (pickedWords.length !== targetWords.length) return false;
  return pickedWords.every(
    (w, i) => w.trim().toLowerCase() === targetWords[i].trim().toLowerCase()
  );
}

// =========================================================================
// Curated Sentence Error-Detection Bank (Grammar, Spelling, Meaning)
// Every item has 4 underlined words, exactly 1 error, and an Arabic explanation.
// =========================================================================
interface CuratedErrorSeed {
  sentenceWithError: string;
  underlinedWords: [string, string, string, string];
  wrongWord: string;
  correctWord: string;
  correctSentence: string;
  ar: string;
  errorType: SentenceErrorCategory;
  explanationAr: string;
}

const CURATED_ERROR_SEEDS: CuratedErrorSeed[] = [
  {
    sentenceWithError: 'She go to the office by train every morning.',
    underlinedWords: ['She', 'go', 'office', 'morning.'],
    wrongWord: 'go',
    correctWord: 'goes',
    correctSentence: 'She goes to the office by train every morning.',
    ar: 'هي تذهب إلى المكتب بالقطار كل صباح.',
    errorType: 'grammar',
    explanationAr: 'مع الضمير المفرد الغائب (She) في المضارع البسيط نضيف -es للفعل ليصبح goes.',
  },
  {
    sentenceWithError: 'They was very happy when they heard the good news.',
    underlinedWords: ['was', 'happy', 'heard', 'news.'],
    wrongWord: 'was',
    correctWord: 'were',
    correctSentence: 'They were very happy when they heard the good news.',
    ar: 'كانوا سعداء جداً عندما سمعوا الأخبار السارة.',
    errorType: 'grammar',
    explanationAr: 'الضمير الجمع (They) يأخذ الفعل الماضي were وليس was.',
  },
  {
    sentenceWithError: 'I have been living in this city since five years.',
    underlinedWords: ['living', 'city', 'since', 'years.'],
    wrongWord: 'since',
    correctWord: 'for',
    correctSentence: 'I have been living in this city for five years.',
    ar: 'أعيش في هذه المدينة منذ خمس سنوات.',
    errorType: 'grammar',
    explanationAr: 'نستخدم for مع المدة الزمنية (five years)، أما since فتُستخدم مع نقطة بداية محددة.',
  },
  {
    sentenceWithError: 'He did not went to the meeting yesterday afternoon.',
    underlinedWords: ['did', 'went', 'meeting', 'yesterday'],
    wrongWord: 'went',
    correctWord: 'go',
    correctSentence: 'He did not go to the meeting yesterday afternoon.',
    ar: 'لم يذهب إلى الاجتماع بعد ظهر أمس.',
    errorType: 'grammar',
    explanationAr: 'بعد did not يأتي الفعل دائماً في المصدر (go) وليس في التصريف الماضي (went).',
  },
  {
    sentenceWithError: 'My brother bought an new laptop for his university classes.',
    underlinedWords: ['bought', 'an', 'laptop', 'classes.'],
    wrongWord: 'an',
    correctWord: 'a',
    correctSentence: 'My brother bought a new laptop for his university classes.',
    ar: 'اشترى أخي حاسوباً محمولاً جديداً لدروسه الجامعية.',
    errorType: 'grammar',
    explanationAr: 'كلمة new تبدأ بصوت ساكن، لذا نستخدم أداة النكرة a وليس an.',
  },
  {
    sentenceWithError: 'We will arrive to the airport two hours before the flight.',
    underlinedWords: ['arrive', 'to', 'hours', 'flight.'],
    wrongWord: 'to',
    correctWord: 'at',
    correctSentence: 'We will arrive at the airport two hours before the flight.',
    ar: 'سنصل إلى المطار قبل الرحلة بساعتين.',
    errorType: 'grammar',
    explanationAr: 'الفعل arrive يأخذ حرف الجر at مع الأماكن المحددة مثل المطار وليس to.',
  },
  {
    sentenceWithError: 'There is many books on the table in the library.',
    underlinedWords: ['is', 'many', 'table', 'library.'],
    wrongWord: 'is',
    correctWord: 'are',
    correctSentence: 'There are many books on the table in the library.',
    ar: 'توجد كتب كثيرة على الطاولة في المكتبة.',
    errorType: 'grammar',
    explanationAr: 'الاسم books جمع، لذا نستخدم There are بدلاً من There is.',
  },
  {
    sentenceWithError: 'She can speaks three languages very fluently and clearly.',
    underlinedWords: ['can', 'speaks', 'languages', 'fluently'],
    wrongWord: 'speaks',
    correctWord: 'speak',
    correctSentence: 'She can speak three languages very fluently and clearly.',
    ar: 'تستطيع أن تتحدث ثلاث لغات بطلاقة ووضوح.',
    errorType: 'grammar',
    explanationAr: 'بعد الأفعال الناقصة مثل can يأتي الفعل دائماً في المصدر بدون s ليصبح speak.',
  },
  {
    sentenceWithError: 'This movie is much more better than the one we watched.',
    underlinedWords: ['movie', 'more', 'better', 'watched.'],
    wrongWord: 'more',
    correctWord: 'better (بدون more)',
    correctSentence: 'This movie is much better than the one we watched.',
    ar: 'هذا الفيلم أفضل بكثير من الذي شاهدناه.',
    errorType: 'grammar',
    explanationAr: 'كلمة better هي أصلاً صيغة مقارنة، فلا يجوز وضع more قبلها.',
  },
  {
    sentenceWithError: 'Everyone in the classroom have a copy of the textbook.',
    underlinedWords: ['Everyone', 'classroom', 'have', 'textbook.'],
    wrongWord: 'have',
    correctWord: 'has',
    correctSentence: 'Everyone in the classroom has a copy of the textbook.',
    ar: 'كل شخص في الصف لديه نسخة من الكتاب المدرسي.',
    errorType: 'grammar',
    explanationAr: 'الضمير Everyone يُعامل معاملة المفرد فيأخذ الفعل has وليس have.',
  },
  {
    sentenceWithError: 'I look forward to meet you at the conference next week.',
    underlinedWords: ['look', 'meet', 'conference', 'week.'],
    wrongWord: 'meet',
    correctWord: 'meeting',
    correctSentence: 'I look forward to meeting you at the conference next week.',
    ar: 'أتطلع إلى لقائك في المؤتمر الأسبوع القادم.',
    errorType: 'grammar',
    explanationAr: 'العبارة look forward to يتبعها اسم أو فعل مضاف إليه -ing (meeting).',
  },
  {
    sentenceWithError: 'If it will rain tomorrow, we will stay inside the house.',
    underlinedWords: ['will', 'rain', 'stay', 'house.'],
    wrongWord: 'will',
    correctWord: 'rains (بدون will)',
    correctSentence: 'If it rains tomorrow, we will stay inside the house.',
    ar: 'إذا أمطرت غداً، سنبقى داخل المنزل.',
    errorType: 'grammar',
    explanationAr: 'في جملة الشرط الأولى بعد If نستخدم المضارع البسيط (rains) ولا نستخدم will.',
  },
  {
    sentenceWithError: 'Please let me know when you recieve the package today.',
    underlinedWords: ['Please', 'know', 'recieve', 'package'],
    wrongWord: 'recieve',
    correctWord: 'receive',
    correctSentence: 'Please let me know when you receive the package today.',
    ar: 'يرجى إعلامي عندما تستلم الطرد اليوم.',
    errorType: 'spelling',
    explanationAr: 'الكتابة الإملائية الصحيحة هي receive (تأتي e قبل i بعد الحرف c).',
  },
  {
    sentenceWithError: 'We are planning to visit our grandparents tomorow afternoon.',
    underlinedWords: ['planning', 'visit', 'tomorow', 'afternoon.'],
    wrongWord: 'tomorow',
    correctWord: 'tomorrow',
    correctSentence: 'We are planning to visit our grandparents tomorrow afternoon.',
    ar: 'نخطط لزيارة أجدادنا بعد ظهر غد.',
    errorType: 'spelling',
    explanationAr: 'كلمة tomorrow تُكتب بحرفَي r مزدوجين (double r).',
  },
  {
    sentenceWithError: 'She stayed at home becouse she had a strong headache.',
    underlinedWords: ['stayed', 'becouse', 'strong', 'headache.'],
    wrongWord: 'becouse',
    correctWord: 'because',
    correctSentence: 'She stayed at home because she had a strong headache.',
    ar: 'بقيت في المنزل لأنها كانت تعاني من صداع شديد.',
    errorType: 'spelling',
    explanationAr: 'الكتابة الصحيحة لكلمة "لأن" هي because بحرف a وليس o.',
  },
  {
    sentenceWithError: 'My best freind helped me prepare for the final exam.',
    underlinedWords: ['best', 'freind', 'prepare', 'exam.'],
    wrongWord: 'freind',
    correctWord: 'friend',
    correctSentence: 'My best friend helped me prepare for the final exam.',
    ar: 'ساعدني أفضل صديق لي في التحضير للامتحان النهائي.',
    errorType: 'spelling',
    explanationAr: 'كلمة friend تُكتب i قبل e.',
  },
  {
    sentenceWithError: 'The hotel room had a beautifull view of the blue ocean.',
    underlinedWords: ['hotel', 'beautifull', 'view', 'ocean.'],
    wrongWord: 'beautifull',
    correctWord: 'beautiful',
    correctSentence: 'The hotel room had a beautiful view of the blue ocean.',
    ar: 'كانت غرفة الفندق تتمتع بإطلالة جميلة على المحيط الأزرق.',
    errorType: 'spelling',
    explanationAr: 'اللاحقة -ful في كلمة beautiful تُكتب بحرف l واحد فقط في النهاية.',
  },
  {
    sentenceWithError: 'People from diffrent countries joined the online workshop today.',
    underlinedWords: ['People', 'diffrent', 'countries', 'workshop'],
    wrongWord: 'diffrent',
    correctWord: 'different',
    correctSentence: 'People from different countries joined the online workshop today.',
    ar: 'انضم أشخاص من بلدان مختلفة إلى ورشة العمل عبر الإنترنت اليوم.',
    errorType: 'spelling',
    explanationAr: 'كلمة different تحتوي على حرف e بين f و r.',
  },
  {
    sentenceWithError: 'This restaurant serves really delicius food at fair prices.',
    underlinedWords: ['restaurant', 'serves', 'delicius', 'prices.'],
    wrongWord: 'delicius',
    correctWord: 'delicious',
    correctSentence: 'This restaurant serves really delicious food at fair prices.',
    ar: 'يقدم هذا المطعم طعاماً لذيذاً حقاً بأسعار عادلة.',
    errorType: 'spelling',
    explanationAr: 'الكتابة الصحيحة هي delicious بحرف o قبل u.',
  },
  {
    sentenceWithError: 'Learning a new langauge takes patience and daily practice.',
    underlinedWords: ['Learning', 'langauge', 'patience', 'practice.'],
    wrongWord: 'langauge',
    correctWord: 'language',
    correctSentence: 'Learning a new language takes patience and daily practice.',
    ar: 'تعلم لغة جديدة يتطلب الصبر والممارسة اليومية.',
    errorType: 'spelling',
    explanationAr: 'الكتابة الصحيحة هي language (u ثم a وليس العكس).',
  },
  {
    sentenceWithError: 'He forgot to bring his umbrela even though it was raining.',
    underlinedWords: ['forgot', 'bring', 'umbrela', 'raining.'],
    wrongWord: 'umbrela',
    correctWord: 'umbrella',
    correctSentence: 'He forgot to bring his umbrella even though it was raining.',
    ar: 'نسي إحضار مظلته رغم أنها كانت تمطر.',
    errorType: 'spelling',
    explanationAr: 'كلمة umbrella تُكتب بحرفَي l مزدوجين (double l).',
  },
  {
    sentenceWithError: 'You need to answer every queston carefully before submitting.',
    underlinedWords: ['answer', 'every', 'queston', 'submitting.'],
    wrongWord: 'queston',
    correctWord: 'question',
    correctSentence: 'You need to answer every question carefully before submitting.',
    ar: 'تحتاج إلى الإجابة عن كل سؤال بعناية قبل الإرسال.',
    errorType: 'spelling',
    explanationAr: 'كلمة question تحتوي على حرف i قبل on.',
  },
  {
    sentenceWithError: 'I was very thirsty so I decided to eat cold water.',
    underlinedWords: ['thirsty', 'decided', 'eat', 'water.'],
    wrongWord: 'eat',
    correctWord: 'drink',
    correctSentence: 'I was very thirsty so I decided to drink cold water.',
    ar: 'كنت عطشاناً جداً لذا قررت أن أشرب ماءً بارداً.',
    errorType: 'meaning',
    explanationAr: 'الماء يُشرب (drink) ولا يُؤكل (eat)؛ الفعل eat خاطئ بالمعنى هنا.',
  },
  {
    sentenceWithError: 'Could you please open the light because the room is dark?',
    underlinedWords: ['please', 'open', 'light', 'dark?'],
    wrongWord: 'open',
    correctWord: 'turn on',
    correctSentence: 'Could you please turn on the light because the room is dark?',
    ar: 'هل يمكنك تشغيل الضوء من فضلك لأن الغرفة مظلمة؟',
    errorType: 'meaning',
    explanationAr: 'لتشغيل الأضواء والأجهزة نستخدم turn on وليس open.',
  },
  {
    sentenceWithError: 'The doctor told him to take his medicine with empty shoes.',
    underlinedWords: ['doctor', 'medicine', 'empty', 'shoes.'],
    wrongWord: 'shoes.',
    correctWord: 'stomach.',
    correctSentence: 'The doctor told him to take his medicine on an empty stomach.',
    ar: 'أخبره الطبيب أن يتناول دواءه على معدة فارغة.',
    errorType: 'meaning',
    explanationAr: 'كلمة shoes (أحذية) لا تناسب معنى الجملة؛ المقصود stomach (معدة).',
  },
  {
    sentenceWithError: 'Every evening my grandfather loves to listen the daily newspaper.',
    underlinedWords: ['evening', 'grandfather', 'listen', 'newspaper.'],
    wrongWord: 'listen',
    correctWord: 'read',
    correctSentence: 'Every evening my grandfather loves to read the daily newspaper.',
    ar: 'في كل مساء يحب جدي قراءة الصحيفة اليومية.',
    errorType: 'meaning',
    explanationAr: 'الصحيفة تُقرأ (read) ولا يُستمع إليها (listen).',
  },
  {
    sentenceWithError: 'Put on your heavy winter coat because it is boiling outside.',
    underlinedWords: ['heavy', 'winter', 'boiling', 'outside.'],
    wrongWord: 'boiling',
    correctWord: 'freezing',
    correctSentence: 'Put on your heavy winter coat because it is freezing outside.',
    ar: 'ارتدِ معطفك الشتوي الثقيل لأن الجو متجمد بالخارج.',
    errorType: 'meaning',
    explanationAr: 'كلمة boiling تعني حار جداً ولا تنسجم مع ارتداء معطف شتوي ثقيل؛ الصحيح freezing.',
  },
  {
    sentenceWithError: 'She drove her bicycle slowly along the quiet park path.',
    underlinedWords: ['drove', 'bicycle', 'slowly', 'path.'],
    wrongWord: 'drove',
    correctWord: 'rode',
    correctSentence: 'She rode her bicycle slowly along the quiet park path.',
    ar: 'قادت دراجتها ببطء على طول مسار الحديقة الهادئ.',
    errorType: 'meaning',
    explanationAr: 'مع الدراجة الهوائية نستخدم الفعل ride/rode وليس drive/drove.',
  },
  {
    sentenceWithError: 'He went to the bakery to buy fresh shoes for breakfast.',
    underlinedWords: ['bakery', 'fresh', 'shoes', 'breakfast.'],
    wrongWord: 'shoes',
    correctWord: 'bread',
    correctSentence: 'He went to the bakery to buy fresh bread for breakfast.',
    ar: 'ذهب إلى المخبز لشراء خبز طازج للفطور.',
    errorType: 'meaning',
    explanationAr: 'من المخبز نشتري bread (الخبز) وليس shoes (الأحذية).',
  },
  {
    sentenceWithError: 'Please speak louder because the music is completely silent here.',
    underlinedWords: ['speak', 'louder', 'music', 'silent'],
    wrongWord: 'silent',
    correctWord: 'loud',
    correctSentence: 'Please speak louder because the music is very loud here.',
    ar: 'يرجى التحدث بصوت أعلى لأن الموسيقى صاخبة جداً هنا.',
    errorType: 'meaning',
    explanationAr: 'طلب رفع الصوت يناسب أن تكون الموسيقى loud (صاخبة) وليس silent (صامتة).',
  },
  {
    sentenceWithError: 'We missed the early bus so we arrived very early today.',
    underlinedWords: ['missed', 'bus', 'arrived', 'early'],
    wrongWord: 'early',
    correctWord: 'late',
    correctSentence: 'We missed the early bus so we arrived very late today.',
    ar: 'فاتنا الباص المبكر لذا وصلنا متأخرين جداً اليوم.',
    errorType: 'meaning',
    explanationAr: 'فوات الباص يؤدي للوصول late (متأخراً) وليس early (مبكراً).',
  },
  {
    sentenceWithError: 'Can you borrow me your pen for just a few minutes?',
    underlinedWords: ['borrow', 'your', 'pen', 'minutes?'],
    wrongWord: 'borrow',
    correctWord: 'lend',
    correctSentence: 'Can you lend me your pen for just a few minutes?',
    ar: 'هل يمكنك أن تُقرضني قلمك لبضع دقائق فقط؟',
    errorType: 'meaning',
    explanationAr: 'lend تعني يُعير/يُقرض شخصاً آخر، أما borrow فتعني يستعير.',
  },
];

function seedToQuestion(seed: CuratedErrorSeed, idx: number): SentenceErrorQuestion | null {
  const tokens = seed.sentenceWithError.split(/\s+/).filter(Boolean);
  const underlinedIndices: number[] = [];
  let errorIndex = -1;

  for (const target of seed.underlinedWords) {
    const foundIdx = tokens.findIndex(
      (tk, ti) => tk === target && !underlinedIndices.includes(ti)
    );
    if (foundIdx === -1) return null;
    underlinedIndices.push(foundIdx);
    if (target === seed.wrongWord && errorIndex === -1) {
      errorIndex = foundIdx;
    }
  }

  if (underlinedIndices.length !== 4 || errorIndex === -1) return null;
  underlinedIndices.sort((a, b) => a - b);

  return {
    id: `err-curated-${idx}`,
    tokens,
    underlinedIndices: underlinedIndices as [number, number, number, number],
    errorIndex,
    wrongWord: seed.wrongWord.replace(/[.,?!]+$/, ''),
    correctWord: seed.correctWord,
    correctSentence: seed.correctSentence,
    ar: seed.ar,
    errorType: seed.errorType,
    explanationAr: seed.explanationAr,
  };
}

const GRAMMAR_SWAPS: Record<string, { wrong: string; explanationAr: string }> = {
  is: { wrong: 'are', explanationAr: 'الفاعل هنا مفرد، لذا الصحيح استخدام is وليس are.' },
  are: { wrong: 'is', explanationAr: 'الفاعل هنا جمع أو ضمير you، لذا الصحيح استخدام are وليس is.' },
  was: { wrong: 'were', explanationAr: 'في هذه الجملة الصحيح استخدام was للمفرد وليس were.' },
  were: { wrong: 'was', explanationAr: 'في هذه الجملة الصحيح استخدام were وليس was.' },
  have: { wrong: 'has', explanationAr: 'مع هذا الفاعل الصحيح استخدام have وليس has.' },
  has: { wrong: 'have', explanationAr: 'مع الفاعل المفرد الغائب الصحيح استخدام has وليس have.' },
  do: { wrong: 'does', explanationAr: 'الصحيح هنا استخدام do وليس does.' },
  does: { wrong: 'do', explanationAr: 'مع الفاعل المفرد الغائب الصحيح استخدام does وليس do.' },
  an: { wrong: 'a', explanationAr: 'الكلمة التالية تبدأ بصوت متحرك، لذا الصحيح استخدام an وليس a.' },
};

const ANTONYM_SWAPS: Record<string, { wrong: string; explanationAr: string }> = {
  hot: { wrong: 'cold', explanationAr: 'كلمة cold تعاكس معنى الجملة؛ الصحيح هو hot.' },
  cold: { wrong: 'hot', explanationAr: 'كلمة hot تعاكس معنى الجملة؛ الصحيح هو cold.' },
  happy: { wrong: 'sad', explanationAr: 'كلمة sad لا تطابق المعنى المقصود؛ الصحيح هو happy.' },
  good: { wrong: 'bad', explanationAr: 'كلمة bad تعاكس المعنى المقصود؛ الصحيح هو good.' },
  big: { wrong: 'small', explanationAr: 'كلمة small تعاكس المعنى المقصود؛ الصحيح هو big.' },
  fast: { wrong: 'slow', explanationAr: 'كلمة slow تعاكس المعنى المقصود؛ الصحيح هو fast.' },
  early: { wrong: 'late', explanationAr: 'كلمة late تعاكس المعنى المقصود؛ الصحيح هو early.' },
  late: { wrong: 'early', explanationAr: 'كلمة early تعاكس المعنى المقصود؛ الصحيح هو late.' },
};

function misspellWord(word: string): string | null {
  const clean = word.replace(/[^a-zA-Z]/g, '');
  if (clean.length < 5) return null;
  // Swap two adjacent middle letters that are different
  for (let i = 1; i < clean.length - 2; i++) {
    if (clean[i].toLowerCase() !== clean[i + 1].toLowerCase()) {
      const mutated =
        clean.slice(0, i) + clean[i + 1] + clean[i] + clean.slice(i + 2);
      if (mutated.toLowerCase() !== clean.toLowerCase()) {
        return word.replace(clean, mutated);
      }
    }
  }
  return null;
}

/**
 * Generates an error-detection question from any arbitrary sentence with >= 5 words,
 * guaranteeing exactly 4 underlined words with 1 grammar/spelling/meaning error.
 */
export function buildErrorQuestionFromSentence(
  en: string,
  ar: string,
  seed = 1
): SentenceErrorQuestion | null {
  const cleanEn = en.split('=')[0].trim();
  const rawTokens = cleanEn.split(/\s+/).filter(Boolean);
  if (rawTokens.length < 5 || rawTokens.length > 16) return null;

  const rnd = seededRandom(seed);
  let errorIdx = -1;
  let wrongToken = '';
  let correctToken = '';
  let errorType: SentenceErrorCategory = 'spelling';
  let explanationAr = '';

  // 1) Try grammar swap
  for (let i = 1; i < rawTokens.length - 1; i++) {
    const low = rawTokens[i].toLowerCase();
    if (GRAMMAR_SWAPS[low]) {
      errorIdx = i;
      correctToken = rawTokens[i];
      wrongToken = GRAMMAR_SWAPS[low].wrong;
      errorType = 'grammar';
      explanationAr = GRAMMAR_SWAPS[low].explanationAr;
      break;
    }
  }

  // 2) Try meaning swap if no grammar match
  if (errorIdx === -1) {
    for (let i = 0; i < rawTokens.length; i++) {
      const clean = rawTokens[i].replace(/[^a-zA-Z]/g, '').toLowerCase();
      if (ANTONYM_SWAPS[clean]) {
        errorIdx = i;
        correctToken = rawTokens[i];
        wrongToken = rawTokens[i].replace(
          new RegExp(clean, 'i'),
          ANTONYM_SWAPS[clean].wrong
        );
        errorType = 'meaning';
        explanationAr = ANTONYM_SWAPS[clean].explanationAr;
        break;
      }
    }
  }

  // 3) Fallback to spelling mutation on a >= 5-letter word
  if (errorIdx === -1) {
    const candidates = rawTokens
      .map((tk, idx) => ({ tk, idx, bad: misspellWord(tk) }))
      .filter((x) => x.bad !== null);
    if (!candidates.length) return null;
    const chosen = candidates[Math.floor(rnd() * candidates.length)];
    errorIdx = chosen.idx;
    correctToken = chosen.tk;
    wrongToken = chosen.bad!;
    errorType = 'spelling';
    explanationAr = `خطأ إملائي في ترتيب الحروف؛ الكتابة الصحيحة هي «${correctToken.replace(/[.,?!]+$/, '')}».`;
  }

  const tokens = rawTokens.slice();
  tokens[errorIdx] = wrongToken;

  // Pick 3 other distinct non-error word indices to underline
  const others = tokens
    .map((tk, i) => ({ tk, i }))
    .filter(({ tk, i }) => i !== errorIdx && /[a-zA-Z]{2,}/.test(tk))
    .map((x) => x.i);

  if (others.length < 3) return null;

  for (let i = others.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [others[i], others[j]] = [others[j], others[i]];
  }

  const underlinedIndices = [errorIdx, others[0], others[1], others[2]].sort(
    (a, b) => a - b
  ) as [number, number, number, number];

  return {
    id: `err-dyn-${seed}`,
    tokens,
    underlinedIndices,
    errorIndex: errorIdx,
    wrongWord: wrongToken.replace(/[.,?!]+$/, ''),
    correctWord: correctToken.replace(/[.,?!]+$/, ''),
    correctSentence: cleanEn,
    ar,
    errorType,
    explanationAr,
  };
}

/**
 * Returns a shuffled round of Sentence Error-Detection questions.
 * Filters optionally by error category ('all' | 'grammar' | 'spelling' | 'meaning').
 */
export function buildErrorDetectionRound(
  count = 10,
  category: 'all' | SentenceErrorCategory = 'all',
  seed = Date.now()
): SentenceErrorQuestion[] {
  const all = CURATED_ERROR_SEEDS.map((s, i) => seedToQuestion(s, i)).filter(
    (q): q is SentenceErrorQuestion => q !== null
  );
  const filtered =
    category === 'all' ? all : all.filter((q) => q.errorType === category);

  const rnd = seededRandom(seed);
  const copy = filtered.slice();
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy.slice(0, Math.min(count, copy.length));
}

// =========================================================================
// Curated Everyday Sentence-Ordering Bank (merged with corrected error bank)
// =========================================================================
const CURATED_ORDER_SEEDS: Array<{ en: string; ar: string }> = [
  { en: 'I usually drink a cup of coffee in the morning.', ar: 'عادةً ما أشرب كوباً من القهوة في الصباح.' },
  { en: 'Can you help me find the nearest train station?', ar: 'هل يمكنك مساعدتي في إيجاد أقرب محطة قطار؟' },
  { en: 'She is learning English to improve her career.', ar: 'هي تتعلم الإنجليزية لتطوير مسيرتها المهنية.' },
  { en: 'We decided to go for a walk after dinner.', ar: 'قررنا الذهاب في نزهة بعد العشاء.' },
  { en: 'What time does the next flight to London leave?', ar: 'في أي وقت تغادر الرحلة القادمة إلى لندن؟' },
  { en: 'Please turn off your phone during the important meeting.', ar: 'يرجى إغلاق هاتفك أثناء الاجتماع المهم.' },
  { en: 'They have been working on this project all week.', ar: 'لقد كانوا يعملون على هذا المشروع طوال الأسبوع.' },
  { en: 'My father cooks a delicious meal every Friday night.', ar: 'يطهو والدي وجبة لذيذة كل ليلة جمعة.' },
  { en: 'I would like to book a quiet room for two nights.', ar: 'أود حجز غرفة هادئة لليلتين.' },
  { en: 'Do you know where I left my car keys?', ar: 'هل تعرف أين تركت مفاتيح سيارتي؟' },
  { en: 'The weather is much warmer today than yesterday.', ar: 'الطقس أدفأ بكثير اليوم مقارنةً بالأمس.' },
  { en: 'Practice every day if you want to speak fluently.', ar: 'تدرّب كل يوم إذا أردت أن تتحدث بطلاقة.' },
  { en: 'He promised to call me as soon as he arrives.', ar: 'وعد أن يتصل بي فور وصوله.' },
  { en: 'Reading books before sleep helps me relax quickly.', ar: 'قراءة الكتب قبل النوم تساعدني على الاسترخاء بسرعة.' },
  { en: 'How long does it take to reach the city center?', ar: 'كم يستغرق الوصول إلى وسط المدينة؟' },
  { en: 'Could you please speak a little more slowly?', ar: 'هل يمكنك التحدث ببطء أكثر قليلاً من فضلك؟' },
  { en: 'We are excited to start our new adventure together.', ar: 'نحن متحمسون لبدء مغامرتنا الجديدة معاً.' },
  { en: 'She forgot her umbrella at home this rainy morning.', ar: 'نسيت مظلتها في المنزل هذا الصباح الممطر.' },
  { en: 'I need to buy fresh vegetables from the market.', ar: 'أحتاج إلى شراء خضروات طازجة من السوق.' },
  { en: 'Thank you very much for your kind and quick help.', ar: 'شكراً جزيلاً لك على مساعدتك اللطيفة والسريعة.' },
  { en: 'The students listened carefully to their teacher in class.', ar: 'استمع الطلاب بعناية إلى معلمهم في الصف.' },
  { en: 'Never give up when you face a difficult challenge.', ar: 'لا تستسلم أبداً عندما تواجه تحدياً صعباً.' },
  { en: 'Would you like some sugar or milk with tea?', ar: 'هل ترغب ببعض السكر أو الحليب مع الشاي؟' },
  { en: 'He always arrives early to prepare for his work.', ar: 'يصل دائماً مبكراً للتحضير لعمله.' },
  { en: 'Our team won the final match by two goals.', ar: 'فاز فريقنا بالمباراة النهائية بهدفين.' },
  { en: 'I enjoy listening to podcasts while walking outside.', ar: 'أستمتع بالاستماع إلى البودكاست أثناء المشي بالخارج.' },
  { en: 'Make sure you lock the front door before leaving.', ar: 'تأكد من قفل الباب الأمامي قبل المغادرة.' },
  { en: 'This app helps me remember new English words easily.', ar: 'يساعدني هذا التطبيق على تذكر الكلمات الإنجليزية الجديدة بسهولة.' },
];

/**
 * Returns a shuffled round of Sentence Ordering questions with full Arabic translations.
 */
export function buildSentenceOrderRound(
  count = 10,
  seed = Date.now()
): SentenceOrderQuestion[] {
  const combined: Array<{ en: string; ar: string }> = [
    ...CURATED_ORDER_SEEDS,
    ...CURATED_ERROR_SEEDS.map((s) => ({ en: s.correctSentence, ar: s.ar })),
  ];

  const questions: SentenceOrderQuestion[] = [];
  combined.forEach((item, idx) => {
    const q = buildSentenceOrderQuestion(
      { id: idx + 1, num: idx + 1, en: item.en },
      item.ar,
      seed + (idx + 1) * 13
    );
    if (q) questions.push(q);
  });

  const rnd = seededRandom(seed);
  for (let i = questions.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [questions[i], questions[j]] = [questions[j], questions[i]];
  }
  return questions.slice(0, Math.min(count, questions.length));
}

// =========================================================================
// 3rd Sentence Game: Audio Sentence Dictation (Listen & Type Full English)
// =========================================================================
export interface SentenceDictationQuestion {
  id: string;
  en: string;
  ar: string;
  wordCount: number;
}

export interface SentenceDictationDiffToken {
  expected: string;
  typed?: string;
  correct: boolean;
}

export interface SentenceDictationCheckResult {
  isExact: boolean;
  accuracyPct: number;
  tokens: SentenceDictationDiffToken[];
  expectedSentence: string;
}

function normalizeDictationWord(w: string): string {
  return w
    .toLowerCase()
    .replace(/[’‘`]/g, "'")
    .replace(/[^a-z0-9']/g, '')
    .trim();
}

export function checkSentenceDictation(
  typedInput: string,
  expectedSentence: string
): SentenceDictationCheckResult {
  const cleanExpected = expectedSentence.split('=')[0].trim();
  const expectedDisplay = cleanExpected.split(/\s+/).filter(Boolean);
  const expectedNorm = expectedDisplay.map(normalizeDictationWord).filter(Boolean);
  const typedRaw = typedInput.trim().split(/\s+/).filter(Boolean);
  const typedNorm = typedRaw.map(normalizeDictationWord).filter(Boolean);

  if (!expectedNorm.length) {
    return { isExact: false, accuracyPct: 0, tokens: [], expectedSentence: cleanExpected };
  }

  // Align typed words against expected words with small lookahead window
  const tokens: SentenceDictationDiffToken[] = [];
  let ti = 0;
  let matched = 0;

  for (let ei = 0; ei < expectedDisplay.length; ei++) {
    const expDisplay = expectedDisplay[ei];
    const expWord = normalizeDictationWord(expDisplay);
    if (!expWord) {
      tokens.push({ expected: expDisplay, typed: expDisplay, correct: true });
      continue;
    }

    if (ti < typedNorm.length && typedNorm[ti] === expWord) {
      tokens.push({ expected: expDisplay, typed: typedRaw[ti], correct: true });
      matched += 1;
      ti += 1;
      continue;
    }

    // Look ahead up to 2 typed tokens in case learner inserted an extra word
    let foundLookahead = -1;
    for (let k = 1; k <= 2 && ti + k < typedNorm.length; k++) {
      if (typedNorm[ti + k] === expWord) {
        foundLookahead = ti + k;
        break;
      }
    }

    if (foundLookahead !== -1) {
      tokens.push({ expected: expDisplay, typed: typedRaw[foundLookahead], correct: true });
      matched += 1;
      ti = foundLookahead + 1;
    } else {
      const candidateTyped = ti < typedRaw.length ? typedRaw[ti] : undefined;
      tokens.push({ expected: expDisplay, typed: candidateTyped, correct: false });
      // Only advance typed pointer if typed word doesn't match the NEXT expected word
      const nextExp = ei + 1 < expectedDisplay.length ? normalizeDictationWord(expectedDisplay[ei + 1]) : '';
      if (ti < typedNorm.length && typedNorm[ti] !== nextExp) {
        ti += 1;
      }
    }
  }

  const extraPenalty =
    typedNorm.length > expectedNorm.length
      ? Math.min(20, (typedNorm.length - expectedNorm.length) * 8)
      : 0;
  const rawPct = Math.round((matched / expectedNorm.length) * 100);
  const accuracyPct = Math.max(0, Math.min(100, rawPct - extraPenalty));
  const isExact = matched === expectedNorm.length && typedNorm.length === expectedNorm.length;

  return {
    isExact,
    accuracyPct,
    tokens,
    expectedSentence: cleanExpected,
  };
}

export function buildSentenceDictationRound(
  count = 8,
  seed = Date.now()
): SentenceDictationQuestion[] {
  const combined: Array<{ en: string; ar: string }> = [
    ...CURATED_ORDER_SEEDS,
    ...CURATED_ERROR_SEEDS.map((s) => ({ en: s.correctSentence, ar: s.ar })),
  ];

  const pool: SentenceDictationQuestion[] = combined
    .map((item, idx) => {
      const clean = item.en.split('=')[0].trim();
      const words = clean.split(/\s+/).filter(Boolean);
      return {
        id: `dict-${idx + 1}`,
        en: clean,
        ar: item.ar,
        wordCount: words.length,
      };
    })
    .filter((q) => q.wordCount >= 5 && q.wordCount <= 12);

  const rnd = seededRandom(seed);
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, Math.min(count, pool.length));
}


