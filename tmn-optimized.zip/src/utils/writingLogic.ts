import type { ArticleItem, PictureScenePrompt, VocabEntry, VocabStore, WritingTopicPrompt } from '../types';

export interface DiffSegment {
  text: string;
  isError: boolean;
}

export interface ArticleToken {
  text: string;
  isWord: boolean;
  cleanWord: string;
}

/**
 * Generates common English inflection variants for a base word so learners
 * using plural/past/continuous forms (e.g. "walked" for "walk", "has" for "have")
 * are properly recognized as using the target word.
 */
export function getWordInflections(rawTarget: string): Set<string> {
  const clean = rawTarget
    .toLowerCase()
    .replace(/^to\s+/, '')
    .replace(/[^a-z'\-\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const variants = new Set<string>();
  if (!clean) return variants;
  variants.add(clean);

  // If multi-word phrase, require phrase or main stem match handled separately
  if (clean.includes(' ')) return variants;

  // Common irregular English verbs & forms
  const irregulars: Record<string, string[]> = {
    be: ['am', 'is', 'are', 'was', 'were', 'been', 'being'],
    have: ['has', 'had', 'having'],
    do: ['does', 'did', 'done', 'doing'],
    go: ['goes', 'went', 'gone', 'going'],
    get: ['gets', 'got', 'gotten', 'getting'],
    make: ['makes', 'made', 'making'],
    take: ['takes', 'took', 'taken', 'taking'],
    come: ['comes', 'came', 'coming'],
    see: ['sees', 'saw', 'seen', 'seeing'],
    know: ['knows', 'knew', 'known', 'knowing'],
    give: ['gives', 'gave', 'given', 'giving'],
    find: ['finds', 'found', 'finding'],
    think: ['thinks', 'thought', 'thinking'],
    tell: ['tells', 'told', 'telling'],
    become: ['becomes', 'became', 'becoming'],
    leave: ['leaves', 'left', 'leaving'],
    feel: ['feels', 'felt', 'feeling'],
    bring: ['brings', 'brought', 'bringing'],
    begin: ['begins', 'began', 'begun', 'beginning'],
    keep: ['keeps', 'kept', 'keeping'],
    hold: ['holds', 'held', 'holding'],
    write: ['writes', 'wrote', 'written', 'writing'],
    stand: ['stands', 'stood', 'standing'],
    hear: ['hears', 'heard', 'hearing'],
    meet: ['meets', 'met', 'meeting'],
    run: ['runs', 'ran', 'running'],
    pay: ['pays', 'paid', 'paying'],
    sit: ['sits', 'sat', 'sitting'],
    speak: ['speaks', 'spoke', 'spoken', 'speaking'],
    eat: ['eats', 'ate', 'eaten', 'eating'],
    drink: ['drinks', 'drank', 'drunk', 'drinking'],
    buy: ['buys', 'bought', 'buying'],
    build: ['builds', 'built', 'building'],
    send: ['sends', 'sent', 'sending'],
    spend: ['spends', 'spent', 'spending'],
    understand: ['understands', 'understood', 'understanding'],
    read: ['reads', 'reading'],
    say: ['says', 'said', 'saying'],
    sleep: ['sleeps', 'slept', 'sleeping'],
    teach: ['teaches', 'taught', 'teaching'],
    learn: ['learns', 'learned', 'learnt', 'learning'],
    wake: ['wakes', 'woke', 'woken', 'waking'],
    break: ['breaks', 'broke', 'broken', 'breaking'],
    choose: ['chooses', 'chose', 'chosen', 'choosing'],
    drive: ['drives', 'drove', 'driven', 'driving'],
    fall: ['falls', 'fell', 'fallen', 'falling'],
    fly: ['flies', 'flew', 'flown', 'flying'],
    forget: ['forgets', 'forgot', 'forgotten', 'forgetting'],
    grow: ['grows', 'grew', 'grown', 'growing'],
    lose: ['loses', 'lost', 'losing'],
    ride: ['rides', 'rode', 'ridden', 'riding'],
    sell: ['sells', 'sold', 'selling'],
    sing: ['sings', 'sang', 'sung', 'singing'],
    swim: ['swims', 'swam', 'swum', 'swimming'],
    wear: ['wears', 'wore', 'worn', 'wearing'],
    win: ['wins', 'won', 'winning'],
    good: ['better', 'best'],
    bad: ['worse', 'worst'],
    child: ['children'],
    man: ['men'],
    woman: ['women'],
    person: ['people'],
    foot: ['feet'],
    tooth: ['teeth'],
    mouse: ['mice'],
    life: ['lives'],
  };

  if (irregulars[clean]) {
    irregulars[clean].forEach((v) => variants.add(v));
  }

  // Regular English inflections
  variants.add(`${clean}s`);
  variants.add(`${clean}es`);
  variants.add(`${clean}ed`);
  variants.add(`${clean}ing`);
  variants.add(`${clean}er`);
  variants.add(`${clean}est`);
  variants.add(`${clean}ly`);

  if (clean.endsWith('e') && clean.length > 2) {
    const stem = clean.slice(0, -1);
    variants.add(`${stem}ed`);
    variants.add(`${stem}ing`);
    variants.add(`${stem}er`);
    variants.add(`${stem}est`);
  }
  if (clean.endsWith('y') && clean.length > 2) {
    const stem = clean.slice(0, -1);
    variants.add(`${stem}ies`);
    variants.add(`${stem}ied`);
    variants.add(`${stem}ier`);
    variants.add(`${stem}iest`);
    variants.add(`${stem}ily`);
  }
  // CVC doubling (e.g., stop -> stopped / stopping, big -> bigger)
  if (/^[a-z]*[^aeiou][aeiou][^aeiouwxy]$/.test(clean) && clean.length >= 3) {
    const last = clean[clean.length - 1];
    variants.add(`${clean}${last}ed`);
    variants.add(`${clean}${last}ing`);
    variants.add(`${clean}${last}er`);
    variants.add(`${clean}${last}est`);
  }

  return variants;
}

/**
 * Checks strictly whether a learner's sentence contains the target English word
 * (or a valid grammatical inflection of it) at word boundaries.
 */
export function containsTargetWord(sentence: string, targetWord: string): boolean {
  const cleanSentence = sentence.toLowerCase();
  const cleanTarget = targetWord
    .toLowerCase()
    .replace(/^to\s+/, '')
    .replace(/[^a-z'\-\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!cleanTarget || !cleanSentence.trim()) return false;

  // Multi-word target phrase (e.g., "look after", "wake up")
  if (cleanTarget.includes(' ')) {
    const escaped = cleanTarget.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp(`(^|[^a-z])${escaped}($|[^a-z])`, 'i');
    if (re.test(cleanSentence)) return true;
    // Also allow inflected first word (e.g., "woke up", "looking after")
    const parts = cleanTarget.split(' ');
    const firstVariants = getWordInflections(parts[0]);
    const rest = parts.slice(1).join('\\s+');
    for (const fv of firstVariants) {
      const fEsc = fv.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      if (new RegExp(`(^|[^a-z])${fEsc}\\s+${rest}($|[^a-z])`, 'i').test(cleanSentence)) {
        return true;
      }
    }
    return false;
  }

  const tokens = cleanSentence.match(/[a-z]+(?:'[a-z]+)?/g) || [];
  const variants = getWordInflections(cleanTarget);
  for (const tk of tokens) {
    if (variants.has(tk)) return true;
    // Handle contractions like "I've" or "don't" -> base token before apostrophe
    const base = tk.split("'")[0];
    if (base && variants.has(base)) return true;
  }
  return false;
}

function normalizeWordForDiff(w: string): string {
  return w.toLowerCase().replace(/^[^a-z0-9']+|[^a-z0-9']+$/g, '');
}

/**
 * Builds visual segments of the learner's original text where erroneous tokens/phrases
 * are flagged with `isError: true` so the UI renders a clear red underline under them.
 * Combines explicit AI-reported wrong phrases with LCS word-level diff against correctedText.
 */
export function buildDiffSegments(
  originalText: string,
  correctedText: string,
  wrongPhrases: string[] = []
): DiffSegment[] {
  const trimmedOrig = originalText.trim();
  if (!trimmedOrig) return [];

  const trimmedCorr = correctedText.trim();
  const explicitBadSet = new Set(
    wrongPhrases
      .flatMap((p) => p.split(/\s+/))
      .map((w) => normalizeWordForDiff(w))
      .filter((w) => w.length > 0)
  );

  // Split preserving whitespace so formatting stays natural
  const rawParts = trimmedOrig.split(/(\s+)/);

  // If strings match identically and no explicit wrong phrases, no errors
  if (
    trimmedCorr &&
    trimmedOrig.toLowerCase().replace(/\s+/g, ' ') ===
      trimmedCorr.toLowerCase().replace(/\s+/g, ' ') &&
    explicitBadSet.size === 0
  ) {
    return [{ text: trimmedOrig, isError: false }];
  }

  // Extract word tokens from original and corrected for LCS alignment
  const origWords: Array<{ partIdx: number; norm: string }> = [];
  rawParts.forEach((p, idx) => {
    const norm = normalizeWordForDiff(p);
    if (norm) origWords.push({ partIdx: idx, norm });
  });

  const corrWords = trimmedCorr
    .split(/\s+/)
    .map((w) => normalizeWordForDiff(w))
    .filter(Boolean);

  // Longest Common Subsequence (LCS) to detect words changed or deleted in correction
  const n = origWords.length;
  const m = corrWords.length;
  const dp: number[][] = Array.from({ length: n + 1 }, () => new Array<number>(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      if (origWords[i].norm === corrWords[j]) {
        dp[i][j] = dp[i + 1][j + 1] + 1;
      } else {
        dp[i][j] = Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
  }

  const matchedOrigWordIndices = new Set<number>();
  let i = 0;
  let j = 0;
  while (i < n && j < m) {
    if (origWords[i].norm === corrWords[j]) {
      matchedOrigWordIndices.add(i);
      i += 1;
      j += 1;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      i += 1;
    } else {
      j += 1;
    }
  }

  const errorPartIndices = new Set<number>();
  origWords.forEach((ow, idx) => {
    if (!matchedOrigWordIndices.has(idx) || explicitBadSet.has(ow.norm)) {
      errorPartIndices.add(ow.partIdx);
    }
  });

  // Also flag exact phrase matches from wrongPhrases when multi-word
  const lowerOrig = trimmedOrig.toLowerCase();
  const segments: DiffSegment[] = rawParts.map((part, idx) => ({
    text: part,
    isError: errorPartIndices.has(idx),
  }));

  // If explicit multi-word phrase wasn't caught via word diff, still honor it
  if (segments.every((s) => !s.isError) && wrongPhrases.length > 0) {
    for (const phrase of wrongPhrases) {
      const cleanP = phrase.trim().toLowerCase();
      if (cleanP && lowerOrig.includes(cleanP)) {
        const pWords = new Set(cleanP.split(/\s+/).map(normalizeWordForDiff).filter(Boolean));
        segments.forEach((seg) => {
          if (pWords.has(normalizeWordForDiff(seg.text))) {
            seg.isError = true;
          }
        });
      }
    }
  }

  // Merge adjacent segments with identical isError state for crisp rendering
  const merged: DiffSegment[] = [];
  for (const seg of segments) {
    if (!seg.text) continue;
    const prev = merged[merged.length - 1];
    if (prev && prev.isError === seg.isError) {
      prev.text += seg.text;
    } else {
      merged.push({ ...seg });
    }
  }
  return merged;
}

/**
 * Splits an English paragraph into clickable word tokens and non-word punctuation/spaces.
 */
export function tokenizeArticleParagraph(paragraph: string): ArticleToken[] {
  const tokens: ArticleToken[] = [];
  const regex = /([A-Za-z]+(?:'[A-Za-z]+)?|[^A-Za-z]+)/g;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(paragraph)) !== null) {
    const text = match[0];
    const isWord = /^[A-Za-z]/.test(text);
    tokens.push({
      text,
      isWord,
      cleanWord: isWord ? text.toLowerCase() : '',
    });
  }
  return tokens;
}

/**
 * Looks up a clicked English word in the 18,484-word local TMN VocabStore,
 * falling back to common stem stripping (-s, -es, -ies, -ed, -ing, -ly, -er, -est).
 */
export function lookupWordInStore(rawWord: string, store: VocabStore): VocabEntry | null {
  const clean = rawWord.toLowerCase().replace(/^[^a-z]+|[^a-z]+$/g, '');
  if (!clean) return null;

  const candidates: string[] = [clean];

  if (clean.includes("'")) {
    candidates.push(clean.split("'")[0]);
  }
  if (clean.endsWith('ies') && clean.length > 4) {
    candidates.push(clean.slice(0, -3) + 'y');
  }
  if (clean.endsWith('ied') && clean.length > 4) {
    candidates.push(clean.slice(0, -3) + 'y');
  }
  if (clean.endsWith('es') && clean.length > 3) {
    candidates.push(clean.slice(0, -2));
    candidates.push(clean.slice(0, -1));
  }
  if (clean.endsWith('s') && clean.length > 2) {
    candidates.push(clean.slice(0, -1));
  }
  if (clean.endsWith('ing') && clean.length > 5) {
    const base = clean.slice(0, -3);
    candidates.push(base);
    candidates.push(base + 'e');
    if (base.length >= 2 && base[base.length - 1] === base[base.length - 2]) {
      candidates.push(base.slice(0, -1));
    }
  }
  if (clean.endsWith('ed') && clean.length > 4) {
    const base = clean.slice(0, -2);
    candidates.push(base);
    candidates.push(base + 'e');
    if (base.length >= 2 && base[base.length - 1] === base[base.length - 2]) {
      candidates.push(base.slice(0, -1));
    }
  }
  if (clean.endsWith('ly') && clean.length > 4) {
    candidates.push(clean.slice(0, -2));
  }
  if (clean.endsWith('er') && clean.length > 4) {
    candidates.push(clean.slice(0, -2));
    candidates.push(clean.slice(0, -1));
  }
  if (clean.endsWith('est') && clean.length > 5) {
    candidates.push(clean.slice(0, -3));
    candidates.push(clean.slice(0, -2));
  }

  for (const cand of candidates) {
    const idx = store.normEn.indexOf(cand);
    if (idx !== -1 && store.words[idx]) {
      return store.words[idx];
    }
  }
  return null;
}

// =========================================================================
// Curated Vivid Picture Scenes for AI Coach "Describe a Picture" Mode
// =========================================================================
export const PICTURE_SCENES: PictureScenePrompt[] = [
  {
    id: 'pic-cafe',
    titleAr: 'مقهى مزدحم في الصباح',
    titleEn: 'A Cozy Morning Coffee Shop',
    unsplashQuery: 'cozy coffee shop people laptop morning warm light',
    fallbackImageUrl:
      'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=960&q=80',
    sceneDescriptionEn:
      'A warm, inviting coffee shop with wooden tables, cups of coffee, soft lighting, and people relaxing or working.',
    guidingQuestionsAr: [
      'ماذا ترى في المكان ومن الموجودون فيه؟',
      'كيف يبدو الجو والإضاءة؟',
      'ماذا يفعل الناس في المقهى برأيك؟',
    ],
    helpfulWords: ['coffee', 'table', 'window', 'warm', 'relaxing', 'working'],
  },
  {
    id: 'pic-mountain',
    titleAr: 'رحلة مشي في الجبال',
    titleEn: 'Hiking in the Mountains',
    unsplashQuery: 'hiker mountain trail scenic landscape sunrise',
    fallbackImageUrl:
      'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=960&q=80',
    sceneDescriptionEn:
      'A breathtaking mountain range under a bright sky with green valleys, rocky peaks, and fresh outdoor nature.',
    guidingQuestionsAr: [
      'صف المنظر الطبيعي والألوان في الصورة.',
      'كيف يبدو الطقس في هذا المكان؟',
      'هل تحب زيارة مكان كهذا ولماذا؟',
    ],
    helpfulWords: ['mountain', 'sky', 'clouds', 'nature', 'peaceful', 'climb'],
  },
  {
    id: 'pic-market',
    titleAr: 'سوق فواكه وخضروات طازجة',
    titleEn: 'A Colorful Street Market',
    unsplashQuery: 'colorful fruit vegetable street market people shopping',
    fallbackImageUrl:
      'https://images.unsplash.com/photo-1488459716781-31db52582fe9?auto=format&fit=crop&w=960&q=80',
    sceneDescriptionEn:
      'An outdoor market stall filled with colorful fresh fruits and vegetables neatly arranged for shoppers.',
    guidingQuestionsAr: [
      'ما أنواع الفواكه أو الخضروات الظاهرة؟',
      'صف الألوان والترتيب في السوق.',
      'ما الذي ستشتريه لو كنت هناك؟',
    ],
    helpfulWords: ['fresh', 'market', 'colorful', 'fruits', 'vegetables', 'buy'],
  },
  {
    id: 'pic-library',
    titleAr: 'مكتبة هادئة للدراسة',
    titleEn: 'A Quiet Study Library',
    unsplashQuery: 'library bookshelves students reading studying',
    fallbackImageUrl:
      'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=960&q=80',
    sceneDescriptionEn:
      'Tall wooden bookshelves packed with hundreds of books inside a calm, classic library designed for reading and study.',
    guidingQuestionsAr: [
      'صف المكتبة ورفوف الكتب الموجودة.',
      'ما الشعور الذي يعطيه هذا المكان؟',
      'هل تفضل الدراسة في المكتبة أم في المنزل؟',
    ],
    helpfulWords: ['books', 'shelves', 'quiet', 'study', 'knowledge', 'reading'],
  },
  {
    id: 'pic-city-rain',
    titleAr: 'شارع مدينة تحت المطر',
    titleEn: 'A Rainy City Street',
    unsplashQuery: 'rainy city street umbrellas evening lights reflection',
    fallbackImageUrl:
      'https://images.unsplash.com/photo-1519692933481-e162a57d6721?auto=format&fit=crop&w=960&q=80',
    sceneDescriptionEn:
      'A city street during rainfall with shiny wet sidewalks, glowing lights, and people walking with umbrellas.',
    guidingQuestionsAr: [
      'كيف يبدو الطقس والشارع في الصورة؟',
      'صف الأضواء والانعكاسات أو الناس.',
      'ما شعورك عند المشي في يوم ممطر؟',
    ],
    helpfulWords: ['rain', 'street', 'umbrella', 'lights', 'wet', 'walking'],
  },
  {
    id: 'pic-cooking',
    titleAr: 'تحضير الطعام في المطبخ',
    titleEn: 'Cooking Together in the Kitchen',
    unsplashQuery: 'family cooking healthy meal modern kitchen fresh ingredients',
    fallbackImageUrl:
      'https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=960&q=80',
    sceneDescriptionEn:
      'A bright kitchen scene with fresh ingredients, cooking utensils, and people preparing a homemade meal.',
    guidingQuestionsAr: [
      'ماذا يحدث في المطبخ الآن؟',
      'اذكر بعض الأشياء أو المكونات التي تراها.',
      'ما وجبتك المفضلة التي تحب طهيها؟',
    ],
    helpfulWords: ['kitchen', 'cooking', 'ingredients', 'healthy', 'delicious', 'prepare'],
  },
  {
    id: 'pic-beach',
    titleAr: 'غروب الشمس على الشاطئ',
    titleEn: 'Sunset at the Beach',
    unsplashQuery: 'beach sunset ocean waves golden sky sand',
    fallbackImageUrl:
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=960&q=80',
    sceneDescriptionEn:
      'A peaceful sandy beach with gentle ocean waves under a glowing golden sunset sky.',
    guidingQuestionsAr: [
      'صف البحر والسماء والشاطئ في الصورة.',
      'ما الألوان التي تلاحظها عند الغروب؟',
      'ما الأنشطة التي تحب القيام بها على الشاطئ؟',
    ],
    helpfulWords: ['beach', 'ocean', 'waves', 'sunset', 'sand', 'calm'],
  },
  {
    id: 'pic-airport',
    titleAr: 'المطار والاستعداد للسفر',
    titleEn: 'At the Airport Terminal',
    unsplashQuery: 'airport terminal airplane window travelers luggage',
    fallbackImageUrl:
      'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=960&q=80',
    sceneDescriptionEn:
      'An airplane flying above the clouds / airport travel scene capturing the excitement of going on a journey.',
    guidingQuestionsAr: [
      'ماذا ترى من نافذة الطائرة أو في المطار؟',
      'صف شعور السفر إلى بلد جديد.',
      'إلى أين تتمنى أن تسافر قريباً؟',
    ],
    helpfulWords: ['flight', 'airplane', 'clouds', 'travel', 'journey', 'destination'],
  },
];

// =========================================================================
// Curated Topic Writing Prompts for AI Coach "Write About a Topic" Mode
// =========================================================================
export const WRITING_TOPICS: WritingTopicPrompt[] = [
  {
    id: 'topic-routine',
    titleEn: 'My Ideal Daily Routine',
    titleAr: 'روتيني اليومي المثالي',
    promptEn:
      'Describe how you spend a productive day from morning to evening. Mention your favorite habits and why they help you.',
    promptAr:
      'اكتب 3 إلى 5 جمل بالإنجليزية تصف فيها كيف تقضي يوماً منتجاً من الصباح حتى المساء، واذكر عاداتك المفضلة ولماذا تساعدك.',
    keywords: ['morning', 'habit', 'focus', 'evening', 'energy'],
    level: 'A2',
  },
  {
    id: 'topic-tech',
    titleEn: 'How Technology Changed Our Lives',
    titleAr: 'كيف غيّرت التكنولوجيا حياتنا',
    promptEn:
      'Write a few sentences about how smartphones or the internet changed the way people learn, work, and communicate.',
    promptAr:
      'اكتب عدة جمل بالإنجليزية حول تأثير الهواتف الذكية أو الإنترنت على طريقة تعلم الناس وعملهم وتواصلهم، واذكر إيجابية وسلبية واحدة.',
    keywords: ['technology', 'communicate', 'easier', 'information', 'balance'],
    level: 'B1',
  },
  {
    id: 'topic-travel',
    titleEn: 'A City I Would Love to Visit',
    titleAr: 'مدينة أتمنى زيارتها',
    promptEn:
      'Choose one city or country you dream of visiting. Explain what you would see, eat, and do there.',
    promptAr:
      'اختر مدينة أو دولة تحلم بزيارتها، واكتب عدة جمل بالإنجليزية عما ستشاهده وتأكله وتفعله هناك.',
    keywords: ['visit', 'culture', 'famous', 'food', 'experience'],
    level: 'A2',
  },
  {
    id: 'topic-english',
    titleEn: 'Why I Am Learning English',
    titleAr: 'لماذا أتعلم اللغة الإنجليزية',
    promptEn:
      'Explain your main goals for learning English and the best methods that help you improve every week.',
    promptAr:
      'اشرح بالإنجليزية أهدافك الأساسية من تعلم اللغة الإنجليزية وما أفضل الطرق التي تساعدك على التطور أسبوعياً.',
    keywords: ['goal', 'practice', 'fluent', 'career', 'confidence'],
    level: 'A2',
  },
  {
    id: 'topic-health',
    titleEn: 'Simple Habits for a Healthy Mind and Body',
    titleAr: 'عادات بسيطة لصحة الجسد والعقل',
    promptEn:
      'Write 3 to 5 sentences about sleep, exercise, and nutrition, and why taking care of your health matters.',
    promptAr:
      'اكتب 3 إلى 5 جمل حول النوم والرياضة والغذاء الصحي، ولماذا يُعد الاهتمام بالصحة أمراً ضرورياً.',
    keywords: ['healthy', 'exercise', 'sleep', 'stress', 'strong'],
    level: 'B1',
  },
  {
    id: 'topic-memory',
    titleEn: 'A Memorable Day in My Life',
    titleAr: 'يوم لا يُنسى في حياتي',
    promptEn:
      'Tell a short story in the past tense about a happy or unforgettable day you experienced with family or friends.',
    promptAr:
      'احكِ قصة قصيرة بالزمن الماضي بالإنجليزية عن يوم سعيد أو لا يُنسى قضيته مع العائلة أو الأصدقاء.',
    keywords: ['remember', 'excited', 'together', 'moment', 'grateful'],
    level: 'B1',
  },
];

// =========================================================================
// Curated Instant Reading Library (Articles, Short Stories, Cultural Texts)
// =========================================================================
export const ARTICLE_TOPICS = [
  { id: 'all', label: 'الكل', queryEn: 'general knowledge' },
  { id: 'stories', label: 'قصص وروايات قصيرة', queryEn: 'inspiring short story fiction' },
  { id: 'tech', label: 'التكنولوجيا والذكاء الاصطناعي', queryEn: 'technology and artificial intelligence' },
  { id: 'health', label: 'الصحة والعادات', queryEn: 'health habits sleep and productivity' },
  { id: 'travel', label: 'السفر والثقافات', queryEn: 'travel adventures and world cultures' },
  { id: 'science', label: 'العلوم والفضاء', queryEn: 'science discoveries and space exploration' },
  { id: 'history', label: 'التاريخ والاقتصاد', queryEn: 'fascinating world history and inventions' },
] as const;

export const CURATED_ARTICLES: ArticleItem[] = [
  {
    id: 'art-story-lantern',
    title: 'The Watchmaker’s Quiet Promise',
    titleAr: 'وعد صانع الساعات الهادئ',
    topicId: 'stories',
    typeLabel: 'قصة قصيرة',
    level: 'A2',
    readingMinutes: 3,
    summaryHintAr: 'قصة مؤثرة عن صانع ساعات عجوز يعلّم شاباً متعجلاً قيمة الصبر وإتقان العمل.',
    paragraphs: [
      'In a narrow street near the old harbor, an elderly watchmaker named Arthur opened his small shop every morning at seven. The windows were always clean, and dozens of wooden clocks ticked softly inside like a gentle heartbeat.',
      'One rainy Tuesday, a young student named Leo rushed through the door holding his grandfather’s broken pocket watch. Leo said he needed it fixed before sunset because it was his mother’s birthday gift.',
      'Arthur smiled calmly and examined the tiny golden gears through his magnifying glass. He explained that good repair takes patience, because rushing a delicate machine only creates deeper damage.',
      'Leo sat beside the wooden counter and watched the old man work in silence. Hour by hour, Arthur cleaned each tiny spring with steady hands until the watch finally began to tick again just before five o’clock.',
      'When Leo offered extra money for the hard work, Arthur refused and asked only for one promise: whenever life feels too fast, slow down and do one thing with full care. Leo never forgot that lesson.',
    ],
  },
  {
    id: 'art-tech-ai',
    title: 'How Smart Assistants Are Changing Daily Learning',
    titleAr: 'كيف تغيّر المساعدات الذكية أسلوب التعلم اليومي',
    topicId: 'tech',
    typeLabel: 'مقالة تقنية',
    level: 'B1',
    readingMinutes: 3,
    summaryHintAr: 'مقالة تشرح كيف تساعد أدوات الذكاء الاصطناعي الطلاب على ممارسة اللغات وتصحيح أخطائهم فوراً.',
    paragraphs: [
      'Ten years ago, learning a foreign language usually required expensive classes, heavy textbooks, or traveling abroad. Today, millions of students carry a patient tutor inside their pocket.',
      'Modern artificial intelligence tools can listen to a learner speak, spot small grammar mistakes, and explain better ways to express an idea within seconds. This instant feedback builds confidence quickly.',
      'However, technology works best when learners stay active rather than passive. Reading real stories, writing original sentences, and speaking aloud every day remain the true foundations of fluency.',
      'Experts believe the future of education will blend human curiosity with smart software. Instead of replacing teachers, digital tools give every motivated learner a personalized space to practice without fear of making mistakes.',
    ],
  },
  {
    id: 'art-health-sleep',
    title: 'Why Ten Minutes of Reading Before Sleep Works Wonders',
    titleAr: 'لماذا تصنع عشر دقائق من القراءة قبل النوم فرقاً كبيراً',
    topicId: 'health',
    typeLabel: 'مقالة صحية',
    level: 'A2',
    readingMinutes: 2,
    summaryHintAr: 'تأثير القراءة الهادئة قبل النوم على تقليل التوتر وتحسين الذاكرة وتقوية اللغة.',
    paragraphs: [
      'Many people end their busy day by scrolling through bright phone screens in bed. Unfortunately, constant notifications keep the brain alert and make it harder to fall into deep, restful sleep.',
      'Replacing the last ten minutes of screen time with calm reading sends a clear signal to the mind that it is time to slow down. Even six minutes of reading can noticeably lower heart rate and muscle tension.',
      'For language learners, evening reading offers a second hidden benefit. While you sleep, your brain organizes new vocabulary and strengthens memory connections from the words you saw right before closing your eyes.',
      'You do not need to finish a whole chapter every night. Simply choosing an enjoyable short article or story turns bedtime into a relaxing ritual that improves both health and English fluency.',
    ],
  },
  {
    id: 'art-travel-kyoto',
    title: 'Morning Walk Through the Quiet Lanes of Kyoto',
    titleAr: 'نزهة صباحية في أزقة كيوتو الهادئة',
    topicId: 'travel',
    typeLabel: 'مقالة سفر',
    level: 'B1',
    readingMinutes: 3,
    summaryHintAr: 'جولة وصفية في مدينة كيوتو اليابانية بين المعابد الخشبية ومقاهي الشاي الصباحية.',
    paragraphs: [
      'If you wake up early in Kyoto, the historic Japanese city feels like a living painting. Soft mist rises above the green hills while shopkeepers sweep the stone paths outside traditional wooden houses.',
      'Near the bamboo forest, the only sounds are footsteps on gravel and wind whispering through tall green stalks. Travelers who arrive before eight o’clock can enjoy the peaceful scenery before the midday crowds appear.',
      'Later in the morning, tiny neighborhood cafes open their sliding doors and serve warm green tea alongside freshly baked pastries. Locals greet each other politely with a gentle nod and a warm smile.',
      'Visiting Kyoto reminds travelers that modern life and ancient traditions can exist side by side. Sometimes the best way to understand a new culture is simply to walk slowly and observe the small details.',
    ],
  },
  {
    id: 'art-science-mars',
    title: 'Listening to the Wind on Mars',
    titleAr: 'الاستماع إلى صوت الرياح على كوكب المريخ',
    topicId: 'science',
    typeLabel: 'مقالة علمية',
    level: 'B2',
    readingMinutes: 3,
    summaryHintAr: 'كيف تمكن العلماء عبر مركبة Perseverance من تسجيل أصوات حقيقية على سطح المريخ واكتشاف سرعة الصوت هناك.',
    paragraphs: [
      'For decades, scientists studied Mars only through photographs and chemical sensors. That changed when NASA’s Perseverance rover landed on the red planet carrying two specialized microphones.',
      'When the first audio recordings reached Earth, researchers heard the eerie whisper of Martian wind blowing across dusty rocks. Because the atmosphere on Mars is nearly one hundred times thinner than Earth’s, sound behaves in a surprising way.',
      'High-pitched noises travel slightly faster than deep, low-pitched sounds on Mars. If two astronauts stood just a few meters apart without radios, their voices would sound faint, muffled, and strangely delayed.',
      'Beyond satisfying human curiosity, these microphones serve a practical engineering purpose. By listening to the hum of wheels and motors, engineers on Earth can detect mechanical wear early and keep the rover exploring safely.',
    ],
  },
  {
    id: 'art-history-coffee',
    title: 'How a Tiny Bean Traveled Around the World',
    titleAr: 'كيف سافرت حبة البن الصغيرة حول العالم',
    topicId: 'history',
    typeLabel: 'مقالة تاريخية',
    level: 'B1',
    readingMinutes: 3,
    summaryHintAr: 'رحلة القهوة التاريخية من المرتفعات الإثيوبية واليمن إلى المقاهي الثقافية في أنحاء العالم.',
    paragraphs: [
      'Every morning, billions of people begin their day with a steaming cup of coffee, yet few stop to wonder how this beloved drink spread across continents.',
      'According to ancient legends, coffee plants were first discovered in the highlands of Ethiopia before merchants carried the beans across the Red Sea to Yemen. By the fifteenth century, roasted coffee had become central to hospitality and intellectual conversation across the Middle East.',
      'Soon, coffeehouses opened in bustling trading cities from Cairo and Damascus to Istanbul, Venice, and London. Writers, merchants, and scientists gathered around small tables to share news, debate ideas, and read newspapers.',
      'Today, coffee connects farmers in tropical mountains with neighborhoods in almost every city on Earth. What started as a wild forest berry became a universal symbol of warmth, energy, and friendship.',
    ],
  },
  {
    id: 'art-story-notebook',
    title: 'The Blue Notebook on Seat 14B',
    titleAr: 'الدفتر الأزرق على المقعد 14B',
    topicId: 'stories',
    typeLabel: 'رواية قصيرة',
    level: 'B1',
    readingMinutes: 3,
    summaryHintAr: 'قصة قصيرة عن مسافرة تعثر على دفتر رسومات في القطار وتخوض رحلة صغيرة لإعادته إلى صاحبته.',
    paragraphs: [
      'As the evening train slowed down at Central Station, Nadia noticed a worn blue notebook resting under seat 14B. She picked it up quickly, hoping to catch the passenger who had just stepped onto the platform.',
      'The crowd had already scattered into the busy hall, so Nadia opened the first page looking for a phone number. Instead of a number, she found delicate pencil sketches of bridges, bakeries, and stray cats, along with a cafe receipt from River Street.',
      'The next afternoon, Nadia walked down to the small riverside cafe and showed the notebook to the barista. His eyes lit up immediately; it belonged to an art teacher named Clara who sketched there every Friday.',
      'Two days later, Nadia received a joyful email from Clara thanking her warmly. Attached to the message was a brand-new sketch of two strangers sharing coffee at a sunny train station.',
    ],
  },
  {
    id: 'art-health-walking',
    title: 'The Surprising Power of a Twenty-Minute Walk',
    titleAr: 'القوة المدهشة للمشي عشرين دقيقة يومياً',
    topicId: 'health',
    typeLabel: 'نص ثقافي',
    level: 'A1',
    readingMinutes: 2,
    summaryHintAr: 'فوائد المشي اليومي البسيط لتحسين المزاج وتوليد الأفكار الإبداعية بدون الحاجة لصالة رياضية.',
    paragraphs: [
      'Many people think that staying fit requires expensive equipment or hours at a crowded gym. In reality, one of the healthiest habits is completely free: taking a twenty-minute walk outdoors.',
      'Walking increases blood flow to the brain and releases natural chemicals that lift your mood. Even a short walk during a lunch break can clear away afternoon tiredness.',
      'Psychologists have also discovered that people come up with more creative ideas while walking than while sitting at a desk. Famous writers and scientists often solved hard problems simply by stepping outside.',
      'If you want to build a lasting habit, pair your walk with something enjoyable, such as listening to an English podcast or noticing new details along your street.',
    ],
  },
];
