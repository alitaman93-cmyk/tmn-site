import type { SrsCardState, SrsRating } from '../types';

const DAY_MS = 24 * 60 * 60 * 1000;
const TEN_MIN_MS = 10 * 60 * 1000;

export const MIN_EASE_FACTOR = 1.3;
export const MAX_EASE_FACTOR = 3.5;
export const DEFAULT_EASE_FACTOR = 2.5;

export function createInitialSrsCard(wordId: number, now = Date.now()): SrsCardState {
  return {
    wordId,
    easeFactor: DEFAULT_EASE_FACTOR,
    intervalDays: 0,
    repetitions: 0,
    lapses: 0,
    dueAt: now,
    lastReviewedAt: 0,
  };
}

/**
 * Pure Anki SM-2 spaced repetition transition.
 * Computes the updated card schedule given the learner's self-rating.
 */
export function reviewSrsCard(
  existing: SrsCardState | undefined,
  wordId: number,
  rating: SrsRating,
  now = Date.now()
): SrsCardState {
  const card = existing ? { ...existing } : createInitialSrsCard(wordId, now);
  let { easeFactor, intervalDays, repetitions, lapses } = card;

  if (rating === 'again') {
    repetitions = 0;
    lapses += 1;
    easeFactor = Math.max(MIN_EASE_FACTOR, Number((easeFactor - 0.2).toFixed(2)));
    intervalDays = 0;
    return {
      wordId,
      easeFactor,
      intervalDays,
      repetitions,
      lapses,
      dueAt: now + TEN_MIN_MS,
      lastReviewedAt: now,
    };
  }

  if (rating === 'hard') {
    easeFactor = Math.max(MIN_EASE_FACTOR, Number((easeFactor - 0.15).toFixed(2)));
    if (repetitions === 0) {
      intervalDays = 0.5; // 12 hours
      repetitions = 1;
    } else if (repetitions === 1) {
      intervalDays = Math.max(1, Math.round(Math.max(1, intervalDays) * 1.2));
      repetitions = 2;
    } else {
      intervalDays = Math.max(intervalDays + 1, Math.round(intervalDays * 1.2));
      repetitions += 1;
    }
  } else if (rating === 'good') {
    if (repetitions === 0) {
      intervalDays = 1;
    } else if (repetitions === 1) {
      intervalDays = 6;
    } else {
      intervalDays = Math.max(intervalDays + 1, Math.round(intervalDays * easeFactor));
    }
    repetitions += 1;
  } else {
    // easy
    easeFactor = Math.min(MAX_EASE_FACTOR, Number((easeFactor + 0.15).toFixed(2)));
    if (repetitions === 0) {
      intervalDays = 4;
    } else if (repetitions === 1) {
      intervalDays = 8;
    } else {
      intervalDays = Math.max(intervalDays + 2, Math.round(intervalDays * easeFactor * 1.3));
    }
    repetitions += 1;
  }

  intervalDays = Math.min(36500, intervalDays);

  return {
    wordId,
    easeFactor,
    intervalDays,
    repetitions,
    lapses,
    dueAt: now + Math.round(intervalDays * DAY_MS),
    lastReviewedAt: now,
  };
}

export function formatIntervalAr(intervalDays: number): string {
  if (intervalDays <= 0) return '< 10 دقائق';
  if (intervalDays < 1) {
    const hours = Math.max(1, Math.round(intervalDays * 24));
    return `${hours} ساعة`;
  }
  if (intervalDays === 1) return 'يوم واحد';
  if (intervalDays === 2) return 'يومان';
  if (intervalDays < 11) return `${Math.round(intervalDays)} أيام`;
  if (intervalDays < 30) return `${Math.round(intervalDays)} يوماً`;
  if (intervalDays < 365) {
    const months = Math.max(1, Math.round(intervalDays / 30));
    return months === 1 ? 'شهر واحد' : months === 2 ? 'شهران' : `${months} أشهر`;
  }
  const years = Math.max(1, Number((intervalDays / 365).toFixed(1)));
  return years === 1 ? 'سنة واحدة' : `${years} سنة`;
}

export function previewSrsIntervals(
  card: SrsCardState | undefined,
  wordId: number,
  now = Date.now()
): Record<SrsRating, string> {
  return {
    again: formatIntervalAr(reviewSrsCard(card, wordId, 'again', now).intervalDays),
    hard: formatIntervalAr(reviewSrsCard(card, wordId, 'hard', now).intervalDays),
    good: formatIntervalAr(reviewSrsCard(card, wordId, 'good', now).intervalDays),
    easy: formatIntervalAr(reviewSrsCard(card, wordId, 'easy', now).intervalDays),
  };
}

/**
 * Prioritize cards for an Anki study session:
 * 1) Overdue / due cards (earliest dueAt first)
 * 2) Unseen / new cards
 * 3) Upcoming cards (earliest dueAt first)
 */
export function orderPoolForSrs(
  pool: number[],
  srsCards: Record<number, SrsCardState>,
  now = Date.now()
): number[] {
  const due: number[] = [];
  const unseen: number[] = [];
  const upcoming: number[] = [];

  for (const id of pool) {
    const card = srsCards[id];
    if (!card || card.lastReviewedAt === 0) {
      unseen.push(id);
    } else if (card.dueAt <= now) {
      due.push(id);
    } else {
      upcoming.push(id);
    }
  }

  due.sort((a, b) => (srsCards[a]?.dueAt || 0) - (srsCards[b]?.dueAt || 0));
  upcoming.sort((a, b) => (srsCards[a]?.dueAt || 0) - (srsCards[b]?.dueAt || 0));

  return [...due, ...unseen, ...upcoming];
}

export interface SrsSummaryStats {
  totalTracked: number;
  dueNow: number;
  learning: number;
  mature: number;
}

export function getSrsStats(
  srsCards: Record<number, SrsCardState>,
  now = Date.now()
): SrsSummaryStats {
  let totalTracked = 0;
  let dueNow = 0;
  let learning = 0;
  let mature = 0;

  for (const card of Object.values(srsCards)) {
    if (!card || card.lastReviewedAt === 0) continue;
    totalTracked += 1;
    if (card.dueAt <= now) dueNow += 1;
    if (card.intervalDays >= 21) mature += 1;
    else learning += 1;
  }

  return { totalTracked, dueNow, learning, mature };
}
