import { POS_AR } from '../data/constants';
import type { CefrBand, UiLanguageCode, WordHubData } from '../types';
import { hotCacheGet, hotCacheSet, idbMediaGet, idbMediaSet } from './storage';
import { sanitizeWordHubData } from './wordHubLogic';
import { enrichWordHubWithOfflineUsage } from './wordUsageOffline';

const HUB_TTL_MS = 45 * 24 * 60 * 60 * 1000; // 45 days
const hubMemCache = new Map<string, WordHubData>();
const hubInFlight = new Map<string, Promise<WordHubData>>();

function cacheKey(word: string, uiLang: UiLanguageCode): string {
  return `hub_v4:${uiLang}:${word.toLowerCase().trim()}`;
}

export async function fastGtxTranslate(
  text: string,
  targetLang: UiLanguageCode = 'ar',
  timeoutMs = 4000
): Promise<string> {
  const clean = (text || '').trim();
  if (!clean) return '';
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch('/api/translate-ui-batch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ texts: [clean], sourceLang: 'en', targetLang }),
      signal: controller.signal,
    });
    if (!res.ok) return '';
    const json = (await res.json()) as { translations?: Record<string, string> };
    return (json?.translations?.[clean] || '').trim();
  } catch {
    return '';
  } finally {
    window.clearTimeout(timer);
  }
}

async function fastGtxTranslateList(
  items: string[],
  targetLang: UiLanguageCode
): Promise<string[]> {
  const clean = items.map((x) => (x || '').trim());
  const nonEmpty = Array.from(new Set(clean.filter(Boolean)));
  if (!nonEmpty.length) return clean;
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 5000);
  try {
    const res = await fetch('/api/translate-ui-batch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ texts: nonEmpty, sourceLang: 'en', targetLang }),
      signal: controller.signal,
    });
    if (res.ok) {
      const json = (await res.json()) as { translations?: Record<string, string> };
      const map = json?.translations || {};
      return clean.map((item) => (item ? (map[item] || '').trim() : ''));
    }
  } catch {
    // Ignore transient failure
  } finally {
    window.clearTimeout(timer);
  }
  return clean.map(() => '');
}

interface DictApiEntry {
  phonetic?: string;
  origin?: string;
  phonetics?: Array<{ text?: string; audio?: string }>;
  meanings?: Array<{
    partOfSpeech?: string;
    synonyms?: string[];
    antonyms?: string[];
    definitions?: Array<{
      definition?: string;
      example?: string;
      synonyms?: string[];
      antonyms?: string[];
    }>;
  }>;
}

interface DatamuseWord {
  word?: string;
  tags?: string[];
}

async function fetchJsonWithTimeout<T>(url: string, timeoutMs = 4500): Promise<T | null> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  } finally {
    window.clearTimeout(timer);
  }
}

function guessWordFamilyPos(
  _baseWord: string,
  candidate: string
): 'Noun' | 'Verb' | 'Adjective' | 'Adverb' {
  const c = candidate.toLowerCase();
  if (c.endsWith('ly')) return 'Adverb';
  if (c.endsWith('tion') || c.endsWith('sion') || c.endsWith('ment') || c.endsWith('ness') || c.endsWith('ity')) {
    return 'Noun';
  }
  if (c.endsWith('ful') || c.endsWith('less') || c.endsWith('able') || c.endsWith('ible') || c.endsWith('ous') || c.endsWith('ive') || c.endsWith('al')) {
    return 'Adjective';
  }
  if (c.endsWith('ize') || c.endsWith('ise') || c.endsWith('ate') || c.endsWith('ify')) {
    return 'Verb';
  }
  return 'Noun';
}

async function buildOfflineFallback(
  word: string,
  ar: string,
  uiLang: UiLanguageCode = 'ar'
): Promise<WordHubData> {
  const cleanWord = word.trim();
  const lower = cleanWord.toLowerCase();
  const encoded = encodeURIComponent(lower);

  const [dictEntries, synList, antList, mlList] = await Promise.all([
    fetchJsonWithTimeout<DictApiEntry[]>(`/api/dictionary?word=${encoded}`, 4500),
    fetchJsonWithTimeout<DatamuseWord[]>(`https://api.datamuse.com/words?rel_syn=${encoded}&max=8`, 3800),
    fetchJsonWithTimeout<DatamuseWord[]>(`https://api.datamuse.com/words?rel_ant=${encoded}&max=6`, 3800),
    fetchJsonWithTimeout<DatamuseWord[]>(`https://api.datamuse.com/words?ml=${encoded}&max=10`, 3800),
  ]);

  let posEn = '';
  let ipaUs = '';
  let ipaUk = '';
  let audioUsUrl = '';
  let audioUkUrl = '';
  let wordOrigin = '';
  const allDefs: string[] = [];
  const rawExamples: string[] = [];
  const synSet = new Set<string>();
  const antSet = new Set<string>();

  if (Array.isArray(dictEntries)) {
    for (const entry of dictEntries) {
      if (!wordOrigin && entry.origin) wordOrigin = entry.origin.trim();
      if (!ipaUs && entry.phonetic) ipaUs = entry.phonetic.trim();
      for (const ph of entry.phonetics || []) {
        const audio = (ph.audio || '').trim();
        const txt = (ph.text || '').trim();
        if (audio) {
          if (/-us\.mp3/i.test(audio) && !audioUsUrl) audioUsUrl = audio;
          else if (/-uk\.mp3/i.test(audio) && !audioUkUrl) audioUkUrl = audio;
          else if (!audioUsUrl) audioUsUrl = audio;
        }
        if (txt) {
          if (/-uk/i.test(audio) && !ipaUk) ipaUk = txt;
          else if (!ipaUs) ipaUs = txt;
          else if (!ipaUk) ipaUk = txt;
        }
      }
      for (const meaning of entry.meanings || []) {
        if (!posEn && meaning.partOfSpeech) posEn = meaning.partOfSpeech.toLowerCase().trim();
        for (const s of meaning.synonyms || []) {
          if (s && s.toLowerCase() !== lower) synSet.add(s.trim());
        }
        for (const a of meaning.antonyms || []) {
          if (a && a.toLowerCase() !== lower) antSet.add(a.trim());
        }
        for (const def of meaning.definitions || []) {
          if (def.definition) allDefs.push(def.definition.trim());
          if (def.example) {
            let ex = def.example.trim();
            if (!/[.!?]$/.test(ex)) ex += '.';
            ex = ex.charAt(0).toUpperCase() + ex.slice(1);
            if (!rawExamples.includes(ex)) rawExamples.push(ex);
          }
          for (const s of def.synonyms || []) {
            if (s && s.toLowerCase() !== lower) synSet.add(s.trim());
          }
          for (const a of def.antonyms || []) {
            if (a && a.toLowerCase() !== lower) antSet.add(a.trim());
          }
        }
      }
    }
  }

  for (const item of synList || []) {
    if (item.word && item.word.toLowerCase() !== lower) synSet.add(item.word.trim());
  }
  for (const item of antList || []) {
    if (item.word && item.word.toLowerCase() !== lower) antSet.add(item.word.trim());
  }

  const mlWords = (mlList || [])
    .map((m) => (m.word || '').trim())
    .filter((w) => w && w.toLowerCase() !== lower && !synSet.has(w) && !antSet.has(w));

  const stem = lower.length >= 4 ? lower.slice(0, Math.min(lower.length - 1, 5)) : lower;
  const familyCandidates = [...mlWords, ...Array.from(synSet)]
    .filter((w) => w.toLowerCase().startsWith(stem) && w.toLowerCase() !== lower)
    .slice(0, 5);

  const definitionEn = allDefs[0] || '';
  const secondaryEn = allDefs.slice(1, 4);
  const topExamples = rawExamples.slice(0, 4);
  const topSyns = Array.from(synSet).slice(0, 6);
  const topAnts = Array.from(antSet).slice(0, 5);
  const topRelated = mlWords.slice(0, 6);

  // Batch-translate missing target-language fields via fast Google GTX (~250ms)
  const textsToTranslate: string[] = [
    uiLang === 'ar' && ar ? '' : (definitionEn || cleanWord),
    ...secondaryEn,
    ...topExamples,
    wordOrigin,
  ];
  const translated = await fastGtxTranslateList(textsToTranslate, uiLang);

  let cursor = 0;
  const translatedDef = translated[cursor++] || '';
  const secondaryTr = secondaryEn.map(() => translated[cursor++] || '');
  const exampleTr = topExamples.map(() => translated[cursor++] || '');
  const originTr = translated[cursor++] || '';

  const definitionAr =
    uiLang === 'ar'
      ? (ar || translatedDef || cleanWord)
      : (translatedDef || ar || cleanWord);

  const hasDictionaryData = Boolean(
    definitionEn || topExamples.length || topSyns.length || topAnts.length || topRelated.length || ipaUs
  );

  return sanitizeWordHubData(
    {
      word: cleanWord,
      posEn,
      posAr: POS_AR[posEn] || posEn,
      ipaUs: ipaUs || ipaUk,
      ipaUk: ipaUk || ipaUs,
      audioUs: audioUsUrl || undefined,
      audioUk: audioUkUrl || undefined,
      definitionEn,
      definitionAr,
      secondaryMeanings: secondaryEn.map((defEn, idx) => ({
        posEn,
        definitionEn: defEn,
        ar: secondaryTr[idx] || defEn,
      })),
      synonyms: topSyns.map((w) => ({
        word: w,
        ar: '',
        nuanceAr: '',
        exampleEn: '',
        exampleAr: '',
      })),
      antonyms: topAnts.map((w) => ({
        word: w,
        ar: '',
        contrastAr: '',
        exampleEn: '',
        exampleAr: '',
      })),
      wordFamily: familyCandidates.map((w) => {
        const famPos = guessWordFamilyPos(cleanWord, w);
        return {
          word: w,
          pos: famPos,
          posAr: POS_AR[famPos.toLowerCase()] || famPos,
          ar: '',
          exampleEn: '',
        };
      }),
      relatedWords: topRelated.map((w) => ({
        word: w,
        ar: '',
        relationAr: 'semantic',
      })),
      collocations: [],
      examples: topExamples.map((en, idx) => ({
        en,
        ar: exampleTr[idx] || '',
        register: 'neutral' as const,
      })),
      commonMistakes: [],
      usageNotes: [],
      formalVsInformal: null,
      idioms: [],
      phrasalVerbs: [],
      wordOrigin: originTr || wordOrigin,
      memoryTip: '',
      source: hasDictionaryData ? 'dictionary' : 'offline',
    },
    cleanWord,
    definitionAr
  );
}

/**
 * Synchronous 0ms lookup from RAM or localStorage hot cache for instant WordDetailView hydration.
 */
export function getHotWordHub(word: string, uiLang: UiLanguageCode = 'ar'): WordHubData | null {
  const cleanWord = String(word || '').trim();
  if (!cleanWord) return null;
  const key = cacheKey(cleanWord, uiLang);
  const mem = hubMemCache.get(key);
  if (mem) return mem;
  const hot = hotCacheGet<WordHubData>('hub', key);
  if (hot && hot.word) {
    hubMemCache.set(key, hot);
    return hot;
  }
  return null;
}

function persistWordHub(key: string, data: WordHubData): void {
  if (data.source !== 'dictionary+ai' && data.source !== 'dictionary') return;
  hubMemCache.set(key, data);
  hotCacheSet('hub', key, data, HUB_TTL_MS);
  void idbMediaSet('wordHub', key, data, HUB_TTL_MS);
}

export async function fetchWordHub(params: {
  word: string;
  ar: string;
  band?: CefrBand;
  uiLang?: UiLanguageCode;
  backendUrl?: string;
  force?: boolean;
  skipAi?: boolean;
}): Promise<{ data: WordHubData; offline: boolean }> {
  const cleanWord = String(params.word || '').trim();
  const uiLang: UiLanguageCode = params.uiLang || 'ar';
  const key = cacheKey(cleanWord, uiLang);

  if (!params.force) {
    const hot = getHotWordHub(cleanWord, uiLang);
    if (hot) {
      return {
        data: enrichWordHubWithOfflineUsage(hot, {
          word: cleanWord,
          ar: params.ar,
          band: params.band,
        }),
        offline: false,
      };
    }
    const cached =
      (await idbMediaGet<WordHubData>('wordHub', key)) ||
      (await idbMediaGet<WordHubData>('wordInfo', key));
    if (cached && cached.word) {
      const enrichedCached = enrichWordHubWithOfflineUsage(cached, {
        word: cleanWord,
        ar: params.ar,
        band: params.band,
      });
      hubMemCache.set(key, enrichedCached);
      hotCacheSet('hub', key, enrichedCached, HUB_TTL_MS);
      return { data: enrichedCached, offline: false };
    }
  }

  const existing = hubInFlight.get(key);
  if (existing && !params.force) {
    const data = await existing;
    return { data, offline: data.source === 'offline' };
  }

  const reqPromise = (async (): Promise<WordHubData> => {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), params.skipAi ? 6_500 : 12_500);
      try {
        const res = await fetch('/api/word-hub', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            word: cleanWord,
            ar: params.ar,
            band: params.band || 'B1',
            uiLang,
            skipAi: Boolean(params.skipAi),
          }),
        });
        if (res.ok) {
          const json = (await res.json()) as Partial<WordHubData>;
          const clean = sanitizeWordHubData(json, cleanWord, params.ar);
          // If server returned sparse profile (missing definition or examples), enrich via dictionary fallback
          if (!clean.definitionEn && clean.examples.length === 0 && clean.synonyms.length === 0) {
            const enriched = await buildOfflineFallback(cleanWord, params.ar, uiLang);
            const merged = sanitizeWordHubData(
              {
                ...enriched,
                ...clean,
                definitionEn: clean.definitionEn || enriched.definitionEn,
                definitionAr: clean.definitionAr || enriched.definitionAr,
                ipaUs: clean.ipaUs || enriched.ipaUs,
                ipaUk: clean.ipaUk || enriched.ipaUk,
                audioUs: clean.audioUs || enriched.audioUs,
                audioUk: clean.audioUk || enriched.audioUk,
                examples: clean.examples.length ? clean.examples : enriched.examples,
                synonyms: clean.synonyms.length ? clean.synonyms : enriched.synonyms,
                antonyms: clean.antonyms.length ? clean.antonyms : enriched.antonyms,
                relatedWords: clean.relatedWords.length ? clean.relatedWords : enriched.relatedWords,
                wordFamily: clean.wordFamily.length ? clean.wordFamily : enriched.wordFamily,
                wordOrigin: clean.wordOrigin || enriched.wordOrigin,
                source: clean.source === 'dictionary+ai' ? 'dictionary+ai' : enriched.source,
              },
              cleanWord,
              params.ar
            );
            const enrichedMerged = enrichWordHubWithOfflineUsage(merged, {
              word: cleanWord,
              ar: params.ar,
              band: params.band,
            });
            persistWordHub(key, enrichedMerged);
            return enrichedMerged;
          }
          const enrichedClean = enrichWordHubWithOfflineUsage(clean, {
            word: cleanWord,
            ar: params.ar,
            band: params.band,
          });
          persistWordHub(key, enrichedClean);
          return enrichedClean;
        }
      } finally {
        clearTimeout(timer);
      }
    } catch {
      // Network or timeout fallback below
    }

    const fallback = enrichWordHubWithOfflineUsage(
      await buildOfflineFallback(cleanWord, params.ar, uiLang),
      {
        word: cleanWord,
        ar: params.ar,
        band: params.band,
      }
    );
    persistWordHub(key, fallback);
    return fallback;
  })();

  hubInFlight.set(key, reqPromise);
  try {
    const data = await reqPromise;
    return { data, offline: data.source === 'offline' };
  } finally {
    hubInFlight.delete(key);
  }
}

export function prefetchWordHub(
  word: string,
  ar: string,
  band?: CefrBand,
  uiLang: UiLanguageCode = 'ar'
): void {
  const key = cacheKey(word, uiLang);
  if (hubMemCache.has(key) || hubInFlight.has(key)) return;
  if (hotCacheGet<WordHubData>('hub', key)) return;
  // Background prefetch warms fast Free Dictionary + Datamuse grounding without burning Gemini daily quota
  void fetchWordHub({ word, ar, band, uiLang, skipAi: true }).catch(() => {});
}
