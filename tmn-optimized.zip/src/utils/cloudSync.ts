import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { BANDS } from '../data/constants';
import { db, handleFirestoreError, OperationType } from '../firebase';
import type { CefrBand, GameModeId, PersistedSettings, SrsCardState } from '../types';
import { todayStr } from './storage';

const VALID_BANDS = new Set<string>(BANDS);

function clampInt(n: unknown, min: number, max: number, fallback: number): number {
  const num = typeof n === 'number' && Number.isFinite(n) ? Math.round(n) : fallback;
  return Math.min(max, Math.max(min, num));
}

function clampFloat(n: unknown, min: number, max: number, fallback: number): number {
  const num = typeof n === 'number' && Number.isFinite(n) ? n : fallback;
  return Math.min(max, Math.max(min, Number(num.toFixed(2))));
}

function sanitizeIntList(arr: unknown, maxLen: number): number[] {
  if (!Array.isArray(arr)) return [];
  const unique = new Set<number>();
  for (const item of arr) {
    if (typeof item === 'number' && Number.isFinite(item) && item >= 0) {
      unique.add(Math.trunc(item));
    }
  }
  const list = Array.from(unique);
  return list.length > maxLen ? list.slice(list.length - maxLen) : list;
}

function sanitizeCompleted(map: unknown): Record<string, number> {
  if (!map || typeof map !== 'object') return {};
  const entries = Object.entries(map as Record<string, unknown>).slice(0, 5000);
  const out: Record<string, number> = {};
  for (const [k, v] of entries) {
    if (typeof k === 'string' && k.length <= 20 && typeof v === 'number' && Number.isFinite(v)) {
      out[k] = clampInt(v, 0, 100, 0);
    }
  }
  return out;
}

export function buildFirestoreProfileFields(user: User, settings: PersistedSettings) {
  const lastBand: CefrBand = VALID_BANDS.has(settings.lastBand) ? settings.lastBand : 'A0';
  return {
    displayName: (user.displayName || 'مستخدم TMN').slice(0, 120),
    photoURL: (user.photoURL || '').slice(0, 500),
    theme: settings.theme === 'light' ? 'light' : 'dark',
    sfx: Boolean(settings.sfx),
    autoSpeak: Boolean(settings.autoSpeak),
    ttsRate: clampFloat(settings.ttsRate, 0.5, 1.5, 0.92),
    levelSize: clampInt(settings.levelSize, 10, 50, 20),
    dailyGoal: clampInt(settings.dailyGoal, 5, 200, 20),
    todayDate: (settings.todayDate || todayStr()).slice(0, 20),
    todayCount: clampInt(settings.todayCount, 0, 100000, 0),
    mcqDir: settings.mcqDir === 'ar2en' ? 'ar2en' : 'en2ar',
    lastGame: String(settings.lastGame || 'missing').slice(0, 32),
    lastBand,
    lastSubLevel: clampInt(settings.lastSubLevel, 0, 5000, 0),
    xp: clampInt(settings.xp, 0, 100000000, 0),
    streak: clampInt(settings.streak, 0, 100000, 0),
    bestStreak: clampInt(settings.bestStreak, 0, 100000, 0),
    completed: sanitizeCompleted(settings.completed),
    mistakes: sanitizeIntList(settings.mistakes, 500),
    favorites: sanitizeIntList(settings.favorites, 1000),
    mastered: sanitizeIntList(settings.mastered, 5000),
    favoriteSentences: sanitizeIntList(settings.favoriteSentences, 500),
    practicedSentences: sanitizeIntList(settings.practicedSentences, 1000),
  };
}

export function mergeCloudAndLocalSettings(
  local: PersistedSettings,
  cloud: Record<string, unknown>,
  cloudSrs: Record<number, SrsCardState>
): PersistedSettings {
  const td = todayStr();
  const cloudCompleted = sanitizeCompleted(cloud.completed);
  const mergedCompleted: Record<string, number> = { ...local.completed };
  for (const [k, v] of Object.entries(cloudCompleted)) {
    mergedCompleted[k] = Math.max(mergedCompleted[k] || 0, v);
  }

  const unionList = (a: number[], b: number[], maxLen: number): number[] => {
    const merged = Array.from(new Set([...a, ...b]));
    return merged.length > maxLen ? merged.slice(merged.length - maxLen) : merged;
  };

  const mergedSrs: Record<number, SrsCardState> = { ...local.srsCards };
  for (const [idStr, card] of Object.entries(cloudSrs)) {
    const id = Number(idStr);
    const localCard = mergedSrs[id];
    if (!localCard || card.lastReviewedAt >= localCard.lastReviewedAt) {
      mergedSrs[id] = card;
    }
  }

  const cloudTodayCount =
    cloud.todayDate === td && typeof cloud.todayCount === 'number' ? cloud.todayCount : 0;
  const localTodayCount = local.todayDate === td ? local.todayCount : 0;

  return {
    ...local,
    theme: cloud.theme === 'light' || cloud.theme === 'dark' ? cloud.theme : local.theme,
    sfx: typeof cloud.sfx === 'boolean' ? cloud.sfx : local.sfx,
    autoSpeak: typeof cloud.autoSpeak === 'boolean' ? cloud.autoSpeak : local.autoSpeak,
    ttsRate: typeof cloud.ttsRate === 'number' ? cloud.ttsRate : local.ttsRate,
    levelSize: typeof cloud.levelSize === 'number' ? cloud.levelSize : local.levelSize,
    dailyGoal: typeof cloud.dailyGoal === 'number' ? cloud.dailyGoal : local.dailyGoal,
    mcqDir: cloud.mcqDir === 'ar2en' || cloud.mcqDir === 'en2ar' ? cloud.mcqDir : local.mcqDir,
    lastGame: (typeof cloud.lastGame === 'string' ? cloud.lastGame : local.lastGame) as GameModeId,
    lastBand: (typeof cloud.lastBand === 'string' && VALID_BANDS.has(cloud.lastBand)
      ? cloud.lastBand
      : local.lastBand) as CefrBand,
    lastSubLevel:
      typeof cloud.lastSubLevel === 'number' ? cloud.lastSubLevel : local.lastSubLevel,
    todayDate: td,
    todayCount: Math.max(localTodayCount, cloudTodayCount),
    xp: Math.max(local.xp, typeof cloud.xp === 'number' ? cloud.xp : 0),
    streak: Math.max(local.streak, typeof cloud.streak === 'number' ? cloud.streak : 0),
    bestStreak: Math.max(
      local.bestStreak,
      typeof cloud.bestStreak === 'number' ? cloud.bestStreak : 0
    ),
    completed: mergedCompleted,
    mistakes: unionList(local.mistakes, sanitizeIntList(cloud.mistakes, 500), 500),
    favorites: unionList(local.favorites, sanitizeIntList(cloud.favorites, 1000), 1000),
    mastered: unionList(local.mastered, sanitizeIntList(cloud.mastered, 5000), 5000),
    favoriteSentences: unionList(
      local.favoriteSentences || [],
      sanitizeIntList(cloud.favoriteSentences, 500),
      500
    ),
    practicedSentences: unionList(
      local.practicedSentences || [],
      sanitizeIntList(cloud.practicedSentences, 1000),
      1000
    ),
    srsCards: mergedSrs,
  };
}

export async function fetchCloudAccountState(
  user: User
): Promise<{
  profileExists: boolean;
  profileData: Record<string, unknown> | null;
  srsCards: Record<number, SrsCardState>;
}> {
  if (!user.emailVerified) {
    return { profileExists: false, profileData: null, srsCards: {} };
  }
  const userPath = `users/${user.uid}`;
  let profileData: Record<string, unknown> | null = null;
  let profileExists = false;

  try {
    const snap = await getDoc(doc(db, 'users', user.uid));
    if (snap.exists()) {
      profileExists = true;
      profileData = snap.data() as Record<string, unknown>;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, userPath);
  }

  const srsCards: Record<number, SrsCardState> = {};
  if (profileExists) {
    const srsPath = `users/${user.uid}/srsCards`;
    try {
      const q = query(collection(db, 'users', user.uid, 'srsCards'), where('userId', '==', user.uid));
      const snap = await getDocs(q);
      snap.forEach((docSnap) => {
        const d = docSnap.data();
        if (typeof d.wordId === 'number') {
          srsCards[d.wordId] = {
            wordId: d.wordId,
            easeFactor: typeof d.easeFactor === 'number' ? d.easeFactor : 2.5,
            intervalDays: typeof d.intervalDays === 'number' ? d.intervalDays : 0,
            repetitions: typeof d.repetitions === 'number' ? d.repetitions : 0,
            lapses: typeof d.lapses === 'number' ? d.lapses : 0,
            dueAt: typeof d.dueAt === 'number' ? d.dueAt : Date.now(),
            lastReviewedAt:
              d.updatedAt && typeof d.updatedAt.toMillis === 'function'
                ? d.updatedAt.toMillis()
                : Date.now(),
          };
        }
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, srsPath);
    }
  }

  return { profileExists, profileData, srsCards };
}

export async function upsertCloudProfile(
  user: User,
  settings: PersistedSettings,
  profileExists: boolean
): Promise<void> {
  if (!user.emailVerified || !user.email) return;
  const userRef = doc(db, 'users', user.uid);
  const userPath = `users/${user.uid}`;
  const mutableFields = buildFirestoreProfileFields(user, settings);

  if (!profileExists) {
    try {
      await setDoc(userRef, {
        uid: user.uid,
        email: user.email.slice(0, 200),
        ...mutableFields,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, userPath);
    }
  } else {
    try {
      await updateDoc(userRef, {
        ...mutableFields,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, userPath);
    }
  }
}

export async function upsertCloudSrsCard(
  user: User,
  card: SrsCardState,
  existsInCloud: boolean
): Promise<void> {
  if (!user.emailVerified) return;
  const cardId = `word_${Math.trunc(card.wordId)}`;
  const cardRef = doc(db, 'users', user.uid, 'srsCards', cardId);
  const cardPath = `users/${user.uid}/srsCards/${cardId}`;

  const payload = {
    easeFactor: clampFloat(card.easeFactor, 1.3, 3.5, 2.5),
    intervalDays: clampFloat(card.intervalDays, 0, 36500, 0),
    repetitions: clampInt(card.repetitions, 0, 10000, 0),
    lapses: clampInt(card.lapses, 0, 10000, 0),
    dueAt: Math.max(0, Math.trunc(card.dueAt)),
  };

  if (existsInCloud) {
    try {
      await updateDoc(cardRef, {
        ...payload,
        updatedAt: serverTimestamp(),
      });
      return;
    } catch {
      // Fallback to create if doc wasn't created yet
    }
  }

  try {
    await setDoc(cardRef, {
      userId: user.uid,
      wordId: clampInt(card.wordId, 0, 100000, 0),
      ...payload,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, cardPath);
  }
}
