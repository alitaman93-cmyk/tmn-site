import assert from 'node:assert/strict';
import test from 'node:test';
import {
  buildGrammarReorderTiles,
  checkFillBlankAnswer,
  checkGrammarReorderAnswer,
  computeGrammarMastery,
  filterGrammarLessons,
} from './grammarLogic';
import type { GrammarLesson } from '../types';

test('checkFillBlankAnswer validates case, punctuation, and contractions accurately', () => {
  assert.equal(checkFillBlankAnswer('has been', ['has been']), true);
  assert.equal(checkFillBlankAnswer('  HAS   BEEN. ', ['has been']), true);
  assert.equal(checkFillBlankAnswer("don't", ['do not']), true);
  assert.equal(checkFillBlankAnswer('do not', ["don't"]), true);
  assert.equal(checkFillBlankAnswer('was', ['were']), false);
  assert.equal(checkFillBlankAnswer('', ['is']), false);
});

test('buildGrammarReorderTiles scrambles tokens and checkGrammarReorderAnswer verifies exact order', () => {
  const sentence = 'She has lived in London since 2020.';
  const { targetTokens, shuffledTiles } = buildGrammarReorderTiles(sentence);
  assert.equal(targetTokens.length, 7);
  assert.equal(shuffledTiles.length, 7);
  assert.notDeepEqual(
    shuffledTiles.map((t) => t.text),
    targetTokens
  );
  assert.equal(checkGrammarReorderAnswer(targetTokens, sentence), true);
  assert.equal(
    checkGrammarReorderAnswer(['She', 'lived', 'has', 'in', 'London', 'since', '2020.'], sentence),
    false
  );
});

test('filterGrammarLessons and computeGrammarMastery filter cleanly and compute percentages', () => {
  const sample: GrammarLesson[] = [
    {
      id: 'present-simple',
      band: 'A1',
      category: 'tenses',
      titleEn: 'Present Simple',
      titleAr: 'الحاضر البسيط',
      formula: 'S + V1',
      summaryAr: 'للروتين والحقائق',
      howToUseAr: [],
      whenToUseAr: [],
      commonMistakes: [],
      examples: [],
      exercises: [],
    },
    {
      id: 'inversion',
      band: 'C1',
      category: 'advanced',
      titleEn: 'Negative Inversion',
      titleAr: 'القلب للتوكيد',
      formula: 'Never + Aux + S + V',
      summaryAr: 'للتأكيد البلاغي',
      howToUseAr: [],
      whenToUseAr: [],
      commonMistakes: [],
      examples: [],
      exercises: [],
    },
  ];
  assert.equal(filterGrammarLessons(sample, { band: 'C1' }).length, 1);
  assert.equal(filterGrammarLessons(sample, { category: 'tenses' }).length, 1);
  assert.equal(filterGrammarLessons(sample, { query: 'inversion' }).length, 1);
  assert.deepEqual(computeGrammarMastery(36, ['a', 'b', 'a', 'c']), {
    completedCount: 3,
    totalCount: 36,
    percent: 8,
  });
});
