import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import {
  analyzeSentenceForSwap,
  buildPatternSwapChain,
  buildPatternSwapRound,
  CURATED_PATTERN_TEMPLATES,
  evaluatePatternSwapOffline,
} from './patternSwapLogic';

describe('patternSwapLogic', () => {
  it('provides 40+ curated pattern templates and analyzes corpus sentences dynamically', () => {
    assert.ok(CURATED_PATTERN_TEMPLATES.length >= 40);
    const analyzed = analyzeSentenceForSwap(
      { id: 1, num: 500, en: 'She usually works in the office before noon.' },
      'هي عادة تعمل في المكتب قبل الظهر.',
      'subject'
    );
    assert.ok(analyzed);
    assert.equal(analyzed.slotType, 'subject');
    assert.equal(analyzed.slotText, 'She');
    assert.ok(analyzed.hints.length >= 3);
  });

  it('builds a 3-step Chain Mode on the same base sentence', () => {
    const round = buildPatternSwapRound([], {}, 'all', 5, 42);
    assert.equal(round.length, 5);
    const chain = buildPatternSwapChain(round[0]);
    assert.equal(chain.length, 3);
    assert.equal(chain[0].sentenceEn, chain[1].sentenceEn);
    assert.equal(chain[1].sentenceEn, chain[2].sentenceEn);
  });

  it('evaluates Pattern Swap offline: accepts valid swap, rejects identical repeat, catches subject-verb errors', () => {
    // Valid subject swap with agreement
    const good = evaluatePatternSwapOffline({
      originalSentence: 'I am ready for the meeting.',
      targetSlotType: 'subject',
      targetSlotText: 'I',
      userSentence: 'She is ready for the meeting.',
    });
    assert.equal(good.swappedCorrectly, true);
    assert.equal(good.isGrammaticallyCorrect, true);
    assert.ok(good.score >= 85);

    // Identical repetition rejected
    const repeated = evaluatePatternSwapOffline({
      originalSentence: 'I am ready for the meeting.',
      targetSlotType: 'subject',
      targetSlotText: 'I',
      userSentence: 'I am ready for the meeting.',
    });
    assert.equal(repeated.swappedCorrectly, false);
    assert.ok(repeated.score <= 40);

    // Agreement slip caught & corrected ("He go" -> "He goes")
    const slip = evaluatePatternSwapOffline({
      originalSentence: 'I go to the gym before breakfast.',
      targetSlotType: 'subject',
      targetSlotText: 'I',
      userSentence: 'He go to the gym before breakfast',
    });
    assert.equal(slip.swappedCorrectly, true);
    assert.equal(slip.isGrammaticallyCorrect, false);
    assert.ok(slip.correctedEn.startsWith('He goes'));
    assert.equal(slip.wrongParts.length, 1);
  });
});
