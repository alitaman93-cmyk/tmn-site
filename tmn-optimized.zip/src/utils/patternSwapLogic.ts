import type {
  CefrBand,
  PatternSwapEvalResult,
  PatternSwapSlotType,
  PatternSwapWrongPart,
  SentenceEntry,
} from '../types';
import { createSeededRng, shuffleWithRng } from './arcadeGamesLogic';
import { filterSentencesBySection, splitSentenceTokens } from './sentenceProGamesLogic';

export interface PatternSwapItem {
  id: string;
  sectionId: string;
  band: CefrBand;
  sentenceEn: string;
  sentenceAr: string;
  slotType: PatternSwapSlotType;
  slotText: string;
  slotStartWordIdx: number;
  slotEndWordIdx: number;
  missionAr: string;
  hints: string[];
}

export const SLOT_META: Record<
  PatternSwapSlotType,
  {
    labelAr: string;
    shortAr: string;
    missionTemplate: string;
    badgeClass: string;
    highlightClass: string;
  }
> = {
  subject: {
    labelAr: 'تبديل الفاعل (Subject)',
    shortAr: 'الفاعل',
    missionTemplate: 'انطق جملة مشابهة مع تبديل الفاعل فقط — انتبه لتوافق الفعل!',
    badgeClass:
      'bg-emerald-500/15 text-emerald-700 border-emerald-500/30 dark:text-emerald-300 dark:border-emerald-500/40',
    highlightClass:
      'rounded-lg border-b-2 border-emerald-500 bg-emerald-500/15 px-1.5 py-0.5 text-emerald-700 dark:text-emerald-300',
  },
  verb: {
    labelAr: 'تبديل الفعل (Verb)',
    shortAr: 'الفعل',
    missionTemplate: 'انطق جملة بنفس النمط مع استبدال الفعل بفعل آخر مناسب للمعنى.',
    badgeClass:
      'bg-indigo-500/15 text-indigo-700 border-indigo-500/30 dark:text-indigo-300 dark:border-indigo-500/40',
    highlightClass:
      'rounded-lg border-b-2 border-indigo-500 bg-indigo-500/15 px-1.5 py-0.5 text-indigo-700 dark:text-indigo-300',
  },
  object: {
    labelAr: 'تبديل المفعول به (Object)',
    shortAr: 'المفعول به',
    missionTemplate: 'حافظ على بداية الجملة واستبدل المفعول به (الجزء المظلّل) بشيء جديد.',
    badgeClass:
      'bg-amber-500/15 text-amber-800 border-amber-500/35 dark:text-amber-300 dark:border-amber-500/40',
    highlightClass:
      'rounded-lg border-b-2 border-amber-500 bg-amber-500/15 px-1.5 py-0.5 text-amber-800 dark:text-amber-300',
  },
  preposition: {
    labelAr: 'تبديل حرف الجر / الوقت أو المكان',
    shortAr: 'الظرف / حرف الجر',
    missionTemplate: 'أعد قول الجملة مع تبديل حرف الجر أو الوقت/المكان المظلّل.',
    badgeClass:
      'bg-sky-500/15 text-sky-700 border-sky-500/30 dark:text-sky-300 dark:border-sky-500/40',
    highlightClass:
      'rounded-lg border-b-2 border-sky-500 bg-sky-500/15 px-1.5 py-0.5 text-sky-700 dark:text-sky-300',
  },
  free: {
    labelAr: 'تبديل حر (Free Swap)',
    shortAr: 'تبديل حر',
    missionTemplate: 'اختر أي جزء في الجملة وبدّله بكلمة جديدة لتكوين جملة طبيعية صحيحة.',
    badgeClass:
      'bg-violet-500/15 text-violet-700 border-violet-500/30 dark:text-violet-300 dark:border-violet-500/40',
    highlightClass:
      'rounded-lg border-b-2 border-violet-500 bg-violet-500/15 px-1.5 py-0.5 text-violet-700 dark:text-violet-300',
  },
};

interface RawTemplate {
  id: string;
  sectionId: string;
  band: CefrBand;
  sentenceEn: string;
  sentenceAr: string;
  slotType: PatternSwapSlotType;
  slotText: string;
  hints: string[];
}

export const CURATED_PATTERN_TEMPLATES: RawTemplate[] = [
  // Subject Swaps (testing agreement!)
  { id: 'ps1', sectionId: 'basics', band: 'A1', sentenceEn: 'I am ready for the meeting.', sentenceAr: 'أنا مستعد للاجتماع.', slotType: 'subject', slotText: 'I', hints: ['She (is)', 'We (are)', 'My friend (is)', 'They (are)'] },
  { id: 'ps2', sectionId: 'daily_chat', band: 'A1', sentenceEn: 'I like drinking hot tea in the morning.', sentenceAr: 'أحب شرب الشاي الساخن في الصباح.', slotType: 'subject', slotText: 'I', hints: ['He (likes)', 'She (likes)', 'My brother (likes)', 'We (like)'] },
  { id: 'ps3', sectionId: 'daily_chat', band: 'A1', sentenceEn: 'They live in a quiet apartment downtown.', sentenceAr: 'هم يعيشون في شقة هادئة وسط المدينة.', slotType: 'subject', slotText: 'They', hints: ['She (lives)', 'My sister (lives)', 'We (live)', 'He (lives)'] },
  { id: 'ps4', sectionId: 'basics', band: 'A1', sentenceEn: 'He has a lot of experience in design.', sentenceAr: 'لديه الكثير من الخبرة في التصميم.', slotType: 'subject', slotText: 'He', hints: ['I (have)', 'They (have)', 'My colleague (has)', 'We (have)'] },
  { id: 'ps5', sectionId: 'basics', band: 'A2', sentenceEn: 'We do not have enough time today.', sentenceAr: 'ليس لدينا وقت كافٍ اليوم.', slotType: 'subject', slotText: 'We', hints: ['She (does not)', 'He (does not)', 'I (do not)', 'They (do not)'] },
  { id: 'ps6', sectionId: 'travel', band: 'A2', sentenceEn: 'She is waiting for the airport bus.', sentenceAr: 'هي تنتظر حافلة المطار.', slotType: 'subject', slotText: 'She', hints: ['We (are)', 'I (am)', 'The tourists (are)', 'He (is)'] },
  { id: 'ps7', sectionId: 'plans', band: 'A2', sentenceEn: 'I want to learn English fluently this year.', sentenceAr: 'أريد أن أتعلم الإنجليزية بطلاقة هذا العام.', slotType: 'subject', slotText: 'I', hints: ['He (wants)', 'My sister (wants)', 'We (want)', 'They (want)'] },
  { id: 'ps8', sectionId: 'tech_work', band: 'B1', sentenceEn: 'He works from home three days a week.', sentenceAr: 'هو يعمل من المنزل ثلاثة أيام في الأسبوع.', slotType: 'subject', slotText: 'He', hints: ['I (work)', 'They (work)', 'My manager (works)', 'We (work)'] },
  { id: 'ps9', sectionId: 'study_lib', band: 'B1', sentenceEn: 'She studies at the library every afternoon.', sentenceAr: 'هي تدرس في المكتبة كل عصر.', slotType: 'subject', slotText: 'She', hints: ['We (study)', 'I (study)', 'The students (study)', 'He (studies)'] },
  { id: 'ps10', sectionId: 'habits_causative', band: 'B1', sentenceEn: 'My brother goes to the gym before breakfast.', sentenceAr: 'أخي يذهب إلى النادي الرياضي قبل الفطور.', slotType: 'subject', slotText: 'My brother', hints: ['I (go)', 'We (go)', 'She (goes)', 'They (go)'] },

  // Verb Swaps
  { id: 'ps11', sectionId: 'daily_chat', band: 'A1', sentenceEn: 'I usually drink coffee at seven.', sentenceAr: 'عادةً أشرب القهوة في السابعة.', slotType: 'verb', slotText: 'drink', hints: ['make', 'prepare', 'order', 'enjoy'] },
  { id: 'ps12', sectionId: 'shopping', band: 'A1', sentenceEn: 'I want to buy a new jacket today.', sentenceAr: 'أريد أن أشتري سترة جديدة اليوم.', slotType: 'verb', slotText: 'buy', hints: ['find', 'order', 'try on', 'choose'] },
  { id: 'ps13', sectionId: 'study_lib', band: 'A2', sentenceEn: 'We need to finish this report before noon.', sentenceAr: 'نحتاج لإنهاء هذا التقرير قبل الظهر.', slotType: 'verb', slotText: 'finish', hints: ['review', 'send', 'update', 'check'] },
  { id: 'ps14', sectionId: 'travel', band: 'A2', sentenceEn: 'I forgot to pack my passport last night.', sentenceAr: 'نسيت أن أضع جواز سفري في الحقيبة الليلة الماضية.', slotType: 'verb', slotText: 'pack', hints: ['check', 'bring', 'find', 'renew'] },
  { id: 'ps15', sectionId: 'modals', band: 'A2', sentenceEn: 'You should read this book this weekend.', sentenceAr: 'ينبغي أن تقرأ هذا الكتاب في عطلة نهاية الأسبوع.', slotType: 'verb', slotText: 'read', hints: ['finish', 'borrow', 'share', 'buy'] },
  { id: 'ps16', sectionId: 'phone_msg', band: 'B1', sentenceEn: 'Please call me when you arrive home.', sentenceAr: 'من فضلك اتصل بي عندما تصل إلى المنزل.', slotType: 'verb', slotText: 'call', hints: ['text', 'message', 'email', 'notify'] },
  { id: 'ps17', sectionId: 'opinions', band: 'B1', sentenceEn: 'We decided to postpone the meeting until Monday.', sentenceAr: 'قررنا تأجيل الاجتماع حتى يوم الإثنين.', slotType: 'verb', slotText: 'postpone', hints: ['cancel', 'move', 'schedule', 'start'] },
  { id: 'ps18', sectionId: 'advice', band: 'B1', sentenceEn: 'Try to practice English for ten minutes daily.', sentenceAr: 'حاول أن تمارس الإنجليزية لعشر دقائق يومياً.', slotType: 'verb', slotText: 'practice', hints: ['speak', 'listen to', 'study', 'review'] },
  { id: 'ps19', sectionId: 'tech_work', band: 'B2', sentenceEn: 'The team managed to solve the problem quickly.', sentenceAr: 'تمكّن الفريق من حل المشكلة بسرعة.', slotType: 'verb', slotText: 'solve', hints: ['fix', 'identify', 'explain', 'handle'] },
  { id: 'ps20', sectionId: 'plans', band: 'B2', sentenceEn: 'I plan to improve my speaking skills this month.', sentenceAr: 'أخطط لتحسين مهارات التحدث لدي هذا الشهر.', slotType: 'verb', slotText: 'improve', hints: ['build', 'develop', 'test', 'boost'] },

  // Object / Complement Swaps
  { id: 'ps21', sectionId: 'daily_chat', band: 'A1', sentenceEn: 'I am cooking pasta for dinner tonight.', sentenceAr: 'أطبخ المعكرونة للعشاء الليلة.', slotType: 'object', slotText: 'pasta', hints: ['chicken', 'rice', 'soup', 'fish'] },
  { id: 'ps22', sectionId: 'shopping', band: 'A1', sentenceEn: 'Could I try on these black shoes?', sentenceAr: 'هل يمكنني قياس هذا الحذاء الأسود؟', slotType: 'object', slotText: 'black shoes', hints: ['blue jeans', 'white shirt', 'warm coat', 'brown boots'] },
  { id: 'ps23', sectionId: 'travel', band: 'A2', sentenceEn: 'I would like to book a hotel room.', sentenceAr: 'أود حجز غرفة فندقية.', slotType: 'object', slotText: 'a hotel room', hints: ['a flight ticket', 'a rental car', 'a window seat', 'a city tour'] },
  { id: 'ps24', sectionId: 'study_lib', band: 'A2', sentenceEn: 'She is reading an interesting article about science.', sentenceAr: 'هي تقرأ مقالاً شيقاً عن العلوم.', slotType: 'object', slotText: 'an interesting article', hints: ['a short story', 'a history book', 'an English novel', 'the daily newspaper'] },
  { id: 'ps25', sectionId: 'daily_chat', band: 'A2', sentenceEn: 'We watched a great movie together last night.', sentenceAr: 'شاهدنا فيلماً رائعاً معاً الليلة الماضية.', slotType: 'object', slotText: 'a great movie', hints: ['a football match', 'a documentary', 'a comedy show', 'the sunset'] },
  { id: 'ps26', sectionId: 'apology', band: 'A2', sentenceEn: 'Sorry, I left my wallet at home.', sentenceAr: 'عذراً، تركت محفظتي في المنزل.', slotType: 'object', slotText: 'my wallet', hints: ['my phone', 'my keys', 'my glasses', 'my notebook'] },
  { id: 'ps27', sectionId: 'tech_work', band: 'B1', sentenceEn: 'I need to send an email to my manager.', sentenceAr: 'أحتاج لإرسال بريد إلكتروني إلى مديري.', slotType: 'object', slotText: 'an email', hints: ['the report', 'a message', 'the schedule', 'an update'] },
  { id: 'ps28', sectionId: 'opinions', band: 'B1', sentenceEn: 'Regular exercise gives me more energy every day.', sentenceAr: 'التمارين المنتظمة تمنحني طاقة أكبر كل يوم.', slotType: 'object', slotText: 'more energy', hints: ['better focus', 'more confidence', 'better sleep', 'less stress'] },
  { id: 'ps29', sectionId: 'travel', band: 'B1', sentenceEn: 'Can you recommend a good restaurant nearby?', sentenceAr: 'هل يمكنك ترشيح مطعم جيد قريب من هنا؟', slotType: 'object', slotText: 'a good restaurant', hints: ['a quiet cafe', 'a local bakery', 'a nice hotel', 'a good museum'] },
  { id: 'ps30', sectionId: 'plans', band: 'B2', sentenceEn: 'She wants to start her own small business.', sentenceAr: 'هي تريد أن تبدأ مشروعها الصغير الخاص.', slotType: 'object', slotText: 'her own small business', hints: ['a new career', 'a podcast channel', 'an online course', 'a design studio'] },

  // Preposition / Time / Place Swaps
  { id: 'ps31', sectionId: 'time_schedule', band: 'A1', sentenceEn: 'The train leaves at eight o clock.', sentenceAr: 'يغادر القطار في الساعة الثامنة.', slotType: 'preposition', slotText: 'at eight', hints: ['at nine', 'in ten minutes', 'before noon', 'after lunch'] },
  { id: 'ps32', sectionId: 'daily_chat', band: 'A1', sentenceEn: 'My keys are on the kitchen table.', sentenceAr: 'مفاتيحي على طاولة المطبخ.', slotType: 'preposition', slotText: 'on', hints: ['under', 'near', 'beside', 'next to'] },
  { id: 'ps33', sectionId: 'time_schedule', band: 'A2', sentenceEn: 'Let us meet in front of the station tomorrow.', sentenceAr: 'دعنا نلتقي أمام المحطة غداً.', slotType: 'preposition', slotText: 'tomorrow', hints: ['tonight', 'this Friday', 'next week', 'at five'] },
  { id: 'ps34', sectionId: 'travel', band: 'A2', sentenceEn: 'We arrived at the airport before sunrise.', sentenceAr: 'وصلنا إلى المطار قبل شروق الشمس.', slotType: 'preposition', slotText: 'before', hints: ['after', 'around', 'at', 'just before'] },
  { id: 'ps35', sectionId: 'daily_chat', band: 'A2', sentenceEn: 'I always go for a walk after dinner.', sentenceAr: 'أذهب دائماً للمشي بعد العشاء.', slotType: 'preposition', slotText: 'after', hints: ['before', 'during', 'right after', 'every'] },
  { id: 'ps36', sectionId: 'study_lib', band: 'B1', sentenceEn: 'He stayed inside the library until evening.', sentenceAr: 'بقي داخل المكتبة حتى المساء.', slotType: 'preposition', slotText: 'until', hints: ['before', 'after', 'during', 'all'] },
  { id: 'ps37', sectionId: 'traffic_way', band: 'B1', sentenceEn: 'The pharmacy is right across from the bank.', sentenceAr: 'الصيدلية تقع مباشرة مقابل البنك.', slotType: 'preposition', slotText: 'across from', hints: ['next to', 'behind', 'near', 'in front of'] },
  { id: 'ps38', sectionId: 'tech_work', band: 'B2', sentenceEn: 'Please submit your feedback before Friday afternoon.', sentenceAr: 'يرجى إرسال ملاحظاتك قبل عصر الجمعة.', slotType: 'preposition', slotText: 'before', hints: ['by', 'on', 'after', 'during'] },

  // Free Pattern Swaps
  { id: 'ps39', sectionId: 'short_qa', band: 'A1', sentenceEn: 'How much does a ticket to Paris cost?', sentenceAr: 'كم يكلف سعر تذكرة إلى باريس؟', slotType: 'free', slotText: 'Paris', hints: ['London', 'Rome', 'Dubai', 'Madrid'] },
  { id: 'ps40', sectionId: 'modals', band: 'A2', sentenceEn: 'Could you please open the window for me?', sentenceAr: 'هل يمكنك فتح النافذة لي من فضلك؟', slotType: 'free', slotText: 'open the window', hints: ['close the door', 'turn on the light', 'pass the water', 'check the time'] },
  { id: 'ps41', sectionId: 'opinions', band: 'B1', sentenceEn: 'I think traveling by train is very relaxing.', sentenceAr: 'أعتقد أن السفر بالقطار مريح جداً.', slotType: 'free', slotText: 'very relaxing', hints: ['fast and easy', 'quite affordable', 'really enjoyable', 'super convenient'] },
  { id: 'ps42', sectionId: 'motivation', band: 'B2', sentenceEn: 'Consistent small habits lead to big results over time.', sentenceAr: 'العادات الصغيرة المستمرة تؤدي إلى نتائج كبيرة مع الوقت.', slotType: 'free', slotText: 'big results', hints: ['real fluency', 'lasting success', 'steady growth', 'strong confidence'] },
];

const SUBJECT_PRONOUNS = new Set(['i', 'you', 'he', 'she', 'it', 'we', 'they']);
const COMMON_VERBS = new Set([
  'like', 'likes', 'love', 'loves', 'want', 'wants', 'need', 'needs', 'have', 'has',
  'go', 'goes', 'make', 'makes', 'take', 'takes', 'give', 'gives', 'work', 'works',
  'live', 'lives', 'eat', 'eats', 'drink', 'drinks', 'read', 'reads', 'write', 'writes',
  'speak', 'speaks', 'learn', 'learns', 'study', 'studies', 'play', 'plays', 'watch',
  'watches', 'buy', 'buys', 'find', 'finds', 'know', 'knows', 'think', 'thinks', 'see',
  'sees', 'feel', 'feels', 'keep', 'keeps', 'help', 'helps', 'use', 'uses', 'start',
  'finish', 'bring', 'send', 'call', 'visit', 'meet', 'check', 'open', 'close',
]);
const PREPOSITIONS_TIME = new Set([
  'in', 'on', 'at', 'before', 'after', 'under', 'near', 'beside', 'between', 'until',
  'during', 'tomorrow', 'yesterday', 'today', 'tonight', 'morning', 'evening', 'always',
  'never', 'usually', 'sometimes', 'often',
]);

function locateSlotIndices(sentenceEn: string, slotText: string): { start: number; end: number } {
  const words = splitSentenceTokens(sentenceEn).map((w) => w.cleanWord.toLowerCase());
  const slotWords = splitSentenceTokens(slotText).map((w) => w.cleanWord.toLowerCase());
  if (slotWords.length === 0) return { start: 0, end: 0 };

  for (let i = 0; i <= words.length - slotWords.length; i++) {
    let ok = true;
    for (let j = 0; j < slotWords.length; j++) {
      if (words[i + j] !== slotWords[j]) {
        ok = false;
        break;
      }
    }
    if (ok) return { start: i, end: i + slotWords.length - 1 };
  }
  return { start: 0, end: 0 };
}

function hydrateTemplate(tpl: RawTemplate): PatternSwapItem {
  const loc = locateSlotIndices(tpl.sentenceEn, tpl.slotText);
  return {
    id: tpl.id,
    sectionId: tpl.sectionId,
    band: tpl.band,
    sentenceEn: tpl.sentenceEn,
    sentenceAr: tpl.sentenceAr,
    slotType: tpl.slotType,
    slotText: tpl.slotText,
    slotStartWordIdx: loc.start,
    slotEndWordIdx: loc.end,
    missionAr: SLOT_META[tpl.slotType].missionTemplate,
    hints: tpl.hints,
  };
}

/**
 * Dynamically detects a swappable slot on any corpus sentence from /sentences-21k.tsv.
 */
export function analyzeSentenceForSwap(
  sentence: SentenceEntry,
  sentenceAr: string,
  preferredSlot?: PatternSwapSlotType
): PatternSwapItem | null {
  const tokens = splitSentenceTokens(sentence.en);
  if (tokens.length < 4 || tokens.length > 14) return null;

  const findSlot = (
    type: PatternSwapSlotType
  ): { idx: number; text: string; hints: string[] } | null => {
    if (type === 'subject') {
      const first = tokens[0]?.cleanWord.toLowerCase();
      if (SUBJECT_PRONOUNS.has(first)) {
        const alts = ['I', 'She', 'He', 'We', 'They'].filter((p) => p.toLowerCase() !== first);
        return { idx: 0, text: tokens[0].cleanWord, hints: alts.slice(0, 4) };
      }
      return null;
    }
    if (type === 'verb') {
      for (let i = 1; i < tokens.length - 1; i++) {
        const w = tokens[i].cleanWord.toLowerCase();
        if (COMMON_VERBS.has(w)) {
          return {
            idx: i,
            text: tokens[i].cleanWord,
            hints: ['prefer', 'enjoy', 'try', 'need'].filter((h) => h !== w).slice(0, 4),
          };
        }
      }
      return null;
    }
    if (type === 'preposition') {
      for (let i = 1; i < tokens.length; i++) {
        const w = tokens[i].cleanWord.toLowerCase();
        if (PREPOSITIONS_TIME.has(w)) {
          const isTime = ['tomorrow', 'yesterday', 'today', 'tonight', 'always', 'never', 'usually'].includes(w);
          return {
            idx: i,
            text: tokens[i].cleanWord,
            hints: isTime
              ? ['today', 'tomorrow', 'tonight', 'every week'].filter((h) => h !== w)
              : ['in', 'on', 'at', 'before', 'after'].filter((h) => h !== w).slice(0, 4),
          };
        }
      }
      return null;
    }
    if (type === 'object') {
      // Pick the last substantial word (typically object/complement)
      for (let i = tokens.length - 1; i >= 2; i--) {
        const w = tokens[i].cleanWord;
        if (/^[A-Za-z]{3,}$/.test(w) && !PREPOSITIONS_TIME.has(w.toLowerCase())) {
          return {
            idx: i,
            text: w,
            hints: ['something new', 'the office', 'my friend', 'this weekend'],
          };
        }
      }
      return null;
    }
    // free
    const mid = Math.max(1, Math.min(tokens.length - 1, Math.floor(tokens.length * 0.65)));
    return {
      idx: mid,
      text: tokens[mid].cleanWord,
      hints: ['اختر كلمة مناسبة للسياق', 'بدّل الوقت أو المكان', 'جرّب فعلاً أو اسماً جديداً'],
    };
  };

  const order: PatternSwapSlotType[] = preferredSlot
    ? [preferredSlot, 'subject', 'verb', 'preposition', 'object', 'free']
    : ['subject', 'verb', 'preposition', 'object', 'free'];

  for (const slotType of order) {
    const found = findSlot(slotType);
    if (found) {
      return {
        id: `corpus-${sentence.num}-${slotType}`,
        sectionId: 'all',
        band: tokens.length <= 6 ? 'A1' : tokens.length <= 9 ? 'A2' : 'B1',
        sentenceEn: sentence.en,
        sentenceAr: sentenceAr || '',
        slotType,
        slotText: found.text,
        slotStartWordIdx: found.idx,
        slotEndWordIdx: found.idx,
        missionAr: SLOT_META[slotType].missionTemplate,
        hints: found.hints,
      };
    }
  }
  return null;
}

/**
 * Builds a rich round of pattern swap items filtered by SENTENCE_SECTIONS, combining
 * curated templates + real dynamically analyzed sentences from /sentences-21k.tsv.
 */
export function buildPatternSwapRound(
  sentences: SentenceEntry[],
  arMap: Record<string, string>,
  sectionId: string,
  count = 12,
  seed: number = Date.now(),
  preferredSlot?: PatternSwapSlotType
): PatternSwapItem[] {
  const rng = createSeededRng(seed);
  const curatedPool =
    sectionId && sectionId !== 'all'
      ? CURATED_PATTERN_TEMPLATES.filter((t) => t.sectionId === sectionId)
      : CURATED_PATTERN_TEMPLATES;

  const curatedHydrated = shuffleWithRng(
    (curatedPool.length >= 3 ? curatedPool : CURATED_PATTERN_TEMPLATES)
      .filter((t) => !preferredSlot || t.slotType === preferredSlot),
    rng
  ).map(hydrateTemplate);

  // Also analyze real sentences from the 21k corpus in the chosen section
  const secSentences = filterSentencesBySection(sentences, sectionId);
  const corpusAnalyzed: PatternSwapItem[] = [];
  const sampledCorpus = shuffleWithRng(secSentences.slice(0, 600), rng);

  for (const s of sampledCorpus) {
    if (corpusAnalyzed.length >= Math.ceil(count / 2)) break;
    const ar = arMap[s.en] || '';
    const item = analyzeSentenceForSwap(s, ar, preferredSlot);
    if (item) {
      item.sectionId = sectionId || 'all';
      corpusAnalyzed.push(item);
    }
  }

  // Interleave curated (which always have verified Arabic translations) with dynamic corpus items
  const combined: PatternSwapItem[] = [];
  const maxLen = Math.max(curatedHydrated.length, corpusAnalyzed.length);
  for (let i = 0; i < maxLen && combined.length < count; i++) {
    if (curatedHydrated[i]) combined.push(curatedHydrated[i]);
    if (combined.length < count && corpusAnalyzed[i]) combined.push(corpusAnalyzed[i]);
  }
  return combined.length > 0 ? combined : CURATED_PATTERN_TEMPLATES.slice(0, count).map(hydrateTemplate);
}

/**
 * Builds a 3-step Chain Mode ("سلسلة 3 تحويلات لنفس الجملة") on the same base sentence:
 * e.g., Step 1: Subject -> Step 2: Verb -> Step 3: Object/Preposition or Free.
 */
export function buildPatternSwapChain(baseItem: PatternSwapItem): PatternSwapItem[] {
  const fakeEntry: SentenceEntry = { id: 0, num: 0, en: baseItem.sentenceEn };
  const chain: PatternSwapItem[] = [baseItem];
  const candidateTypes: PatternSwapSlotType[] = ['subject', 'verb', 'object', 'preposition', 'free'].filter(
    (t): t is PatternSwapSlotType => t !== baseItem.slotType
  );

  for (const slotType of candidateTypes) {
    if (chain.length >= 3) break;
    const step = analyzeSentenceForSwap(fakeEntry, baseItem.sentenceAr, slotType);
    if (
      step &&
      step.slotType === slotType &&
      !chain.some((c) => c.slotStartWordIdx === step.slotStartWordIdx && c.slotType === step.slotType)
    ) {
      chain.push({
        ...step,
        id: `${baseItem.id}-chain-${chain.length + 1}`,
        band: baseItem.band,
        sectionId: baseItem.sectionId,
      });
    }
  }

  // Ensure always 3 steps in Chain Mode by adding a Free Swap step if needed
  while (chain.length < 3) {
    chain.push({
      ...baseItem,
      id: `${baseItem.id}-chain-${chain.length + 1}`,
      slotType: 'free',
      missionAr: SLOT_META.free.missionTemplate,
      hints: ['بدّل كلمة مختلفة عن المحاولة السابقة', 'غيّر الوقت أو المكان أو المفعول به'],
    });
  }

  return chain;
}

function normalizeWords(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9'\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
}

const THIRD_SINGULAR_BARE_VERBS: Record<string, string> = {
  go: 'goes',
  like: 'likes',
  love: 'loves',
  want: 'wants',
  need: 'needs',
  work: 'works',
  live: 'lives',
  eat: 'eats',
  drink: 'drinks',
  play: 'plays',
  study: 'studies',
  speak: 'speaks',
  read: 'reads',
  write: 'writes',
  watch: 'watches',
  walk: 'walks',
  cook: 'cooks',
  sleep: 'sleeps',
  run: 'runs',
  have: 'has',
  do: 'does',
};

/**
 * 100% Offline Instant Structural & Grammar Evaluator for Sentence Pattern Swap.
 * Verifies:
 *  (a) Structural overlap >= 40% (kept the core pattern)
 *  (b) Target slot actually replaced (not merely repeating the identical sentence)
 *  (c) Common English subject-verb agreement rules (he/she/it vs I/you/we/they)
 */
export function evaluatePatternSwapOffline(params: {
  originalSentence: string;
  targetSlotType: PatternSwapSlotType;
  targetSlotText: string;
  userSentence: string;
}): PatternSwapEvalResult {
  const userTrim = params.userSentence.trim();
  const origWords = normalizeWords(params.originalSentence);
  const userWords = normalizeWords(userTrim);
  const slotWords = normalizeWords(params.targetSlotText);

  if (userWords.length < 2) {
    return {
      heardText: userTrim,
      swappedCorrectly: false,
      isGrammaticallyCorrect: false,
      score: 15,
      correctedEn: params.originalSentence,
      newSentenceAr: '',
      feedbackAr: 'الجملة قصيرة جداً — حاول قول أو كتابة الجملة كاملة مع تبديل الجزء المظلّل.',
      wrongParts: [],
      source: 'offline',
    };
  }

  const sameExact =
    origWords.length === userWords.length && origWords.every((w, i) => w === userWords[i]);
  if (sameExact) {
    return {
      heardText: userTrim,
      swappedCorrectly: false,
      isGrammaticallyCorrect: true,
      score: 30,
      correctedEn: userTrim,
      newSentenceAr: '',
      feedbackAr: `أعدتَ نفس الجملة الأصلية بدون تبديل! جرّب استبدال «${params.targetSlotText}» بكلمة جديدة.`,
      wrongParts: [
        {
          wrong: params.targetSlotText,
          right: 'كلمة بديلة جديدة',
          reasonAr: 'يجب تغيير الجزء المظلّل لتدريب الدماغ على توليد جمل جديدة.',
        },
      ],
      source: 'offline',
    };
  }

  // Structural overlap ratio excluding the target slot words
  const nonSlotOrig = origWords.filter((w) => !slotWords.includes(w));
  const userSet = new Set(userWords);
  let matchedCount = 0;
  for (const w of nonSlotOrig) {
    if (userSet.has(w)) matchedCount++;
  }
  const overlapRatio = nonSlotOrig.length > 0 ? matchedCount / nonSlotOrig.length : 1;

  // Did user change the target slot?
  const slotPhraseOrig = slotWords.join(' ');
  const userJoined = userWords.join(' ');
  const slotStillIdenticalAtSameSpot =
    params.targetSlotType !== 'free' &&
    slotWords.length > 0 &&
    ((params.targetSlotType === 'subject' && userWords[0] === slotWords[0]) ||
      (params.targetSlotType !== 'subject' &&
        slotPhraseOrig.length > 0 &&
        userJoined.includes(slotPhraseOrig) &&
        overlapRatio >= 0.85));

  // Subject-verb agreement checks
  const wrongParts: PatternSwapWrongPart[] = [];
  let correctedTokens = userTrim.split(/\s+/).filter(Boolean);

  const w0 = userWords[0] || '';
  const w1 = userWords[1] || '';

  const isThirdSing = w0 === 'he' || w0 === 'she' || w0 === 'it';
  const isPluralOrYou = w0 === 'you' || w0 === 'we' || w0 === 'they';
  const isFirstSing = w0 === 'i';

  if (isThirdSing) {
    if (w1 === 'are' || w1 === 'am') {
      wrongParts.push({
        wrong: `${correctedTokens[0]} ${correctedTokens[1]}`,
        right: `${correctedTokens[0]} is`,
        reasonAr: `مع الضمير (${correctedTokens[0]}) نستخدم "is" بدلاً من "${w1}".`,
      });
      correctedTokens[1] = 'is';
    } else if (w1 === 'do' || w1 === "don't") {
      const fix = w1 === 'do' ? 'does' : "doesn't";
      wrongParts.push({
        wrong: `${correctedTokens[0]} ${correctedTokens[1]}`,
        right: `${correctedTokens[0]} ${fix}`,
        reasonAr: `مع الضمير (${correctedTokens[0]}) نستخدم "${fix}" بدلاً من "${w1}".`,
      });
      correctedTokens[1] = fix;
    } else if (w1 === 'have') {
      wrongParts.push({
        wrong: `${correctedTokens[0]} have`,
        right: `${correctedTokens[0]} has`,
        reasonAr: `مع الضمير (${correctedTokens[0]}) نستخدم "has" بدلاً من "have".`,
      });
      correctedTokens[1] = 'has';
    } else if (THIRD_SINGULAR_BARE_VERBS[w1]) {
      const fix = THIRD_SINGULAR_BARE_VERBS[w1];
      wrongParts.push({
        wrong: `${correctedTokens[0]} ${correctedTokens[1]}`,
        right: `${correctedTokens[0]} ${fix}`,
        reasonAr: `مع الضمير (${correctedTokens[0]}) في المضارع البسيط نضيف s للفعل لتصبح "${fix}".`,
      });
      correctedTokens[1] = fix;
    }
  } else if (isPluralOrYou) {
    if (w1 === 'is' || w1 === 'am') {
      wrongParts.push({
        wrong: `${correctedTokens[0]} ${correctedTokens[1]}`,
        right: `${correctedTokens[0]} are`,
        reasonAr: `مع الضمير (${correctedTokens[0]}) نستخدم "are" بدلاً من "${w1}".`,
      });
      correctedTokens[1] = 'are';
    } else if (w1 === 'does' || w1 === "doesn't") {
      const fix = w1 === 'does' ? 'do' : "don't";
      wrongParts.push({
        wrong: `${correctedTokens[0]} ${correctedTokens[1]}`,
        right: `${correctedTokens[0]} ${fix}`,
        reasonAr: `مع الضمير (${correctedTokens[0]}) نستخدم "${fix}" بدلاً من "${w1}".`,
      });
      correctedTokens[1] = fix;
    } else if (w1 === 'has') {
      wrongParts.push({
        wrong: `${correctedTokens[0]} has`,
        right: `${correctedTokens[0]} have`,
        reasonAr: `مع الضمير (${correctedTokens[0]}) نستخدم "have" بدلاً من "has".`,
      });
      correctedTokens[1] = 'have';
    }
  } else if (isFirstSing) {
    if (w1 === 'is' || w1 === 'are') {
      wrongParts.push({
        wrong: `I ${correctedTokens[1]}`,
        right: 'I am',
        reasonAr: `مع الضمير (I) نستخدم "am" بدلاً من "${w1}".`,
      });
      correctedTokens[1] = 'am';
    } else if (w1 === 'does' || w1 === "doesn't") {
      const fix = w1 === 'does' ? 'do' : "don't";
      wrongParts.push({
        wrong: `I ${correctedTokens[1]}`,
        right: `I ${fix}`,
        reasonAr: `مع الضمير (I) نستخدم "${fix}" بدلاً من "${w1}".`,
      });
      correctedTokens[1] = fix;
    } else if (w1 === 'has') {
      wrongParts.push({
        wrong: 'I has',
        right: 'I have',
        reasonAr: 'مع الضمير (I) نستخدم "have" بدلاً من "has".',
      });
      correctedTokens[1] = 'have';
    }
  }

  let correctedEn = correctedTokens.join(' ');
  if (correctedEn.length > 0) {
    correctedEn = correctedEn[0].toUpperCase() + correctedEn.slice(1);
    if (!/[.!?]$/.test(correctedEn)) {
      correctedEn += params.originalSentence.trim().endsWith('?') ? '?' : '.';
    }
  }

  const keptPattern = overlapRatio >= 0.4;
  const swappedCorrectly = keptPattern && !slotStillIdenticalAtSameSpot;
  const isGrammaticallyCorrect = wrongParts.length === 0;

  let score = 92;
  let feedbackAr = 'ممتاز! حافظت على بنية الجملة وبدّلت الجزء المطلوب بسلاسة وطلاقة.';

  if (!keptPattern) {
    score = 50;
    feedbackAr = 'جملتك مختلفة كثيراً عن النمط المطلوب — حاول الحفاظ على بقية كلمات الجملة وتبديل الجزء المظلّل فقط.';
  } else if (slotStillIdenticalAtSameSpot) {
    score = 55;
    feedbackAr = `يبدو أن الجزء المطلوب «${params.targetSlotText}» لم يتغير — جرّب استبداله بكلمة أخرى.`;
  } else if (!isGrammaticallyCorrect) {
    score = 72;
    feedbackAr = `أحسنت في تبديل النمط! ملاحظة قواعدية سريعة: ${wrongParts[0].reasonAr}`;
  }

  return {
    heardText: userTrim,
    swappedCorrectly,
    isGrammaticallyCorrect,
    score,
    correctedEn,
    newSentenceAr: '',
    feedbackAr,
    wrongParts,
    source: 'offline',
  };
}
