import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildSentenceSearchQueries,
  buildWordMatchRegex,
  computeWordClipWindow,
  dedupeVideoClips,
  extractSentenceClipsFromCues,
  extractWordClipsFromCues,
  getActiveCaptionAtTime,
  getNextPrefetchIndices,
  type SourceVideoMeta,
} from './videoClipLogic';

test('buildWordMatchRegex matches exact word and inflections without partial-word false positives', () => {
  const rx = buildWordMatchRegex('walk');
  assert.equal(rx.test('They walked through the park.'), true);
  assert.equal(rx.test('She is walking quickly.'), true);
  assert.equal(rx.test('Sidewalk is busy.'), false);

  const studyRx = buildWordMatchRegex('study');
  assert.equal(studyRx.test('He studied physics in college.'), true);
  assert.equal(studyRx.test('Recent studies show improvement.'), true);
});

test('computeWordClipWindow always produces exact 3s before and 3s after clamped safely to duration', () => {
  const mid = computeWordClipWindow(42.5, 300, 3, 3);
  assert.equal(mid.startSec, 39.5);
  assert.equal(mid.endSec, 45.5);
  assert.equal(mid.clipDurationSec, 6);
  assert.equal(mid.wordOffsetPct, 50);

  // Near beginning of video
  const startEdge = computeWordClipWindow(1.2, 120, 3, 3);
  assert.equal(startEdge.startSec, 0);
  assert.equal(startEdge.endSec, 6);

  // Near end of video
  const endEdge = computeWordClipWindow(119.0, 120, 3, 3);
  assert.equal(endEdge.endSec, 120);
  assert.equal(endEdge.startSec, 114);
});

test('extractWordClipsFromCues extracts exact ±3s clips, spaces duplicates, and attaches synchronized captions', () => {
  const meta: SourceVideoMeta = {
    videoId: 'vid-100',
    slug: 'sample-talk',
    title: 'How Language Works',
    speaker: 'Jane Doe',
    sourceLabel: 'TED Talk',
    videoUrl: 'https://download.ted.com/products/100.mp4',
    posterUrl: 'https://pi.tedcdn.com/sample.jpg',
    durationSec: 240,
  };

  const cues = [
    { time: 10000, text: 'Let us talk about fresh water today.' },
    { time: 14000, text: 'Water is essential for every living cell.' }, // < 9s away -> should be spaced out
    { time: 35000, text: 'Clean water transforms entire communities.' },
    { time: 39000, text: 'And helps children thrive in school.' },
  ];

  const clips = extractWordClipsFromCues(meta, cues, 'water', 4);
  assert.equal(clips.length, 2);

  // First clip centered around "water" (~12s) -> ±3s
  assert.ok(clips[0].startSec >= 8 && clips[0].startSec <= 10.5);
  assert.equal(Number((clips[0].endSec - clips[0].startSec).toFixed(1)), 6);
  assert.equal(clips[0].matchedTerm.toLowerCase(), 'water');
  assert.ok(clips[0].cues.length >= 1);

  // Live caption sync returns exact active cue at timestamp
  const capAt36 = getActiveCaptionAtTime(clips[1], 36.0);
  assert.ok(capAt36.includes('Clean water'));
});

test('getNextPrefetchIndices and dedupeVideoClips prepare smooth zero-wait lookahead', () => {
  assert.deepEqual(getNextPrefetchIndices(0, 55, 3), [1, 2, 3]);
  assert.deepEqual(getNextPrefetchIndices(4, 55, 3), [5, 6, 7, 3]);
  assert.deepEqual(getNextPrefetchIndices(54, 55, 3), [53]);

  const sampleClip = {
    id: 'a-1',
    word: 'water',
    matchedTerm: 'water',
    videoUrl: 'https://example.com/a.mp4',
    posterUrl: 'https://example.com/a.jpg',
    title: 'Sample',
    speaker: 'Speaker',
    sourceLabel: 'TED',
    wordStartSec: 20,
    startSec: 17,
    endSec: 23,
    durationSec: 100,
    captionText: 'Drink water.',
    cues: [],
  };
  const deduped = dedupeVideoClips([sampleClip, { ...sampleClip }, { ...sampleClip, id: 'a-2', startSec: 50, endSec: 56 }]);
  assert.equal(deduped.length, 2);
});

test('buildSentenceSearchQueries prioritizes exact full sentence and contraction expansion', () => {
  const queries = buildSentenceSearchQueries("I don't know what to do!");
  assert.equal(queries[0], '"I don\'t know what to do"');
  assert.ok(queries.some((q) => q.toLowerCase().includes('do not know')));
  assert.ok(queries.includes("I don't know what to do"));
});

test('extractSentenceClipsFromCues matches full sentences across split cues and rejects isolated single words', () => {
  const meta: SourceVideoMeta = {
    videoId: 'vid-202',
    slug: 'everyday-english',
    title: 'Everyday Conversations',
    speaker: 'Alex Rivera',
    sourceLabel: 'TED Talk',
    videoUrl: 'https://download.ted.com/products/202.mp4',
    posterUrl: 'https://pi.tedcdn.com/202.jpg',
    durationSec: 300,
  };

  const cues = [
    { time: 10000, text: 'I know many people around the world.' }, // Only has word "know" -> MUST NOT MATCH!
    { time: 30000, text: 'Sometimes I do not know' },
    { time: 32500, text: 'what to do next in life.' }, // Split across 2 cues -> MUST MATCH full sentence!
  ];

  const clips = extractSentenceClipsFromCues(meta, cues, "I don't know what to do.", 3);
  assert.equal(clips.length, 1);
  assert.equal(clips[0].matchKind, 'exact_sentence');
  assert.equal(clips[0].matchScore, 100);
  assert.ok(clips[0].startSec <= 28.5 && clips[0].endSec >= 35.5);

  // Completely unrelated talk with only one word in common must return 0 clips
  const singleWordOnlyCues = [
    { time: 5000, text: 'You know how hard it is to build a rocket.' },
    { time: 20000, text: 'What makes this engine work so well?' },
  ];
  const rejected = extractSentenceClipsFromCues(meta, singleWordOnlyCues, "I don't know what to do.", 3);
  assert.equal(rejected.length, 0);
});

