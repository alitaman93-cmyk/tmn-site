import { STARTER_AR_TRANSLATIONS, STARTER_SENTENCES_TSV } from './sentenceLogic';
import type {
  CefrBand,
  WordHubCollocation,
  WordHubData,
  WordHubExample,
  WordHubExpression,
  WordHubFormalRegister,
  WordHubMistake,
} from '../types';
import { buildWordMatchRegex } from './videoClipLogic';

export interface OfflineUsageCorpusItem {
  en: string;
  ar?: string;
}

export interface OfflineUsageResult {
  examples: WordHubExample[];
  collocations: WordHubCollocation[];
  commonMistakes: WordHubMistake[];
  usageNotes: string[];
  formalVsInformal: WordHubFormalRegister;
  idioms: WordHubExpression[];
  phrasalVerbs: WordHubExpression[];
}

interface CuratedWordUsageEntry {
  pos?: 'verb' | 'noun' | 'adjective' | 'adverb' | 'phrase';
  collocations: WordHubCollocation[];
  commonMistakes?: WordHubMistake[];
  usageNotes?: string[];
  formalVsInformal?: WordHubFormalRegister;
  idioms?: WordHubExpression[];
  phrasalVerbs?: WordHubExpression[];
  examples?: WordHubExample[];
}

let cachedStarterCorpus: OfflineUsageCorpusItem[] | null = null;

function getStarterSentenceCorpus(): OfflineUsageCorpusItem[] {
  if (cachedStarterCorpus) return cachedStarterCorpus;
  const rows: OfflineUsageCorpusItem[] = [];
  const lines = STARTER_SENTENCES_TSV.split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const parts = trimmed.split('\t');
    const rawEn = (parts.length >= 2 ? parts[1] : parts[0]).trim();
    if (!rawEn) continue;
    const cleanEn = rawEn.split('=')[0].trim();
    if (!cleanEn) continue;
    const ar = STARTER_AR_TRANSLATIONS[rawEn] || STARTER_AR_TRANSLATIONS[cleanEn] || '';
    rows.push({ en: cleanEn, ar });
  }
  cachedStarterCorpus = rows;
  return rows;
}

const CURATED_WORD_USAGE: Record<string, CuratedWordUsageEntry> = {
  the: {
    pos: 'phrase',
    collocations: [
      {
        phrase: 'the morning / the evening',
        ar: 'الصباح / المساء',
        exampleEn: 'I like to drink coffee in the morning.',
        exampleAr: 'أحب أن أشرب القهوة في الصباح.',
      },
      {
        phrase: 'in the end',
        ar: 'في النهاية',
        exampleEn: 'In the end, everything worked out well.',
        exampleAr: 'في النهاية، سارت كل الأمور على ما يرام.',
      },
      {
        phrase: 'the best / the first',
        ar: 'الأفضل / الأول (مع التفضيل)',
        exampleEn: 'This is the best book I have read this year.',
        exampleAr: 'هذا أفضل كتاب قرأته هذا العام.',
      },
    ],
    examples: [
      { en: 'Please close the door before you leave.', ar: 'من فضلك أغلق الباب قبل أن تغادر.' },
      { en: 'The sun rises in the east every morning.', ar: 'تشرق الشمس من الشرق كل صباح.' },
      { en: 'She is the most experienced doctor in the hospital.', ar: 'هي أكثر طبيبة خبرةً في المستشفى.' },
    ],
    commonMistakes: [
      {
        wrong: 'I love the music and the coffee.',
        right: 'I love music and coffee.',
        noteAr: 'لا نستخدم «the» قبل الأسماء غير المعدودة أو الجمع عند الحديث بشكل عام، عكس اللغة العربية.',
      },
      {
        wrong: 'He went to the Cairo last week.',
        right: 'He went to Cairo last week.',
        noteAr: 'لا نستخدم «the» قبل أسماء المدن أو معظم الدول (ما عدا الدول المركبة مثل the USA و the UK).',
      },
    ],
    usageNotes: [
      'أداة التعريف «the» تُستخدم للإشارة إلى شيء محدد ومعروف لدى المتحدث والسامع (مثل: the book on the table).',
      'تُستخدم دائماً قبل الأشياء الفريدة (the sun, the moon, the internet) وصيغ التفضيل (the best, the biggest).',
      'تُنطق «ذا» قبل الأصوات الساكنة (the car) وتُنطق «ذي» قبل الأصوات المتحركة (the apple).',
    ],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'تُستخدم «the» في جميع المستويات الرسمية وغير الرسمية وهي أكثر كلمة شيوعاً في الإنجليزية.',
    },
  },
  a: {
    pos: 'phrase',
    collocations: [
      {
        phrase: 'a lot of',
        ar: 'الكثير من',
        exampleEn: 'We have a lot of work to finish today.',
        exampleAr: 'لدينا الكثير من العمل لننهيه اليوم.',
      },
      {
        phrase: 'a few / a little',
        ar: 'بضع / القليل من',
        exampleEn: 'I only need a few minutes to get ready.',
        exampleAr: 'أحتاج فقط إلى بضع دقائق لأستعد.',
      },
      {
        phrase: 'once a day',
        ar: 'مرة في اليوم',
        exampleEn: 'Take this medicine once a day after breakfast.',
        exampleAr: 'تناول هذا الدواء مرة في اليوم بعد الإفطار.',
      },
    ],
    examples: [
      { en: 'I bought a new notebook for my English notes.', ar: 'اشتريت دفتراً جديداً لملاحظاتي الإنجليزية.' },
      { en: 'She is a doctor at a local clinic.', ar: 'هي طبيبة في عيادة محلية.' },
    ],
    commonMistakes: [
      {
        wrong: 'He is teacher.',
        right: 'He is a teacher.',
        noteAr: 'في الإنجليزية يجب وضع أداة النكرة «a / an» قبل المهنة والاسم المفرد المعدود.',
      },
      {
        wrong: 'I need a advice.',
        right: 'I need some advice.',
        noteAr: 'لا تُستخدم «a» قبل الأسماء غير المعدودة مثل advice و information و water.',
      },
    ],
    usageNotes: [
      'تُستخدم «a» قبل الاسم المفرد المعدود النكرة الذي يبدأ بصوت ساكن (a book, a university).',
      'الاعتماد يكون على الصوت الأول وليس الحرف، لذا نقول a university (صوت y) و an hour (حرف h صامت).',
    ],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'أداة أساسية في المحادثة والكتابة بجميع مستوياتها.',
    },
  },
  an: {
    pos: 'phrase',
    collocations: [
      {
        phrase: 'an hour ago',
        ar: 'قبل ساعة',
        exampleEn: 'The train arrived an hour ago.',
        exampleAr: 'وصل القطار قبل ساعة.',
      },
      {
        phrase: 'an important question',
        ar: 'سؤال مهم',
        exampleEn: 'That is an important question to ask.',
        exampleAr: 'هذا سؤال مهم ينبغي طرحه.',
      },
    ],
    examples: [
      { en: 'She ate an apple before going to school.', ar: 'أكلت تفاحة قبل الذهاب إلى المدرسة.' },
      { en: 'It was an honest mistake.', ar: 'لقد كان خطأً غير مقصود.' },
    ],
    commonMistakes: [
      {
        wrong: 'Wait for a hour.',
        right: 'Wait for an hour.',
        noteAr: 'حرف h في hour صامت، فتبدأ الكلمة بصوت متحرك ولذلك نستخدم «an».',
      },
    ],
    usageNotes: [
      'تُستخدم «an» قبل الاسم المفرد المعدود النكرة الذي يبدأ بصوت متحرك (a, e, i, o, u) لتسهيل النطق.',
    ],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'أداة نحوية قياسية في جميع السياقات.',
    },
  },
  in: {
    pos: 'phrase',
    collocations: [
      { phrase: 'in the morning', ar: 'في الصباح', exampleEn: 'I study English in the morning.', exampleAr: 'أدرس الإنجليزية في الصباح.' },
      { phrase: 'in time', ar: 'في الوقت المناسب', exampleEn: 'We arrived at the airport just in time.', exampleAr: 'وصلنا إلى المطار في الوقت المناسب تماماً.' },
      { phrase: 'in general', ar: 'بشكل عام', exampleEn: 'In general, the weather here is mild.', exampleAr: 'بشكل عام، الطقس هنا معتدل.' },
    ],
    commonMistakes: [
      { wrong: 'My birthday is in Monday.', right: 'My birthday is on Monday.', noteAr: 'نستخدم «in» مع الشهور والسنوات والفصول، أما الأيام والتواريخ فنستخدم معها «on».' },
    ],
    usageNotes: [
      'تُستخدم «in» للأماكن المغلقة والمدن والدول (in the room, in London) ومع الشهور والسنوات (in May, in 2026).',
    ],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'حرف جر أساسي يُستخدم في جميع المستويات.',
    },
  },
  on: {
    pos: 'phrase',
    collocations: [
      { phrase: 'on time', ar: 'في الموعد بالضبط', exampleEn: 'The flight departed on time.', exampleAr: 'أقلعت الرحلة في الموعد بالضبط.' },
      { phrase: 'on Monday', ar: 'يوم الإثنين', exampleEn: 'We have a team meeting on Monday.', exampleAr: 'لدينا اجتماع فريق يوم الإثنين.' },
      { phrase: 'depend on', ar: 'يعتمد على', exampleEn: 'Success depends on daily consistency.', exampleAr: 'النجاح يعتمد على الاستمرارية اليومية.' },
    ],
    commonMistakes: [
      { wrong: 'I will see you in Friday.', right: 'I will see you on Friday.', noteAr: 'أيام الأسبوع والتواريخ المحددة تأخذ دائماً حرف الجر «on».' },
    ],
    usageNotes: ['تُستخدم «on» للأسطح (on the table)، ولأيام الأسبوع والتواريخ (on Sunday, on July 4th)، ووسائل الإعلام (on TV, on the phone).'],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'حرف جر محايد وواسع الاستخدام.',
    },
  },
  at: {
    pos: 'phrase',
    collocations: [
      { phrase: 'at home / at work', ar: 'في المنزل / في العمل', exampleEn: 'She is still at work right now.', exampleAr: 'ما زالت في العمل الآن.' },
      { phrase: 'at night', ar: 'في الليل', exampleEn: 'The city looks beautiful at night.', exampleAr: 'تبدو المدينة جميلة في الليل.' },
      { phrase: 'good at', ar: 'جيد في', exampleEn: 'He is very good at explaining grammar.', exampleAr: 'هو جيد جداً في شرح القواعد.' },
    ],
    commonMistakes: [
      { wrong: 'The class starts in 8 o’clock.', right: 'The class starts at 8 o’clock.', noteAr: 'الساعات المحددة تأخذ دائماً حرف الجر «at» وليس «in».' },
    ],
    usageNotes: ['تُستخدم «at» مع الساعات الدقيقة (at 7:30) والنقاط المكانية المحددة (at the door, at the station).'],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'حرف جر أساسي في الكلام والكتابة.',
    },
  },
  to: {
    pos: 'phrase',
    collocations: [
      { phrase: 'go to work / school', ar: 'يذهب إلى العمل / المدرسة', exampleEn: 'I walk to work every morning.', exampleAr: 'أمشي إلى العمل كل صباح.' },
      { phrase: 'listen to', ar: 'يستمع إلى', exampleEn: 'Listen to the native speaker carefully.', exampleAr: 'استمع إلى المتحدث الأصلي بانتباه.' },
      { phrase: 'want to + verb', ar: 'يريد أن + فعل', exampleEn: 'I want to speak English fluently.', exampleAr: 'أريد أن أتحدث الإنجليزية بطلاقة.' },
    ],
    commonMistakes: [
      { wrong: 'I went to home early.', right: 'I went home early.', noteAr: 'لا نضع «to» قبل كلمة home مع أفعال الحركة مثل go home و come home.' },
    ],
    usageNotes: ['تأتي «to» كحرف جر للاتجاه (go to Cairo) أو قبل المصدر لبيان الغرض (to learn).'],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'كلمة محورية في جميع السياقات الإنجليزية.',
    },
  },
  of: {
    pos: 'phrase',
    collocations: [
      { phrase: 'a cup of coffee', ar: 'فنجان من القهوة', exampleEn: 'Would you like a cup of coffee?', exampleAr: 'هل ترغب في فنجان من القهوة؟' },
      { phrase: 'a lot of', ar: 'الكثير من', exampleEn: 'She learned a lot of new words.', exampleAr: 'تعلمت الكثير من الكلمات الجديدة.' },
      { phrase: 'proud of', ar: 'فخور بـ', exampleEn: 'We are proud of your progress.', exampleAr: 'نحن فخورون بتقدمك.' },
    ],
    commonMistakes: [
      { wrong: 'A friend of me.', right: 'A friend of mine.', noteAr: 'بعد «of» نستخدم ضمير الملكية (mine / yours / hers) وليس ضمير المفعول.' },
    ],
    usageNotes: ['تُستخدم «of» لبيان الملكية والانتماء والكميات (the color of the sky, a piece of cake).'],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'حرف جر أساسي ومحايد.',
    },
  },
  and: {
    pos: 'phrase',
    collocations: [
      { phrase: 'back and forth', ar: 'ذهاباً وإياباً', exampleEn: 'They walked back and forth while talking.', exampleAr: 'مشيا ذهاباً وإياباً أثناء الحديث.' },
      { phrase: 'sooner or later / now and then', ar: 'بين الحين والآخر', exampleEn: 'We meet for lunch now and then.', exampleAr: 'نلتقي للغداء بين الحين والآخر.' },
    ],
    commonMistakes: [
      { wrong: 'I bought apples, and bananas, and oranges.', right: 'I bought apples, bananas, and oranges.', noteAr: 'في القوائم الإنجليزية نضع «and» مرة واحدة فقط قبل العنصر الأخير، عكس «و» المتكررة في العربية.' },
    ],
    usageNotes: ['تُستخدم أداة الربط «and» للربط بين كلمتين أو جملتين متكافئتين في المعنى.'],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'أداة ربط محايدة وأساسية.',
    },
  },
  for: {
    pos: 'phrase',
    collocations: [
      { phrase: 'for example', ar: 'على سبيل المثال', exampleEn: 'You can practice daily, for example by reading.', exampleAr: 'يمكنك التدرب يومياً، على سبيل المثال بالقراءة.' },
      { phrase: 'wait for', ar: 'ينتظر', exampleEn: 'Please wait for me at the entrance.', exampleAr: 'من فضلك انتظرني عند المدخل.' },
      { phrase: 'for two hours', ar: 'لمدة ساعتين', exampleEn: 'We studied English for two hours.', exampleAr: 'درسنا الإنجليزية لمدة ساعتين.' },
    ],
    commonMistakes: [
      { wrong: 'I have lived here since five years.', right: 'I have lived here for five years.', noteAr: 'نستخدم «for» مع المدة الزمنية (five years) و«since» مع نقطة البداية (2021).' },
    ],
    usageNotes: ['تُستخدم «for» لبيان السبب أو الغرض (This gift is for you) أو المدة الزمنية (for a week).'],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'حرف جر قياسي في كل السياقات.',
    },
  },
  with: {
    pos: 'phrase',
    collocations: [
      { phrase: 'agree with', ar: 'يتفق مع', exampleEn: 'I completely agree with your idea.', exampleAr: 'أتفق تماماً مع فكرتك.' },
      { phrase: 'deal with', ar: 'يتعامل مع', exampleEn: 'She knows how to deal with difficult tasks.', exampleAr: 'تعرف كيف تتعامل مع المهام الصعبة.' },
    ],
    commonMistakes: [
      { wrong: 'She is married with a doctor.', right: 'She is married to a doctor.', noteAr: 'الصفة married تأخذ حرف الجر «to» وليس «with».' },
    ],
    usageNotes: ['تدل «with» على المصاحبة (come with me) أو الأداة المستخدمة (write with a pen).'],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'حرف جر أساسي ومحايد.',
    },
  },
  be: {
    pos: 'verb',
    collocations: [
      { phrase: 'be careful', ar: 'كن حذراً', exampleEn: 'Be careful when crossing the street.', exampleAr: 'كن حذراً عند عبور الشارع.' },
      { phrase: 'be ready', ar: 'يكون مستعداً', exampleEn: 'Will you be ready in ten minutes?', exampleAr: 'هل ستكون مستعداً خلال عشر دقائق؟' },
      { phrase: 'be able to', ar: 'يستطيع / يكون قادراً على', exampleEn: 'Soon you will be able to speak comfortably.', exampleAr: 'قريباً ستكون قادراً على التحدث بأريحية.' },
    ],
    commonMistakes: [
      { wrong: 'I happy today.', right: 'I am happy today.', noteAr: 'الجملة الاسمية في الإنجليزية لا بد أن تحتوي على فعل الكينونة (am / is / are)، عكس العربية.' },
    ],
    usageNotes: ['فعل الكينونة «be» يتصرف إلى (am / is / are) في المضارع و(was / were) في الماضي، ويأتي المصدر «be» بعد الأفعال الناقصة (will be, can be).'],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
      noteAr: 'أهم فعل في اللغة الإنجليزية في جميع المستويات.',
    },
  },
  make: {
    pos: 'verb',
    collocations: [
      {
        phrase: 'make a decision',
        ar: 'يتخذ قراراً',
        exampleEn: 'We need to make a decision before Friday.',
        exampleAr: 'نحتاج إلى اتخاذ قرار قبل يوم الجمعة.',
      },
      {
        phrase: 'make a mistake',
        ar: 'يرتكب خطأً',
        exampleEn: 'Everyone can make a mistake while learning.',
        exampleAr: 'يمكن لأي شخص أن يرتكب خطأً أثناء التعلم.',
      },
      {
        phrase: 'make progress',
        ar: 'يحقق تقدماً',
        exampleEn: 'She is making steady progress in English.',
        exampleAr: 'إنها تحقق تقدماً ثابتاً في اللغة الإنجليزية.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'I did a mistake in the exam.',
        right: 'I made a mistake in the exam.',
        noteAr: 'نستخدم الفعل make وليس do مع mistake و decision و progress.',
      },
    ],
    phrasalVerbs: [
      {
        phrase: 'make up',
        ar: 'يخترع قصة / يتصالح',
        exampleEn: 'They argued yesterday, but they made up today.',
      },
      {
        phrase: 'make out',
        ar: 'يميّز بصعوبة / يفهم',
        exampleEn: 'I could barely make out the sign in the fog.',
      },
    ],
    idioms: [
      {
        phrase: 'make ends meet',
        ar: 'يغطي نفقات المعيشة بصعوبة',
        exampleEn: 'He worked two jobs just to make ends meet.',
      },
    ],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد (يُستخدم في كل السياقات)',
      noteAr: 'فعل أساسي شائع جداً في الحديث والكتابة؛ وفي الكتابة الأكاديمية يمكن استبداله بأفعال أدق حسب السياق.',
      formalAlt: 'produce / create / reach (a decision)',
      informalAlt: 'make',
    },
  },
  do: {
    pos: 'verb',
    collocations: [
      {
        phrase: 'do homework',
        ar: 'يؤدي الواجب المنزلي',
        exampleEn: 'Please do your homework before watching TV.',
        exampleAr: 'من فضلك أنجز واجبك المنزلي قبل مشاهدة التلفاز.',
      },
      {
        phrase: 'do your best',
        ar: 'يبذل قصارى جهده',
        exampleEn: 'Just do your best and stay calm.',
        exampleAr: 'ابذل قصارى جهدك فقط وابقَ هادئاً.',
      },
      {
        phrase: 'do business',
        ar: 'يمارس عملاً تجارياً',
        exampleEn: 'Our company does business with clients worldwide.',
        exampleAr: 'تتعامل شركتنا تجارياً مع عملاء حول العالم.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'She makes her homework every night.',
        right: 'She does her homework every night.',
        noteAr: 'نستخدم الفعل do مع المهام والواجبات والأعمال الروتينية مثل homework و housework.',
      },
    ],
    phrasalVerbs: [
      {
        phrase: 'do without',
        ar: 'يستغني عن',
        exampleEn: 'I cannot do without my morning coffee.',
      },
    ],
  },
  take: {
    pos: 'verb',
    collocations: [
      {
        phrase: 'take a break',
        ar: 'يأخذ استراحة',
        exampleEn: 'Let us take a short break and stretch.',
        exampleAr: 'لنأخذ استراحة قصيرة ونتمدد.',
      },
      {
        phrase: 'take care of',
        ar: 'يعتني بـ',
        exampleEn: 'Please take care of yourself while traveling.',
        exampleAr: 'اعتنِ بنفسك جيداً أثناء السفر.',
      },
      {
        phrase: 'take time',
        ar: 'يستغرق وقتاً',
        exampleEn: 'Mastering a new language takes time and patience.',
        exampleAr: 'إتقان لغة جديدة يستغرق وقتاً وصبراً.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'It spends two hours to get there.',
        right: 'It takes two hours to get there.',
        noteAr: 'للتعبير عن المدة التي يستغرقها عمل أو طريق نستخدم It takes وليس It spends.',
      },
    ],
    phrasalVerbs: [
      {
        phrase: 'take off',
        ar: 'تقلع (الطائرة) / يخلع (ملابس)',
        exampleEn: 'The plane will take off in ten minutes.',
      },
      {
        phrase: 'take up',
        ar: 'يبدأ هواية جديدة / يشغل مساحة',
        exampleEn: 'She decided to take up photography this year.',
      },
    ],
  },
  get: {
    pos: 'verb',
    collocations: [
      {
        phrase: 'get ready',
        ar: 'يستعد / يجهز نفسه',
        exampleEn: 'We should get ready before the taxi arrives.',
        exampleAr: 'يجب أن نستعد قبل وصول سيارة الأجرة.',
      },
      {
        phrase: 'get in touch',
        ar: 'يتواصل مع',
        exampleEn: 'Feel free to get in touch if you have any questions.',
        exampleAr: 'لا تتردد في التواصل إذا كان لديك أي أسئلة.',
      },
      {
        phrase: 'get better',
        ar: 'يتحسن',
        exampleEn: 'Your pronunciation will get better with daily practice.',
        exampleAr: 'سيتحسن نطقك مع التدريب اليومي.',
      },
    ],
    phrasalVerbs: [
      {
        phrase: 'get along with',
        ar: 'ينسجم مع',
        exampleEn: 'He gets along well with all his coworkers.',
      },
      {
        phrase: 'get over',
        ar: 'يتعافى من / يتجاوز',
        exampleEn: 'It took her a week to get over the flu.',
      },
    ],
    formalVsInformal: {
      registerLabel: 'Informal',
      registerLabelAr: 'يومي وشائع في المحادثة',
      noteAr: 'كلمة get مرنة وشائعة جداً في الحديث اليومي، بينما في الكتابة الرسمية يُفضّل استخدام receive أو obtain أو become.',
      formalAlt: 'receive / obtain / become',
      informalAlt: 'get',
    },
  },
  time: {
    pos: 'noun',
    collocations: [
      {
        phrase: 'on time',
        ar: 'في الوقت المحدد تماماً',
        exampleEn: 'The train arrived right on time.',
        exampleAr: 'وصل القطار في الوقت المحدد تماماً.',
      },
      {
        phrase: 'in time',
        ar: 'في الوقت المناسب (قبل فوات الأوان)',
        exampleEn: 'We reached the gate just in time for boarding.',
        exampleAr: 'وصلنا إلى البوابة في الوقت المناسب تماماً للصعود.',
      },
      {
        phrase: 'spend time',
        ar: 'يقضي وقتاً',
        exampleEn: 'I love to spend time reading in the evening.',
        exampleAr: 'أحب قضاء الوقت في القراءة مساءً.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'I do not have many time today.',
        right: 'I do not have much time today.',
        noteAr: 'كلمة time بمعنى «الوقت» اسم غير معدود، لذا نستخدم معها much وليس many.',
      },
    ],
    idioms: [
      {
        phrase: 'time flies',
        ar: 'يمر الوقت بسرعة',
        exampleEn: 'Time flies when you are enjoying a good conversation.',
      },
    ],
  },
  water: {
    pos: 'noun',
    collocations: [
      {
        phrase: 'drinking water',
        ar: 'مياه صالحة للشرب',
        exampleEn: 'Clean drinking water is essential for health.',
        exampleAr: 'مياه الشرب النظيفة ضرورية للصحة.',
      },
      {
        phrase: 'a glass of water',
        ar: 'كوب من الماء',
        exampleEn: 'Could I have a glass of cold water, please?',
        exampleAr: 'هل يمكنني الحصول على كوب من الماء البارد من فضلك؟',
      },
      {
        phrase: 'running water',
        ar: 'مياه جارية',
        exampleEn: 'Every house in the village now has running water.',
        exampleAr: 'كل منزل في القرية أصبح فيه مياه جارية الآن.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'Please give me a water.',
        right: 'Please give me a glass of water / some water.',
        noteAr: 'كلمة water اسم غير معدود في الإنجليزية القياسية؛ نستخدم a glass of / a bottle of أو some قبلها.',
      },
    ],
    idioms: [
      {
        phrase: 'in hot water',
        ar: 'في ورطة أو مشكلة كبيرة',
        exampleEn: 'He got into hot water after missing the deadline.',
      },
    ],
  },
  work: {
    pos: 'verb',
    collocations: [
      {
        phrase: 'work hard',
        ar: 'يعمل بجد',
        exampleEn: 'They work hard to achieve their goals.',
        exampleAr: 'إنهم يعملون بجد لتحقيق أهدافهم.',
      },
      {
        phrase: 'at work',
        ar: 'في العمل',
        exampleEn: 'She is still at work and will return at six.',
        exampleAr: 'ما زالت في العمل وستعود في الساعة السادسة.',
      },
      {
        phrase: 'hard work',
        ar: 'عمل شاق ومجتهد',
        exampleEn: 'Success is usually the result of hard work.',
        exampleAr: 'النجاح عادة ما يكون نتيجة العمل الجاد.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'I have a good work in the city.',
        right: 'I have a good job in the city.',
        noteAr: 'كلمة work كاسم غير معدود لا تأتي مع أداة النكرة (a)؛ للتعبير عن وظيفة نستخدم a job.',
      },
    ],
    phrasalVerbs: [
      {
        phrase: 'work out',
        ar: 'يتمرن رياضياً / تنجح الخطة',
        exampleEn: 'He works out at the gym three times a week.',
      },
    ],
  },
  good: {
    pos: 'adjective',
    collocations: [
      {
        phrase: 'good at',
        ar: 'جيد في (مهارة)',
        exampleEn: 'She is really good at solving complex problems.',
        exampleAr: 'هي بارعة حقاً في حل المشكلات المعقدة.',
      },
      {
        phrase: 'a good idea',
        ar: 'فكرة جيدة',
        exampleEn: 'Taking notes during the lecture is a good idea.',
        exampleAr: 'تدوين الملاحظات أثناء المحاضرة فكرة جيدة.',
      },
      {
        phrase: 'good luck',
        ar: 'حظاً سعيداً',
        exampleEn: 'Good luck with your interview tomorrow!',
        exampleAr: 'حظاً سعيداً في مقابلتك غداً!',
      },
    ],
    commonMistakes: [
      {
        wrong: 'He speaks English very good.',
        right: 'He speaks English very well.',
        noteAr: 'كلمة good صفة تصف الأسماء، أما لوصف طريقة أداء الفعل فنستخدم الظرف well.',
      },
    ],
  },
  important: {
    pos: 'adjective',
    collocations: [
      {
        phrase: 'very important',
        ar: 'مهم جداً',
        exampleEn: 'Sleep is very important for memory and focus.',
        exampleAr: 'النوم مهم جداً للذاكرة والتركيز.',
      },
      {
        phrase: 'play an important role',
        ar: 'يلعب دوراً مهماً',
        exampleEn: 'Daily reading plays an important role in vocabulary growth.',
        exampleAr: 'تلعب القراءة اليومية دوراً مهماً في تنمية المفردات.',
      },
      {
        phrase: 'important decision',
        ar: 'قرار مهم',
        exampleEn: 'Choosing a career path is an important decision.',
        exampleAr: 'اختيار المسار المهني قرار مهم.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'It is very important that you coming early.',
        right: 'It is very important to come early.',
        noteAr: 'بعد العبارة It is important نستخدم صيغة المصدر (to + verb) أو (that + subject + verb).',
      },
    ],
    formalVsInformal: {
      registerLabel: 'Neutral',
      registerLabelAr: 'محايد ومناسب للرسمي واليومي',
      noteAr: 'صفة مناسبة لكل المستويات؛ وفي الكتابة الأكاديمية العالية يمكن تنويعها بـ significant أو crucial.',
      formalAlt: 'significant / crucial / vital',
      informalAlt: 'big / key',
    },
  },
  learn: {
    pos: 'verb',
    collocations: [
      {
        phrase: 'learn from mistakes',
        ar: 'يتعلم من الأخطاء',
        exampleEn: 'Smart students always learn from their mistakes.',
        exampleAr: 'الطلاب الأذكياء يتعلمون دائماً من أخطائهم.',
      },
      {
        phrase: 'learn by heart',
        ar: 'يحفظ عن ظهر قلب',
        exampleEn: 'You do not need to learn every rule by heart.',
        exampleAr: 'لست بحاجة إلى حفظ كل قاعدة عن ظهر قلب.',
      },
      {
        phrase: 'learn how to',
        ar: 'يتعلم كيفية ...',
        exampleEn: 'I want to learn how to speak fluently.',
        exampleAr: 'أريد أن أتعلم كيفية التحدث بطلاقة.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'My teacher learned me English.',
        right: 'My teacher taught me English.',
        noteAr: 'الفعل learn يعني «يتعلّم» بنفسه، أما «يُعلّم شخصاً آخر» فهو teach (ماضيه taught).',
      },
    ],
  },
  help: {
    pos: 'verb',
    collocations: [
      {
        phrase: 'help someone out',
        ar: 'يساعد شخصاً في موقف',
        exampleEn: 'Thanks for helping me out with the project.',
        exampleAr: 'شكراً لمساعدتي في المشروع.',
      },
      {
        phrase: 'ask for help',
        ar: 'يطلب المساعدة',
        exampleEn: 'Never hesitate to ask for help when you feel stuck.',
        exampleAr: 'لا تتردد أبداً في طلب المساعدة عندما تواجه صعوبة.',
      },
      {
        phrase: 'cannot help + -ing',
        ar: 'لا يستطيع منع نفسه من ...',
        exampleEn: 'I could not help smiling when I heard the news.',
        exampleAr: 'لم أستطع منع نفسي من الابتسام عندما سمعت الخبر.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'She helped me for carrying the bag.',
        right: 'She helped me carry the bag.',
        noteAr: 'بعد الفعل help نستخدم المصدر مباشرة (carry) أو (to carry) وليس for + ing.',
      },
    ],
  },
  think: {
    pos: 'verb',
    collocations: [
      {
        phrase: 'think about',
        ar: 'يفكر في',
        exampleEn: 'I need a moment to think about your offer.',
        exampleAr: 'أحتاج لحظة للتفكير في عرضك.',
      },
      {
        phrase: 'think twice',
        ar: 'يفكر مرتين قبل الإقدام',
        exampleEn: 'You should think twice before quitting your job.',
        exampleAr: 'يجب أن تفكر مرتين قبل ترك عملك.',
      },
      {
        phrase: 'think of',
        ar: 'يخطر بباله / يبدي رأياً في',
        exampleEn: 'What do you think of this new design?',
        exampleAr: 'ما رأيك في هذا التصميم الجديد؟',
      },
    ],
    commonMistakes: [
      {
        wrong: 'I am thinking that English is useful.',
        right: 'I think that English is useful.',
        noteAr: 'عندما يعني الفعل think «أعتقد/برأيي» يُستخدم في المضارع البسيط (I think) وليس المستمر.',
      },
    ],
  },
  experience: {
    pos: 'noun',
    collocations: [
      {
        phrase: 'gain experience',
        ar: 'يكتسب خبرة',
        exampleEn: 'Internships help graduates gain practical experience.',
        exampleAr: 'تساعد التدريبات الخريجين على اكتساب خبرة عملية.',
      },
      {
        phrase: 'work experience',
        ar: 'خبرة عملية',
        exampleEn: 'The position requires two years of work experience.',
        exampleAr: 'تتطلب الوظيفة سنتين من الخبرة العملية.',
      },
      {
        phrase: 'unforgettable experience',
        ar: 'تجربة لا تُنسى',
        exampleEn: 'Visiting the desert under the stars was an unforgettable experience.',
        exampleAr: 'كانت زيارة الصحراء تحت النجوم تجربة لا تُنسى.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'He has many experiences in marketing.',
        right: 'He has a lot of experience in marketing.',
        noteAr: 'بمعنى «الخبرة المهنية» تُعد experience غير معدودة، وتُجمع (experiences) فقط عند الحديث عن «تجارب/مواقف حياتية».',
      },
    ],
  },
  advice: {
    pos: 'noun',
    collocations: [
      {
        phrase: 'give advice',
        ar: 'يقدم نصيحة',
        exampleEn: 'My mentor always gives practical advice.',
        exampleAr: 'يقدم مرشدي دائماً نصائح عملية.',
      },
      {
        phrase: 'a piece of advice',
        ar: 'نصيحة واحدة',
        exampleEn: 'Let me give you a useful piece of advice.',
        exampleAr: 'دعني أقدم لك نصيحة مفيدة.',
      },
      {
        phrase: 'follow advice',
        ar: 'يتبع النصيحة',
        exampleEn: 'If you follow the doctor’s advice, you will recover quickly.',
        exampleAr: 'إذا اتبعت نصيحة الطبيب، ستتعافى بسرعة.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'She gave me many good advices.',
        right: 'She gave me a lot of good advice.',
        noteAr: 'كلمة advice غير معدودة ولا تُجمع بـ s أبداً؛ للعد نستخدم a piece of advice.',
      },
    ],
  },
  information: {
    pos: 'noun',
    collocations: [
      {
        phrase: 'detailed information',
        ar: 'معلومات مفصّلة',
        exampleEn: 'You can find detailed information on our website.',
        exampleAr: 'يمكنك العثور على معلومات مفصّلة على موقعنا.',
      },
      {
        phrase: 'for more information',
        ar: 'لمزيد من المعلومات',
        exampleEn: 'Please contact support for more information.',
        exampleAr: 'يرجى التواصل مع الدعم لمزيد من المعلومات.',
      },
      {
        phrase: 'accurate information',
        ar: 'معلومات دقيقة',
        exampleEn: 'Always verify that you have accurate information.',
        exampleAr: 'تحقق دائماً من أن لديك معلومات دقيقة.',
      },
    ],
    commonMistakes: [
      {
        wrong: 'I need some informations about the flight.',
        right: 'I need some information about the flight.',
        noteAr: 'كلمة information غير معدودة في الإنجليزية ولا تأخذ حرف الجمع s أبداً.',
      },
    ],
  },
};

function cleanTargetWord(raw: string): string {
  return (raw || '')
    .trim()
    .replace(/\s+/g, ' ');
}

function normalizePosCategory(
  word: string,
  posEn?: string
): 'verb' | 'noun' | 'adjective' | 'adverb' | 'phrase' {
  const lowerPos = (posEn || '').toLowerCase();
  const clean = cleanTargetWord(word).toLowerCase();
  if (clean.includes(' ') && !clean.startsWith('to ')) return 'phrase';
  if (lowerPos.includes('verb') && !lowerPos.includes('adverb')) return 'verb';
  if (lowerPos.includes('adverb')) return 'adverb';
  if (lowerPos.includes('adjective') || lowerPos.includes('adj')) return 'adjective';
  if (lowerPos.includes('noun')) return 'noun';
  if (clean.startsWith('to ')) return 'verb';
  if (clean.endsWith('ly') && clean.length >= 5) return 'adverb';
  if (
    /(ful|less|ous|ive|able|ible|al|ic|ish|ary|ory|ant|ent)$/.test(clean) &&
    clean.length >= 5
  ) {
    return 'adjective';
  }
  if (/(ize|ise|ify|ate)$/.test(clean) && clean.length >= 5) {
    return 'verb';
  }
  if (/(tion|sion|ment|ness|ity|ship|hood|ance|ence|ism|ist)$/.test(clean) && clean.length >= 5) {
    return 'noun';
  }
  return 'noun';
}

function needsAnArticle(word: string): boolean {
  const clean = word.trim().toLowerCase();
  if (!clean) return false;
  if (/^(honest|hour|heir|honor|honour)/.test(clean)) return true;
  if (/^(uni|use|user|europe|one)/.test(clean)) return false;
  return /^[aeiou]/.test(clean);
}

function formatBaseWordForSentence(word: string, pos: 'verb' | 'noun' | 'adjective' | 'adverb' | 'phrase'): string {
  const clean = cleanTargetWord(word);
  if (pos === 'verb' && /^to\s+/i.test(clean)) {
    return clean.replace(/^to\s+/i, '').trim();
  }
  return clean;
}

function findMatchingCorpusExamples(
  word: string,
  extraCorpus: OfflineUsageCorpusItem[] = [],
  limit = 4
): WordHubExample[] {
  const rx = buildWordMatchRegex(word);
  const seen = new Set<string>();
  const out: WordHubExample[] = [];

  const scan = (items: OfflineUsageCorpusItem[]) => {
    for (const item of items) {
      if (out.length >= limit) break;
      const en = (item.en || '').trim();
      if (!en || en.length < 14 || en.length > 135) continue;
      if (!rx.test(en)) continue;
      const key = en.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({
        en,
        ar: (item.ar || '').trim(),
        register: 'neutral',
      });
    }
  };

  // Prefer starter sentences with curated Arabic translations first, then the full 21k corpus
  scan(getStarterSentenceCorpus());
  if (out.length < limit && extraCorpus.length > 0) {
    scan(extraCorpus);
  }

  return out;
}

function buildContextualExamplesForPos(
  word: string,
  ar: string,
  pos: 'verb' | 'noun' | 'adjective' | 'adverb' | 'phrase',
  band: CefrBand
): WordHubExample[] {
  const base = formatBaseWordForSentence(word, pos);
  const meaning = (ar || '').trim();
  const meaningHint = meaning ? ` (${meaning})` : '';
  const article = needsAnArticle(base) ? 'an' : 'a';
  const isAdvanced = band === 'C1' || band === 'C2' || band === 'B2';

  if (pos === 'verb') {
    return [
      {
        en: `We try to ${base} carefully whenever we practice English every day.`,
        ar: `نحاول أن نستخدم الفعل "${base}"${meaningHint} بعناية أثناء ممارسة الإنجليزية يومياً.`,
        register: 'neutral',
      },
      {
        en: `Could you ${base} this clearly before the meeting starts?`,
        ar: `هل يمكنك تطبيق "${base}"${meaningHint} بوضوح قبل بدء الاجتماع؟`,
        register: isAdvanced ? 'formal' : 'neutral',
      },
      {
        en: `It really helps to ${base} step by step instead of rushing.`,
        ar: `من المفيد حقاً أن "${base}"${meaningHint} خطوة بخطوة بدلاً من التسرع.`,
        register: 'informal',
      },
    ];
  }

  if (pos === 'adjective') {
    return [
      {
        en: `That approach looks very ${base} for everyday situations.`,
        ar: `تبدو هذه الطريقة "${base}"${meaningHint} جداً للمواقف اليومية.`,
        register: 'neutral',
      },
      {
        en: `The team gave ${article} ${base} explanation during the presentation.`,
        ar: `قدّم الفريق شرحاً "${base}"${meaningHint} أثناء العرض التقديمي.`,
        register: isAdvanced ? 'formal' : 'neutral',
      },
      {
        en: `Honestly, it feels more ${base} once you see a real example.`,
        ar: `بصراحة، يبدو الأمر أكثر "${base}"${meaningHint} بمجرد رؤية مثال حقيقي.`,
        register: 'informal',
      },
    ];
  }

  if (pos === 'adverb') {
    return [
      {
        en: `She explained the whole idea ${base} so everyone understood.`,
        ar: `شرحت الفكرة بالكامل بصورة "${base}"${meaningHint} حتى يفهم الجميع.`,
        register: 'neutral',
      },
      {
        en: `Please review the instructions ${base} before submitting your work.`,
        ar: `يرجى مراجعة التعليمات بصورة "${base}"${meaningHint} قبل تسليم عملك.`,
        register: 'formal',
      },
      {
        en: `He handled the sudden change ${base} without losing focus.`,
        ar: `تعامل مع التغيير المفاجئ بصورة "${base}"${meaningHint} دون أن يفقد تركيزه.`,
        register: 'neutral',
      },
    ];
  }

  if (pos === 'phrase') {
    return [
      {
        en: `Native speakers often say "${base}" in natural conversation.`,
        ar: `يستخدم المتحدثون الأصليون عبارة "${base}"${meaningHint} كثيراً في المحادثة الطبيعية.`,
        register: 'neutral',
      },
      {
        en: `Try using "${base}" in a short sentence about your day.`,
        ar: `جرّب استخدام عبارة "${base}"${meaningHint} في جملة قصيرة عن يومك.`,
        register: 'informal',
      },
      {
        en: `In context, "${base}" makes your English sound much more natural.`,
        ar: `في السياق، تجعل عبارة "${base}"${meaningHint} لغتك الإنجليزية تبدو أكثر طبيعية.`,
        register: 'neutral',
      },
    ];
  }

  // Default: noun
  return [
    {
      en: `Understanding the role of ${base} makes daily communication easier.`,
      ar: `فهم دور "${base}"${meaningHint} يجعل التواصل اليومي أسهل.`,
      register: 'neutral',
    },
    {
      en: `The article highlighted ${base} as a central point of the discussion.`,
      ar: `سلّط المقال الضوء على "${base}"${meaningHint} كنقطة محورية في النقاش.`,
      register: 'formal',
    },
    {
      en: `We talked about ${base} for a few minutes after class.`,
      ar: `تحدثنا عن "${base}"${meaningHint} لبضع دقائق بعد الدرس.`,
      register: 'informal',
    },
  ];
}

function buildStructuralCollocations(
  word: string,
  ar: string,
  pos: 'verb' | 'noun' | 'adjective' | 'adverb' | 'phrase'
): WordHubCollocation[] {
  const base = formatBaseWordForSentence(word, pos);
  const meaning = (ar || '').trim();
  const gloss = meaning ? ` (${meaning})` : '';

  if (pos === 'verb') {
    return [
      {
        phrase: `${base} clearly`,
        ar: `${meaning || base} بوضوح`,
        exampleEn: `Try to ${base} clearly when speaking with others.`,
        exampleAr: `حاول أن تستخدم "${base}"${gloss} بوضوح عند التحدث مع الآخرين.`,
      },
      {
        phrase: `${base} effectively`,
        ar: `${meaning || base} بفعالية`,
        exampleEn: `Regular practice helps you ${base} effectively.`,
        exampleAr: `التدريب المنتظم يساعدك على تطبيق "${base}" بفعالية.`,
      },
      {
        phrase: `learn to ${base}`,
        ar: `يتعلم كيف ${meaning || base}`,
        exampleEn: `Students quickly learn to ${base} in real situations.`,
        exampleAr: `يتعلم الطلاب بسرعة كيفية استخدام "${base}" في المواقف الحقيقية.`,
      },
    ];
  }

  if (pos === 'adjective') {
    return [
      {
        phrase: `very ${base}`,
        ar: `${meaning || base} جداً`,
        exampleEn: `This detail is very ${base} for understanding the topic.`,
        exampleAr: `هذا التفصيل ${meaning || base} جداً لفهم الموضوع.`,
      },
      {
        phrase: `become ${base}`,
        ar: `يصبح ${meaning || base}`,
        exampleEn: `Over time, the difference will become ${base}.`,
        exampleAr: `مع مرور الوقت، سيصبح الفرق ${meaning || base}.`,
      },
      {
        phrase: `seem ${base}`,
        ar: `يبدو ${meaning || base}`,
        exampleEn: `At first glance, the plan may seem ${base}.`,
        exampleAr: `للوهلة الأولى، قد تبدو الخطة ${meaning || base}.`,
      },
    ];
  }

  if (pos === 'adverb') {
    return [
      {
        phrase: `speak ${base}`,
        ar: `يتحدث بـ${meaning || base}`,
        exampleEn: `Try to speak ${base} during your presentation.`,
        exampleAr: `حاول أن تتحدث بصورة ${meaning || base} أثناء عرضك التقديمي.`,
      },
      {
        phrase: `act ${base}`,
        ar: `يتصرف بـ${meaning || base}`,
        exampleEn: `A good leader knows how to act ${base} under pressure.`,
        exampleAr: `يعرف القائد الجيد كيف يتصرف بصورة ${meaning || base} تحت الضغط.`,
      },
      {
        phrase: `work ${base}`,
        ar: `يعمل بـ${meaning || base}`,
        exampleEn: `The whole team worked ${base} to finish on schedule.`,
        exampleAr: `عمل الفريق بالكامل بصورة ${meaning || base} للانتهاء في الموعد.`,
      },
    ];
  }

  if (pos === 'phrase') {
    return [
      {
        phrase: `use "${base}" naturally`,
        ar: `استخدام "${meaning || base}" بعفوية`,
        exampleEn: `Listen to native speakers to use "${base}" naturally.`,
        exampleAr: `استمع للمتحدثين الأصليين لاستخدام العبارة بعفوية.`,
      },
      {
        phrase: `in context: ${base}`,
        ar: `في سياق الحديث: ${meaning || base}`,
        exampleEn: `Remember "${base}" as a single fixed expression.`,
        exampleAr: `احفظ العبارة كتركيب واحد متماسك وليس ككلمات منفصلة.`,
      },
    ];
  }

  // Noun collocations
  return [
    {
      phrase: `important ${base}`,
      ar: `${meaning || base} مهم`,
      exampleEn: `This is an important ${base} to keep in mind.`,
      exampleAr: `هذا ${meaning || base} مهم ينبغي تذكّره.`,
    },
    {
      phrase: `everyday ${base}`,
      ar: `${meaning || base} يومي`,
      exampleEn: `We often encounter this ${base} in everyday life.`,
      exampleAr: `غالباً ما نواجه هذا ${meaning || base} في الحياة اليومية.`,
    },
    {
      phrase: `clear ${base}`,
      ar: `${meaning || base} واضح`,
      exampleEn: `She gave a clear ${base} that everyone appreciated.`,
      exampleAr: `قدّمت ${meaning || base} واضحاً نال تقدير الجميع.`,
    },
  ];
}

function buildOfflineRegister(
  word: string,
  pos: 'verb' | 'noun' | 'adjective' | 'adverb' | 'phrase',
  band: CefrBand
): WordHubFormalRegister {
  const lower = word.toLowerCase();
  const hasFormalMorphology =
    /(tion|sion|ment|ence|ance|ity|ize|ise|ate|ous|ive|ary|ory)$/.test(lower) &&
    lower.length >= 8;

  if (band === 'C1' || band === 'C2' || (band === 'B2' && hasFormalMorphology)) {
    return {
      registerLabel: 'Formal',
      registerLabelAr: 'رسمي / أكاديمي ومهني',
      noteAr: `تنتمي كلمة «${word}» إلى المستوى المتقدم (${band})، وتظهر بكثرة في المقالات الاحترافية والتقارير والعروض الرسمية، كما ترفع دقة تعبيرك عند الكتابة.`,
    };
  }

  if (pos === 'phrase') {
    return {
      registerLabel: 'Informal',
      registerLabelAr: 'طبيعي في المحادثة اليومية',
      noteAr: `تُستخدم عبارة «${word}» بسلاسة في المحادثات اليومية الحقيقية؛ انتبه لعدم ترجمتها حرفياً كلمة بكلمة.`,
    };
  }

  return {
    registerLabel: 'Neutral',
    registerLabelAr: 'محايد (مناسب للحديث والكتابة)',
    noteAr: `كلمة «${word}» من المستوى (${band}) وتصلح للاستخدام اليومي والرسمي على حدٍّ سواء دون تكلّف.`,
  };
}

function buildOfflineUsageNotes(
  word: string,
  ar: string,
  pos: 'verb' | 'noun' | 'adjective' | 'adverb' | 'phrase',
  band: CefrBand
): string[] {
  const base = formatBaseWordForSentence(word, pos);
  const meaningSnippet = ar ? ` وتعني «${ar}»` : '';

  if (pos === 'verb') {
    return [
      `تُستخدم «${base}» كفعل${meaningSnippet}؛ احرص على تصريفه بحسب الزمن (المضارع والماضي) ومطابقته مع الفاعل المفرد الغائب (he/she/it + s).`,
      `عند ربط الفعل «${base}» بجملة جديدة، انتبه لحرف الجر أو المفعول الذي يليه، فالمعنى يتغير أحياناً بتغيّر حرف الجر.`,
      `مستوى الكلمة هو ${band} — أفضل طريقة لترسيخها هي نطقها في جملة قصيرة عن موقف مرّ بك اليوم.`,
    ];
  }

  if (pos === 'adjective') {
    return [
      `تُستخدم «${base}» كصفة${meaningSnippet} وتأتي عادةً قبل الاسم الموصوف مباشرةً أو بعد أفعال الربط مثل (be / seem / look / feel).`,
      `تذكّر أن الصفات في الإنجليزية لا تُجمع أبداً حتى لو كان الاسم بعدها جمعاً، وللمقارنة نستخدم (more ${base} / the most ${base}) أو (-er / -est) للصفات القصيرة.`,
      `مستوى الكلمة هو ${band} — جرّب ربطها باسم شائع تحتاجه يومياً لتتذكرها أسرع.`,
    ];
  }

  if (pos === 'adverb') {
    return [
      `تُستخدم «${base}» كظرف${meaningSnippet} لوصف كيفية أو درجة حدوث الفعل، وغالباً ما تأتي بعد الفعل مباشرة أو في نهاية الجملة.`,
      `لا تخلط بين الصفة والظرف: الصفة تصف الاسم، بينما الظرف «${base}» يصف الفعل أو صفة أخرى.`,
      `مستوى الكلمة هو ${band} — استخدام الظروف الدقيقة يمنح جملك الإنجليزية سلاسة ووضوحاً عالياً.`,
    ];
  }

  if (pos === 'phrase') {
    return [
      `احفظ «${base}» كوحدة تعبيرية كاملة${meaningSnippet} بدلاً من ترجمة كل كلمة على حدة.`,
      `لاحظ النغمة الصوتية وموضع التشديد عند نطق العبارة حتى تبدو طبيعية في المحادثة.`,
    ];
  }

  return [
    `تُستخدم «${base}» كاسم${meaningSnippet}؛ انتبه لاستخدام أداة التعريف أو التنكير (a / an / the) قبل الاسم المفرد المعدود.`,
    `للتحدث بطلاقة، اربط الاسم «${base}» دائماً بفعل أو صفة شائعة (تلازم لفظي) بدلاً من حفظه منفرداً.`,
    `مستوى الكلمة هو ${band} — كرّر الكلمة بصوت عالٍ داخل مثالين مختلفين لتثبيت معناها ونطقها.`,
  ];
}

function buildOfflineMistakes(
  word: string,
  pos: 'verb' | 'noun' | 'adjective' | 'adverb' | 'phrase'
): WordHubMistake[] {
  const base = formatBaseWordForSentence(word, pos);
  const article = needsAnArticle(base) ? 'an' : 'a';

  if (pos === 'verb') {
    return [
      {
        wrong: `He ${base} every day.`,
        right: `He ${base.endsWith('s') || base.endsWith('sh') || base.endsWith('ch') || base.endsWith('x') || base.endsWith('o') ? `${base}es` : base.endsWith('y') && !/[aeiou]y$/i.test(base) ? `${base.slice(0, -1)}ies` : `${base}s`} every day.`,
        noteAr: 'لا تنسَ إضافة s/es للفعل في المضارع البسيط مع الضمائر المفردة (he / she / it).',
      },
    ];
  }

  if (pos === 'adjective') {
    return [
      {
        wrong: `They are ${base}s examples.`,
        right: `They are ${base} examples.`,
        noteAr: 'الصفات في الإنجليزية لا تُجمع أبداً بإضافة حرف s حتى عندما تصف اسماً جمعاً.',
      },
    ];
  }

  if (pos === 'adverb') {
    return [
      {
        wrong: `She is a ${base} student.`,
        right: `She studies ${base}.`,
        noteAr: `كلمة «${base}» ظرف يصف الفعل (studies) ولا يأتي مباشرة قبل الاسم لوصفه.`,
      },
    ];
  }

  if (pos === 'phrase') {
    return [
      {
        wrong: `Changing the words inside "${base}" literally from Arabic`,
        right: `Keep "${base}" together as one natural chunk`,
        noteAr: 'الترجمة الحرفية من العربية قد تغيّر التركيب؛ التزم بصيغة العبارة كما ينطقها أهل اللغة.',
      },
    ];
  }

  return [
    {
      wrong: `This is ${base} important.`,
      right: `This is ${article === 'an' ? 'an' : 'a'} important ${base}.`,
      noteAr: 'في الإنجليزية تأتي الصفة دائماً قبل الاسم الموصوف وليس بعده كما في العربية.',
    },
  ];
}

/**
 * 100% OFFLINE deterministic Word Usage builder.
 * Guarantees rich examples, collocations, register analysis, usage notes, and common mistakes
 * for EVERY English word (A0–C2) in 0ms without requiring internet or AI quota.
 */
export function buildOfflineWordUsage(options: {
  word: string;
  ar?: string;
  posEn?: string;
  band?: CefrBand;
  extraCorpus?: OfflineUsageCorpusItem[];
}): OfflineUsageResult {
  const cleanWord = cleanTargetWord(options.word);
  const lower = cleanWord.toLowerCase();
  const band: CefrBand = options.band || 'B1';
  const curated = CURATED_WORD_USAGE[lower];
  const pos = curated?.pos || normalizePosCategory(cleanWord, options.posEn);

  // 1. Real corpus sentences matching this word + curated/contextual examples
  const corpusMatches = findMatchingCorpusExamples(cleanWord, options.extraCorpus, 4);
  const curatedExamples = curated?.examples || [];
  const contextualExamples = buildContextualExamplesForPos(cleanWord, options.ar || '', pos, band);

  const examples: WordHubExample[] = [];
  const seenEx = new Set<string>();
  for (const ex of [...curatedExamples, ...corpusMatches, ...contextualExamples]) {
    const key = ex.en.trim().toLowerCase();
    if (!key || seenEx.has(key)) continue;
    seenEx.add(key);
    examples.push(ex);
    if (examples.length >= 4) break;
  }

  // 2. Collocations
  const collocations: WordHubCollocation[] =
    curated?.collocations && curated.collocations.length > 0
      ? curated.collocations
      : buildStructuralCollocations(cleanWord, options.ar || '', pos);

  // 3. Common Mistakes
  const commonMistakes: WordHubMistake[] =
    curated?.commonMistakes && curated.commonMistakes.length > 0
      ? curated.commonMistakes
      : buildOfflineMistakes(cleanWord, pos);

  // 4. Register (Formal vs Informal)
  const formalVsInformal: WordHubFormalRegister =
    curated?.formalVsInformal || buildOfflineRegister(cleanWord, pos, band);

  // 5. Usage Notes
  const usageNotes: string[] =
    curated?.usageNotes && curated.usageNotes.length > 0
      ? curated.usageNotes
      : buildOfflineUsageNotes(cleanWord, options.ar || '', pos, band);

  return {
    examples,
    collocations,
    commonMistakes,
    usageNotes,
    formalVsInformal,
    idioms: curated?.idioms || [],
    phrasalVerbs: curated?.phrasalVerbs || [],
  };
}

/**
 * Enriches any WordHubData (online, dictionary-only, or offline fallback) so the Usage tab
 * is NEVER empty and ALWAYS works 100% offline. Preserves richer AI-fetched items whenever present.
 */
export function enrichWordHubWithOfflineUsage(
  hub: WordHubData,
  options: {
    word?: string;
    ar?: string;
    band?: CefrBand;
    extraCorpus?: OfflineUsageCorpusItem[];
  } = {}
): WordHubData {
  const targetWord = cleanTargetWord(options.word || hub.word);
  if (!targetWord) return hub;

  const offline = buildOfflineWordUsage({
    word: targetWord,
    ar: options.ar || hub.definitionAr || '',
    posEn: hub.posEn,
    band: options.band || 'B1',
    extraCorpus: options.extraCorpus,
  });

  // Merge examples: keep existing online examples first, top up from offline corpus/context up to 4
  const mergedExamples: WordHubExample[] = [];
  const seenEx = new Set<string>();
  for (const ex of [...(hub.examples || []), ...offline.examples]) {
    const k = (ex.en || '').trim().toLowerCase();
    if (!k || seenEx.has(k)) continue;
    seenEx.add(k);
    mergedExamples.push(ex);
    if (mergedExamples.length >= 5) break;
  }

  return {
    ...hub,
    examples: mergedExamples,
    collocations:
      hub.collocations && hub.collocations.length > 0 ? hub.collocations : offline.collocations,
    commonMistakes:
      hub.commonMistakes && hub.commonMistakes.length > 0
        ? hub.commonMistakes
        : offline.commonMistakes,
    usageNotes:
      hub.usageNotes && hub.usageNotes.length > 0 ? hub.usageNotes : offline.usageNotes,
    formalVsInformal: hub.formalVsInformal || offline.formalVsInformal,
    idioms: hub.idioms && hub.idioms.length > 0 ? hub.idioms : offline.idioms,
    phrasalVerbs:
      hub.phrasalVerbs && hub.phrasalVerbs.length > 0 ? hub.phrasalVerbs : offline.phrasalVerbs,
  };
}
