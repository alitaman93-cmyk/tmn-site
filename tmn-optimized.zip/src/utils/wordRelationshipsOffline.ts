import { POS_AR } from '../data/constants';
import type {
  CefrBand,
  VocabEntry,
  VocabStore,
  WordHubAntonym,
  WordHubData,
  WordHubDerivative,
  WordHubRelatedWord,
  WordHubSynonym,
} from '../types';

export interface OfflineWordRelationships {
  synonyms: WordHubSynonym[];
  antonyms: WordHubAntonym[];
  wordFamily: WordHubDerivative[];
  relatedWords: WordHubRelatedWord[];
}

interface CuratedRelProfile {
  synonyms?: WordHubSynonym[];
  antonyms?: WordHubAntonym[];
  wordFamily?: WordHubDerivative[];
  relatedWords?: WordHubRelatedWord[];
}

const CURATED_RELATIONSHIPS: Record<string, CuratedRelProfile> = {
  the: {
    synonyms: [
      { word: 'this', ar: 'هذا / هذه', nuanceAr: 'للإشارة إلى شيء محدد قريب بدلاً من التعريف العام', exampleEn: 'This book is very helpful.', exampleAr: 'هذا الكتاب مفيد جداً.' },
      { word: 'that', ar: 'ذلك / تلك', nuanceAr: 'للإشارة إلى شيء محدد بعيد', exampleEn: 'That house looks beautiful.', exampleAr: 'ذلك المنزل يبدو جميلاً.' },
    ],
    antonyms: [
      { word: 'a', ar: 'أداة نكرة', contrastAr: 'تُستخدم للشيء غير المحدد (نكرة) بينما the للمعرفة المحددة', exampleEn: 'I saw a dog in the park.', exampleAr: 'رأيت كلباً في الحديقة.' },
      { word: 'an', ar: 'أداة نكرة قبل حرف علة', contrastAr: 'أداة نكرة تسبق الأصوات المتحركة عكس التعريف بـ the', exampleEn: 'She ate an apple.', exampleAr: 'أكلت تفاحة.' },
    ],
    relatedWords: [
      { word: 'these', ar: 'هؤلاء / هذه (للجمع القريب)', relationAr: 'أداة إشارة وتحديد للجمع' },
      { word: 'those', ar: 'أولئك / تلك (للجمع البعيد)', relationAr: 'أداة إشارة وتحديد للجمع' },
      { word: 'some', ar: 'بعض', relationAr: 'محدِّد كمية للأسماء' },
      { word: 'every', ar: 'كل', relationAr: 'محدِّد شمول للأسماء المفردة' },
    ],
  },
  a: {
    synonyms: [
      { word: 'an', ar: 'أداة نكرة (قبل صوت متحرك)', nuanceAr: 'نفس وظيفة a لكن قبل الكلمات التي تبدأ بصوت علة', exampleEn: 'Take an umbrella today.', exampleAr: 'خذ مظلة اليوم.' },
      { word: 'one', ar: 'واحد', nuanceAr: 'تؤكد على العدد المفرد بدقة أكبر من a', exampleEn: 'I need one minute.', exampleAr: 'أحتاج دقيقة واحدة.' },
    ],
    antonyms: [
      { word: 'the', ar: 'الـ (أداة التعريف)', contrastAr: 'تُستخدم للاسم المعرّف المحدد بينما a للنكرة', exampleEn: 'Please close the door.', exampleAr: 'من فضلك أغلق الباب.' },
    ],
    relatedWords: [
      { word: 'any', ar: 'أيّ', relationAr: 'محدِّد نكرة في السؤال والنفي' },
      { word: 'some', ar: 'بعض', relationAr: 'محدِّد كمية للجمع وغير المعدود' },
      { word: 'each', ar: 'كل واحد', relationAr: 'محدِّد للمفرد' },
    ],
  },
  an: {
    synonyms: [
      { word: 'a', ar: 'أداة نكرة (قبل صوت ساكن)', nuanceAr: 'نفس المعنى قبل الأصوات الساكنة', exampleEn: 'He bought a new phone.', exampleAr: 'اشترى هاتفاً جديداً.' },
      { word: 'one', ar: 'واحد', nuanceAr: 'تدل على المفرد مع إبراز العدد', exampleEn: 'We waited one hour.', exampleAr: 'انتظرنا ساعة واحدة.' },
    ],
    antonyms: [
      { word: 'the', ar: 'الـ (أداة التعريف)', contrastAr: 'أداة معرفة للاسم المحدد بعكس النكرة an', exampleEn: 'The exam was easy.', exampleAr: 'الامتحان كان سهلاً.' },
    ],
    relatedWords: [
      { word: 'any', ar: 'أيّ', relationAr: 'محدِّد في النفي والاستفهام' },
      { word: 'another', ar: 'آخر', relationAr: 'تركيب شائع من an + other' },
    ],
  },
  be: {
    synonyms: [
      { word: 'exist', ar: 'يوجد / يكون', nuanceAr: 'أكثر رسمية وتعبّر عن الوجود الفعلي', exampleEn: 'These traditions still exist.', exampleAr: 'هذه التقاليد لا تزال موجودة.' },
      { word: 'remain', ar: 'يبقى', nuanceAr: 'تعبّر عن استمرار الحالة دون تغيير', exampleEn: 'Please remain calm.', exampleAr: 'يرجى البقاء هادئاً.' },
      { word: 'become', ar: 'يصبح', nuanceAr: 'تدل على التحول إلى حالة جديدة', exampleEn: 'She wants to become a doctor.', exampleAr: 'تريد أن تصبح طبيبة.' },
    ],
    wordFamily: [
      { word: 'being', pos: 'Noun', posAr: 'اسم / صيغة مستمرة', ar: 'كائن / كينونة', exampleEn: 'Every human being deserves respect.' },
      { word: 'been', pos: 'Verb', posAr: 'فعل (تصريف ثالث)', ar: 'كان (مع الأزمنة التامة)', exampleEn: 'I have been here before.' },
      { word: 'was', pos: 'Verb', posAr: 'فعل ماضٍ', ar: 'كان (للمفرد)', exampleEn: 'It was a wonderful day.' },
      { word: 'were', pos: 'Verb', posAr: 'فعل ماضٍ', ar: 'كانوا (للجمع)', exampleEn: 'They were ready early.' },
    ],
    relatedWords: [
      { word: 'seem', ar: 'يبدو', relationAr: 'فعل ربط شبيه بـ be' },
      { word: 'feel', ar: 'يشعر', relationAr: 'فعل حالة وربط شائع' },
      { word: 'stay', ar: 'يبقى', relationAr: 'فعل استمرار الحالة' },
    ],
  },
  have: {
    synonyms: [
      { word: 'own', ar: 'يمتلك', nuanceAr: 'أقوى وأوضح في الدلالة على الملكية القانونية أو الكاملة', exampleEn: 'They own a small cafe.', exampleAr: 'يمتلكون مقهى صغيراً.' },
      { word: 'possess', ar: 'يحوز / يمتلك', nuanceAr: 'رسمية وتُستخدم للصفات والممتلكات', exampleEn: 'She possesses great leadership skills.', exampleAr: 'تمتلك مهارات قيادية رائعة.' },
      { word: 'hold', ar: 'يمسك / يحمل / يعقد', nuanceAr: 'تُستخدم مع الأشياء والاجتماعات والمناصب', exampleEn: 'We will hold a meeting tomorrow.', exampleAr: 'سنعقد اجتماعاً غداً.' },
    ],
    antonyms: [
      { word: 'lack', ar: 'يفتقر إلى', contrastAr: 'غياب الشيء أو عدم امتلاكه', exampleEn: 'The plan lacks clear details.', exampleAr: 'تفتقر الخطة إلى تفاصيل واضحة.' },
      { word: 'lose', ar: 'يفقد / يخسر', contrastAr: 'فقدان ما كنت تمتلكه', exampleEn: 'Do not lose your keys.', exampleAr: 'لا تفقد مفاتيحك.' },
    ],
    wordFamily: [
      { word: 'has', pos: 'Verb', posAr: 'فعل (مضارع للمفرد)', ar: 'يمتلك / لديه', exampleEn: 'He has two sisters.' },
      { word: 'had', pos: 'Verb', posAr: 'فعل ماضٍ', ar: 'امتلك / كان لديه', exampleEn: 'We had a great time.' },
      { word: 'having', pos: 'Verb', posAr: 'صيغة الاستمرار', ar: 'يمتلك / يتناول', exampleEn: 'We are having dinner now.' },
    ],
    relatedWords: [
      { word: 'get', ar: 'يحصل على', relationAr: 'فعل شائع للحصول والتملك' },
      { word: 'keep', ar: 'يحتفظ بـ', relationAr: 'الاستمرار في الامتلاك' },
      { word: 'need', ar: 'يحتاج', relationAr: 'فعل حاجة مرتبط بالتملك' },
    ],
  },
  do: {
    synonyms: [
      { word: 'perform', ar: 'يؤدّي / ينفّذ', nuanceAr: 'أكثر رسمية للأعمال والمهام والعروض', exampleEn: 'Doctors perform delicate surgeries.', exampleAr: 'يؤدي الأطباء عمليات دقيقة.' },
      { word: 'complete', ar: 'يُكمل / يُنجز', nuanceAr: 'تركز على إنهاء المهمة بالكامل', exampleEn: 'Please complete the form.', exampleAr: 'يرجى إكمال النموذج.' },
      { word: 'act', ar: 'يتصرف / يعمل', nuanceAr: 'تعبّر عن اتخاذ فعل أو تصرف', exampleEn: 'We must act quickly.', exampleAr: 'يجب أن نتصرف بسرعة.' },
    ],
    wordFamily: [
      { word: 'does', pos: 'Verb', posAr: 'فعل (مضارع للمفرد)', ar: 'يفعل', exampleEn: 'She does her homework daily.' },
      { word: 'did', pos: 'Verb', posAr: 'فعل ماضٍ', ar: 'فعل', exampleEn: 'He did a great job.' },
      { word: 'done', pos: 'Adjective', posAr: 'صفة / تصريف ثالث', ar: 'مُنجَز / منتهٍ', exampleEn: 'The project is finally done.' },
      { word: 'undo', pos: 'Verb', posAr: 'فعل', ar: 'يتراجع عن', exampleEn: 'You can undo the last change.' },
    ],
    relatedWords: [
      { word: 'make', ar: 'يصنع / يعمل', relationAr: 'غالباً ما يُقارن مع do في التلازمات' },
      { word: 'work', ar: 'يعمل', relationAr: 'فعل نشاط وإنجاز' },
      { word: 'try', ar: 'يحاول', relationAr: 'الشروع في فعل' },
    ],
  },
  make: {
    synonyms: [
      { word: 'create', ar: 'يُنشئ / يبتكر', nuanceAr: 'تركز على الإبداع أو إيجاد شيء جديد', exampleEn: 'She creates digital art.', exampleAr: 'تبتكر فناً رقمياً.' },
      { word: 'build', ar: 'يبني', nuanceAr: 'تُستخدم للبناء المادي أو المعنوي', exampleEn: 'They build strong relationships.', exampleAr: 'يبنون علاقات قوية.' },
      { word: 'produce', ar: 'يُنتج', nuanceAr: 'رسمية للإنتاج الصناعي أو الفني', exampleEn: 'This factory produces electric cars.', exampleAr: 'ينتج هذا المصنع سيارات كهربائية.' },
    ],
    antonyms: [
      { word: 'destroy', ar: 'يدمّر', contrastAr: 'الهدم والإتلاف بعكس الصنع والبناء', exampleEn: 'The storm destroyed the bridge.', exampleAr: 'دمّرت العاصفة الجسر.' },
      { word: 'break', ar: 'يكسر', contrastAr: 'تفكيك أو إتلاف شيء مصنوع', exampleEn: 'Be careful not to break the glass.', exampleAr: 'انتبه ألا تكسر الزجاج.' },
    ],
    wordFamily: [
      { word: 'maker', pos: 'Noun', posAr: 'اسم', ar: 'صانع / مُنتِج', exampleEn: 'He is a skilled furniture maker.' },
      { word: 'making', pos: 'Noun', posAr: 'اسم / مصدر', ar: 'صناعة / عملية الصنع', exampleEn: 'Good decisions are in the making.' },
      { word: 'made', pos: 'Verb', posAr: 'فعل ماضٍ', ar: 'صنع / مصنوع', exampleEn: 'She made a delicious cake.' },
      { word: 'remake', pos: 'Verb', posAr: 'فعل / اسم', ar: 'يعيد صنع', exampleEn: 'They decided to remake the classic film.' },
    ],
    relatedWords: [
      { word: 'do', ar: 'يفعل', relationAr: 'فعل شائع يختلف عنه في التلازمات' },
      { word: 'form', ar: 'يشكّل', relationAr: 'تكوين شيء جديد' },
      { word: 'design', ar: 'يصمّم', relationAr: 'مرحلة التخطيط قبل الصنع' },
    ],
  },
  good: {
    synonyms: [
      { word: 'great', ar: 'رائع / ممتاز', nuanceAr: 'أقوى في المدح من good', exampleEn: 'You did a great job!', exampleAr: 'قمت بعمل رائع!' },
      { word: 'excellent', ar: 'ممتاز', nuanceAr: 'جودة عالية جداً ورسمية', exampleEn: 'Her English is excellent.', exampleAr: 'إنجليزيتها ممتازة.' },
      { word: 'positive', ar: 'إيجابي', nuanceAr: 'للنتائج والمواقف والمشاعر', exampleEn: 'We received positive feedback.', exampleAr: 'تلقّينا تقييماً إيجابياً.' },
      { word: 'useful', ar: 'مفيد', nuanceAr: 'تركز على الفائدة العملية', exampleEn: 'That is a very useful tip.', exampleAr: 'تلك نصيحة مفيدة جداً.' },
    ],
    antonyms: [
      { word: 'bad', ar: 'سيئ', contrastAr: 'الضد المباشر والأكثر شيوعاً', exampleEn: 'The weather is bad today.', exampleAr: 'الطقس سيئ اليوم.' },
      { word: 'poor', ar: 'ضعيف / رديء', contrastAr: 'تُستخدم للجودة المنخفضة والأداء الضعيف', exampleEn: 'The signal is poor here.', exampleAr: 'الإشارة ضعيفة هنا.' },
    ],
    wordFamily: [
      { word: 'goodness', pos: 'Noun', posAr: 'اسم', ar: 'طِيبة / صلاح / خير', exampleEn: 'Thank goodness everyone is safe.' },
      { word: 'well', pos: 'Adverb', posAr: 'ظرف', ar: 'بشكل جيد', exampleEn: 'She speaks English very well.' },
      { word: 'better', pos: 'Adjective', posAr: 'صفة مقارنة', ar: 'أفضل', exampleEn: 'Practice makes your pronunciation better.' },
      { word: 'best', pos: 'Adjective', posAr: 'صفة تفضيل', ar: 'الأفضل', exampleEn: 'This is the best way to learn.' },
    ],
    relatedWords: [
      { word: 'nice', ar: 'لطيف / جميل', relationAr: 'صفة استحسان يومية' },
      { word: 'fine', ar: 'جيد / بخير', relationAr: 'صفة قبول ورضا' },
      { word: 'kind', ar: 'طيب / عطوف', relationAr: 'صفة أخلاقية إيجابية' },
    ],
  },
  bad: {
    synonyms: [
      { word: 'poor', ar: 'رديء / ضعيف', nuanceAr: 'أكثر تهذيباً ورسمية لوصف الجودة', exampleEn: 'The road is in poor condition.', exampleAr: 'الطريق في حالة رديئة.' },
      { word: 'terrible', ar: 'فظيع / سيئ جداً', nuanceAr: 'أقوى بكثير من bad', exampleEn: 'I had a terrible headache.', exampleAr: 'أصبت بصداع فظيع.' },
      { word: 'harmful', ar: 'ضارّ', nuanceAr: 'تركز على الأذى الصحي أو المادي', exampleEn: 'Smoking is harmful to your health.', exampleAr: 'التدخين ضار بصحتك.' },
    ],
    antonyms: [
      { word: 'good', ar: 'جيد', contrastAr: 'الضد المباشر والأشيع', exampleEn: 'That was a good decision.', exampleAr: 'كان ذلك قراراً جيداً.' },
      { word: 'excellent', ar: 'ممتاز', contrastAr: 'ضد قوي يدل على أعلى جودة', exampleEn: 'The service was excellent.', exampleAr: 'كانت الخدمة ممتازة.' },
    ],
    wordFamily: [
      { word: 'badly', pos: 'Adverb', posAr: 'ظرف', ar: 'بشكل سيئ / بشدة', exampleEn: 'The team played badly yesterday.' },
      { word: 'worse', pos: 'Adjective', posAr: 'صفة مقارنة', ar: 'أسوأ', exampleEn: 'The traffic got worse at five.' },
      { word: 'worst', pos: 'Adjective', posAr: 'صفة تفضيل', ar: 'الأسوأ', exampleEn: 'That was the worst storm of the year.' },
    ],
    relatedWords: [
      { word: 'wrong', ar: 'خاطئ', relationAr: 'وصف الخطأ وعدم الصواب' },
      { word: 'awful', ar: 'مريع', relationAr: 'درجة أشد من السوء' },
    ],
  },
  in: {
    synonyms: [
      { word: 'inside', ar: 'داخل', nuanceAr: 'أوضح للتأكيد على الوجود في الداخل المادي', exampleEn: 'The keys are inside the bag.', exampleAr: 'المفاتيح داخل الحقيبة.' },
      { word: 'within', ar: 'ضمن / في غضون', nuanceAr: 'رسمية للحدود الزمنية والمكانية', exampleEn: 'Please reply within two days.', exampleAr: 'يرجى الرد خلال يومين.' },
    ],
    antonyms: [
      { word: 'out', ar: 'خارج', contrastAr: 'الوجود خارج المكان', exampleEn: 'He stepped out of the office.', exampleAr: 'خرج من المكتب.' },
      { word: 'outside', ar: 'في الخارج', contrastAr: 'المساحة الخارجية بعكس داخل المكان', exampleEn: 'The children are playing outside.', exampleAr: 'الأطفال يلعبون في الخارج.' },
    ],
    relatedWords: [
      { word: 'into', ar: 'إلى داخل', relationAr: 'حرف جر للحركة نحو الداخل' },
      { word: 'on', ar: 'على', relationAr: 'حرف جر للموضع السطحي' },
      { word: 'at', ar: 'عند / في', relationAr: 'حرف جر لنقطة محددة' },
    ],
  },
  on: {
    synonyms: [
      { word: 'upon', ar: 'فوق / على', nuanceAr: 'صيغة أكثر رسمية أو أدبية من on', exampleEn: 'Place the letter upon the desk.', exampleAr: 'ضع الرسالة فوق المكتب.' },
      { word: 'above', ar: 'أعلى / فوق', nuanceAr: 'فوق الشيء دون ملامسة مباشرة', exampleEn: 'The lamp hangs above the table.', exampleAr: 'المصباح معلق فوق الطاولة.' },
    ],
    antonyms: [
      { word: 'off', ar: 'مُطفأ / بعيداً عن', contrastAr: 'عكس التشغيل أو الملامسة السطحية', exampleEn: 'Turn the light off before sleeping.', exampleAr: 'أطفئ الضوء قبل النوم.' },
      { word: 'under', ar: 'تحت', contrastAr: 'الموقع السفلي عكس الفوقي', exampleEn: 'The cat is sleeping under the chair.', exampleAr: 'القطة نائمة تحت الكرسي.' },
    ],
    relatedWords: [
      { word: 'onto', ar: 'إلى فوق', relationAr: 'حرف جر للحركة نحو السطح' },
      { word: 'in', ar: 'في', relationAr: 'حرف جر أساسي للمكان والزمان' },
      { word: 'at', ar: 'عند', relationAr: 'حرف جر أساسي للنقطة والوقت' },
    ],
  },
  to: {
    synonyms: [
      { word: 'toward', ar: 'نحو / باتجاه', nuanceAr: 'تعبّر عن الاتجاه نحو هدف معين', exampleEn: 'She walked toward the station.', exampleAr: 'مشت نحو المحطة.' },
      { word: 'until', ar: 'حتى', nuanceAr: 'عند الإشارة إلى نهاية مدة زمنية', exampleEn: 'We work from nine until five.', exampleAr: 'نعمل من التاسعة حتى الخامسة.' },
    ],
    antonyms: [
      { word: 'from', ar: 'من', contrastAr: 'نقطة البداية عكس نقطة الوصول to', exampleEn: 'This train travels from London to Paris.', exampleAr: 'يسافر هذا القطار من لندن إلى باريس.' },
    ],
    relatedWords: [
      { word: 'into', ar: 'إلى داخل', relationAr: 'حرف جر للوصول إلى الداخل' },
      { word: 'for', ar: 'لـ / لأجل', relationAr: 'حرف جر للغرض والمستفيد' },
    ],
  },
  of: {
    synonyms: [
      { word: 'from', ar: 'من', nuanceAr: 'تُستخدم للمصدر أو الأصل أو المادة', exampleEn: 'This cheese is made from fresh milk.', exampleAr: 'هذا الجبن مصنوع من حليب طازج.' },
      { word: 'about', ar: 'عن / حول', nuanceAr: 'عندما تعبّر of عن الموضوع أو الفكرة', exampleEn: 'Tell me about your trip.', exampleAr: 'أخبرني عن رحلتك.' },
    ],
    relatedWords: [
      { word: 'for', ar: 'لـ / خاص بـ', relationAr: 'حرف جر شائع للانتماء والغرض' },
      { word: 'with', ar: 'مع / ذو', relationAr: 'حرف جر للوصف والمصاحبة' },
      { word: 'by', ar: 'بواسطة', relationAr: 'حرف جر للفاعل والمؤلف' },
    ],
  },
  and: {
    synonyms: [
      { word: 'plus', ar: 'زائد / بالإضافة إلى', nuanceAr: 'تبرز الإضافة الحسابية أو الإضافية', exampleEn: 'You get the book plus audio lessons.', exampleAr: 'تحصل على الكتاب بالإضافة إلى دروس صوتية.' },
      { word: 'also', ar: 'أيضاً', nuanceAr: 'تضيف معلومة جديدة في جملة متصلة', exampleEn: 'She speaks Arabic and also English.', exampleAr: 'تتحدث العربية والإنجليزية أيضاً.' },
    ],
    antonyms: [
      { word: 'but', ar: 'لكن', contrastAr: 'تُستخدم للتناقض والاستدراك عكس الجمع بـ and', exampleEn: 'It was cold, but we enjoyed the walk.', exampleAr: 'كان الجو بارداً، لكننا استمتعنا بالمشي.' },
      { word: 'or', ar: 'أو', contrastAr: 'تُستخدم للتخيير بين بديلين بدلاً من الجمع', exampleEn: 'Would you like tea or coffee?', exampleAr: 'هل تفضل الشاي أم القهوة؟' },
    ],
    relatedWords: [
      { word: 'both', ar: 'كلاهما', relationAr: 'تُستخدم كثيراً مع and (both ... and ...)' },
      { word: 'with', ar: 'مع', relationAr: 'الجمع والمصاحبة بين عنصرين' },
    ],
  },
  for: {
    synonyms: [
      { word: 'during', ar: 'خلال / طوال', nuanceAr: 'تُستخدم للمدة الزمنية داخل فترة معينة', exampleEn: 'She studied hard during the summer.', exampleAr: 'درست بجد خلال الصيف.' },
      { word: 'toward', ar: 'من أجل / نحو', nuanceAr: 'للغرض أو الوجهة المقصودة', exampleEn: 'They saved money toward a new home.', exampleAr: 'ادّخروا المال من أجل منزل جديد.' },
    ],
    antonyms: [
      { word: 'against', ar: 'ضد', contrastAr: 'المعارضة بعكس التأييد والدعم بـ for', exampleEn: 'Are you for or against the idea?', exampleAr: 'هل أنت مع الفكرة أم ضدها؟' },
    ],
    relatedWords: [
      { word: 'to', ar: 'إلى / لـ', relationAr: 'حرف جر قريب في الدلالة على الهدف' },
      { word: 'because', ar: 'لأن', relationAr: 'أداة ربط للسبب والغرض' },
    ],
  },
  with: {
    synonyms: [
      { word: 'alongside', ar: 'إلى جانب', nuanceAr: 'تدل على المرافقة أو العمل جنباً إلى جنب', exampleEn: 'She works alongside experienced engineers.', exampleAr: 'تعمل إلى جانب مهندسين ذوي خبرة.' },
      { word: 'using', ar: 'باستخدام', nuanceAr: 'عندما تدل with على الأداة أو الوسيلة', exampleEn: 'Write your name using a blue pen.', exampleAr: 'اكتب اسمك باستخدام قلم أزرق.' },
    ],
    antonyms: [
      { word: 'without', ar: 'بدون', contrastAr: 'غياب المرافقة أو الأداة', exampleEn: 'I drink coffee without sugar.', exampleAr: 'أشرب القهوة بدون سكر.' },
    ],
    relatedWords: [
      { word: 'together', ar: 'معاً', relationAr: 'ظرف مصاحبة واشتراك' },
      { word: 'by', ar: 'بواسطة', relationAr: 'حرف جر للوسيلة' },
    ],
  },
  important: {
    synonyms: [
      { word: 'essential', ar: 'أساسي / ضروري', nuanceAr: 'أقوى وتدل على أنه لا غنى عنه', exampleEn: 'Water is essential for life.', exampleAr: 'الماء ضروري للحياة.' },
      { word: 'significant', ar: 'مهم / ذو دلالة', nuanceAr: 'رسمية وأكاديمية للتأثير الكبير', exampleEn: 'She made significant progress.', exampleAr: 'حققت تقدماً ملحوظاً.' },
      { word: 'key', ar: 'محوري / رئيسي', nuanceAr: 'مختصرة وطبيعية في الحديث والعمل', exampleEn: 'Practice is the key factor.', exampleAr: 'الممارسة هي العامل المحوري.' },
    ],
    antonyms: [
      { word: 'minor', ar: 'ثانوي / بسيط', contrastAr: 'قليل الأهمية أو التأثير', exampleEn: 'It was only a minor mistake.', exampleAr: 'كان مجرد خطأ بسيط.' },
      { word: 'unimportant', ar: 'غير مهم', contrastAr: 'النفي المباشر للأهمية', exampleEn: 'Skip the unimportant details.', exampleAr: 'تجاوز التفاصيل غير المهمة.' },
    ],
    wordFamily: [
      { word: 'importance', pos: 'Noun', posAr: 'اسم', ar: 'أهمية', exampleEn: 'We understand the importance of sleep.' },
      { word: 'importantly', pos: 'Adverb', posAr: 'ظرف', ar: 'بشكل مهم / والأهم', exampleEn: 'More importantly, stay consistent.' },
      { word: 'unimportant', pos: 'Adjective', posAr: 'صفة', ar: 'غير مهم', exampleEn: 'Do not worry about unimportant issues.' },
    ],
    relatedWords: [
      { word: 'necessary', ar: 'ضروري', relationAr: 'صفة مرتبطة بالحاجة والأولوية' },
      { word: 'valuable', ar: 'قيّم', relationAr: 'ذو قيمة وفائدة كبيرة' },
    ],
  },
  learn: {
    synonyms: [
      { word: 'study', ar: 'يدرس', nuanceAr: 'تركز على الدراسة المنظمة والكتب', exampleEn: 'He studies medicine at university.', exampleAr: 'يدرس الطب في الجامعة.' },
      { word: 'master', ar: 'يتقن', nuanceAr: 'الوصول إلى مستوى احترافي عالٍ', exampleEn: 'She mastered spoken English.', exampleAr: 'أتقنت الإنجليزية المحكية.' },
      { word: 'discover', ar: 'يكتشف', nuanceAr: 'معرفة معلومة أو حقيقة جديدة', exampleEn: 'We discovered a better method.', exampleAr: 'اكتشفنا طريقة أفضل.' },
    ],
    antonyms: [
      { word: 'forget', ar: 'ينسى', contrastAr: 'فقدان ما تم تعلمه', exampleEn: 'Review daily so you never forget.', exampleAr: 'راجع يومياً حتى لا تنسى.' },
      { word: 'teach', ar: 'يُعلّم', contrastAr: 'نقل المعرفة للآخرين بدلاً من تلقيها', exampleEn: 'He teaches English online.', exampleAr: 'يُعلّم الإنجليزية عبر الإنترنت.' },
    ],
    wordFamily: [
      { word: 'learner', pos: 'Noun', posAr: 'اسم', ar: 'متعلّم', exampleEn: 'Every learner improves with practice.' },
      { word: 'learning', pos: 'Noun', posAr: 'اسم / مصدر', ar: 'التعلّم', exampleEn: 'Language learning takes patience.' },
      { word: 'learned', pos: 'Adjective', posAr: 'صفة / فعل ماضٍ', ar: 'مُتعلّم / تَعلّم', exampleEn: 'I learned ten new words today.' },
    ],
    relatedWords: [
      { word: 'knowledge', ar: 'معرفة', relationAr: 'ثمرة التعلّم' },
      { word: 'practice', ar: 'يمارس / تدريب', relationAr: 'أساس تثبيت التعلم' },
      { word: 'education', ar: 'تعليم', relationAr: 'المجال العام للتعلم' },
    ],
  },
  work: {
    synonyms: [
      { word: 'job', ar: 'وظيفة / عمل', nuanceAr: 'تُستخدم للوظيفة المحددة (اسم معدود)', exampleEn: 'She found a new job.', exampleAr: 'وجدت وظيفة جديدة.' },
      { word: 'labor', ar: 'عمل / جهد', nuanceAr: 'رسمية للعمل البدني أو الجهد الكبير', exampleEn: 'The project took months of hard labor.', exampleAr: 'استغرق المشروع أشهراً من العمل الشاق.' },
      { word: 'operate', ar: 'يعمل / يشتغل (للأجهزة)', nuanceAr: 'عند الحديث عن عمل الآلات والأنظمة', exampleEn: 'This machine operates quietly.', exampleAr: 'تعمل هذه الآلة بهدوء.' },
    ],
    antonyms: [
      { word: 'rest', ar: 'يرتاح / راحة', contrastAr: 'التوقف عن الجهد للراحة', exampleEn: 'Take a short rest after studying.', exampleAr: 'خذ استراحة قصيرة بعد الدراسة.' },
      { word: 'play', ar: 'يلعب', contrastAr: 'الترفيه واللعب مقابل العمل الجاد', exampleEn: 'Balance work and play.', exampleAr: 'وازن بين العمل واللعب.' },
    ],
    wordFamily: [
      { word: 'worker', pos: 'Noun', posAr: 'اسم', ar: 'عامل / موظف', exampleEn: 'Every worker deserves fair pay.' },
      { word: 'working', pos: 'Adjective', posAr: 'صفة', ar: 'عامل / قيد التشغيل', exampleEn: 'We need a working solution.' },
      { word: 'workplace', pos: 'Noun', posAr: 'اسم مركب', ar: 'مكان العمل', exampleEn: 'Clear communication improves the workplace.' },
      { word: 'homework', pos: 'Noun', posAr: 'اسم مركب', ar: 'واجب منزلي', exampleEn: 'Finish your homework before dinner.' },
    ],
    relatedWords: [
      { word: 'career', ar: 'مسار مهني', relationAr: 'المستقبل الوظيفي الطويل' },
      { word: 'office', ar: 'مكتب', relationAr: 'بيئة عمل شائعة' },
      { word: 'task', ar: 'مهمة', relationAr: 'جزء محدد من العمل' },
    ],
  },
  time: {
    synonyms: [
      { word: 'period', ar: 'فترة زمنية', nuanceAr: 'مدة زمنية محددة البداية والنهاية', exampleEn: 'It was a difficult period.', exampleAr: 'كانت فترة صعبة.' },
      { word: 'moment', ar: 'لحظة', nuanceAr: 'وقت قصير جداً ومحدد', exampleEn: 'Wait a moment, please.', exampleAr: 'انتظر لحظة من فضلك.' },
      { word: 'duration', ar: 'مدة', nuanceAr: 'رسمية لقياس طول الوقت', exampleEn: 'The duration of the flight is three hours.', exampleAr: 'مدة الرحلة ثلاث ساعات.' },
    ],
    wordFamily: [
      { word: 'timely', pos: 'Adjective', posAr: 'صفة', ar: 'في الوقت المناسب', exampleEn: 'Thank you for your timely reply.' },
      { word: 'timer', pos: 'Noun', posAr: 'اسم', ar: 'مؤقّت', exampleEn: 'Set a timer for ten minutes.' },
      { word: 'timeless', pos: 'Adjective', posAr: 'صفة', ar: 'خالد / لا يرتبط بزمن', exampleEn: 'Good manners are timeless.' },
      { word: 'overtime', pos: 'Noun', posAr: 'اسم', ar: 'عمل إضافي / وقت إضافي', exampleEn: 'He worked overtime this week.' },
    ],
    relatedWords: [
      { word: 'hour', ar: 'ساعة', relationAr: 'وحدة قياس الوقت' },
      { word: 'schedule', ar: 'جدول زمني', relationAr: 'تنظيم الوقت' },
      { word: 'clock', ar: 'ساعة حائط / منبه', relationAr: 'أداة قياس الوقت' },
    ],
  },
  happy: {
    synonyms: [
      { word: 'glad', ar: 'مسرور', nuanceAr: 'لطيفة وشائعة للتعبير عن الرضا', exampleEn: 'I am glad to meet you.', exampleAr: 'أنا مسرور بلقائك.' },
      { word: 'joyful', ar: 'مبتهج / فرح', nuanceAr: 'فرح أعمق وأكثر إشراقاً', exampleEn: 'It was a joyful celebration.', exampleAr: 'كان احتفالاً مبهجاً.' },
      { word: 'pleased', ar: 'راضٍ / سعيد', nuanceAr: 'رسمية قليلاً للتعبير عن الرضا بنتيجة', exampleEn: 'We are pleased with your progress.', exampleAr: 'نحن سعداء بتقدمك.' },
    ],
    antonyms: [
      { word: 'sad', ar: 'حزين', contrastAr: 'الشعور المقابل للفرح', exampleEn: 'She felt sad when her friend moved away.', exampleAr: 'شعرت بالحزن عندما انتقلت صديقتها.' },
      { word: 'unhappy', ar: 'غير سعيد', contrastAr: 'النفي المباشر للسعادة أو الرضا', exampleEn: 'He was unhappy with the delay.', exampleAr: 'كان غير راضٍ عن التأخير.' },
    ],
    wordFamily: [
      { word: 'happiness', pos: 'Noun', posAr: 'اسم', ar: 'سعادة', exampleEn: 'True happiness comes from within.' },
      { word: 'happily', pos: 'Adverb', posAr: 'ظرف', ar: 'بسعادة', exampleEn: 'They lived happily together.' },
      { word: 'unhappy', pos: 'Adjective', posAr: 'صفة', ar: 'حزين / غير سعيد', exampleEn: 'Why do you look unhappy today?' },
    ],
    relatedWords: [
      { word: 'smile', ar: 'يبتسم', relationAr: 'تعبير ظاهري عن السعادة' },
      { word: 'excited', ar: 'متحمس', relationAr: 'شعور إيجابي قريب' },
    ],
  },
};

// Bidirectional common English antonym pairs (100% offline verified pairs)
const ANTONYM_PAIR_LIST: Array<[string, string]> = [
  ['good', 'bad'], ['big', 'small'], ['large', 'small'], ['huge', 'tiny'],
  ['happy', 'sad'], ['fast', 'slow'], ['quick', 'slow'], ['rapid', 'slow'],
  ['new', 'old'], ['young', 'old'], ['modern', 'ancient'], ['fresh', 'stale'],
  ['easy', 'hard'], ['easy', 'difficult'], ['simple', 'complex'], ['simple', 'difficult'],
  ['hot', 'cold'], ['warm', 'cool'], ['high', 'low'], ['tall', 'short'], ['long', 'short'],
  ['rich', 'poor'], ['wealth', 'poverty'], ['strong', 'weak'], ['powerful', 'weak'],
  ['clean', 'dirty'], ['open', 'close'], ['open', 'shut'], ['true', 'false'], ['right', 'wrong'],
  ['right', 'left'], ['up', 'down'], ['in', 'out'], ['inside', 'outside'], ['on', 'off'],
  ['over', 'under'], ['above', 'below'], ['before', 'after'], ['early', 'late'], ['first', 'last'],
  ['start', 'stop'], ['start', 'finish'], ['begin', 'end'], ['continue', 'stop'],
  ['win', 'lose'], ['success', 'failure'], ['succeed', 'fail'], ['pass', 'fail'],
  ['love', 'hate'], ['like', 'dislike'], ['friend', 'enemy'], ['peace', 'war'],
  ['light', 'dark'], ['light', 'heavy'], ['bright', 'dark'], ['day', 'night'], ['summer', 'winter'],
  ['safe', 'dangerous'], ['public', 'private'], ['buy', 'sell'], ['push', 'pull'],
  ['give', 'take'], ['send', 'receive'], ['borrow', 'lend'], ['teach', 'learn'],
  ['ask', 'answer'], ['question', 'answer'], ['speak', 'listen'], ['smile', 'cry'], ['laugh', 'cry'],
  ['remember', 'forget'], ['accept', 'refuse'], ['accept', 'reject'], ['agree', 'disagree'],
  ['allow', 'forbid'], ['build', 'destroy'], ['create', 'destroy'], ['make', 'break'],
  ['calm', 'nervous'], ['cheap', 'expensive'], ['clear', 'unclear'], ['common', 'rare'],
  ['deep', 'shallow'], ['defend', 'attack'], ['dry', 'wet'], ['empty', 'full'],
  ['enter', 'exit'], ['arrive', 'leave'], ['come', 'go'], ['stay', 'leave'],
  ['expand', 'shrink'], ['increase', 'decrease'], ['rise', 'fall'], ['raise', 'lower'],
  ['far', 'near'], ['few', 'many'], ['less', 'more'], ['most', 'least'],
  ['future', 'past'], ['gain', 'loss'], ['profit', 'loss'], ['generous', 'selfish'],
  ['gentle', 'rough'], ['smooth', 'rough'], ['soft', 'hard'], ['sharp', 'dull'],
  ['health', 'illness'], ['healthy', 'sick'], ['alive', 'dead'], ['live', 'die'],
  ['hide', 'show'], ['honest', 'dishonest'], ['hope', 'fear'], ['hungry', 'full'],
  ['ignore', 'notice'], ['import', 'export'], ['include', 'exclude'], ['inner', 'outer'],
  ['join', 'separate'], ['kind', 'cruel'], ['lazy', 'active'], ['lead', 'follow'],
  ['legal', 'illegal'], ['local', 'global'], ['lock', 'unlock'], ['loose', 'tight'],
  ['loud', 'quiet'], ['noisy', 'quiet'], ['noisy', 'silent'], ['major', 'minor'],
  ['maximum', 'minimum'], ['melt', 'freeze'], ['move', 'stay'], ['natural', 'artificial'],
  ['necessary', 'optional'], ['negative', 'positive'], ['never', 'always'], ['often', 'rarely'],
  ['north', 'south'], ['east', 'west'], ['order', 'chaos'], ['ordinary', 'special'],
  ['pain', 'pleasure'], ['part', 'whole'], ['permanent', 'temporary'], ['polite', 'rude'],
  ['possible', 'impossible'], ['present', 'absent'], ['pretty', 'ugly'], ['beautiful', 'ugly'],
  ['protect', 'harm'], ['proud', 'humble'], ['pure', 'impure'], ['real', 'fake'],
  ['regular', 'irregular'], ['rest', 'work'], ['reward', 'punish'], ['rural', 'urban'],
  ['same', 'different'], ['similar', 'different'], ['save', 'spend'], ['save', 'waste'],
  ['secret', 'public'], ['serious', 'funny'], ['single', 'married'], ['sit', 'stand'],
  ['smart', 'foolish'], ['wise', 'foolish'], ['solid', 'liquid'], ['sweet', 'bitter'],
  ['sweet', 'sour'], ['thick', 'thin'], ['together', 'apart'], ['top', 'bottom'],
  ['trust', 'doubt'], ['truth', 'lie'], ['useful', 'useless'], ['victory', 'defeat'],
  ['visible', 'invisible'], ['white', 'black'], ['wide', 'narrow'], ['with', 'without'],
  ['yes', 'no'], ['best', 'worst'], ['better', 'worse'], ['brave', 'afraid'],
  ['free', 'busy'], ['front', 'back'], ['forward', 'backward'], ['glad', 'sorry'],
  ['grow', 'shrink'], ['help', 'harm'], ['improve', 'worsen'], ['known', 'unknown'],
  ['likely', 'unlikely'], ['lucky', 'unlucky'], ['patient', 'impatient'], ['fair', 'unfair'],
];

const ANTONYM_MAP = new Map<string, string[]>();
for (const [a, b] of ANTONYM_PAIR_LIST) {
  const listA = ANTONYM_MAP.get(a) || [];
  if (!listA.includes(b)) listA.push(b);
  ANTONYM_MAP.set(a, listA);

  const listB = ANTONYM_MAP.get(b) || [];
  if (!listB.includes(a)) listB.push(a);
  ANTONYM_MAP.set(b, listB);
}

interface OfflineStoreIndex {
  byLower: Map<string, VocabEntry>;
  byGloss: Map<string, VocabEntry[]>;
}

const storeIndexCache = new WeakMap<VocabStore, OfflineStoreIndex>();

function normalizeArabicToken(raw: string): string {
  return raw
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[()[\]{}«»"'.!?؟،,:;؛\-_/\\]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractArabicGlosses(ar: string): string[] {
  if (!ar) return [];
  const rawParts = ar.split(/[،,/;|؛]+/);
  const out: string[] = [];
  for (const part of rawParts) {
    const cleaned = normalizeArabicToken(part);
    if (cleaned.length >= 2) {
      out.push(cleaned);
      // Also strip leading "ال" for noun matching (e.g. "العمل" <-> "عمل")
      if (cleaned.startsWith('ال') && cleaned.length >= 4 && !cleaned.includes(' ')) {
        out.push(cleaned.slice(2));
      }
    }
  }
  return Array.from(new Set(out));
}

function getStoreIndex(store?: VocabStore | null): OfflineStoreIndex | null {
  if (!store || !Array.isArray(store.words) || store.words.length === 0) return null;
  const cached = storeIndexCache.get(store);
  if (cached) return cached;

  const byLower = new Map<string, VocabEntry>();
  const byGloss = new Map<string, VocabEntry[]>();

  for (const entry of store.words) {
    if (!entry?.en) continue;
    const lower = entry.en.trim().toLowerCase();
    if (!lower) continue;
    if (!byLower.has(lower)) {
      byLower.set(lower, entry);
    }
    if (entry.ar) {
      const glosses = extractArabicGlosses(entry.ar);
      for (const g of glosses) {
        let bucket = byGloss.get(g);
        if (!bucket) {
          bucket = [];
          byGloss.set(g, bucket);
        }
        if (bucket.length < 28) {
          bucket.push(entry);
        }
      }
    }
  }

  const index: OfflineStoreIndex = { byLower, byGloss };
  storeIndexCache.set(store, index);
  return index;
}

function inferPosFromWord(word: string): { pos: WordHubDerivative['pos']; posAr: string } {
  const w = word.toLowerCase();
  if (w.endsWith('ly') && w.length > 4) return { pos: 'Adverb', posAr: POS_AR.adverb };
  if (
    /(tion|sion|ment|ness|ity|ship|hood|ance|ence|ism|ist|er|or|ry|age|ure)$/.test(w) &&
    w.length > 4
  ) {
    return { pos: 'Noun', posAr: POS_AR.noun };
  }
  if (
    /(ful|less|able|ible|ous|ious|ive|al|ial|ic|ical|ary|ory|ish|ant|ent|ed)$/.test(w) &&
    w.length > 4
  ) {
    return { pos: 'Adjective', posAr: POS_AR.adjective };
  }
  if (/(ize|ise|ify|ate|ing)$/.test(w) && w.length > 4) {
    return { pos: 'Verb', posAr: POS_AR.verb };
  }
  return { pos: 'Noun', posAr: POS_AR.noun };
}

function generateMorphologicalCandidates(lower: string): string[] {
  if (!/^[a-z]{2,24}$/.test(lower)) return [];

  const roots = new Set<string>([lower]);

  // Strip common prefixes to recover base root
  const prefixes = ['un', 'in', 'im', 'il', 'ir', 'dis', 'mis', 're', 'pre', 'over', 'under', 'non', 'out', 'sub', 'co'];
  for (const pre of prefixes) {
    if (lower.startsWith(pre) && lower.length - pre.length >= 3) {
      roots.add(lower.slice(pre.length));
    }
  }

  // Strip common suffixes to recover base root
  const suffixRemovals: Array<[RegExp, string[]]> = [
    [/ies$/, ['y']],
    [/ied$/, ['y']],
    [/ier$/, ['y']],
    [/iest$/, ['y']],
    [/ily$/, ['y']],
    [/iness$/, ['y']],
    [/ation$/, ['e', 'ate', '']],
    [/ition$/, ['e', '']],
    [/tion$/, ['t', 'te', '']],
    [/sion$/, ['d', 'de', 's', 'se', '']],
    [/ment$/, ['e', '']],
    [/ness$/, ['']],
    [/ity$/, ['e', '']],
    [/able$/, ['e', '']],
    [/ible$/, ['e', '']],
    [/ful$/, ['']],
    [/less$/, ['']],
    [/ous$/, ['e', '']],
    [/ive$/, ['e', '']],
    [/al$/, ['e', '']],
    [/ic$/, ['y', 'e', '']],
    [/ly$/, ['e', '']],
    [/ing$/, ['e', '']],
    [/ed$/, ['e', '']],
    [/er$/, ['e', '']],
    [/or$/, ['e', '']],
    [/ist$/, ['e', 'y', '']],
    [/ize$/, ['e', '']],
    [/ise$/, ['e', '']],
    [/es$/, ['']],
    [/s$/, ['']],
  ];

  for (const [rx, repls] of suffixRemovals) {
    if (rx.test(lower)) {
      for (const rep of repls) {
        const stem = lower.replace(rx, rep);
        if (stem.length >= 3) {
          roots.add(stem);
          // Handle doubled final consonant (e.g., running -> run, stopped -> stop)
          if (stem.length >= 4 && stem[stem.length - 1] === stem[stem.length - 2]) {
            roots.add(stem.slice(0, -1));
          }
        }
      }
    }
  }

  const candidates = new Set<string>();
  const suffixes = [
    '', 's', 'es', 'ed', 'd', 'ing', 'er', 'r', 'or', 'ist', 'ism',
    'ly', 'y', 'ful', 'less', 'able', 'ible', 'al', 'ial', 'ic', 'ical',
    'ive', 'ative', 'ous', 'ious', 'ment', 'ness', 'ity', 'ty', 'ion', 'ions',
    'tion', 'ation', 'sion', 'ance', 'ence', 'ant', 'ent', 'ize', 'ise', 'ify', 'en',
  ];
  const derivPrefixes = ['un', 'in', 'im', 'dis', 're', 'mis', 'over', 'non'];

  for (const root of roots) {
    if (root.length < 3) continue;
    const noE = root.endsWith('e') && root.length >= 4 ? root.slice(0, -1) : root;
    const yToI = root.endsWith('y') && root.length >= 4 ? `${root.slice(0, -1)}i` : null;
    const doubled =
      /[bcdfghjklmnpqrstvwxz]$/.test(root) && root.length >= 3 && root.length <= 7
        ? `${root}${root[root.length - 1]}`
        : null;

    for (const suf of suffixes) {
      candidates.add(`${root}${suf}`);
      if (noE !== root) candidates.add(`${noE}${suf}`);
      if (yToI && /^(ed|er|est|es|ly|ness|ful|less|able|al|ous|cation)$/.test(suf)) {
        candidates.add(`${yToI}${suf}`);
      }
      if (doubled && /^(ed|ing|er|est|y)$/.test(suf)) {
        candidates.add(`${doubled}${suf}`);
      }
    }
    for (const pre of derivPrefixes) {
      candidates.add(`${pre}${root}`);
    }
  }

  candidates.delete(lower);
  return Array.from(candidates);
}

const BAND_ORDER: Record<CefrBand, number> = {
  A0: 0,
  A1: 1,
  A2: 2,
  B1: 3,
  B2: 4,
  C1: 5,
  C2: 6,
};

export function buildOfflineWordRelationships(params: {
  word: string;
  ar?: string;
  band?: CefrBand;
  store?: VocabStore | null;
}): OfflineWordRelationships {
  const cleanWord = String(params.word || '').trim();
  const lower = cleanWord.toLowerCase();
  const ar = String(params.ar || '').trim();
  const band: CefrBand = params.band || 'B1';
  const index = getStoreIndex(params.store);

  const curated = CURATED_RELATIONSHIPS[lower];
  const synonyms: WordHubSynonym[] = [...(curated?.synonyms || [])];
  const antonyms: WordHubAntonym[] = [...(curated?.antonyms || [])];
  const wordFamily: WordHubDerivative[] = [...(curated?.wordFamily || [])];
  const relatedWords: WordHubRelatedWord[] = [...(curated?.relatedWords || [])];

  const seenAll = new Set<string>([lower]);
  const registerSeen = (w: string) => seenAll.add(w.toLowerCase().trim());

  synonyms.forEach((s) => registerSeen(s.word));
  antonyms.forEach((a) => registerSeen(a.word));
  wordFamily.forEach((f) => registerSeen(f.word));
  relatedWords.forEach((r) => registerSeen(r.word));

  // 1) Offline Verified Antonyms (curated table + verified negative prefix/unprefixed pairs in VocabStore)
  const mappedAnts = ANTONYM_MAP.get(lower) || [];
  for (const antWord of mappedAnts) {
    if (antonyms.length >= 4) break;
    if (seenAll.has(antWord)) continue;
    const entry = index?.byLower.get(antWord);
    antonyms.push({
      word: entry?.en || antWord,
      ar: entry?.ar || '',
      contrastAr: 'معنى مضاد مباشر في السياق العام',
      exampleEn: '',
      exampleAr: '',
    });
    registerSeen(antWord);
  }

  if (index && antonyms.length < 3 && /^[a-z]{4,}$/.test(lower)) {
    const negPrefixes = ['un', 'in', 'im', 'il', 'ir', 'dis', 'non'];
    for (const pre of negPrefixes) {
      if (antonyms.length >= 3) break;
      const prefixed = `${pre}${lower}`;
      const match = index.byLower.get(prefixed);
      if (match && !seenAll.has(prefixed)) {
        antonyms.push({
          word: match.en,
          ar: match.ar || '',
          contrastAr: `ضد مُشتق بإضافة البادئة (${pre}-)`,
          exampleEn: '',
          exampleAr: '',
        });
        registerSeen(prefixed);
      }
      if (lower.startsWith(pre) && lower.length - pre.length >= 4) {
        const unprefixed = lower.slice(pre.length);
        const baseMatch = index.byLower.get(unprefixed);
        if (baseMatch && !seenAll.has(unprefixed)) {
          antonyms.push({
            word: baseMatch.en,
            ar: baseMatch.ar || '',
            contrastAr: `الأصل المقابل بدون البادئة (${pre}-)`,
            exampleEn: '',
            exampleAr: '',
          });
          registerSeen(unprefixed);
        }
      }
    }
  }

  // 2) Offline Verified Morphological Word Family from VocabStore (18,484 real English words)
  if (index && wordFamily.length < 5) {
    const candidates = generateMorphologicalCandidates(lower);
    const verified: VocabEntry[] = [];
    for (const cand of candidates) {
      if (seenAll.has(cand)) continue;
      const match = index.byLower.get(cand);
      if (match) verified.push(match);
    }
    // Prefer closer CEFR band and shorter/cleaner derivatives
    verified.sort((a, b) => {
      const distA = Math.abs(BAND_ORDER[a.band] - BAND_ORDER[band]);
      const distB = Math.abs(BAND_ORDER[b.band] - BAND_ORDER[band]);
      if (distA !== distB) return distA - distB;
      return a.en.length - b.en.length;
    });
    for (const match of verified) {
      if (wordFamily.length >= 6) break;
      const key = match.en.toLowerCase();
      if (seenAll.has(key)) continue;
      const guessed = inferPosFromWord(match.en);
      wordFamily.push({
        word: match.en,
        pos: guessed.pos,
        posAr: guessed.posAr,
        ar: match.ar || '',
        exampleEn: '',
      });
      registerSeen(key);
    }
  }

  // 3) Offline Verified Synonyms via exact shared Arabic glosses in VocabStore
  if (index && synonyms.length < 5) {
    const targetEntry = index.byLower.get(lower);
    const effectiveAr = ar || targetEntry?.ar || '';
    const glosses = extractArabicGlosses(effectiveAr);
    const scoreMap = new Map<string, { entry: VocabEntry; overlap: number; matchedGloss: string }>();

    for (const g of glosses) {
      const bucket = index.byGloss.get(g);
      if (!bucket) continue;
      for (const candidate of bucket) {
        const key = candidate.en.toLowerCase();
        if (key === lower || seenAll.has(key)) continue;
        // Skip multi-word phrases if we already have single-word candidates, unless needed
        const prev = scoreMap.get(key);
        if (prev) {
          prev.overlap += 1;
        } else {
          scoreMap.set(key, { entry: candidate, overlap: 1, matchedGloss: g });
        }
      }
    }

    const rankedSyns = Array.from(scoreMap.values()).sort((a, b) => {
      if (b.overlap !== a.overlap) return b.overlap - a.overlap;
      const distA = Math.abs(BAND_ORDER[a.entry.band] - BAND_ORDER[band]);
      const distB = Math.abs(BAND_ORDER[b.entry.band] - BAND_ORDER[band]);
      if (distA !== distB) return distA - distB;
      return a.entry.en.length - b.entry.en.length;
    });

    for (const item of rankedSyns) {
      if (synonyms.length >= 5) break;
      const key = item.entry.en.toLowerCase();
      if (seenAll.has(key)) continue;
      synonyms.push({
        word: item.entry.en,
        ar: item.entry.ar || '',
        nuanceAr: `تشترك معها في المعنى (${item.matchedGloss}) ضمن مستوى ${item.entry.band}`,
        exampleEn: '',
        exampleAr: '',
      });
      registerSeen(key);
    }
  }

  // 4) Offline Related Words via partial Arabic keyword overlap or same-band neighbors
  if (index && relatedWords.length < 5) {
    const targetEntry = index.byLower.get(lower);
    const effectiveAr = ar || targetEntry?.ar || '';
    const arWords = normalizeArabicToken(effectiveAr)
      .split(' ')
      .filter((tok) => tok.length >= 3);

    for (const tok of arWords) {
      if (relatedWords.length >= 5) break;
      const bucket = index.byGloss.get(tok);
      if (!bucket) continue;
      for (const candidate of bucket) {
        if (relatedWords.length >= 5) break;
        const key = candidate.en.toLowerCase();
        if (seenAll.has(key)) continue;
        relatedWords.push({
          word: candidate.en,
          ar: candidate.ar || '',
          relationAr: `مرتبطة دلالياً (${tok})`,
        });
        registerSeen(key);
      }
    }

    // Guarantee non-empty helpful related words from same CEFR level neighborhood if still sparse
    if (relatedWords.length < 3 && params.store) {
      const bandIds = params.store.byBand[band] || [];
      if (bandIds.length > 0) {
        const selfIdx = targetEntry ? bandIds.indexOf(targetEntry.id) : -1;
        const start = selfIdx >= 0 ? Math.max(0, selfIdx - 3) : 0;
        const windowIds = bandIds.slice(start, start + 14);
        for (const id of windowIds) {
          if (relatedWords.length >= 4) break;
          const neighbor = params.store.words[id];
          if (!neighbor) continue;
          const key = neighbor.en.toLowerCase();
          if (seenAll.has(key)) continue;
          relatedWords.push({
            word: neighbor.en,
            ar: neighbor.ar || '',
            relationAr: `كلمة مرافقة في نفس المستوى (${band})`,
          });
          registerSeen(key);
        }
      }
    }
  }

  return {
    synonyms: synonyms.slice(0, 6),
    antonyms: antonyms.slice(0, 5),
    wordFamily: wordFamily.slice(0, 6),
    relatedWords: relatedWords.slice(0, 6),
  };
}

/**
 * Non-destructively enriches WordHubData with 100% offline verified relationships
 * so the Relationships tab renders instantaneously with zero network requirement.
 */
export function enrichWordHubWithOfflineRelationships(
  data: WordHubData,
  params: { word: string; ar?: string; band?: CefrBand; store?: VocabStore | null }
): WordHubData {
  const offline = buildOfflineWordRelationships(params);

  const mergeByWord = <T extends { word: string }>(primary: T[], fallback: T[], max: number): T[] => {
    const out: T[] = [];
    const seen = new Set<string>();
    for (const item of [...primary, ...fallback]) {
      const key = (item?.word || '').trim().toLowerCase();
      if (!key || seen.has(key)) continue;
      seen.add(key);
      out.push(item);
      if (out.length >= max) break;
    }
    return out;
  };

  return {
    ...data,
    synonyms: mergeByWord(data.synonyms || [], offline.synonyms, 6),
    antonyms: mergeByWord(data.antonyms || [], offline.antonyms, 5),
    wordFamily: mergeByWord(data.wordFamily || [], offline.wordFamily, 6),
    relatedWords: mergeByWord(data.relatedWords || [], offline.relatedWords, 6),
  };
}
