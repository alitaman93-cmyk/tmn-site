import { GRAMMAR_EXTRA_DRILLS_PART_1, type CompactDrillPack } from '../data/grammarExtraDrillsPart1';
import { GRAMMAR_EXTRA_DRILLS_PART_2 } from '../data/grammarExtraDrillsPart2';
import type { GrammarExercise, GrammarExerciseType, GrammarLesson } from '../types';

const EXTRA_DRILLS_BY_ID: Record<string, CompactDrillPack> = {
  ...GRAMMAR_EXTRA_DRILLS_PART_1,
  ...GRAMMAR_EXTRA_DRILLS_PART_2,
};

const expandedCache = new Map<string, GrammarExercise[]>();

function cleanToken(word: string): string {
  return word.replace(/^[.,!?;:"'“”()]+|[.,!?;:"'“”()]+$/g, '');
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function unpackExtraDrills(lessonId: string, pack?: CompactDrillPack): GrammarExercise[] {
  if (!pack) return [];
  const out: GrammarExercise[] = [];

  pack.mcq.forEach(([prompt, options, correctIndex, explanationAr], i) => {
    out.push({
      id: `${lessonId}-xmcq-${i + 1}`,
      type: 'mcq',
      prompt,
      options: [...options],
      correctIndex,
      explanationAr,
    });
  });

  pack.fill.forEach(([prompt, acceptedAnswers, hint, explanationAr], i) => {
    out.push({
      id: `${lessonId}-xfill-${i + 1}`,
      type: 'fill_blank',
      prompt,
      acceptedAnswers: [...acceptedAnswers],
      hint,
      explanationAr,
    });
  });

  pack.spot.forEach(([prompt, options, correctIndex, correctedSentence, explanationAr], i) => {
    out.push({
      id: `${lessonId}-xspot-${i + 1}`,
      type: 'spot_error',
      prompt,
      options: [...options],
      correctIndex,
      correctedSentence,
      explanationAr,
    });
  });

  pack.reorder.forEach(([targetSentence, explanationAr], i) => {
    out.push({
      id: `${lessonId}-xreo-${i + 1}`,
      type: 'reorder',
      prompt: 'رتّب الكلمات لتكوين الجملة الإنجليزية الصحيحة:',
      targetSentence,
      explanationAr,
    });
  });

  return out;
}

/**
 * Derives authentic extra fill-in-the-blank, reorder, and spot-error exercises
 * directly from the lesson's verified examples and commonMistakes pairs.
 */
function deriveExercisesFromLesson(lesson: GrammarLesson): GrammarExercise[] {
  const derived: GrammarExercise[] = [];

  // 1) Turn every common mistake pair into a genuine spot-the-error challenge
  lesson.commonMistakes.forEach((m, idx) => {
    const wrongTokens = m.wrong.trim().split(/\s+/).map(cleanToken).filter(Boolean);
    const rightTokens = m.right.trim().split(/\s+/).map(cleanToken).filter(Boolean);

    // Find first differing token in wrong sentence
    let diffToken = '';
    for (let i = 0; i < wrongTokens.length; i++) {
      if ((wrongTokens[i] || '').toLowerCase() !== (rightTokens[i] || '').toLowerCase()) {
        diffToken = wrongTokens[i];
        break;
      }
    }

    if (diffToken && wrongTokens.length >= 4) {
      const uniqueChoices: string[] = [diffToken];
      const lowerSeen = new Set<string>([diffToken.toLowerCase()]);
      for (const tok of wrongTokens) {
        if (uniqueChoices.length >= 4) break;
        const low = tok.toLowerCase();
        if (tok.length >= 2 && !lowerSeen.has(low)) {
          lowerSeen.add(low);
          uniqueChoices.push(tok);
        }
      }

      if (uniqueChoices.length === 4) {
        // Deterministically position the error token so it isn't always index 0
        const targetSlot = (idx + lesson.id.length) % 4;
        const ordered = [...uniqueChoices];
        const [errWord] = ordered.splice(0, 1);
        ordered.splice(targetSlot, 0, errWord);

        derived.push({
          id: `${lesson.id}-mspot-${idx + 1}`,
          type: 'spot_error',
          prompt: m.wrong,
          options: ordered,
          correctIndex: targetSlot,
          correctedSentence: m.right,
          explanationAr: m.noteAr,
        });
      }
    }

    // Also add a sentence-reorder drill on the corrected sentence when natural length (4-11 words)
    const rightWords = m.right.trim().split(/\s+/).filter(Boolean);
    if (rightWords.length >= 4 && rightWords.length <= 11) {
      derived.push({
        id: `${lesson.id}-mreo-${idx + 1}`,
        type: 'reorder',
        prompt: 'رتّب الكلمات لتكوين الجملة الصحيحة وتجنّب الخطأ الشائع:',
        targetSentence: m.right,
        explanationAr: m.noteAr,
      });
    }
  });

  // 2) Turn lesson examples with highlights into authentic fill-in-the-blank & reorder drills
  lesson.examples.forEach((ex, idx) => {
    const cleanEn = ex.en.trim();
    const hl = (ex.highlight || '').trim();
    if (hl && hl.length >= 1 && hl.length <= 28) {
      const re = new RegExp(`(?<![A-Za-z])${escapeRegExp(hl)}(?![A-Za-z])`, 'i');
      if (re.test(cleanEn)) {
        const blanked = cleanEn.replace(re, '___');
        if (blanked !== cleanEn && blanked.includes('___')) {
          derived.push({
            id: `${lesson.id}-efill-${idx + 1}`,
            type: 'fill_blank',
            prompt: `${blanked} (${ex.ar})`,
            acceptedAnswers: [hl],
            hint: lesson.formula.slice(0, 46),
            explanationAr: `الجملة الصحيحة: «${cleanEn}» — ${ex.ar}`,
          });
        }
      }
    }

    const words = cleanEn.split(/\s+/).filter(Boolean);
    if (words.length >= 4 && words.length <= 11) {
      derived.push({
        id: `${lesson.id}-ereo-${idx + 1}`,
        type: 'reorder',
        prompt: `رتّب الجملة الإنجليزية التي تعني: «${ex.ar}»`,
        targetSentence: cleanEn,
        explanationAr: `الترتيب الصحيح: ${cleanEn}`,
      });
    }
  });

  return derived;
}

/**
 * Returns the complete, deduplicated expanded exercise bank for a grammar lesson
 * (original curated + 15 hand-crafted extra drills + derived example/mistake drills = ~25-32 exercises/rule).
 */
export function getExpandedGrammarExercises(lesson: GrammarLesson): GrammarExercise[] {
  const cached = expandedCache.get(lesson.id);
  if (cached) return cached;

  const combined: GrammarExercise[] = [
    ...lesson.exercises,
    ...unpackExtraDrills(lesson.id, EXTRA_DRILLS_BY_ID[lesson.id]),
    ...deriveExercisesFromLesson(lesson),
  ];

  const deduped: GrammarExercise[] = [];
  const seenKeys = new Set<string>();

  for (const ex of combined) {
    const sig = `${ex.type}::${(ex.targetSentence || ex.prompt).trim().toLowerCase()}`;
    if (seenKeys.has(sig)) continue;
    seenKeys.add(sig);
    deduped.push(ex);
  }

  expandedCache.set(lesson.id, deduped);
  return deduped;
}

export function getTotalCurriculumExerciseCount(lessons: GrammarLesson[]): number {
  return lessons.reduce((sum, lesson) => sum + getExpandedGrammarExercises(lesson).length, 0);
}

function seededShuffle<T>(items: T[], seed: number): T[] {
  const arr = [...items];
  let s = (seed || 1) >>> 0;
  for (let i = arr.length - 1; i > 0; i--) {
    s = (s * 1664525 + 1013904223) >>> 0;
    const j = s % (i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/**
 * Builds a balanced practice round of the requested exercise mode and size.
 * When mode === 'all' and roundSize is limited (10 or 20), interleaves all 4 exercise types fairly.
 */
export function buildGrammarPracticeRound(
  allExercises: GrammarExercise[],
  mode: GrammarExerciseType | 'all',
  roundSize: 10 | 20 | 'all',
  shuffleSeed = 0
): GrammarExercise[] {
  const filtered =
    mode === 'all' ? [...allExercises] : allExercises.filter((ex) => ex.type === mode);

  if (filtered.length === 0) return [];

  const ordered =
    mode === 'all'
      ? (() => {
          const buckets: Record<GrammarExerciseType, GrammarExercise[]> = {
            mcq: [],
            fill_blank: [],
            spot_error: [],
            reorder: [],
          };
          for (const ex of filtered) {
            buckets[ex.type].push(ex);
          }
          const types: GrammarExerciseType[] = ['mcq', 'fill_blank', 'spot_error', 'reorder'];
          if (shuffleSeed > 0) {
            for (const t of types) {
              buckets[t] = seededShuffle(buckets[t], shuffleSeed + t.length * 97);
            }
          }
          const interleaved: GrammarExercise[] = [];
          let added = true;
          while (added) {
            added = false;
            for (const t of types) {
              const next = buckets[t].shift();
              if (next) {
                interleaved.push(next);
                added = true;
              }
            }
          }
          return interleaved;
        })()
      : shuffleSeed > 0
        ? seededShuffle(filtered, shuffleSeed)
        : filtered;

  if (roundSize === 'all') return ordered;
  return ordered.slice(0, Math.min(roundSize, ordered.length));
}
