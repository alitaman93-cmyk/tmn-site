import test from 'node:test';
import assert from 'node:assert/strict';
import { GRAMMAR_LESSONS } from '../data/grammarLessons';
import {
  buildGrammarPracticeRound,
  getExpandedGrammarExercises,
  getTotalCurriculumExerciseCount,
} from './grammarPracticeBank';

test('Every single one of the 36 grammar lessons has >= 22 valid, deduplicated exercises and total >= 950', () => {
  assert.equal(GRAMMAR_LESSONS.length, 36);
  const total = getTotalCurriculumExerciseCount(GRAMMAR_LESSONS);
  assert.ok(total >= 950, `Expected >= 950 total grammar exercises, got ${total}`);

  for (const lesson of GRAMMAR_LESSONS) {
    const exercises = getExpandedGrammarExercises(lesson);
    assert.ok(
      exercises.length >= 22,
      `Lesson "${lesson.id}" only has ${exercises.length} exercises (expected >= 22)`
    );

    const ids = new Set<string>();
    const counts = { mcq: 0, fill_blank: 0, spot_error: 0, reorder: 0 };

    for (const ex of exercises) {
      assert.ok(!ids.has(ex.id), `Duplicate exercise id "${ex.id}" in "${lesson.id}"`);
      ids.add(ex.id);
      counts[ex.type] += 1;

      assert.ok(ex.prompt.trim().length > 0, `Empty prompt in ${ex.id}`);
      assert.ok(ex.explanationAr.trim().length > 0, `Empty Arabic explanation in ${ex.id}`);

      if (ex.type === 'mcq' || ex.type === 'spot_error') {
        assert.ok(
          Array.isArray(ex.options) && ex.options.length === 4,
          `${ex.id} must have exactly 4 options`
        );
        assert.ok(
          typeof ex.correctIndex === 'number' && ex.correctIndex >= 0 && ex.correctIndex < 4,
          `${ex.id} has invalid correctIndex`
        );
      }

      if (ex.type === 'fill_blank') {
        assert.ok(ex.prompt.includes('___'), `${ex.id} fill_blank prompt missing ___`);
        assert.ok(
          Array.isArray(ex.acceptedAnswers) && ex.acceptedAnswers.length > 0,
          `${ex.id} fill_blank missing acceptedAnswers`
        );
      }

      if (ex.type === 'reorder') {
        const tokens = (ex.targetSentence || '').trim().split(/\s+/).filter(Boolean);
        assert.ok(tokens.length >= 3, `${ex.id} reorder needs >= 3 words`);
      }
    }

    assert.ok(counts.mcq >= 5, `${lesson.id} needs >= 5 MCQs (got ${counts.mcq})`);
    assert.ok(counts.fill_blank >= 5, `${lesson.id} needs >= 5 fill_blank (got ${counts.fill_blank})`);
    assert.ok(counts.spot_error >= 4, `${lesson.id} needs >= 4 spot_error (got ${counts.spot_error})`);
    assert.ok(counts.reorder >= 4, `${lesson.id} needs >= 4 reorder (got ${counts.reorder})`);
  }
});

test('buildGrammarPracticeRound interleaves all 4 types fairly and supports shuffle & round sizing', () => {
  const firstLesson = GRAMMAR_LESSONS[0];
  const all = getExpandedGrammarExercises(firstLesson);

  const round10 = buildGrammarPracticeRound(all, 'all', 10, 0);
  assert.equal(round10.length, 10);
  const typesInFirst4 = new Set(round10.slice(0, 4).map((e) => e.type));
  assert.equal(typesInFirst4.size, 4, 'First 4 questions in mixed mode should cover all 4 exercise types');

  const round20 = buildGrammarPracticeRound(all, 'all', 20, 42);
  assert.equal(round20.length, 20);

  const mcqOnly = buildGrammarPracticeRound(all, 'mcq', 'all', 7);
  assert.ok(mcqOnly.length >= 5);
  assert.ok(mcqOnly.every((e) => e.type === 'mcq'));
});
