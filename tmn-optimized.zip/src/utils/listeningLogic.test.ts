import assert from 'node:assert/strict';
import test from 'node:test';
import {
  LISTENING_LEVELS,
  TED_LANG_CODE_MAP,
  buildFallbackTranscriptQuiz,
  computeListeningLevelProgress,
  formatDurationMMSS,
  getActiveListeningCue,
} from './listeningLogic';

test('LISTENING_LEVELS defines all 7 CEFR bands A0-C2 with ascending required hours', () => {
  assert.equal(LISTENING_LEVELS.length, 7);
  assert.deepEqual(
    LISTENING_LEVELS.map((l) => l.band),
    ['A0', 'A1', 'A2', 'B1', 'B2', 'C1', 'C2']
  );
  for (let i = 1; i < LISTENING_LEVELS.length; i++) {
    assert.ok(
      LISTENING_LEVELS[i].requiredHours > LISTENING_LEVELS[i - 1].requiredHours,
      `Level ${LISTENING_LEVELS[i].band} should require more listening hours than ${LISTENING_LEVELS[i - 1].band}`
    );
  }
  assert.equal(LISTENING_LEVELS[0].nextBand, 'A1');
  assert.equal(LISTENING_LEVELS[6].nextBand, null);
  assert.equal(Object.keys(TED_LANG_CODE_MAP).length, 10);
});

test('getActiveListeningCue finds exact synchronized caption cue across timestamps', () => {
  const cues = [
    { startSec: 0, endSec: 3.5, text: 'Hello everyone.' },
    { startSec: 3.6, endSec: 7.2, text: 'Today we talk about oceans.' },
    { startSec: 7.3, endSec: 12.0, text: 'Water covers most of our planet.' },
  ];
  assert.equal(getActiveListeningCue(cues, 1.0)?.text, 'Hello everyone.');
  assert.equal(getActiveListeningCue(cues, 5.4)?.text, 'Today we talk about oceans.');
  assert.equal(getActiveListeningCue(cues, 10.1)?.text, 'Water covers most of our planet.');
  assert.equal(getActiveListeningCue([], 2.0), null);
});

test('computeListeningLevelProgress computes watched hours, remaining hours, and percentage accurately', () => {
  const a0 = LISTENING_LEVELS[0]; // 5 hours = 18000s
  const half = computeListeningLevelProgress(a0, {
    watchedSec: 9000,
    completedVideoIds: ['v1', 'v2', 'v3'],
    quizScores: { v1: 100 },
  });
  assert.equal(half.watchedHours, 2.5);
  assert.equal(half.remainingHours, 2.5);
  assert.equal(half.percent, 50);
  assert.equal(half.completedCount, 3);

  const capped = computeListeningLevelProgress(a0, {
    watchedSec: 25000,
    completedVideoIds: ['v1'],
    quizScores: {},
  });
  assert.equal(capped.percent, 100);
  assert.equal(capped.remainingHours, 0);
});

test('buildFallbackTranscriptQuiz creates valid video-specific MCQ comprehension questions', () => {
  const cues = [
    { startSec: 0, endSec: 4, text: 'Sunlight powers almost every ecosystem on Earth today.' },
    { startSec: 4, endSec: 8, text: 'Scientists discovered glowing creatures deep beneath the ocean surface.' },
    { startSec: 8, endSec: 12, text: 'These remarkable organisms communicate using blue bioluminescent light.' },
    { startSec: 12, endSec: 16, text: 'Protecting marine habitats ensures biodiversity survives for future generations.' },
    { startSec: 16, endSec: 20, text: 'Exploration requires patience, curiosity, and careful teamwork.' },
    { startSec: 20, endSec: 24, text: 'Together we can understand the hidden wonders of the deep sea.' },
  ];
  const quiz = buildFallbackTranscriptQuiz('Glowing life underwater', 'Dr. Edith Widder', cues);
  assert.ok(quiz.length >= 4 && quiz.length <= 5);
  for (const q of quiz) {
    assert.equal(q.options.length, 4);
    assert.ok(q.correctIndex >= 0 && q.correctIndex < 4);
    assert.ok(q.question.length > 10);
    assert.ok(q.explanation.length > 10);
  }
  assert.equal(formatDurationMMSS(125), '2:05');
  assert.equal(formatDurationMMSS(3665), '1:01:05');
});
