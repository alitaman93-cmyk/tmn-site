import test from 'node:test';
import assert from 'node:assert/strict';
import type { WordHubData } from '../types';
import { buildOfflineWordUsage, enrichWordHubWithOfflineUsage } from './wordUsageOffline';

test('buildOfflineWordUsage returns rich curated usage for high-frequency words offline', () => {
  const usage = buildOfflineWordUsage({ word: 'make', ar: 'يصنع / يفعل', posEn: 'verb', band: 'A1' });
  assert.ok(usage.collocations.length >= 3);
  assert.ok(usage.collocations.some((c) => c.phrase.toLowerCase().includes('decision')));
  assert.ok(usage.examples.length >= 3);
  assert.ok(usage.commonMistakes.length >= 1);
  assert.ok(usage.phrasalVerbs.length >= 1);
  assert.ok(usage.idioms.length >= 1);
  assert.ok(usage.formalVsInformal.registerLabelAr.length > 0);
  assert.ok(usage.usageNotes.length >= 2);
});

test('buildOfflineWordUsage guarantees complete non-empty usage for rare C2 words offline', () => {
  const usage = buildOfflineWordUsage({
    word: 'perspicacious',
    ar: 'ثاقب البصيرة',
    posEn: 'adjective',
    band: 'C2',
  });
  assert.ok(usage.collocations.length >= 3);
  assert.ok(usage.examples.length >= 3);
  assert.ok(usage.examples.every((ex) => ex.en.toLowerCase().includes('perspicacious')));
  assert.ok(usage.examples.every((ex) => ex.ar.length > 0));
  assert.ok(usage.commonMistakes.length >= 1);
  assert.equal(usage.formalVsInformal.registerLabel, 'Formal');
  assert.ok(usage.usageNotes.length >= 2);
});

test('buildOfflineWordUsage pulls real matching sentences from extra offline corpus when available', () => {
  const usage = buildOfflineWordUsage({
    word: 'umbrella',
    ar: 'مظلة',
    posEn: 'noun',
    band: 'A2',
    extraCorpus: [
      {
        en: 'Do not forget to bring your umbrella because it looks cloudy.',
        ar: 'لا تنسَ إحضار مظلتك لأن الجو يبدو غائماً.',
      },
    ],
  });
  assert.ok(
    usage.examples.some((ex) => ex.en.includes('bring your umbrella')),
    'Should include matching sentence from offline corpus'
  );
  assert.ok(usage.collocations.length >= 3);
});

test('enrichWordHubWithOfflineUsage fills empty offline fallback without overwriting existing AI data', () => {
  const emptyHub: WordHubData = {
    word: 'advice',
    posEn: 'noun',
    posAr: 'اسم',
    ipaUs: '/ədˈvaɪs/',
    ipaUk: '/ədˈvaɪs/',
    definitionEn: 'Guidance or recommendations.',
    definitionAr: 'نصيحة',
    synonyms: [],
    antonyms: [],
    wordFamily: [],
    relatedWords: [],
    collocations: [],
    examples: [],
    commonMistakes: [],
    usageNotes: [],
    formalVsInformal: null,
    idioms: [],
    phrasalVerbs: [],
    wordOrigin: '',
    memoryTip: '',
    source: 'offline',
  };

  const enriched = enrichWordHubWithOfflineUsage(emptyHub, { band: 'A2' });
  assert.ok(enriched.collocations.length >= 3);
  assert.ok(enriched.examples.length >= 3);
  assert.ok(enriched.commonMistakes.length >= 1);
  assert.ok(enriched.usageNotes.length >= 2);
  assert.ok(enriched.formalVsInformal !== null);

  // Verify existing AI collocations are preserved, not overwritten
  const aiHub: WordHubData = {
    ...emptyHub,
    collocations: [
      {
        phrase: 'custom ai collocation',
        ar: 'تلازم مخصص',
        exampleEn: 'This is a custom ai collocation.',
        exampleAr: 'هذا تلازم مخصص.',
      },
    ],
  };
  const enrichedAi = enrichWordHubWithOfflineUsage(aiHub, { band: 'A2' });
  assert.equal(enrichedAi.collocations[0].phrase, 'custom ai collocation');
});

test('buildOfflineWordUsage gives function words like "the" natural grammatical collocations', () => {
  const usage = buildOfflineWordUsage({ word: 'the', ar: 'ال', band: 'A0' });
  assert.ok(usage.collocations.length >= 3);
  assert.ok(
    !usage.collocations.some((c) => c.phrase.toLowerCase().includes('important the')),
    'must never produce ungrammatical "important the"'
  );
  assert.ok(usage.commonMistakes.length >= 1);
  assert.ok(usage.usageNotes.length >= 2);
  assert.equal(usage.formalVsInformal.registerLabel, 'Neutral');
});
