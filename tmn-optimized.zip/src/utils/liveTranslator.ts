import type { UiLanguageCode as AppLang } from '../types';
import { hotCacheGet, hotCacheSet, idbMediaGet, idbMediaSet } from './storage';
import { lookupLocalUiTranslation } from './uiPhrasebook';

const UI_TR_TTL_MS = 45 * 24 * 60 * 60 * 1000;

const ARABIC_CHAR_RE = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]/;

const ramCache = new Map<string, string>();
const inFlight = new Map<string, Promise<string>>();

export function containsArabic(text: string): boolean {
  return Boolean(text && ARABIC_CHAR_RE.test(text));
}

function makeCacheKey(lang: AppLang, text: string): string {
  return `ui::${lang}::${text}`;
}

export function getCachedUiTranslation(lang: AppLang, text: string): string | null {
  if (lang === 'ar' || !text) return text;
  const trimmed = text.trim();
  if (!trimmed || !containsArabic(trimmed)) return text;

  const key = makeCacheKey(lang, trimmed);
  const ram = ramCache.get(key);
  if (ram) return preserveWhitespace(text, ram);

  const localHit = lookupLocalUiTranslation(lang, trimmed);
  if (localHit) {
    ramCache.set(key, localHit);
    return preserveWhitespace(text, localHit);
  }

  const hot = hotCacheGet<string>('ui_tr', key);
  if (hot && !containsArabic(hot)) {
    ramCache.set(key, hot);
    return preserveWhitespace(text, hot);
  }
  return null;
}

function preserveWhitespace(original: string, translated: string): string {
  const lead = original.match(/^\s*/)?.[0] ?? '';
  const trail = original.match(/\s*$/)?.[0] ?? '';
  return `${lead}${translated.trim()}${trail}`;
}

function storeTranslation(lang: AppLang, originalTrimmed: string, translated: string): void {
  const clean = translated.trim();
  if (!clean) return;
  const key = makeCacheKey(lang, originalTrimmed);
  ramCache.set(key, clean);
  hotCacheSet('ui_tr', key, clean);
  void idbMediaSet('sentencesAr', key, clean, UI_TR_TTL_MS);
}

export async function translateArabicUiBatch(
  rawTexts: string[],
  lang: AppLang,
  backendUrl = ''
): Promise<Map<string, string>> {
  const result = new Map<string, string>();
  if (lang === 'ar' || rawTexts.length === 0) return result;

  const uniqueTrimmed = Array.from(
    new Set(rawTexts.map((t) => t.trim()).filter((t) => t.length > 0 && containsArabic(t)))
  );
  if (uniqueTrimmed.length === 0) return result;

  const pendingPromises: Array<{ text: string; promise: Promise<string> }> = [];
  const needLookup: string[] = [];

  for (const text of uniqueTrimmed) {
    const key = makeCacheKey(lang, text);
    const ram = ramCache.get(key);
    if (ram) {
      result.set(text, ram);
      continue;
    }
    const localHit = lookupLocalUiTranslation(lang, text);
    if (localHit) {
      ramCache.set(key, localHit);
      result.set(text, localHit);
      continue;
    }
    const hot = hotCacheGet<string>('ui_tr', key);
    if (hot && !containsArabic(hot)) {
      ramCache.set(key, hot);
      result.set(text, hot);
      continue;
    }
    const existing = inFlight.get(key);
    if (existing) {
      pendingPromises.push({ text, promise: existing });
      continue;
    }
    needLookup.push(text);
  }

  // Check IndexedDB before hitting network
  const missingFromDb: string[] = [];
  if (needLookup.length > 0) {
    const idbResults = await Promise.all(
      needLookup.map(async (text) => {
        const key = makeCacheKey(lang, text);
        const val = await idbMediaGet<string>('sentencesAr', key);
        return { text, val };
      })
    );
    for (const { text, val } of idbResults) {
      if (val && typeof val === 'string' && !containsArabic(val)) {
        const key = makeCacheKey(lang, text);
        ramCache.set(key, val);
        hotCacheSet('ui_tr', key, val);
        result.set(text, val);
      } else {
        missingFromDb.push(text);
      }
    }
  }

  // Fetch missing strings via server batch route (fast LRU + GTX), fallback to direct GTX
  if (missingFromDb.length > 0) {
    const CHUNK_SIZE = 36;
    const chunks: string[][] = [];
    for (let i = 0; i < missingFromDb.length; i += CHUNK_SIZE) {
      chunks.push(missingFromDb.slice(i, i + CHUNK_SIZE));
    }

    await Promise.all(
      chunks.map(async (chunk) => {
        const resolvers = new Map<string, (val: string) => void>();
        chunk.forEach((text) => {
          const key = makeCacheKey(lang, text);
          const p = new Promise<string>((resolve) => {
            resolvers.set(text, resolve);
          });
          inFlight.set(key, p);
        });

        let translatedMap: Record<string, string> = {};
        try {
          const base = (backendUrl || '').replace(/\/+$/, '');
          const controller = new AbortController();
          const timer = window.setTimeout(() => controller.abort(), 5500);
          try {
            const res = await fetch(`${base}/api/translate-ui-batch`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ texts: chunk, targetLang: lang }),
              signal: controller.signal,
            });
            if (res.ok) {
              const data = (await res.json()) as { translations?: Record<string, string> };
              if (data?.translations && typeof data.translations === 'object') {
                translatedMap = data.translations;
              }
            }
          } finally {
            window.clearTimeout(timer);
          }
        } catch {
          // Server unreachable or offline
        }

        chunk.forEach((src) => {
          const key = makeCacheKey(lang, src);
          const tr = (translatedMap[src] || '').trim();
          if (tr && !containsArabic(tr)) {
            storeTranslation(lang, src, tr);
            result.set(src, tr);
            resolvers.get(src)?.(tr);
          } else {
            resolvers.get(src)?.(src);
          }
          inFlight.delete(key);
        });
      })
    );
  }

  if (pendingPromises.length > 0) {
    const settled = await Promise.all(
      pendingPromises.map(async ({ text, promise }) => ({ text, val: await promise }))
    );
    settled.forEach(({ text, val }) => {
      if (val && !containsArabic(val)) {
        result.set(text, val);
      }
    });
  }

  return result;
}
