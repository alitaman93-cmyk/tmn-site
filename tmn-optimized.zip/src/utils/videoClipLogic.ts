import type { VideoCaptionCue, WordVideoClip } from '../types';

export interface RawTranscriptCue {
  /** Timestamp in milliseconds from the beginning of the video */
  time: number;
  /** Raw caption text */
  text: string;
}

export interface SourceVideoMeta {
  videoId: string;
  slug: string;
  title: string;
  speaker: string;
  sourceLabel: string;
  videoUrl: string;
  posterUrl: string;
  durationSec: number;
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Builds a strict word-boundary regex matching the English word and its natural
 * English inflections (plurals, -ed, -ing, -er, -est, -s, -es, y->ies).
 */
export function buildWordMatchRegex(rawWord: string): RegExp {
  const clean = (rawWord || '')
    .trim()
    .toLowerCase()
    .replace(/^to\s+/, '')
    .replace(/[^a-z0-9'\-\s]/g, '')
    .trim();

  if (!clean) return /\b__never_match__\b/i;

  // Multi-word phrase: match exact phrase with flexible whitespace
  if (clean.includes(' ')) {
    const parts = clean.split(/\s+/).filter(Boolean).map(escapeRegExp);
    return new RegExp(`\\b${parts.join('\\s+')}\\b`, 'i');
  }

  const forms = new Set<string>([clean]);
  if (clean.length >= 3) {
    forms.add(`${clean}s`);
    forms.add(`${clean}es`);
    forms.add(`${clean}ed`);
    forms.add(`${clean}d`);
    forms.add(`${clean}ing`);
    forms.add(`${clean}er`);
    forms.add(`${clean}est`);
    if (clean.endsWith('e') && clean.length >= 4) {
      const stem = clean.slice(0, -1);
      forms.add(`${stem}ing`);
      forms.add(`${stem}ed`);
      forms.add(`${stem}er`);
      forms.add(`${stem}est`);
    }
    if (clean.endsWith('y') && clean.length >= 4 && !/[aeiou]y$/.test(clean)) {
      const stem = clean.slice(0, -1);
      forms.add(`${stem}ies`);
      forms.add(`${stem}ied`);
      forms.add(`${stem}ier`);
      forms.add(`${stem}iest`);
    }
  }

  const ordered = Array.from(forms).sort((a, b) => b.length - a.length);
  return new RegExp(`\\b(${ordered.map(escapeRegExp).join('|')})\\b`, 'i');
}

/**
 * Computes the exact playback clip window:
 * 3 seconds BEFORE the word is spoken and 3 seconds AFTER it is spoken,
 * clamped cleanly to [0, videoDurationSec].
 */
export function computeWordClipWindow(
  wordStartSec: number,
  videoDurationSec: number,
  padBefore = 3,
  padAfter = 3
): {
  startSec: number;
  endSec: number;
  clipDurationSec: number;
  wordOffsetPct: number;
} {
  const safeDur = Math.max(6, Number.isFinite(videoDurationSec) ? videoDurationSec : 120);
  const safeWordSec = Math.max(0, Math.min(safeDur, Number.isFinite(wordStartSec) ? wordStartSec : 0));

  let startSec = Math.max(0, safeWordSec - padBefore);
  let endSec = Math.min(safeDur, safeWordSec + padAfter);

  // Guarantee a clean ~6s window near video boundaries when possible
  if (endSec - startSec < padBefore + padAfter) {
    if (startSec === 0) {
      endSec = Math.min(safeDur, padBefore + padAfter);
    } else if (endSec === safeDur) {
      startSec = Math.max(0, safeDur - (padBefore + padAfter));
    }
  }

  startSec = Number(startSec.toFixed(2));
  endSec = Number(Math.max(startSec + 1.5, endSec).toFixed(2));
  const clipDurationSec = Number((endSec - startSec).toFixed(2));
  const rawPct = clipDurationSec > 0 ? ((safeWordSec - startSec) / clipDurationSec) * 100 : 50;
  const wordOffsetPct = Math.max(5, Math.min(95, Math.round(rawPct)));

  return { startSec, endSec, clipDurationSec, wordOffsetPct };
}

function cleanCaptionText(text: string): string {
  return (text || '')
    .replace(/\r?\n/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Extracts verified, exact-timestamp 6-second clips (±3s around each spoken occurrence)
 * from a video's timed English transcript cues.
 */
export function extractWordClipsFromCues(
  video: SourceVideoMeta,
  rawCues: RawTranscriptCue[],
  targetWord: string,
  maxPerVideo = 4
): WordVideoClip[] {
  if (!video.videoUrl || !rawCues.length) return [];

  const regex = buildWordMatchRegex(targetWord);
  const normalizedCues: VideoCaptionCue[] = rawCues
    .filter((c) => c && typeof c.text === 'string' && Number.isFinite(c.time))
    .map((c, idx, arr) => {
      const startSec = Math.max(0, c.time / 1000);
      const nextSec = arr[idx + 1] ? arr[idx + 1].time / 1000 : startSec + 4.2;
      const endSec = Math.max(startSec + 1.1, Math.min(startSec + 8.5, nextSec));
      return {
        startSec: Number(startSec.toFixed(2)),
        endSec: Number(endSec.toFixed(2)),
        text: cleanCaptionText(c.text),
      };
    })
    .filter((c) => c.text.length > 0);

  if (!normalizedCues.length) return [];

  const results: WordVideoClip[] = [];
  let lastAcceptedWordSec = -999;

  for (let i = 0; i < normalizedCues.length; i++) {
    if (results.length >= maxPerVideo) break;
    const cue = normalizedCues[i];
    const match = regex.exec(cue.text);
    if (!match) continue;

    // Estimate the exact second inside the cue when the target word is spoken
    const charRatio = cue.text.length > 1 ? match.index / cue.text.length : 0.3;
    const cueDur = Math.max(1.0, cue.endSec - cue.startSec);
    const wordStartSec = Number((cue.startSec + charRatio * cueDur).toFixed(2));

    // Keep at least 9 seconds between clips from the same video so clips feel distinct
    if (wordStartSec - lastAcceptedWordSec < 9) continue;
    lastAcceptedWordSec = wordStartSec;

    const { startSec, endSec } = computeWordClipWindow(wordStartSec, video.durationSec, 3, 3);

    // Gather all overlapping synchronized captions inside [startSec, endSec]
    const windowCues = normalizedCues.filter(
      (c) => c.endSec >= startSec + 0.15 && c.startSec <= endSec - 0.15
    );

    const captionText = cue.text;
    results.push({
      id: `${video.videoId}-${Math.round(wordStartSec * 10)}`,
      word: targetWord,
      matchedTerm: match[0],
      videoUrl: video.videoUrl,
      posterUrl: video.posterUrl,
      title: video.title,
      speaker: video.speaker,
      sourceLabel: video.sourceLabel,
      wordStartSec,
      startSec,
      endSec,
      durationSec: video.durationSec,
      captionText,
      cues: windowCues.length > 0 ? windowCues : [cue],
    });
  }

  return results;
}

/**
 * Returns the live English caption line for a given playback time inside a clip.
 */
export function getActiveCaptionAtTime(clip: WordVideoClip, currentTimeSec: number): string {
  if (!clip.cues || clip.cues.length === 0) return clip.captionText;
  const active = clip.cues.find(
    (c) => currentTimeSec >= c.startSec - 0.2 && currentTimeSec <= c.endSec + 0.15
  );
  return active ? active.text : clip.captionText;
}

/**
 * Computes lookahead indices to speculatively preload ahead of user swiping/clicking Next.
 */
export function getNextPrefetchIndices(
  currentIndex: number,
  totalCount: number,
  lookahead = 3
): number[] {
  if (totalCount <= 1) return [];
  const out: number[] = [];
  const safeIdx = Math.max(0, Math.min(currentIndex, totalCount - 1));
  for (let offset = 1; offset <= lookahead; offset++) {
    const idx = safeIdx + offset;
    if (idx < totalCount) out.push(idx);
  }
  if (safeIdx - 1 >= 0) {
    out.push(safeIdx - 1);
  }
  return out;
}

/**
 * Deduplicates clips across paginated server fetches while preserving relevance order.
 */
export function dedupeVideoClips(clips: WordVideoClip[]): WordVideoClip[] {
  const seen = new Set<string>();
  const out: WordVideoClip[] = [];
  for (const clip of clips) {
    const bucketKey = `${clip.videoUrl}::${Math.round(clip.startSec / 4)}`;
    if (seen.has(clip.id) || seen.has(bucketKey)) continue;
    seen.add(clip.id);
    seen.add(bucketKey);
    out.push(clip);
  }
  return out;
}

export function formatSecondsShort(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}:${rem < 10 ? '0' : ''}${rem}`;
}

export interface SentenceVideoClipMatch extends WordVideoClip {
  matchScore: number;
  matchKind: 'exact_sentence' | 'contiguous_phrase';
}

const CONTRACTION_EXPANSIONS: Array<[RegExp, string]> = [
  [/\bi'm\b/gi, 'i am'],
  [/\byou're\b/gi, 'you are'],
  [/\bwe're\b/gi, 'we are'],
  [/\bthey're\b/gi, 'they are'],
  [/\bhe's\b/gi, 'he is'],
  [/\bshe's\b/gi, 'she is'],
  [/\bit's\b/gi, 'it is'],
  [/\bthat's\b/gi, 'that is'],
  [/\bthere's\b/gi, 'there is'],
  [/\bwhat's\b/gi, 'what is'],
  [/\bwhere's\b/gi, 'where is'],
  [/\bwho's\b/gi, 'who is'],
  [/\bcan't\b/gi, 'cannot'],
  [/\bwon't\b/gi, 'will not'],
  [/\bdon't\b/gi, 'do not'],
  [/\bdoesn't\b/gi, 'does not'],
  [/\bdidn't\b/gi, 'did not'],
  [/\bisn't\b/gi, 'is not'],
  [/\baren't\b/gi, 'are not'],
  [/\bwasn't\b/gi, 'was not'],
  [/\bweren't\b/gi, 'were not'],
  [/\bhaven't\b/gi, 'have not'],
  [/\bhasn't\b/gi, 'has not'],
  [/\bhadn't\b/gi, 'had not'],
  [/\bwouldn't\b/gi, 'would not'],
  [/\bcouldn't\b/gi, 'could not'],
  [/\bshouldn't\b/gi, 'should not'],
  [/\bi've\b/gi, 'i have'],
  [/\byou've\b/gi, 'you have'],
  [/\bwe've\b/gi, 'we have'],
  [/\bthey've\b/gi, 'they have'],
  [/\bi'll\b/gi, 'i will'],
  [/\byou'll\b/gi, 'you will'],
  [/\bwe'll\b/gi, 'we will'],
  [/\bthey'll\b/gi, 'they will'],
  [/\bi'd\b/gi, 'i would'],
  [/\byou'd\b/gi, 'you would'],
  [/\blet's\b/gi, 'let us'],
];

/**
 * Strips synonym suffixes (`=...`), smart quotes, and punctuation while keeping apostrophes.
 */
export function cleanSentenceForVideoSearch(rawSentence: string): string {
  const base = (rawSentence || '').split('=')[0].trim();
  return base
    .replace(/[“”"]/g, '')
    .replace(/[’`]/g, "'")
    .replace(/[^a-zA-Z0-9'\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function expandEnglishContractionsForMatch(text: string): string {
  let out = (text || '').replace(/[’`]/g, "'");
  for (const [rx, replacement] of CONTRACTION_EXPANSIONS) {
    out = out.replace(rx, replacement);
  }
  return out.replace(/\s+/g, ' ').trim();
}

function tokenizeSentenceWords(text: string): string[] {
  return cleanSentenceForVideoSearch(text)
    .toLowerCase()
    .replace(/'/g, '')
    .split(/\s+/)
    .filter(Boolean);
}

/**
 * Builds prioritized TED search queries for a full sentence:
 * 1. Exact quoted full sentence
 * 2. Contraction-expanded quoted sentence (when different)
 * 3. Unquoted clean full sentence
 * 4. Longest contiguous 4-5 word core phrase for very long sentences
 */
export function buildSentenceSearchQueries(rawSentence: string): string[] {
  const clean = cleanSentenceForVideoSearch(rawSentence);
  if (!clean) return [];

  const expanded = expandEnglishContractionsForMatch(clean);
  const queries: string[] = [];
  const seen = new Set<string>();

  const pushUnique = (q: string) => {
    const trimmed = q.trim();
    if (!trimmed) return;
    const key = trimmed.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    queries.push(trimmed);
  };

  pushUnique(`"${clean}"`);
  if (expanded.toLowerCase() !== clean.toLowerCase()) {
    pushUnique(`"${expanded}"`);
  }
  pushUnique(clean);

  const words = clean.split(/\s+/).filter(Boolean);
  if (words.length >= 6) {
    // Also try a 4-word contiguous core chunk (first 4 and last 4 words) to locate exact TED talks
    pushUnique(`"${words.slice(0, 4).join(' ')}"`);
    pushUnique(`"${words.slice(-4).join(' ')}"`);
  }

  return queries;
}

/**
 * Builds a regex matching a sequence of English words allowing optional punctuation/spaces between them.
 */
function buildContiguousPhraseRegex(words: string[]): RegExp {
  const pattern = words
    .map((w) => {
      const escaped = escapeRegExp(w);
      // Allow apostrophe inside words like dont / don't
      return escaped;
    })
    .join("['’]?[\\s,;:.!?\\-–—]+");
  return new RegExp(`\\b${pattern}\\b`, 'i');
}

/**
 * Builds a flexible regex that matches either contracted or expanded forms of the full sentence
 * across transcript text (including punctuation breaks between cues).
 */
export function buildSentenceMatchRegex(rawSentence: string): RegExp {
  const clean = cleanSentenceForVideoSearch(rawSentence);
  if (!clean) return /\b__never_match__\b/i;

  const variants = new Set<string>([clean, expandEnglishContractionsForMatch(clean)]);
  const patterns: string[] = [];
  for (const variant of variants) {
    const words = variant
      .split(/\s+/)
      .map((w) => w.trim())
      .filter(Boolean);
    if (words.length === 0) continue;
    patterns.push(
      words.map((w) => escapeRegExp(w).replace(/'/g, "['’]?")).join("[\\s,;:.!?\\-–—]+")
    );
  }
  if (!patterns.length) return /\b__never_match__\b/i;
  return new RegExp(`\\b(?:${patterns.join('|')})\\b`, 'i');
}

/**
 * Extracts verified video clips where the FULL target sentence (or a >=72% contiguous
 * multi-word phrase of at least 3 words for longer sentences) is actually spoken.
 * Merges 1–3 adjacent timed cues so sentences split across subtitle lines still match cleanly.
 * Strictly rejects isolated single-word matches!
 */
export function extractSentenceClipsFromCues(
  video: SourceVideoMeta,
  rawCues: RawTranscriptCue[],
  targetSentence: string,
  maxPerVideo = 3
): SentenceVideoClipMatch[] {
  if (!video.videoUrl || !rawCues.length) return [];

  const cleanTarget = cleanSentenceForVideoSearch(targetSentence);
  if (!cleanTarget) return [];

  const targetWords = cleanTarget.split(/\s+/).filter(Boolean);
  if (targetWords.length <= 1) {
    // Delegate single-word targets to the word extractor
    return extractWordClipsFromCues(video, rawCues, cleanTarget, maxPerVideo).map((clip) => ({
      ...clip,
      matchScore: 100,
      matchKind: 'exact_sentence',
    }));
  }

  const normalizedCues: VideoCaptionCue[] = rawCues
    .filter((c) => c && typeof c.text === 'string' && Number.isFinite(c.time))
    .map((c, idx, arr) => {
      const startSec = Math.max(0, c.time / 1000);
      const nextSec = arr[idx + 1] ? arr[idx + 1].time / 1000 : startSec + 4.2;
      const endSec = Math.max(startSec + 1.1, Math.min(startSec + 8.5, nextSec));
      return {
        startSec: Number(startSec.toFixed(2)),
        endSec: Number(endSec.toFixed(2)),
        text: cleanCaptionText(c.text),
      };
    })
    .filter((c) => c.text.length > 0);

  if (!normalizedCues.length) return [];

  const exactRegex = buildSentenceMatchRegex(cleanTarget);

  // Build candidate contiguous sub-phrases ONLY for sentences with >= 4 words,
  // requiring at least 3 consecutive words and >= 72% sentence coverage (never single words!).
  const subPhraseMatchers: Array<{ regex: RegExp; score: number }> = [];
  const rawTokens = targetWords;
  if (rawTokens.length >= 4) {
    const minSubLen = Math.max(3, Math.ceil(rawTokens.length * 0.72));
    for (let len = rawTokens.length - 1; len >= minSubLen; len--) {
      const score = Math.round((len / rawTokens.length) * 92);
      for (let start = 0; start <= rawTokens.length - len; start++) {
        const chunk = rawTokens.slice(start, start + len);
        subPhraseMatchers.push({
          regex: buildContiguousPhraseRegex(chunk),
          score,
        });
      }
    }
  }

  const candidates: SentenceVideoClipMatch[] = [];
  let lastAcceptedSec = -999;

  for (let i = 0; i < normalizedCues.length; i++) {
    if (candidates.length >= maxPerVideo * 2) break;

    let bestMatch: {
      matchedText: string;
      spanStartSec: number;
      spanEndSec: number;
      combinedText: string;
      score: number;
      kind: 'exact_sentence' | 'contiguous_phrase';
      anchorCue: VideoCaptionCue;
    } | null = null;

    // Try 1-cue, 2-cue, and 3-cue merged windows so sentences spanning subtitle breaks match cleanly
    for (let span = 1; span <= 3 && i + span <= normalizedCues.length; span++) {
      const slice = normalizedCues.slice(i, i + span);
      // Avoid merging cues separated by a huge silence gap
      if (span > 1 && slice[span - 1].startSec - slice[0].endSec > 3.5) break;

      const combinedRaw = slice.map((c) => c.text).join(' ');
      const combinedExpanded = expandEnglishContractionsForMatch(combinedRaw);

      const exactRaw = exactRegex.exec(combinedRaw);
      const exactExp = exactRaw ? null : exactRegex.exec(combinedExpanded);
      if (exactRaw || exactExp) {
        const hitText = (exactRaw ? exactRaw[0] : exactExp![0]).trim();
        const hitIdx = exactRaw ? exactRaw.index : exactExp!.index;
        const totalLen = Math.max(1, (exactRaw ? combinedRaw : combinedExpanded).length);
        const spanDur = Math.max(1.2, slice[span - 1].endSec - slice[0].startSec);
        const estStart = slice[0].startSec + (hitIdx / totalLen) * spanDur;
        const estEnd = Math.min(
          slice[span - 1].endSec,
          estStart + Math.max(1.6, (hitText.length / totalLen) * spanDur)
        );

        bestMatch = {
          matchedText: hitText,
          spanStartSec: Number(estStart.toFixed(2)),
          spanEndSec: Number(estEnd.toFixed(2)),
          combinedText: combinedRaw,
          score: 100,
          kind: 'exact_sentence',
          anchorCue: slice[0],
        };
        break; // Prefer shortest cue span containing the exact full sentence
      }

      if (!bestMatch && subPhraseMatchers.length > 0) {
        for (const sub of subPhraseMatchers) {
          const m = sub.regex.exec(combinedRaw);
          if (m) {
            const hitText = m[0].trim();
            const totalLen = Math.max(1, combinedRaw.length);
            const spanDur = Math.max(1.2, slice[span - 1].endSec - slice[0].startSec);
            const estStart = slice[0].startSec + (m.index / totalLen) * spanDur;
            const estEnd = Math.min(
              slice[span - 1].endSec,
              estStart + Math.max(1.5, (hitText.length / totalLen) * spanDur)
            );
            bestMatch = {
              matchedText: hitText,
              spanStartSec: Number(estStart.toFixed(2)),
              spanEndSec: Number(estEnd.toFixed(2)),
              combinedText: combinedRaw,
              score: sub.score,
              kind: 'contiguous_phrase',
              anchorCue: slice[0],
            };
            break;
          }
        }
      }
    }

    if (!bestMatch) continue;
    if (bestMatch.spanStartSec - lastAcceptedSec < 10) continue;
    lastAcceptedSec = bestMatch.spanStartSec;

    // Cover the ENTIRE spoken sentence with generous ±2.5s..3.2s padding anchored to cue start so first word never clips
    const safeDur = Math.max(8, Number.isFinite(video.durationSec) ? video.durationSec : 180);
    const clipAnchorStart = Math.min(bestMatch.anchorCue.startSec, bestMatch.spanStartSec);
    const startSec = Number(Math.max(0, clipAnchorStart - 2.5).toFixed(2));
    const endSec = Number(
      Math.min(safeDur, Math.max(bestMatch.spanEndSec + 3.2, startSec + 6.5)).toFixed(2)
    );

    const windowCues = normalizedCues.filter(
      (c) => c.endSec >= startSec + 0.15 && c.startSec <= endSec - 0.15
    );

    // Extra sanity check: ensure normalized words overlap genuinely (guards regex edge cases)
    const matchedWordCount = tokenizeSentenceWords(bestMatch.matchedText).length;
    if (matchedWordCount < Math.min(targetWords.length, 2)) continue;

    candidates.push({
      id: `${video.videoId}-s-${Math.round(bestMatch.spanStartSec * 10)}`,
      word: cleanTarget,
      matchedTerm: bestMatch.matchedText,
      videoUrl: video.videoUrl,
      posterUrl: video.posterUrl,
      title: video.title,
      speaker: video.speaker,
      sourceLabel: video.sourceLabel,
      wordStartSec: bestMatch.spanStartSec,
      startSec,
      endSec,
      durationSec: video.durationSec,
      captionText: bestMatch.combinedText,
      cues: windowCues.length > 0 ? windowCues : [bestMatch.anchorCue],
      matchScore: bestMatch.score,
      matchKind: bestMatch.kind,
    });
  }

  return candidates
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, maxPerVideo);
}

