import type { CefrBand, VocabEntry, VocabStore } from '../types';

export type WordleTileState = 'correct' | 'present' | 'absent' | 'empty';

export interface BlitzQuestion {
  target: VocabEntry;
  direction: 'en2ar' | 'ar2en';
  prompt: string;
  options: Array<{ id: number; label: string; isCorrect: boolean }>;
}

export interface MemoryCardItem {
  uid: string;
  pairId: number;
  wordId: number;
  side: 'en' | 'ar';
  text: string;
  band: CefrBand;
  matched: boolean;
}

export interface RocketGameState {
  word: string;
  maskedChars: Array<{ ch: string; revealed: boolean }>;
  wrongLetters: string[];
  wrongCount: number;
  maxWrong: number;
  remainingAttempts: number;
  status: 'playing' | 'won' | 'lost';
}

const FALLBACK_FIVE_LETTER_WORDS: VocabEntry[] = [
  { id: -1, band: 'A1', en: 'apple', ar: 'تفاحة' },
  { id: -2, band: 'A1', en: 'water', ar: 'ماء' },
  { id: -3, band: 'A1', en: 'house', ar: 'منزل' },
  { id: -4, band: 'A1', en: 'happy', ar: 'سعيد' },
  { id: -5, band: 'A1', en: 'music', ar: 'موسيقى' },
  { id: -6, band: 'A1', en: 'table', ar: 'طاولة' },
  { id: -7, band: 'A1', en: 'bread', ar: 'خبز' },
  { id: -8, band: 'A1', en: 'light', ar: 'ضوء' },
  { id: -9, band: 'A1', en: 'smile', ar: 'ابتسامة' },
  { id: -10, band: 'A1', en: 'world', ar: 'عالم' },
  { id: -11, band: 'A2', en: 'train', ar: 'قطار' },
  { id: -12, band: 'A2', en: 'beach', ar: 'شاطئ' },
  { id: -13, band: 'A2', en: 'dream', ar: 'حلم' },
  { id: -14, band: 'A2', en: 'plant', ar: 'نبات' },
  { id: -15, band: 'A2', en: 'voice', ar: 'صوت' },
  { id: -16, band: 'B1', en: 'smart', ar: 'ذكي' },
  { id: -17, band: 'B1', en: 'focus', ar: 'تركيز' },
  { id: -18, band: 'B1', en: 'trust', ar: 'ثقة' },
  { id: -19, band: 'B1', en: 'brave', ar: 'شجاع' },
  { id: -20, band: 'B2', en: 'craft', ar: 'حرفة / إتقان' },
];

export function createSeededRng(seed: number): () => number {
  let state = (Math.floor(seed) >>> 0) || 123456789;
  return () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state / 0x100000000;
  };
}

export function hashString(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function shuffleWithRng<T>(items: readonly T[], rng: () => number): T[] {
  const arr = items.slice();
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/**
 * Returns clean single-word 5-letter ASCII English vocabulary entries.
 */
export function getFiveLetterWords(store: VocabStore, band: CefrBand | 'ALL' = 'ALL'): VocabEntry[] {
  const filtered = store.words.filter((w) => {
    if (band !== 'ALL' && w.band !== band) return false;
    const clean = w.en.trim().toLowerCase();
    return /^[a-z]{5}$/.test(clean) && Boolean(w.ar?.trim());
  });
  if (filtered.length >= 5) return filtered;
  if (band !== 'ALL') {
    const allFiltered = store.words.filter(
      (w) => /^[a-z]{5}$/.test(w.en.trim().toLowerCase()) && Boolean(w.ar?.trim())
    );
    if (allFiltered.length >= 5) return allFiltered;
  }
  return FALLBACK_FIVE_LETTER_WORDS;
}

/**
 * Deterministic daily 5-letter English word keyed to today's date string.
 */
export function pickDailyWordleWord(store: VocabStore, dateKey: string): VocabEntry {
  const pool = getFiveLetterWords(store, 'ALL');
  const idx = hashString(`tmn-wordle-${dateKey}`) % pool.length;
  return pool[idx];
}

export function pickRandomWordleWord(
  store: VocabStore,
  band: CefrBand | 'ALL',
  seed: number = Date.now(),
  excludeId?: number
): VocabEntry {
  const pool = getFiveLetterWords(store, band);
  const rng = createSeededRng(seed);
  if (pool.length === 1) return pool[0];
  let pick = pool[Math.floor(rng() * pool.length)];
  if (excludeId !== undefined && pick.id === excludeId) {
    pick = pool[(pool.indexOf(pick) + 1) % pool.length];
  }
  return pick;
}

/**
 * Exact 2-pass Wordle evaluation handling duplicate letters faithfully.
 */
export function evaluateWordleGuess(guessRaw: string, targetRaw: string): WordleTileState[] {
  const guess = guessRaw.trim().toLowerCase();
  const target = targetRaw.trim().toLowerCase();
  const len = target.length;
  const result: WordleTileState[] = Array.from({ length: len }, () => 'absent');
  const remaining: Record<string, number> = {};

  // Pass 1: exact matches
  for (let i = 0; i < len; i++) {
    if (guess[i] === target[i]) {
      result[i] = 'correct';
    } else {
      const ch = target[i];
      remaining[ch] = (remaining[ch] || 0) + 1;
    }
  }

  // Pass 2: wrong-position matches respecting remaining letter counts
  for (let i = 0; i < len; i++) {
    if (result[i] === 'correct') continue;
    const ch = guess[i];
    if (remaining[ch] && remaining[ch] > 0) {
      result[i] = 'present';
      remaining[ch] -= 1;
    }
  }

  return result;
}

const KEY_STATE_RANK: Record<WordleTileState, number> = {
  empty: 0,
  absent: 1,
  present: 2,
  correct: 3,
};

export function mergeWordleKeyStates(
  prev: Record<string, WordleTileState>,
  guessRaw: string,
  states: WordleTileState[]
): Record<string, WordleTileState> {
  const next = { ...prev };
  const guess = guessRaw.trim().toLowerCase();
  for (let i = 0; i < states.length && i < guess.length; i++) {
    const ch = guess[i];
    const current = next[ch] || 'empty';
    const candidate = states[i];
    if (KEY_STATE_RANK[candidate] > KEY_STATE_RANK[current]) {
      next[ch] = candidate;
    }
  }
  return next;
}

/**
 * Combo multiplier for 60-Second Speed Blitz & Sentence Blitz:
 * x1 (0-2), x2 (3-5), x3 (6-9), x5 (10+).
 */
export function getBlitzMultiplier(streak: number): 1 | 2 | 3 | 5 {
  if (streak >= 10) return 5;
  if (streak >= 6) return 3;
  if (streak >= 3) return 2;
  return 1;
}

export function getFilteredBandWords(store: VocabStore, band: CefrBand | 'ALL'): VocabEntry[] {
  const base =
    band === 'ALL'
      ? store.words
      : (store.byBand[band] || []).map((idx) => store.words[idx]).filter(Boolean);
  const clean = base.filter((w) => w && w.en.trim().length > 0 && w.ar.trim().length > 0);
  return clean.length >= 6 ? clean : store.words.filter((w) => w.en.trim() && w.ar.trim());
}

export function buildBlitzQuestion(
  store: VocabStore,
  band: CefrBand | 'ALL',
  seed: number,
  recentWordIds: Set<number> = new Set(),
  questionNumber = 0
): BlitzQuestion {
  const rng = createSeededRng(seed);
  const pool = getFilteredBandWords(store, band);
  const candidates = pool.filter((w) => !recentWordIds.has(w.id));
  const pickPool = candidates.length >= 4 ? candidates : pool;
  const target = pickPool[Math.floor(rng() * pickPool.length)] || store.words[0];
  const direction: 'en2ar' | 'ar2en' = Math.floor(questionNumber / 4) % 2 === 0 ? 'en2ar' : 'ar2en';

  const distractors: VocabEntry[] = [];
  const usedLabels = new Set<string>([
    direction === 'en2ar' ? target.ar.trim().toLowerCase() : target.en.trim().toLowerCase(),
  ]);
  let guard = 0;
  while (distractors.length < 3 && guard < 120 && pool.length > 1) {
    guard++;
    const cand = pool[Math.floor(rng() * pool.length)];
    if (!cand || cand.id === target.id) continue;
    const labelKey =
      direction === 'en2ar' ? cand.ar.trim().toLowerCase() : cand.en.trim().toLowerCase();
    if (usedLabels.has(labelKey)) continue;
    usedLabels.add(labelKey);
    distractors.push(cand);
  }

  const options = shuffleWithRng(
    [
      {
        id: target.id,
        label: direction === 'en2ar' ? target.ar : target.en,
        isCorrect: true,
      },
      ...distractors.map((d) => ({
        id: d.id,
        label: direction === 'en2ar' ? d.ar : d.en,
        isCorrect: false,
      })),
    ],
    rng
  );

  return {
    target,
    direction,
    prompt: direction === 'en2ar' ? target.en : target.ar,
    options,
  };
}

/**
 * Builds a shuffled Memory Flip deck of 6 pairs (12 cards) or 8 pairs (16 cards).
 */
export function buildMemoryDeck(
  store: VocabStore,
  band: CefrBand | 'ALL',
  pairCount: 6 | 8,
  seed: number = Date.now()
): MemoryCardItem[] {
  const rng = createSeededRng(seed);
  const pool = getFilteredBandWords(store, band);
  const shuffledPool = shuffleWithRng(pool, rng);
  const picked: VocabEntry[] = [];
  const seenAr = new Set<string>();
  const seenEn = new Set<string>();

  for (const w of shuffledPool) {
    const enKey = w.en.trim().toLowerCase();
    const arKey = w.ar.trim().toLowerCase();
    if (enKey.length > 18 || seenEn.has(enKey) || seenAr.has(arKey)) continue;
    seenEn.add(enKey);
    seenAr.add(arKey);
    picked.push(w);
    if (picked.length >= pairCount) break;
  }

  const cards: MemoryCardItem[] = [];
  picked.forEach((w, idx) => {
    cards.push({
      uid: `en-${w.id}-${idx}`,
      pairId: idx,
      wordId: w.id,
      side: 'en',
      text: w.en,
      band: w.band,
      matched: false,
    });
    cards.push({
      uid: `ar-${w.id}-${idx}`,
      pairId: idx,
      wordId: w.id,
      side: 'ar',
      text: w.ar,
      band: w.band,
      matched: false,
    });
  });

  return shuffleWithRng(cards, rng);
}

/**
 * Picks a clean single English word (4–10 letters) for Save the Rocket.
 */
export function pickRocketWord(
  store: VocabStore,
  band: CefrBand | 'ALL',
  seed: number = Date.now(),
  excludeIds: Set<number> = new Set()
): VocabEntry {
  const pool = getFilteredBandWords(store, band).filter((w) => {
    const clean = w.en.trim().toLowerCase();
    return /^[a-z]{4,10}$/.test(clean) && !excludeIds.has(w.id);
  });
  const source = pool.length > 0 ? pool : getFiveLetterWords(store, band);
  const rng = createSeededRng(seed);
  return source[Math.floor(rng() * source.length)] || FALLBACK_FIVE_LETTER_WORDS[0];
}

export function evaluateRocketState(
  wordRaw: string,
  guessedLetters: readonly string[],
  maxWrong = 6
): RocketGameState {
  const word = wordRaw.trim().toLowerCase();
  const guessedSet = new Set(guessedLetters.map((c) => c.toLowerCase()));
  const wordLetterSet = new Set(word.split('').filter((c) => /[a-z]/.test(c)));

  const wrongLetters = Array.from(guessedSet).filter((c) => /[a-z]/.test(c) && !wordLetterSet.has(c));
  const wrongCount = wrongLetters.length;
  const remainingAttempts = Math.max(0, maxWrong - wrongCount);

  const maskedChars = word.split('').map((ch) => ({
    ch,
    revealed: !/[a-z]/.test(ch) || guessedSet.has(ch),
  }));

  const allRevealed = maskedChars.every((item) => item.revealed);
  const status: 'playing' | 'won' | 'lost' = allRevealed
    ? 'won'
    : wrongCount >= maxWrong
      ? 'lost'
      : 'playing';

  return {
    word,
    maskedChars,
    wrongLetters,
    wrongCount,
    maxWrong,
    remainingAttempts,
    status,
  };
}

export function pickRocketHintLetter(wordRaw: string, guessedLetters: readonly string[]): string | null {
  const word = wordRaw.trim().toLowerCase();
  const guessedSet = new Set(guessedLetters.map((c) => c.toLowerCase()));
  for (const ch of word) {
    if (/[a-z]/.test(ch) && !guessedSet.has(ch)) {
      return ch;
    }
  }
  return null;
}

export function computeWordRainSpeed(score: number): number {
  // Smooth percentage-of-arena-per-second progression: approachable opening (~10%/s), caps at ~23%/s
  return Math.min(23, 10 + Math.floor(score / 40) * 1.15);
}
