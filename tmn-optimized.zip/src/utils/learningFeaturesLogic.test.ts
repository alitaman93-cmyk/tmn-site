import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import type { PersistedSettings, VocabStore } from '../types';
import {
  build30DayHeatmap,
  buildAnkiCsvExport,
  buildDailyPlan,
  computeAchievementBadges,
  createMistakeFixerSession,
  DAILY_PLAN_BONUS_XP,
  getIsoWeekKey,
  getMistakeFixerPhase,
  getUnlockedCertificateBands,
  markDailyPlanStep,
  MISTAKE_FIXER_GRADUATION_XP,
  paceToDailyGoal,
  recordDailyStudyActivity,
  submitMistakeFixerAnswer,
} from './learningFeaturesLogic';

function makeSettings(overrides: Partial<PersistedSettings> = {}): PersistedSettings {
  return {
    levelSize: 20,
    dailyGoal: 20,
    todayDate: '2026-11-26',
    todayCount: 0,
    theme: 'dark',
    uiLang: 'ar',
    sfx: true,
    autoSpeak: false,
    ttsRate: 0.92,
    mcqDir: 'en2ar',
    lastGame: 'missing',
    lastBand: 'A2',
    lastSubLevel: 1,
    xp: 100,
    streak: 4,
    bestStreak: 6,
    completed: {},
    mistakes: [],
    favorites: [],
    mastered: [],
    favoriteSentences: [],
    practicedSentences: [],
    srsCards: {},
    completedGrammarIds: [],
    savedWordNotes: [],
    wordMastery: {},
    onboardingCompleted: true,
    learningGoal: 'daily_chat',
    dailyPaceMinutes: 10,
    dailyPlanDate: '2026-11-26',
    dailyPlanSteps: {},
    dailySentencesCount: 0,
    studyHistory: {},
    streakFreezes: 1,
    lastFreezeWeek: getIsoWeekKey('2026-11-25'),
    lastActiveDate: '2026-11-25',
    pixabayKey: '',
    unsplashKey: '',
    backendUrl: '',
    usingCustom: false,
    customSourceName: '',
    ...overrides,
  };
}

describe('learningFeaturesLogic', () => {
  it('maps onboarding daily pace minutes cleanly to dailyGoal targets', () => {
    assert.equal(paceToDailyGoal(5), 10);
    assert.equal(paceToDailyGoal(10), 20);
    assert.equal(paceToDailyGoal(20), 40);
  });

  it('tracks daily study plan steps and awards +50 XP bonus exactly once when all 4 steps complete', () => {
    let settings = makeSettings();
    const today = '2026-11-26';

    let plan = buildDailyPlan(settings, 4, today);
    assert.equal(plan.steps.length, 4);
    assert.equal(plan.completedCount, 0);
    assert.equal(plan.allCompleted, false);

    for (const stepId of ['srs', 'words', 'sentences'] as const) {
      const res = markDailyPlanStep(settings, stepId, today);
      assert.equal(res.newlyCompletedStep, true);
      assert.equal(res.awardedDailyBonusXp, 0);
      settings = { ...settings, ...res.settingsPatch };
    }

    // Complete 4th step -> triggers +50 XP bonus
    const finalRes = markDailyPlanStep(settings, 'grammarOrListening', today);
    assert.equal(finalRes.newlyCompletedStep, true);
    assert.equal(finalRes.awardedDailyBonusXp, DAILY_PLAN_BONUS_XP);
    settings = { ...settings, ...finalRes.settingsPatch };
    assert.equal(settings.xp, 100 + DAILY_PLAN_BONUS_XP);

    // Repeating an already-completed step does NOT re-award bonus XP
    const dupRes = markDailyPlanStep(settings, 'words', today);
    assert.equal(dupRes.newlyCompletedStep, false);
    assert.equal(dupRes.awardedDailyBonusXp, 0);

    plan = buildDailyPlan(settings, 0, today);
    assert.equal(plan.completedCount, 4);
    assert.equal(plan.allCompleted, true);
    assert.equal(plan.bonusClaimed, true);
  });

  it('auto-protects streak with Streak Freeze when missing 1 day and replenishes freeze on a new week', () => {
    // Last active Nov 23 -> returning Nov 25 (missed Nov 24 = 1 missed day, gap = 2)
    const settings = makeSettings({
      streak: 5,
      bestStreak: 5,
      streakFreezes: 1,
      lastActiveDate: '2026-11-23',
      lastFreezeWeek: getIsoWeekKey('2026-11-23'),
    });

    const protectedRes = recordDailyStudyActivity(settings, 3, '2026-11-25');
    assert.equal(protectedRes.usedStreakFreeze, true);
    assert.equal(protectedRes.settingsPatch.streak, 6);
    assert.equal(protectedRes.settingsPatch.streakFreezes, 0);
    assert.equal(protectedRes.settingsPatch.studyHistory?.['2026-11-25'], 3);

    // Next week (Dec 2) replenishes 1 free freeze automatically
    const afterUsed: PersistedSettings = { ...settings, ...protectedRes.settingsPatch };
    const nextWeekRes = recordDailyStudyActivity(afterUsed, 2, '2026-12-02');
    assert.equal(nextWeekRes.replenishedFreeze, true);
    assert.equal(nextWeekRes.settingsPatch.streakFreezes, 1);
  });

  it('builds a 30-day heatmap with correct intensity buckets 0..4', () => {
    const cells = build30DayHeatmap(
      {
        '2026-11-26': 25,
        '2026-11-25': 12,
        '2026-11-24': 5,
        '2026-11-23': 1,
      },
      '2026-11-26'
    );
    assert.equal(cells.length, 30);
    assert.equal(cells[29].isoDate, '2026-11-26');
    assert.equal(cells[29].level, 4);
    assert.equal(cells[28].level, 3);
    assert.equal(cells[27].level, 2);
    assert.equal(cells[26].level, 1);
    assert.equal(cells[25].level, 0);
  });

  it('graduates a word from Mistake Fixer after 2 consecutive correct answers and awards +15 XP', () => {
    let state = createMistakeFixerSession([10, 20], 8);
    assert.equal(getMistakeFixerPhase(state), 'listen');

    // Word 10: 1st correct -> stays in queue, no graduation yet
    const r1 = submitMistakeFixerAnswer(state, true);
    assert.equal(r1.graduatedWordId, null);
    assert.equal(r1.xpAwarded, 0);
    state = r1.nextState;
    assert.equal(getMistakeFixerPhase(state), 'choose');

    // Word 20: wrong -> resets consecutive count, stays in queue
    const r2 = submitMistakeFixerAnswer(state, false);
    assert.equal(r2.graduatedWordId, null);
    state = r2.nextState;
    assert.equal(state.progress[20].consecutiveCorrect, 0);
    assert.equal(getMistakeFixerPhase(state), 'type');

    // Word 10 again: 2nd consecutive correct -> graduates + awards +15 XP!
    const r3 = submitMistakeFixerAnswer(state, true);
    assert.equal(r3.graduatedWordId, 10);
    assert.equal(r3.xpAwarded, MISTAKE_FIXER_GRADUATION_XP);
    assert.deepEqual(r3.nextState.graduatedIds, [10]);
    assert.equal(r3.nextState.totalXpEarned, MISTAKE_FIXER_GRADUATION_XP);
  });

  it('computes achievement badges, unlocked certificates, and UTF-8 BOM Anki CSV export', () => {
    const settings = makeSettings({
      mastered: Array.from({ length: 12 }, (_, i) => i),
      xp: 1200,
      streak: 8,
    });
    const badges = computeAchievementBadges(settings);
    assert.equal(badges.find((b) => b.id === 'first_10')?.unlocked, true);
    assert.equal(badges.find((b) => b.id === 'streak_7')?.unlocked, true);
    assert.equal(badges.find((b) => b.id === 'xp_1000')?.unlocked, true);

    const mockStore: VocabStore = {
      words: Array.from({ length: 12 }, (_, i) => ({
        id: i,
        en: `word${i}`,
        ar: `كلمة ${i}`,
        band: 'A0',
      })),
      byBand: {
        A0: Array.from({ length: 12 }, (_, i) => i),
        A1: [],
        A2: [],
        B1: [],
        B2: [],
        C1: [],
        C2: [],
      },
      normEn: Array.from({ length: 12 }, (_, i) => `word${i}`),
      normAr: Array.from({ length: 12 }, (_, i) => `كلمة ${i}`),
    };
    const certs = getUnlockedCertificateBands(settings, mockStore);
    assert.equal(certs.some((c) => c.band === 'A0'), true);

    const csv = buildAnkiCsvExport(
      [mockStore.words[0]],
      [
        {
          id: 'n1',
          parentWord: 'bright',
          kind: 'synonym',
          text: 'radiant',
          meaningAr: 'مشرق',
          savedAt: Date.now(),
        },
      ],
      [{ en: 'Hello, world!', ar: 'مرحباً بالعالم!' }]
    );
    assert.ok(csv.startsWith('\uFEFFFront,Back,Tags'));
    assert.ok(csv.includes('word0,كلمة 0,TMN word A0'));
    assert.ok(csv.includes('"Hello, world!"'));
  });
});
