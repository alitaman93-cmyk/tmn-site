import type { GrammarCategoryId, GrammarExerciseType, UiLanguageCode } from '../types';

export interface ListeningGrammarStrings {
  navListening: string;
  navGrammar: string;
  // Listening Hub
  listeningTitle: string;
  listeningDesc: string;
  hoursToNext: string;
  hoursMastery: string;
  catalogHoursLabel: string;
  videosCountLabel: string;
  watchedHoursLabel: string;
  remainingLabel: string;
  openLevelBtn: string;
  backToLevels: string;
  backToVideos: string;
  searchVideosPlaceholder: string;
  loadingCatalog: string;
  loadingVideo: string;
  captionsLabel: string;
  captionsOff: string;
  captionsEnglish: string;
  captionsDual: string;
  captionsAllLanguages: string;
  speedLabel: string;
  transcriptTitle: string;
  showTranscript: string;
  hideTranscript: string;
  quizTitle: string;
  quizSubtitle: string;
  quizStartBtn: string;
  quizSubmitBtn: string;
  quizRetryBtn: string;
  quizNextVideoBtn: string;
  quizPassedMsg: string;
  quizTryAgainMsg: string;
  completedBadge: string;
  // Grammar Academy
  grammarTitle: string;
  grammarDesc: string;
  grammarSearchPlaceholder: string;
  grammarAllCategories: string;
  grammarAllLevels: string;
  grammarMasteredProgress: string;
  grammarBackToAll: string;
  grammarFormulaTitle: string;
  grammarHowTitle: string;
  grammarWhenTitle: string;
  grammarMistakesTitle: string;
  grammarExamplesTitle: string;
  grammarPracticeTitle: string;
  grammarPracticeSub: string;
  grammarTabLearn: string;
  grammarTabPractice: string;
  grammarCheckBtn: string;
  grammarNextQuestion: string;
  grammarFinishPractice: string;
  grammarTypePlaceholder: string;
  grammarTapWrongWord: string;
  grammarTapReorderHint: string;
  grammarResetOrder: string;
  grammarCorrectLabel: string;
  grammarWrongLabel: string;
  grammarRuleCompleted: string;
  grammarMarkComplete: string;
  grammarLocalizing: string;
  categories: Record<GrammarCategoryId, string>;
  exerciseTypes: Record<GrammarExerciseType | 'all', string>;
}

const AR: ListeningGrammarStrings = {
  navListening: 'الاستماع',
  navGrammar: 'القواعد',
  listeningTitle: 'الاستماع الممنهج حسب مستويات CEFR',
  listeningDesc:
    '7 مستويات من A0 إلى C2 — كل مستوى يضم مكتبة فيديوهات حقيقية يعادل مجموع ساعاتها عدد ساعات الاستماع المطلوبة للانتقال إلى المستوى التالي، مع كابشن بـ 11 لغة واختبار فهم بعد كل فيديو.',
  hoursToNext: 'ساعة استماع للانتقال إلى',
  hoursMastery: 'ساعة استماع لإتقان مستوى C2',
  catalogHoursLabel: 'إجمالي ساعات الفيديوهات',
  videosCountLabel: 'فيديو',
  watchedHoursLabel: 'تم إنجازه',
  remainingLabel: 'متبقي للمستوى التالي',
  openLevelBtn: 'دخول المستوى',
  backToLevels: 'جميع المستويات',
  backToVideos: 'فيديوهات المستوى',
  searchVideosPlaceholder: 'ابحث بعنوان الفيديو أو اسم المتحدث...',
  loadingCatalog: 'جاري تجهيز مكتبة فيديوهات المستوى...',
  loadingVideo: 'جاري تحميل الفيديو والترجمات المتزامنة...',
  captionsLabel: 'الكابشن (الترجمة)',
  captionsOff: 'بدون كابشن',
  captionsEnglish: 'English (الإنجليزية)',
  captionsDual: 'مزدوج (EN + لغتي)',
  captionsAllLanguages: 'لغات الترجمة العشر',
  speedLabel: 'السرعة',
  transcriptTitle: 'النص الكامل التفاعلي',
  showTranscript: 'إظهار النص',
  hideTranscript: 'إخفاء النص',
  quizTitle: 'اختبار الفهم بعد الفيديو',
  quizSubtitle: 'أسئلة اختيار من متعدد خاصة بمحتوى هذا الفيديو لتثبيت الفهم واحتساب ساعات الاستماع.',
  quizStartBtn: 'ابدأ اختبار الفيديو',
  quizSubmitBtn: 'تحقق من الإجابة',
  quizRetryBtn: 'إعادة الاختبار',
  quizNextVideoBtn: 'الفيديو التالي',
  quizPassedMsg: 'ممتاز! اجتزت اختبار الفيديو وتمت إضافة مدته إلى ساعات الاستماع الخاصة بك.',
  quizTryAgainMsg: 'محاولة جيدة! راجع الإجابات الصحيحة وأعد الاختبار لتحقيق 60% فأكثر.',
  completedBadge: 'مكتمل',
  grammarTitle: 'أكاديمية قواعد اللغة الإنجليزية الشاملة',
  grammarDesc:
    'جميع قواعد اللغة الإنجليزية من التأسيس A0 حتى الإتقان C2 — شرح مبسّط بلغتك، أمثلة صوتية بالإنجليزية، أخطاء شائعة، واختبارات تفاعلية متنوعة لكل قاعدة.',
  grammarSearchPlaceholder: 'ابحث عن أي قاعدة (مثل: Present Perfect، Passive، Conditionals...)',
  grammarAllCategories: 'كل التصنيفات',
  grammarAllLevels: 'كل المستويات',
  grammarMasteredProgress: 'القواعد المتقنة',
  grammarBackToAll: 'كل القواعد',
  grammarFormulaTitle: 'الصيغة والتركيب',
  grammarHowTitle: 'كيف نستخدم القاعدة؟',
  grammarWhenTitle: 'متى نستخدمها؟',
  grammarMistakesTitle: 'أخطاء شائعة تجنّبها',
  grammarExamplesTitle: 'أمثلة بالإنجليزية مع النطق',
  grammarPracticeTitle: 'اختبارات وألعاب القاعدة',
  grammarPracticeSub: 'تدرّب على القاعدة عبر 4 أنماط: اختيار من متعدد، املأ الفراغ، اكتشف الخطأ، وترتيب الجملة.',
  grammarTabLearn: 'الشرح والأمثلة',
  grammarTabPractice: 'الاختبارات والألعاب',
  grammarCheckBtn: 'تحقق',
  grammarNextQuestion: 'السؤال التالي',
  grammarFinishPractice: 'إنهاء التدريب وإتقان القاعدة',
  grammarTypePlaceholder: 'اكتب الإجابة الإنجليزية هنا...',
  grammarTapWrongWord: 'اضغط على الجزء الخاطئ في الجملة أدناه:',
  grammarTapReorderHint: 'اضغط على الكلمات بالترتيب الصحيح لبناء الجملة:',
  grammarResetOrder: 'إعادة الترتيب',
  grammarCorrectLabel: 'إجابة صحيحة!',
  grammarWrongLabel: 'ليست دقيقة — راجع التصحيح:',
  grammarRuleCompleted: 'قاعدة متقنة',
  grammarMarkComplete: 'تحديد القاعدة كمتقنة',
  grammarLocalizing: 'جاري عرض الشرح بلغتك المختارة...',
  categories: {
    foundations: 'الأساسيات وبنية الجملة',
    tenses: 'الأزمنة الإنجليزية',
    modals: 'الأفعال الناقصة',
    modifiers: 'الصفات والظروف والكميات',
    connectors: 'حروف الجر والروابط',
    voice_speech: 'المبني للمجهول والكلام المنقول',
    clauses: 'الشرط وجمل الوصل والمصدر',
    advanced: 'القواعد المتقدمة C1–C2',
  },
  exerciseTypes: {
    all: 'الكل (شامل)',
    mcq: 'اختيار من متعدد',
    fill_blank: 'املأ الفراغ',
    spot_error: 'تصحيح خطأ',
    reorder: 'ترتيب الجملة',
  },
};

const EN_BASE: Omit<ListeningGrammarStrings, 'navListening' | 'navGrammar'> = {
  listeningTitle: 'CEFR Listening Hub (A0–C2)',
  listeningDesc:
    '7 progressive listening levels from A0 to C2 — each level provides real spoken videos totaling the required listening hours to advance, with 11-language captions and a comprehension quiz after every video.',
  hoursToNext: 'listening hours to reach',
  hoursMastery: 'listening hours for C2 mastery',
  catalogHoursLabel: 'Library video hours',
  videosCountLabel: 'videos',
  watchedHoursLabel: 'Completed',
  remainingLabel: 'Remaining for next level',
  openLevelBtn: 'Open Level',
  backToLevels: 'All Levels',
  backToVideos: 'Level Videos',
  searchVideosPlaceholder: 'Search by video title or speaker...',
  loadingCatalog: 'Preparing level video library...',
  loadingVideo: 'Loading video & synchronized captions...',
  captionsLabel: 'Captions',
  captionsOff: 'Captions Off',
  captionsEnglish: 'English',
  captionsDual: 'Dual (EN + My Language)',
  captionsAllLanguages: '10 Translation Languages',
  speedLabel: 'Speed',
  transcriptTitle: 'Interactive Transcript',
  showTranscript: 'Show Transcript',
  hideTranscript: 'Hide Transcript',
  quizTitle: 'Post-Video Comprehension Quiz',
  quizSubtitle: 'Multiple-choice questions about this specific video to verify understanding and log your listening hours.',
  quizStartBtn: 'Start Video Quiz',
  quizSubmitBtn: 'Check Answer',
  quizRetryBtn: 'Retry Quiz',
  quizNextVideoBtn: 'Next Video',
  quizPassedMsg: 'Great job! You passed the video quiz and logged its duration toward your level hours.',
  quizTryAgainMsg: 'Good try! Review the explanations and retry to score 60%+.',
  completedBadge: 'Completed',
  grammarTitle: 'Complete English Grammar Academy',
  grammarDesc:
    'Every English grammar rule from A0 foundations to C2 mastery — clear explanations in your language, spoken examples, common mistakes, and 4 interactive quiz modes per rule.',
  grammarSearchPlaceholder: 'Search any grammar rule (Present Perfect, Passive, Conditionals...)',
  grammarAllCategories: 'All Categories',
  grammarAllLevels: 'All Levels',
  grammarMasteredProgress: 'Rules Mastered',
  grammarBackToAll: 'All Rules',
  grammarFormulaTitle: 'Formula & Structure',
  grammarHowTitle: 'How to Use It',
  grammarWhenTitle: 'When to Use It',
  grammarMistakesTitle: 'Common Mistakes to Avoid',
  grammarExamplesTitle: 'English Examples with Audio',
  grammarPracticeTitle: 'Rule Quizzes & Games',
  grammarPracticeSub: 'Practice with 4 interactive modes: Multiple Choice, Fill in the Blank, Spot the Error, and Sentence Reorder.',
  grammarTabLearn: 'Explanation & Examples',
  grammarTabPractice: 'Quizzes & Games',
  grammarCheckBtn: 'Check',
  grammarNextQuestion: 'Next Question',
  grammarFinishPractice: 'Finish & Mark Mastered',
  grammarTypePlaceholder: 'Type the English answer here...',
  grammarTapWrongWord: 'Tap the incorrect part in the sentence below:',
  grammarTapReorderHint: 'Tap the words in the right grammatical order:',
  grammarResetOrder: 'Reset Order',
  grammarCorrectLabel: 'Correct!',
  grammarWrongLabel: 'Not quite — review the fix:',
  grammarRuleCompleted: 'Mastered',
  grammarMarkComplete: 'Mark as Mastered',
  grammarLocalizing: 'Translating explanation into your selected language...',
  categories: {
    foundations: 'Foundations & Structure',
    tenses: 'English Tenses',
    modals: 'Modal Verbs',
    modifiers: 'Adjectives, Adverbs & Quantifiers',
    connectors: 'Prepositions & Connectors',
    voice_speech: 'Questions, Passive & Reported Speech',
    clauses: 'Conditionals, Relatives & Verb Patterns',
    advanced: 'Advanced C1–C2 Grammar',
  },
  exerciseTypes: {
    all: 'All Modes',
    mcq: 'Multiple Choice',
    fill_blank: 'Fill in the Blank',
    spot_error: 'Spot & Fix Error',
    reorder: 'Sentence Order',
  },
};

const LANG_MAP: Record<UiLanguageCode, ListeningGrammarStrings> = {
  ar: AR,
  hi: {
    ...EN_BASE,
    navListening: 'सुनना',
    navGrammar: 'व्याकरण',
    listeningTitle: 'CEFR सुनने का अभ्यास (A0–C2)',
    hoursToNext: 'घंटे सुनना अगले स्तर के लिए:',
    hoursMastery: 'घंटे C2 पूर्णता के लिए',
    captionsOff: 'कैप्शन बंद',
    captionsEnglish: 'English (अंग्रेज़ी)',
    captionsDual: 'दोहरा (EN + हिन्दी)',
    quizTitle: 'वीडियो के बाद प्रश्नोत्तरी',
    grammarTitle: 'संपूर्ण अंग्रेज़ी व्याकरण अकादमी',
    grammarTabLearn: 'व्याख्या और उदाहरण',
    grammarTabPractice: 'क्विज़ और गेम्स',
    grammarHowTitle: 'इसका उपयोग कैसे करें',
    grammarWhenTitle: 'इसका उपयोग कब करें',
    grammarMistakesTitle: 'सामान्य गलतियों से बचें',
    grammarExamplesTitle: 'ऑडियो के साथ अंग्रेज़ी उदाहरण',
    grammarCheckBtn: 'जाँचें',
    grammarLocalizing: 'आपकी भाषा में व्याख्या तैयार हो रही है...',
  },
  zh: {
    ...EN_BASE,
    navListening: '听力',
    navGrammar: '语法',
    listeningTitle: 'CEFR 分级英语听力 (A0–C2)',
    hoursToNext: '小时听力晋级至',
    hoursMastery: '小时听力精通 C2',
    captionsOff: '关闭字幕',
    captionsEnglish: 'English (英语)',
    captionsDual: '双语字幕 (EN + 中文)',
    quizTitle: '视频理解选择题测验',
    grammarTitle: '完整英语语法学院',
    grammarTabLearn: '讲解与例句',
    grammarTabPractice: '练习与测验',
    grammarHowTitle: '如何使用该语法',
    grammarWhenTitle: '何时使用该语法',
    grammarMistakesTitle: '避免常见错误',
    grammarExamplesTitle: '英语例句与朗读',
    grammarCheckBtn: '检查',
    grammarLocalizing: '正在为您切换中文语法讲解...',
  },
  ru: {
    ...EN_BASE,
    navListening: 'Аудирование',
    navGrammar: 'Грамматика',
    listeningTitle: 'Аудирование CEFR (A0–C2)',
    hoursToNext: 'ч. аудирования до уровня',
    hoursMastery: 'ч. аудирования для C2',
    captionsOff: 'Без субтитров',
    captionsEnglish: 'English (Английский)',
    captionsDual: 'Двойные (EN + Русский)',
    quizTitle: 'Тест после видео',
    grammarTitle: 'Полная академия грамматики',
    grammarTabLearn: 'Объяснение и примеры',
    grammarTabPractice: 'Тесты и игры',
    grammarHowTitle: 'Как использовать',
    grammarWhenTitle: 'Когда использовать',
    grammarMistakesTitle: 'Частые ошибки',
    grammarExamplesTitle: 'Примеры с озвучкой',
    grammarCheckBtn: 'Проверить',
    grammarLocalizing: 'Переводим объяснение на русский...',
  },
  de: {
    ...EN_BASE,
    navListening: 'Hören',
    navGrammar: 'Grammatik',
    listeningTitle: 'CEFR Hörverstehen (A0–C2)',
    hoursToNext: 'Hörstunden bis Niveau',
    hoursMastery: 'Hörstunden für C2-Meisterschaft',
    captionsOff: 'Untertitel aus',
    captionsEnglish: 'English (Englisch)',
    captionsDual: 'Doppelt (EN + Deutsch)',
    quizTitle: 'Quiz zum Video',
    grammarTitle: 'Komplette Englisch-Grammatik',
    grammarTabLearn: 'Erklärung & Beispiele',
    grammarTabPractice: 'Übungen & Spiele',
    grammarHowTitle: 'Wie man es benutzt',
    grammarWhenTitle: 'Wann man es benutzt',
    grammarMistakesTitle: 'Häufige Fehler vermeiden',
    grammarExamplesTitle: 'Beispiele mit Audio',
    grammarCheckBtn: 'Prüfen',
    grammarLocalizing: 'Erklärung wird auf Deutsch geladen...',
  },
  fr: {
    ...EN_BASE,
    navListening: 'Écoute',
    navGrammar: 'Grammaire',
    listeningTitle: 'Compréhension Orale CEFR (A0–C2)',
    hoursToNext: "heures d'écoute pour atteindre",
    hoursMastery: "heures d'écoute pour maîtriser C2",
    captionsOff: 'Sans sous-titres',
    captionsEnglish: 'English (Anglais)',
    captionsDual: 'Double (EN + Français)',
    quizTitle: 'Quiz après la vidéo',
    grammarTitle: 'Académie Complète de Grammaire',
    grammarTabLearn: 'Explication & Exemples',
    grammarTabPractice: 'Quiz & Jeux',
    grammarHowTitle: "Comment l'utiliser",
    grammarWhenTitle: "Quand l'utiliser",
    grammarMistakesTitle: 'Erreurs courantes à éviter',
    grammarExamplesTitle: 'Exemples audio en anglais',
    grammarCheckBtn: 'Vérifier',
    grammarLocalizing: 'Traduction de la leçon en français...',
  },
  es: {
    ...EN_BASE,
    navListening: 'Escucha',
    navGrammar: 'Gramática',
    listeningTitle: 'Comprensión Auditiva CEFR (A0–C2)',
    hoursToNext: 'horas de escucha para pasar a',
    hoursMastery: 'horas de escucha para dominar C2',
    captionsOff: 'Sin subtítulos',
    captionsEnglish: 'English (Inglés)',
    captionsDual: 'Doble (EN + Español)',
    quizTitle: 'Cuestionario del video',
    grammarTitle: 'Academia Completa de Gramática',
    grammarTabLearn: 'Explicación y Ejemplos',
    grammarTabPractice: 'Tests y Juegos',
    grammarHowTitle: 'Cómo se usa',
    grammarWhenTitle: 'Cuándo se usa',
    grammarMistakesTitle: 'Errores comunes que evitar',
    grammarExamplesTitle: 'Ejemplos en inglés con audio',
    grammarCheckBtn: 'Comprobar',
    grammarLocalizing: 'Cargando explicación en español...',
  },
  it: {
    ...EN_BASE,
    navListening: 'Ascolto',
    navGrammar: 'Grammatica',
    listeningTitle: 'Ascolto CEFR (A0–C2)',
    hoursToNext: 'ore di ascolto per passare a',
    hoursMastery: 'ore di ascolto per padroneggiare C2',
    captionsOff: 'Senza sottotitoli',
    captionsEnglish: 'English (Inglese)',
    captionsDual: 'Doppi (EN + Italiano)',
    quizTitle: 'Quiz dopo il video',
    grammarTitle: 'Accademia Completa di Grammatica',
    grammarTabLearn: 'Spiegazione ed Esempi',
    grammarTabPractice: 'Quiz e Giochi',
    grammarHowTitle: 'Come si usa',
    grammarWhenTitle: 'Quando si usa',
    grammarMistakesTitle: 'Errori comuni da evitare',
    grammarExamplesTitle: 'Esempi inglesi con audio',
    grammarCheckBtn: 'Verifica',
    grammarLocalizing: 'Caricamento spiegazione in italiano...',
  },
  pt: {
    ...EN_BASE,
    navListening: 'Escuta',
    navGrammar: 'Gramática',
    listeningTitle: 'Compreensão Auditiva CEFR (A0–C2)',
    hoursToNext: 'horas de escuta para avançar para',
    hoursMastery: 'horas de escuta para dominar C2',
    captionsOff: 'Sem legendas',
    captionsEnglish: 'English (Inglês)',
    captionsDual: 'Dupla (EN + Português)',
    quizTitle: 'Quiz pós-vídeo',
    grammarTitle: 'Academia Completa de Gramática',
    grammarTabLearn: 'Explicação e Exemplos',
    grammarTabPractice: 'Quizzes e Jogos',
    grammarHowTitle: 'Como usar',
    grammarWhenTitle: 'Quando usar',
    grammarMistakesTitle: 'Erros comuns a evitar',
    grammarExamplesTitle: 'Exemplos em inglês com áudio',
    grammarCheckBtn: 'Verificar',
    grammarLocalizing: 'Carregando explicação em português...',
  },
  sv: {
    ...EN_BASE,
    navListening: 'Lyssna',
    navGrammar: 'Grammatik',
    listeningTitle: 'CEFR Hörförståelse (A0–C2)',
    hoursToNext: 'timmar lyssning för att nå',
    hoursMastery: 'timmar lyssning för C2-nivå',
    captionsOff: 'Utan undertexter',
    captionsEnglish: 'English (Engelska)',
    captionsDual: 'Dubbla (EN + Svenska)',
    quizTitle: 'Quiz efter videon',
    grammarTitle: 'Komplett Engelsk Grammatik',
    grammarTabLearn: 'Förklaring & Exempel',
    grammarTabPractice: 'Quiz & Spel',
    grammarHowTitle: 'Hur den används',
    grammarWhenTitle: 'När den används',
    grammarMistakesTitle: 'Vanliga misstag att undvika',
    grammarExamplesTitle: 'Engelska exempel med ljud',
    grammarCheckBtn: 'Kontrollera',
    grammarLocalizing: 'Laddar förklaring på svenska...',
  },
};

export function getListeningGrammarStrings(lang?: UiLanguageCode): ListeningGrammarStrings {
  return LANG_MAP[lang || 'ar'] || LANG_MAP.ar;
}
