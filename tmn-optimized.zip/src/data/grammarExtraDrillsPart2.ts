import type { CompactDrillPack } from './grammarExtraDrillsPart1';

export const GRAMMAR_EXTRA_DRILLS_PART_2: Record<string, CompactDrillPack> = {
  'adjectives-adverbs': {
    mcq: [
      ['The documentary about deep oceans was truly ___.', ['fascinated', 'fascinating', 'fascinate', 'fascinatingly'], 1, 'الصفة المنتهية بـ ing تصف الشيء المسبّب للشعور (الوثائقي).'],
      ['She spoke ___ so that nobody in the library was disturbed.', ['quiet', 'quietly', 'quieter', 'quietness'], 1, 'لوصف كيفية حدوث الفعل (spoke) نستخدم الظرف quietly.'],
      ['He felt ___ after failing the driving test twice.', ['disappointing', 'disappointed', 'disappoint', 'disappointingly'], 1, 'الصفة المنتهية بـ ed تصف شعور الشخص نفسه.'],
      ['The soup smells ___! What spices did you add?', ['deliciously', 'delicious', 'more deliciously', 'delicacy'], 1, 'بعد أفعال الحواس مثل smell / taste / look نستخدم صفة (delicious) لا ظرفاً.'],
      ['She bought a ___ handbag in Milan.', ['leather small Italian', 'small Italian leather', 'Italian leather small', 'leather Italian small'], 1, 'ترتيب الصفات: الحجم (small) ← الأصل (Italian) ← المادة (leather).'],
    ],
    fill: [
      ['He drives very ___ whenever it rains heavily.', ['carefully', 'slowly'], 'careful / slow', 'لوصف طريقة القيادة نستخدم الظرف المنتهي بـ ly.'],
      ['She speaks English remarkably ___ for a beginner.', ['well', 'fluently'], 'good → well', 'الظرف الشاذ من الصفة good هو well.'],
      ['We were really ___ by the sudden plot twist.', ['surprised', 'amazed'], 'surprising / surprised', 'لوصف شعور الأشخاص نستخدم الصفة المنتهية بـ ed.'],
      ['The train arrived ___ despite the heavy snow.', ['fast', 'early', 'late', 'on time'], 'fast / early', 'كلمات مثل fast و early تبقى كما هي كظرف دون إضافة ly.'],
    ],
    spot: [
      ['He ran very fastly to catch the morning bus.', ['He', 'ran', 'fastly', 'bus'], 2, 'He ran very fast to catch the morning bus.', 'كلمة fast ظرف شاذ لا يُضاف لها ly أبداً.'],
      ['The lecture was so bored that I almost fell asleep.', ['lecture', 'was', 'bored', 'asleep'], 2, 'The lecture was so boring that I almost fell asleep.', 'المحاضرة هي سبب الملل فنستخدم boring وليس bored.'],
      ['She sings very good in the school choir.', ['She', 'sings', 'good', 'choir'], 2, 'She sings very well in the school choir.', 'لوصف الفعل sings نستخدم الظرف well وليس الصفة good.'],
    ],
    reorder: [
      ['She solved the difficult problem very quickly.', 'الظرف quickly يصف الفعل solved ويسبقه very.'],
      ['I was excited about the upcoming trip.', 'الصفة المنتهية بـ ed (excited) تصف شعور المتحدث.'],
      ['He wore a stylish black wool coat.', 'ترتيب الصفات: الرأي ← اللون ← المادة.'],
    ],
  },

  'comparatives-superlatives': {
    mcq: [
      ['This laptop is much ___ than my old one.', ['fast', 'faster', 'fastest', 'more fast'], 1, 'الصفة القصيرة في المقارنة تأخذ er + than: faster.'],
      ['Mount Everest is the ___ peak on Earth.', ['high', 'higher', 'highest', 'most high'], 2, 'التفضيل للصفة القصيرة: the + صفة + est.'],
      ['Your pronunciation is getting ___ every single week.', ['gooder', 'more good', 'better', 'best'], 2, 'مقارنة الصفة الشاذة good هي better.'],
      ['This puzzle is ___ complicated than the last one.', ['more', 'most', 'much', 'very'], 0, 'الصفة الطويلة (complicated) تأخذ more ... than في المقارنة.'],
      ['Today’s traffic is ___ as bad as yesterday’s.', ['more', 'not', 'less', 'most'], 1, 'لمقارنة التساوي المنفية نستخدم not as + صفة + as.'],
    ],
    fill: [
      ['Health is ___ important than wealth.', ['more'], 'more / most', 'للمقارنة مع صفة طويلة + than نستخدم more.'],
      ['That was the ___ movie I have ever watched!', ['worst', 'best', 'funniest'], 'bad → worst / good → best', 'التفضيل الشاذ من bad هو worst ومن good هو best.'],
      ['The ___ you practice, the faster you improve.', ['more'], 'The more ..., the ...', 'أسلوب المقارنة المزدوجة: The more ... the faster.'],
      ['Her house is as spacious ___ ours.', ['as'], 'as / than', 'صيغة التساوي هي as + صفة + as.'],
    ],
    spot: [
      ['This phone is more cheaper than the pro model.', ['phone', 'more', 'cheaper', 'model'], 1, 'This phone is cheaper than the pro model.', 'لا نجمع بين more و er معاً؛ نقول cheaper فقط.'],
      ['She is the most tallest player on the team.', ['She', 'most', 'tallest', 'team'], 1, 'She is the tallest player on the team.', 'لا نجمع بين most و est معاً؛ نكتفي بـ the tallest.'],
      ['My new job is much more better than the old one.', ['job', 'more', 'better', 'old'], 1, 'My new job is much better than the old one.', 'better صيغة مقارنة جاهزة ولا تُسبق بـ more.'],
    ],
    reorder: [
      ['This exam was easier than I expected.', 'المقارنة: الصفة المنتهية بـ y تتحول إلى ier + than.'],
      ['He is the kindest person I know.', 'التفضيل: the + الصفة القصيرة + est.'],
      ['The harder you work, the luckier you get.', 'المقارنة المزدوجة للتناسب الطردي.'],
    ],
  },

  'quantifiers-some-any-much': {
    mcq: [
      ['We don’t have ___ time left before the flight.', ['many', 'much', 'a few', 'several'], 1, 'كلمة time غير معدودة وفي النفي نستخدم much.'],
      ['Would you like ___ more tea with your cake?', ['any', 'some', 'many', 'few'], 1, 'في العرض والطلب المهذب نستخدم some حتى في صيغة السؤال.'],
      ['Only ___ students managed to solve the bonus question.', ['a little', 'a few', 'much', 'any'], 1, 'مع الجمع المعدود (students) بمعنى عدد قليل كافٍ نستخدم a few.'],
      ['The coffee is ___ hot to drink right now.', ['enough', 'too', 'many', 'few'], 1, 'قبل الصفة للتعبير عن الزيادة السلبية نستخدم too + صفة + to.'],
      ['She isn’t old ___ to apply for a driver’s license.', ['too', 'enough', 'much', 'very'], 1, 'كلمة enough تأتي بعد الصفة (old enough) وليس قبلها.'],
    ],
    fill: [
      ['Are there ___ vegetarian dishes on the menu?', ['any'], 'some / any', 'في السؤال العام نستخدم any.'],
      ['How ___ cups of coffee do you drink per day?', ['many'], 'much / many', 'كلمة cups معدود جمع فتأخذ How many.'],
      ['There is only a ___ olive oil left in the bottle.', ['little'], 'few / little', 'الزيت غير معدود فيأخذ a little.'],
      ['We have ___ chairs for all the guests.', ['enough', 'many', 'plenty of'], 'enough / many', 'كلمة enough تأتي قبل الاسم (enough chairs).'],
    ],
    spot: [
      ['How much books did you read last summer?', ['How', 'much', 'books', 'summer'], 1, 'How many books did you read last summer?', 'books اسم جمع معدود فيأخذ many وليس much.'],
      ['He is enough tall to reach the top shelf.', ['He', 'enough', 'tall', 'shelf'], 1, 'He is tall enough to reach the top shelf.', 'تأتي enough بعد الصفة (tall enough) وليس قبلها.'],
      ['I don’t have some cash in my wallet today.', ['don’t', 'some', 'cash', 'wallet'], 1, "I don't have any cash in my wallet today.", 'في الجملة المنفية نستخدم any بدلاً من some.'],
    ],
    reorder: [
      ['There is too much noise in this street.', 'too much تُستخدم قبل الاسم غير المعدود noise.'],
      ['She has enough experience for this role.', 'enough تسبق الاسم experience.'],
      ['Would you like some fresh orange juice?', 'في العرض المهذب نستخدم some.'],
    ],
  },

  'prepositions-time-place': {
    mcq: [
      ['Our graduation ceremony is ___ June 15th.', ['in', 'on', 'at', 'by'], 1, 'مع التواريخ والأيام المحددة نستخدم on.'],
      ['The café opens every day ___ 7:30 a.m.', ['in', 'on', 'at', 'until'], 2, 'مع الساعات والأوقات الدقيقة نستخدم at.'],
      ['Please submit your essay ___ Friday at the latest.', ['until', 'by', 'on', 'in'], 1, 'للحد الأقصى (موعد التسليم النهائي) نستخدم by.'],
      ['I stayed at the office ___ 9 p.m. to finish the launch.', ['by', 'until', 'at', 'in'], 1, 'لاستمرار فعل حتى نقطة زمنية نستخدم until.'],
      ['We usually travel to the mountains ___ winter.', ['at', 'on', 'in', 'by'], 2, 'مع الفصول والشهور والسنوات نستخدم in.'],
    ],
    fill: [
      ['She was born ___ 1998 in Amman.', ['in'], 'in / on / at', 'السنوات تأخذ حرف الجر in.'],
      ['Let’s meet ___ the entrance of the museum.', ['at'], 'in / on / at', 'للنقطة المكانية المحددة نستخدم at.'],
      ['The picture is hanging ___ the wall above the sofa.', ['on'], 'in / on / at', 'للأسطح الملامسة نستخدم on.'],
      ['I have a dentist appointment ___ Monday morning.', ['on'], 'in / on / at', 'أيام الأسبوع وأجزاؤها تأخذ on.'],
    ],
    spot: [
      ['We have a team meeting in Thursday afternoon.', ['team', 'meeting', 'in', 'Thursday'], 2, 'We have a team meeting on Thursday afternoon.', 'مع أيام الأسبوع نستخدم on وليس in.'],
      ['She arrived to the airport two hours early.', ['She', 'arrived', 'to', 'airport'], 2, 'She arrived at the airport two hours early.', 'الفعل arrive يأخذ at للأماكن و in للمدن، ولا يأخذ to.'],
      ['I will wait here by you come back.', ['wait', 'here', 'by', 'back'], 2, 'I will wait here until you come back.', 'للاستمرار في الانتظار حتى وقوع حدث نستخدم until وليس by.'],
    ],
    reorder: [
      ['The flight departs at midnight on Sunday.', 'الساعة/الوقت الدقيق يأخذ at واليوم يأخذ on.'],
      ['Please finish the report by five o’clock.', 'نستخدم by لتحديد الموعد النهائي للتسليم.'],
      ['The keys are in the top drawer.', 'للأماكن المغلقة من الداخل نستخدم in.'],
    ],
  },

  'conjunctions-linking': {
    mcq: [
      ['___ the heavy rain, the outdoor concert went ahead.', ['Although', 'Despite', 'However', 'Even though'], 1, 'بعد Despite يأتي اسم أو عبارة اسمية (the heavy rain) لا جملة كاملة.'],
      ['___ she was exhausted, she stayed up to help her son.', ['Despite', 'In spite of', 'Although', 'However'], 2, 'بعد Although تأتي جملة كاملة (فاعل + فعل).'],
      ['The hotel was expensive; ___, the service was outstanding.', ['although', 'despite', 'however', 'while'], 2, 'بعد الفاصلة المنقوطة وقبل الفاصلة نستخدم however للربط بين جملتين.'],
      ['He missed the train ___ he woke up late.', ['because of', 'because', 'despite', 'although'], 1, 'بعد because تأتي جملة كاملة (فاعل + فعل).'],
      ['The picnic was canceled ___ the sudden sandstorm.', ['because', 'although', 'because of', 'whereas'], 2, 'بعد because of يأتي اسم (the sudden sandstorm).'],
    ],
    fill: [
      ['In ___ of the tight deadline, the team delivered great work.', ['spite'], 'spite / despite', 'التعبير الكامل هو In spite of (ويعادل Despite).'],
      ['Even ___ he studied all night, the test felt challenging.', ['though'], 'though / despite', 'التعبير الكامل للتناقض مع جملة كاملة هو Even though.'],
      ['I love warm summers, ___ my brother prefers snowy winters.', ['whereas', 'while', 'but'], 'whereas / while', 'للمقارنة المتقابلة بين فكرتين نستخدم whereas أو while.'],
      ['She practiced daily; ___, her fluency improved dramatically.', ['therefore', 'consequently', 'as a result', 'thus'], 'therefore / consequently', 'لبيان النتيجة بعد فاصلة منقوطة نستخدم therefore أو consequently.'],
    ],
    spot: [
      ['Despite of the cold weather, we went swimming.', ['Despite', 'of', 'weather', 'swimming'], 1, 'Despite the cold weather, we went swimming.', 'لا نضع of بعد Despite أبداً؛ of تأتي فقط مع In spite of.'],
      ['Although it was raining, but we walked home.', ['Although', 'raining', 'but', 'walked'], 2, 'Although it was raining, we walked home.', 'لا نجمع بين Although و but في نفس الجملة الإنجليزية.'],
      ['He stayed home because of he had a fever.', ['stayed', 'because of', 'had', 'fever'], 1, 'He stayed home because he had a fever.', 'قبل الجملة الكاملة (he had) نستخدم because بدون of.'],
    ],
    reorder: [
      ['Although it was late, we kept working.', 'جملة Although تأتي كاملة بفاعل وفعل ثم فاصلة.'],
      ['Despite the traffic, she arrived on time.', 'Despite يتبعها الاسم the traffic ثم الجملة الرئيسية.'],
      ['The task was hard; however, we succeeded.', 'تأتي however بين فاصلة منقوطة وفاصلة للربط التناقضي.'],
    ],
  },

  'questions-tags': {
    mcq: [
      ['You’ve been to Rome before, ___?', ['haven’t you', 'didn’t you', 'aren’t you', 'don’t you'], 0, 'الجملة فيها have مثبتة فيكون السؤال المذيّل haven’t you.'],
      ['Could you tell me where ___?', ['is the nearest bank', 'the nearest bank is', 'does the bank', 'is bank'], 1, 'في السؤال غير المباشر يعود الترتيب إلى جملة خبرية (الفاعل قبل الفعل).'],
      ['Let’s grab some coffee after class, ___?', ['will we', 'shall we', 'don’t we', 'aren’t we'], 1, 'السؤال المذيّل بعد Let’s هو دائماً shall we.'],
      ['She rarely eats fast food, ___?', ['doesn’t she', 'does she', 'isn’t she', 'did she'], 1, 'كلمة rarely تحمل معنى النفي فيكون السؤال المذيّل مثبتاً: does she.'],
      ['I’m right about this formula, ___?', ['amn’t I', 'aren’t I', 'isn’t I', 'don’t I'], 1, 'السؤال المذيّل الشاذ لـ I am هو aren’t I.'],
    ],
    fill: [
      ['He didn’t forget the appointment, ___ he?', ['did'], 'did / didn’t', 'الجملة منفية بـ didn’t فيكون المذيّل مثبتاً: did he.'],
      ['Do you know what time the movie ___?', ['starts', 'begins'], 'starts / does start', 'في السؤال غير المباشر لا نستخدم does بل نُصرّف الفعل مباشرة.'],
      ['Open the window for a minute, ___ you?', ['will', 'would', 'could'], 'will / would', 'السؤال المذيّل بعد الأمر المهذب هو will you.'],
      ['They won’t cancel the trip, ___ they?', ['will'], 'will / won’t', 'الجملة منفية بـ won’t فيكون المذيّل مثبتاً: will they.'],
    ],
    spot: [
      ['Could you tell me where does she live?', ['Could', 'where', 'does', 'live'], 2, 'Could you tell me where she lives?', 'في السؤال غير المباشر نحذف does ونُبقي الترتيب الخبري.'],
      ['She can swim very fast, doesn’t she?', ['She', 'can', 'fast', "doesn’t"], 3, "She can swim very fast, can't she?", 'الفعل المساعد في الجملة هو can فيجب أن يكون المذيّل can’t she.'],
      ['Nobody called while I was out, didn’t they?', ['Nobody', 'called', 'out', "didn’t"], 3, 'Nobody called while I was out, did they?', 'Nobody تعطي معنى النفي فيكون السؤال المذيّل مثبتاً did they.'],
    ],
    reorder: [
      ['Do you know where the station is?', 'في السؤال غير المباشر يأتي الفاعل (the station) قبل الفعل (is).'],
      ['She speaks French fluently, doesn’t she?', 'جملة مضارع بسيط مثبتة تتبعها ذيل منفي doesn’t she.'],
      ['Let’s start the meeting early, shall we?', 'السؤال المذيّل القياسي بعد Let’s هو shall we.'],
    ],
  },

  'passive-voice': {
    mcq: [
      ['English ___ in more than seventy countries worldwide.', ['speaks', 'is spoken', 'spoke', 'speaking'], 1, 'حقيقة حاضرة بالمبني للمجهول: is + التصريف الثالث spoken.'],
      ['The Eiffel Tower ___ in 1889.', ['built', 'was built', 'is built', 'has built'], 1, 'حدث ماضٍ محدد بالمبني للمجهول: was + V3.'],
      ['The road ___ right now, so please take another route.', ['is repairing', 'is being repaired', 'repaired', 'has repaired'], 1, 'المضارع المستمر في المبني للمجهول: is being + V3.'],
      ['All the invitations ___ already ___.', ['have / sent', 'have / been sent', 'are / sending', 'were / send'], 1, 'المضارع التام في المبني للمجهول: have been + V3.'],
      ['This report must ___ before 5 p.m. today.', ['submit', 'be submitted', 'submitted', 'been submitted'], 1, 'بعد الأفعال الناقصة في المجهول: modal + be + V3.'],
    ],
    fill: [
      ['This bridge was ___ by a famous architect.', ['designed', 'built'], 'design / build', 'الماضي البسيط للمجهول: was + V3.'],
      ['Your package will ___ delivered tomorrow morning.', ['be'], 'be / been / being', 'المستقبل البسيط للمجهول: will + be + V3.'],
      ['Coffee is ___ in Brazil and Colombia.', ['grown', 'produced'], 'grow / produce', 'المضارع البسيط للمجهول: is + V3 (grown).'],
      ['The broken laptop is ___ repaired at the shop right now.', ['being'], 'be / been / being', 'المضارع المستمر للمجهول: is + being + V3.'],
    ],
    spot: [
      ['The novel was wrote by a Syrian author.', ['novel', 'was', 'wrote', 'author'], 2, 'The novel was written by a Syrian author.', 'في المبني للمجهول نستخدم التصريف الثالث written وليس wrote.'],
      ['The room is cleaning by the hotel staff now.', ['room', 'is cleaning', 'hotel', 'staff'], 1, 'The room is being cleaned by the hotel staff now.', 'المضارع المستمر المجهول هو is being cleaned.'],
      ['The parcel has been deliver to the wrong door.', ['parcel', 'been', 'deliver', 'door'], 2, 'The parcel has been delivered to the wrong door.', 'بعد has been نحتاج التصريف الثالث delivered.'],
    ],
    reorder: [
      ['This museum is visited by millions yearly.', 'المضارع البسيط المجهول: الفاعل النائب + is + V3.'],
      ['The email was sent two hours ago.', 'الماضي البسيط المجهول: was + V3 + ظرف الزمان.'],
      ['The contract will be signed tomorrow morning.', 'المستقبل المجهول: will be + V3.'],
    ],
  },

  'reported-speech': {
    mcq: [
      ['She said that she ___ busy the next day.', ['is', 'was', 'would be', 'will be'], 2, 'عند التحويل للماضي المنقول تتحول will be إلى would be.'],
      ['He asked me where I ___ from.', ['am', 'was', 'were', 'did'], 1, 'في السؤال المنقول يعود الزمن خطوة للخلف (am → was) والترتيب خبري.'],
      ['The doctor advised him ___ more vegetables.', ['eat', 'to eat', 'eating', 'ate'], 1, 'الفعل advise يتبعه مفعول + to + المصدر.'],
      ['They told us that they ___ the movie the night before.', ['saw', 'have seen', 'had seen', 'see'], 2, 'الماضي البسيط يتحول في الكلام المنقول إلى ماضي تام had seen.'],
      ['She asked ___ I had finished the assignment.', ['that', 'if', 'what', 'did'], 1, 'في نقل أسئلة نعم/لا نستخدم if أو whether.'],
    ],
    fill: [
      ['He ___ me that the flight had been delayed.', ['told'], 'said / told', 'عند وجود مفعول مباشر (me) نستخدم told وليس said.'],
      ['She ___ that she loved learning languages.', ['said'], 'said / told', 'عند عدم وجود مفعول مباشر نستخدم said.'],
      ['The teacher asked us not ___ talk during the test.', ['to'], 'to / for', 'نقل الأمر المنفي: asked + مفعول + not to + المصدر.'],
      ['He said he ___ never been to Japan before.', ['had'], 'has / had', 'في الكلام المنقول تتحول have/has إلى had.'],
    ],
    spot: [
      ['She said me that she was tired.', ['She', 'said', 'me', 'tired'], 1, 'She told me that she was tired.', 'الفعل say لا يأخذ مفعولاً مباشراً؛ نستخدم told me أو said to me.'],
      ['He asked me where did I buy my jacket.', ['asked', 'where', 'did', 'jacket'], 2, 'He asked me where I had bought my jacket.', 'في السؤال المنقول نحذف did ونستخدم ترتيباً خبرياً.'],
      ['They told that the store was closed.', ['They', 'told', 'store', 'closed'], 1, 'They said that the store was closed.', 'الفعل tell يحتاج مفعولاً بعده (told us) وإلا نستخدم said.'],
    ],
    reorder: [
      ['She told me she would call later.', 'تحويل will إلى would في الكلام المنقول مع told me.'],
      ['He asked if I needed any help.', 'نقل سؤال نعم/لا باستخدام if وترتيب خبري.'],
      ['The coach told us to keep practicing.', 'نقل الأمر المثبت: told + مفعول + to + المصدر.'],
    ],
  },

  'causative-verbs': {
    mcq: [
      ['I’m going to ___ my hair cut before the wedding.', ['make', 'let', 'have', 'do'], 2, 'لخدمة ينفذها شخص آخر لك نستخدم have / get + شيء + V3.'],
      ['My parents never ___ me stay out past midnight.', ['make', 'let', 'get', 'have'], 1, 'للسماح بفعل شيء نستخدم let + شخص + المصدر المجرد.'],
      ['That sad movie ___ everyone in the room cry.', ['let', 'got', 'made', 'had'], 2, 'بمعنى جعل/تسبب في نستخدم make + شخص + المصدر المجرد.'],
      ['She finally ___ her brother to fix the Wi-Fi router.', ['made', 'let', 'had', 'got'], 3, 'الفعل get مع شخص يأخذ to + المصدر (got him to fix).'],
      ['We had our house ___ last spring.', ['paint', 'painting', 'painted', 'to paint'], 2, 'في التركيب السببي المجهول نستخدم التصريف الثالث V3 بعد الشيء (painted).'],
    ],
    fill: [
      ['He got his car ___ at the garage yesterday.', ['repaired', 'fixed', 'washed'], 'repair / fix / wash', 'بعد get + الشيء نستخدم التصريف الثالث V3.'],
      ['The teacher made us ___ the essay again.', ['write', 'rewrite'], 'write / rewrite', 'بعد make + شخص نضع المصدر المجرد بدون to.'],
      ['Please ___ me know as soon as you arrive safely.', ['let'], 'let / make', 'التعبير الشائع هو let me know + المصدر المجرد.'],
      ['She is having her eyes ___ by a specialist tomorrow.', ['checked', 'tested', 'examined'], 'check / test', 'صيغة الخدمة المستقبلية: is having + الشيء + V3.'],
    ],
    spot: [
      ['The boss made us to work overtime on Friday.', ['boss', 'made', 'to', 'overtime'], 2, 'The boss made us work overtime on Friday.', 'بعد make في المبني للمعلوم نستخدم المصدر بدون to.'],
      ['I had my phone repair at the mall yesterday.', ['had', 'phone', 'repair', 'yesterday'], 2, 'I had my phone repaired at the mall yesterday.', 'بعد have + الشيء نستخدم التصريف الثالث repaired.'],
      ['My dad doesn’t let me to drive his new car.', ['let', 'me', 'to', 'drive'], 2, 'My dad doesn’t let me drive his new car.', 'بعد let يأتي الفعل المجرد مباشرة بدون to.'],
    ],
    reorder: [
      ['I had my laptop repaired last week.', 'التركيب السببي: had + الشيء + التصريف الثالث.'],
      ['Her joke made everyone laugh out loud.', 'make + مفعول + مصدر مجرد بدون to.'],
      ['Please let me help you with that.', 'let + ضمير المفعول + المصدر المجرد.'],
    ],
  },

  'conditionals-all': {
    mcq: [
      ['If you heat ice, it ___ into water.', ['melts', 'will melt', 'melted', 'would melt'], 0, 'الحالة الصفرية للحقائق العلمية: مضارع بسيط + مضارع بسيط.'],
      ['If it rains tomorrow, we ___ the picnic indoors.', ['move', 'will move', 'moved', 'would move'], 1, 'الحالة الشرطية الأولى للاحتمال المستقبلي: مضارع بسيط + will + مصدر.'],
      ['If I ___ you, I would accept that scholarship immediately.', ['am', 'was', 'were', 'had been'], 2, 'في الشرطية الثانية للتخيل والنصيحة نستخدم If I were you.'],
      ['If she had left earlier, she ___ the flight.', ['would catch', 'would have caught', 'will catch', 'caught'], 1, 'الشرطية الثالثة للندم على الماضي: had + V3 ← would have + V3.'],
      ['If he had studied medicine ten years ago, he ___ a doctor now.', ['would have been', 'would be', 'will be', 'is'], 1, 'الشرط المختلط: سبب ماضٍ (had + V3) ونتيجة حاضرة (would + مصدر).'],
    ],
    fill: [
      ['If you study consistently, you ___ pass the IELTS exam.', ['will', "'ll"], 'will / would', 'الشرطية الأولى: مضارع بسيط في جملة if + will في الجواب.'],
      ['If I had more free time, I ___ learn Spanish.', ['would', "'d"], 'will / would', 'الشرطية الثانية: ماضي بسيط في if + would + مصدر.'],
      ['They wouldn’t have gotten lost if they ___ brought a map.', ['had'], 'have / had', 'الشرطية الثالثة تتطلب الماضي التام had + V3 في جملة if.'],
      ['Unless you hurry, we ___ miss the opening scene.', ['will', "'ll"], 'will / would', 'Unless تعني If ... not وتتبع قواعد الشرطية الأولى.'],
    ],
    spot: [
      ['If I will see Omar tomorrow, I will tell him.', ['If', 'will see', 'tomorrow', 'tell'], 1, 'If I see Omar tomorrow, I will tell him.', 'لا نستخدم will داخل جملة الشرط if؛ نستخدم المضارع البسيط see.'],
      ['If she would have money, she would buy a boat.', ['If', 'would have', 'money', 'boat'], 1, 'If she had money, she would buy a boat.', 'في جملة الشرط الثانية نستخدم الماضي البسيط had وليس would have.'],
      ['If he had trained harder, he would win yesterday.', ['had trained', 'harder', 'would win', 'yesterday'], 2, 'If he had trained harder, he would have won yesterday.', 'النتيجة في الماضي (yesterday) تتطلب would have won.'],
    ],
    reorder: [
      ['If it rains, we will stay inside.', 'الشرطية الأولى: جملة If بالمضارع البسيط ثم النتيجة بـ will.'],
      ['If I were you, I would take it.', 'الشرطية الثانية للنصيحة باستخدام were و would.'],
      ['We would have arrived earlier if we hurried.', 'ترتيب جملة الجواب قبل جملة الشرط بدون فاصلة.'],
    ],
  },

  'relative-clauses': {
    mcq: [
      ['The engineer ___ designed this bridge won an award.', ['which', 'who', 'whose', 'where'], 1, 'للعاقل (فاعل الجملة الموصولة) نستخدم who.'],
      ['That’s the bakery ___ they bake fresh sourdough every dawn.', ['which', 'where', 'whose', 'who'], 1, 'للمكان الذي يقع فيه الفعل نستخدم where.'],
      ['I met a writer ___ novel was translated into ten languages.', ['who', 'which', 'whose', 'whom'], 2, 'للملكية (روايته) نستخدم whose.'],
      ['Paris, ___ is the capital of France, attracts millions of visitors.', ['that', 'which', 'who', 'where'], 1, 'في الجمل الموصولة غير المحدِّدة (بين فاصلتين) لا نستخدم that بل which.'],
      ['The laptop ___ I bought last month already needs an update.', ['who', 'where', 'that', 'whose'], 2, 'لغير العاقل في جملة محدِّدة نستخدم which أو that.'],
    ],
    fill: [
      ['Do you remember the day ___ we first met?', ['when', 'that'], 'when / where', 'للإشارة إلى الزمان (the day) نستخدم when.'],
      ['She is the colleague ___ helped me solve the bug.', ['who', 'that'], 'who / which', 'للعاقل نستخدم who أو that.'],
      ['The student ___ project won first place is only sixteen.', ['whose'], 'who / whose', 'للملكية (مشروعه) نستخدم whose.'],
      ['This is the café ___ we used to study together.', ['where'], 'where / which', 'للمكان الذي حدث فيه الفعل نستخدم where.'],
    ],
    spot: [
      ['My brother, that lives in Canada, is visiting us.', ['brother', 'that', 'Canada', 'visiting'], 1, 'My brother, who lives in Canada, is visiting us.', 'بعد الفاصلة في الجملة غير المحدِّدة نستخدم who للعاقل ولا نستخدم that.'],
      ['The woman which called you left a voicemail.', ['woman', 'which', 'called', 'voicemail'], 1, 'The woman who called you left a voicemail.', 'للعاقل نستخدم who وليس which.'],
      ['That is the restaurant where we visited yesterday.', ['restaurant', 'where', 'visited', 'yesterday'], 1, 'That is the restaurant which we visited yesterday.', 'الفعل visit متعدٍّ يأخذ مفعولاً (which) وليس ظرف مكان (where).'],
    ],
    reorder: [
      ['The book that she recommended was brilliant.', 'الجملة الموصولة المحدِّدة تأتي مباشرة بعد الاسم The book.'],
      ['I know a doctor whose clinic is nearby.', 'تُستخدم whose لربط المالك (doctor) بالمملوك (clinic).'],
      ['This is the city where I grew up.', 'تُستخدم where لربط المكان (city) بالحدث الذي وقع فيه.'],
    ],
  },

  'gerunds-infinitives': {
    mcq: [
      ['She decided ___ a new career in data science.', ['starting', 'to start', 'start', 'started'], 1, 'الفعل decide يتبعه دائماً to + المصدر.'],
      ['He avoids ___ junk food before going to sleep.', ['to eat', 'eating', 'eat', 'eaten'], 1, 'الفعل avoid يتبعه دائماً اسم الفعل V-ing.'],
      ['I look forward to ___ from you very soon.', ['hear', 'hearing', 'heard', 'to hear'], 1, 'حرف الجر to في look forward to يتبعه V-ing دائماً.'],
      ['She stopped ___ a coffee because she needed energy.', ['drinking', 'to drink', 'drink', 'drank'], 1, 'stop + to + مصدر تعني توقف لكي يفعل شيئاً (الهدف).'],
      ['___ regularly is one of the best habits for your health.', ['Exercise', 'Exercising', 'Exercised', 'To exercising'], 1, 'عندما يقع الفعل فاعلاً في بداية الجملة نستخدم Gerund (V-ing).'],
    ],
    fill: [
      ['They promised ___ arrive before the ceremony begins.', ['to'], 'to / -ing', 'الفعل promise يتبعه to + المصدر.'],
      ['Would you mind ___ the air conditioner slightly?', ['lowering', 'turning down'], 'lower / turn down', 'بعد mind نستخدم دائماً V-ing.'],
      ['She is very good at ___ complex concepts simply.', ['explaining'], 'explain', 'بعد حروف الجر (at / in / of / about) نستخدم V-ing دائماً.'],
      ['He suggested ___ a short break after two hours of study.', ['taking', 'having'], 'take / have', 'الفعل suggest يتبعه V-ing وليس to + مصدر.'],
    ],
    spot: [
      ['I enjoy to read mystery novels on rainy days.', ['enjoy', 'to read', 'novels', 'days'], 1, 'I enjoy reading mystery novels on rainy days.', 'الفعل enjoy يتبعه دائماً V-ing (reading).'],
      ['She suggested to go to the Italian restaurant.', ['She', 'suggested', 'to go', 'restaurant'], 2, 'She suggested going to the Italian restaurant.', 'الفعل suggest يتبعه V-ing (going) وليس to + مصدر.'],
      ['We look forward to see you at the summit.', ['look', 'forward', 'see', 'summit'], 2, 'We look forward to seeing you at the summit.', 'بعد look forward to يأتي V-ing (seeing).'],
    ],
    reorder: [
      ['He agreed to help us with moving.', 'الفعل agree يتبعه to + المصدر.'],
      ['She finished writing the report before noon.', 'الفعل finish يتبعه V-ing.'],
      ['Learning a new language takes daily practice.', 'استخدام Gerund كفاعل في بداية الجملة.'],
    ],
  },

  'wish-if-only': {
    mcq: [
      ['I wish I ___ closer to the beach right now.', ['live', 'lived', 'will live', 'have lived'], 1, 'التمني لتغيير وضع حاضر يستخدم الماضي البسيط (wish + V2).'],
      ['If only we ___ booked our flights earlier! Now they’re sold out.', ['have', 'had', 'would', 'were'], 1, 'الندم على الماضي يستخدم الماضي التام (If only + had + V3).'],
      ['I wish it ___ stop raining so we could go for a walk.', ['will', 'would', 'had', 'did'], 1, 'للشكوى من موقف مزعج نتمنى تغيّره نستخدم wish + would + مصدر.'],
      ['She wishes she ___ speak Japanese fluently.', ['can', 'could', 'will', 'may'], 1, 'لتمنّي قدرة غير موجودة حالياً نستخدم could.'],
      ['He wishes he ___ said those harsh words yesterday.', ['didn’t', 'hadn’t', 'wouldn’t', 'hasn’t'], 1, 'للندم على فعل حدث أمس نستخدم hadn’t + V3.'],
    ],
    fill: [
      ['I wish I ___ taller so I could play basketball.', ['were', 'was'], 'were / was', 'مع التمني الحاضر نستخدم were (الأفصح) أو was.'],
      ['If only he ___ listened to our advice last week!', ['had'], 'has / had', 'الندم على الماضي يأخذ had + V3.'],
      ['I wish my neighbor ___ stop playing loud music at night.', ['would'], 'will / would', 'للتعبير عن الانزعاج من سلوك الآخرين نستخدم would.'],
      ['She wishes she ___ have to work on weekends.', ["didn't", 'did not'], 'don’t / didn’t', 'نفي التمني في الحاضر يكون بـ didn’t + المصدر.'],
    ],
    spot: [
      ['I wish I can fly like a bird.', ['I', 'wish', 'can', 'bird'], 2, 'I wish I could fly like a bird.', 'بعد wish نرجع الزمن للماضي: could وليس can.'],
      ['If only I didn’t missed the bus yesterday.', ['If only', 'didn’t', 'missed', 'yesterday'], 1, 'If only I hadn’t missed the bus yesterday.', 'الندم على الماضي يستخدم الماضي التام hadn’t missed.'],
      ['I wish I would know the answer right now.', ['wish', 'would know', 'answer', 'now'], 1, 'I wish I knew the answer right now.', 'لا نستخدم would مع نفس الفاعل أو أفعال الحالة؛ نستخدم الماضي البسيط knew.'],
    ],
    reorder: [
      ['I wish I had more time today.', 'تمنّي تغيير الحاضر: wish + الفاعل + الماضي البسيط.'],
      ['If only we had taken that shortcut!', 'الندم على الماضي: If only + had + V3.'],
      ['She wishes she could travel the world.', 'تمنّي القدرة: wish + could + المصدر.'],
    ],
  },

  'inversion-emphasis': {
    mcq: [
      ['Never ___ such a breathtaking sunset before.', ['I have seen', 'have I seen', 'I saw', 'did I saw'], 1, 'عند بدء الجملة بظرف نفي مثل Never نقلب الفاعل والفعل المساعد: have I seen.'],
      ['Not only ___ the race, but she also broke the record.', ['she won', 'did she win', 'won she', 'she did win'], 1, 'بعد Not only في بداية الجملة يحدث قلب: did + الفاعل + المصدر.'],
      ['Rarely ___ such dedication in a young athlete.', ['we see', 'do we see', 'we do see', 'are we see'], 1, 'بعد Rarely في الصدارة نستخدم القلب: do + الفاعل + الفعل.'],
      ['It was the manager ___ approved the final budget.', ['which', 'who', 'where', 'whose'], 1, 'في الجملة المشطورة (Cleft Sentence) للعاقل نستخدم It was ... who.'],
      ['Little ___ that a surprise party was waiting inside.', ['he knew', 'did he know', 'knew he', 'he did know'], 1, 'عند بدء الجملة بـ Little بمعنى النفي نقلب: did he know.'],
    ],
    fill: [
      ['Seldom ___ I heard a speech so inspiring.', ['have'], 'have / do', 'بعد Seldom نقلب الفعل المساعد have قبل الفاعل I.'],
      ['What I really need right now ___ a long vacation.', ['is'], 'is / are', 'جملة What-cleft للتأكيد تتبعها is ثم الشيء المؤكَّد.'],
      ['Only after reading the letter ___ she understand the truth.', ['did'], 'did / was', 'بعد Only after في البداية يحدث القلب في الجملة الرئيسية: did she understand.'],
      ['No sooner ___ we sat down than the fire alarm rang.', ['had'], 'had / did', 'التركيب القياسي: No sooner + had + الفاعل + V3 ... than.'],
    ],
    spot: [
      ['Never I have met someone so generous.', ['Never', 'I have', 'met', 'generous'], 1, 'Never have I met someone so generous.', 'عند تقديم Never في بداية الجملة يجب قلب الفعل المساعد قبل الفاعل.'],
      ['Hardly had he arrived than the phone rang.', ['Hardly', 'arrived', 'than', 'rang'], 2, 'Hardly had he arrived when the phone rang.', 'تأخذ Hardly الرابط when وليس than (بينما No sooner تأخذ than).'],
      ['Not only did she sang well, she danced too.', ['Not only', 'did', 'sang', 'danced'], 2, 'Not only did she sing well, she danced too.', 'بعد did يعود الفعل للمصدر المجرد sing.'],
    ],
    reorder: [
      ['Never have I seen anything so remarkable.', 'قلب الفاعل والمساعد بعد Never في الصدارة.'],
      ['It was Sarah who solved the mystery.', 'جملة Cleft لتسليط الضوء على الفاعل Sarah.'],
      ['What matters most is consistent daily effort.', 'جملة What-cleft للتأكيد على الفكرة الأهم.'],
    ],
  },

  'subjunctive-formal': {
    mcq: [
      ['The board recommended that every member ___ the briefing.', ['attends', 'attend', 'attended', 'attending'], 1, 'في الصيغة الإلزامية الرسمية (Subjunctive) نستخدم المصدر المجرد attend بدون s.'],
      ['It is essential that he ___ on time for the hearing.', ['is', 'be', 'was', 'being'], 1, 'بعد It is essential that نستخدم المصدر المجرد be مع جميع الضمائر.'],
      ['The doctor insisted that she ___ not skip her medication.', ['does', 'do', '—', 'is'], 2, 'نفي الـ Subjunctive يكون بوضع not مباشرة قبل المصدر المجرد بدون do/does.'],
      ['We demanded that the data ___ verified immediately.', ['is', 'be', 'was', 'were'], 1, 'المبني للمجهول في الـ Subjunctive هو be + V3.'],
      ['The committee proposed that the deadline ___ extended by a week.', ['is', 'be', 'will be', 'was'], 1, 'بعد propose that في المجهول الرسمي نستخدم be + V3.'],
    ],
    fill: [
      ['It is vital that every applicant ___ a valid ID.', ['bring', 'have', 'present', 'submit'], 'base verb', 'في الـ Subjunctive نستخدم الفعل المجرد بدون s حتى مع المفرد.'],
      ['The manager requested that she ___ in charge of the launch.', ['be'], 'be / is', 'فعل الكون في الـ Subjunctive هو دائماً be.'],
      ['I suggest that he ___ his notes carefully before presenting.', ['review', 'check', 'read'], 'base verb', 'بعد suggest that نستخدم المصدر المجرد review.'],
      ['It is imperative that no details ___ leaked to the press.', ['be'], 'be / are', 'المجهول في الـ Subjunctive يستخدم be + V3.'],
    ],
    spot: [
      ['She insisted that he apologizes to the whole team.', ['insisted', 'that', 'apologizes', 'team'], 2, 'She insisted that he apologize to the whole team.', 'بعد insist that نستخدم المصدر المجرد apologize بدون s.'],
      ['It is crucial that the report is submitted today.', ['crucial', 'report', 'is', 'submitted'], 2, 'It is crucial that the report be submitted today.', 'في الإنجليزية الرسمية بعد It is crucial that نستخدم be submitted.'],
      ['They recommended that she doesn’t leave early.', ['recommended', 'she', "doesn’t", 'leave'], 2, 'They recommended that she not leave early.', 'النفي في الـ Subjunctive يكون بـ not + المصدر بدون doesn’t.'],
    ],
    reorder: [
      ['It is essential that he be informed.', 'صيغة Subjunctive المجهولة: that + الفاعل + be + V3.'],
      ['The judge ordered that he pay immediately.', 'بعد order that نستخدم الفعل المجرد pay.'],
      ['We suggest that she not delay further.', 'النفي الرسمي في الـ Subjunctive: not + المصدر.'],
    ],
  },

  'participle-clauses': {
    mcq: [
      ['___ by the loud noise, the birds flew away immediately.', ['Startling', 'Startled', 'Startle', 'Having startle'], 1, 'الطيور هي من أُفزعت (معنى مجهول) فنستخدم التصريف الثالث Startled.'],
      ['___ her degree, she moved to Zurich for her first job.', ['Having finished', 'Finished', 'Finishing of', 'Being finish'], 0, 'عندما يسبق أحد الفعلين الآخر تماماً نستخدم Having + V3.'],
      ['The woman ___ next to the window is our chief architect.', ['sits', 'sitting', 'sat', 'is sitting'], 1, 'اختصار الجملة الموصولة المعلومة (who is sitting) يكون بـ V-ing.'],
      ['___ through the old market, we discovered a hidden bookstore.', ['Walked', 'Walking', 'To walking', 'Walk'], 1, 'الفاعل (we) هو من قام بالمشي (معلوم) فنستخدم اسم الفاعل Walking.'],
      ['The bridge ___ in 1920 still carries thousands of cars daily.', ['building', 'built', 'was built', 'to build'], 1, 'اختصار الجملة الموصولة المجهولة (which was built) يكون بالتصريف الثالث built.'],
    ],
    fill: [
      ['___ tired from the long journey, he went straight to bed.', ['Feeling', 'Being'], 'Feel / Be', 'الفاعل هو من يشعر بالتعب فنستخدم اسم الفاعل Feeling.'],
      ['Having ___ all the instructions, she assembled the desk easily.', ['read', 'followed'], 'read / follow', 'بعد Having نستخدم التصريف الثالث V3.'],
      ['Anyone ___ to volunteer should sign the list at the desk.', ['wishing', 'wanting'], 'wish / want', 'اختصار who wishes هو wishing.'],
      ['___ in Italy, these leather shoes last for years.', ['Made', 'Crafted'], 'Make / Craft', 'المعنى مبني للمجهول (صُنعت في إيطاليا) فيبدأ بالتصريف الثالث Made.'],
    ],
    spot: [
      ['Walking down the street, a bright rainbow caught my eye.', ['Walking', 'street', 'rainbow', 'eye'], 2, 'Walking down the street, I saw a bright rainbow.', 'يجب أن يتطابق فاعل الجملة الرئيسية (I) مع فاعل جملة اسم الفاعل (Walking) لمنع dangling participle.'],
      ['Having finish his speech, he thanked the audience.', ['Having', 'finish', 'speech', 'audience'], 1, 'Having finished his speech, he thanked the audience.', 'بعد Having يجب استخدام التصريف الثالث finished.'],
      ['The emails sending yesterday contained an error.', ['emails', 'sending', 'yesterday', 'error'], 1, 'The emails sent yesterday contained an error.', 'الرسائل أُرسِلت (مجهول) فنختصرها بالتصريف الثالث sent لا sending.'],
    ],
    reorder: [
      ['Exhausted by the climb, they rested briefly.', 'جملة اسم المفعول (Exhausted) توضح سبب الفعل الرئيسي.'],
      ['Having checked the map, we turned left.', 'Having + V3 يوضح اكتمال الحدث الأول قبل الثاني.'],
      ['The students waiting outside look very excited.', 'اختصار جملة الوصل المعلومة باستخدام waiting.'],
    ],
  },

  'phrasal-verbs-mastery': {
    mcq: [
      ['We had to ___ the meeting until next Tuesday.', ['put on', 'put off', 'put out', 'put up'], 1, 'الفعل المركب put off يعني يؤجّل.'],
      ['Could you please ___ the music? It’s a bit too loud.', ['turn up', 'turn down', 'turn on', 'turn into'], 1, 'turn down يعني يخفض الصوت (أو يرفض عرضاً).'],
      ['I ___ an old university friend while shopping downtown.', ['ran out of', 'ran into', 'ran away', 'ran over'], 1, 'run into someone يعني يقابل شخصاً بالصدفة.'],
      ['We have completely ___ milk; I’ll grab some on my way home.', ['run into', 'run out of', 'come up with', 'look up to'], 1, 'run out of يعني ينفد منه الشيء.'],
      ['She picked up the letter and threw ___.', ['away it', 'it away', 'away them', 'off it'], 1, 'عندما يكون المفعول ضميراً (it) في الفعل القابل للفصل يجب وضعه في الوسط: threw it away.'],
    ],
    fill: [
      ['Never give ___ on your goals, even when progress feels slow.', ['up'], 'up / off / out', 'give up يعني يستسلم.'],
      ['Can you look ___ this word in the dictionary for me?', ['up'], 'up / after / for', 'look up يعني يبحث عن معلومة أو كلمة في مرجع.'],
      ['She really looks ___ to her older sister as a role model.', ['up'], 'up / down / over', 'look up to someone يعني يحترم شخصاً ويقتدي به.'],
      ['They came up ___ a brilliant solution to the traffic issue.', ['with'], 'with / for / to', 'الفعل الثلاثي come up with يعني يبتكر فكرة أو حلاً.'],
    ],
    spot: [
      ['Please turn off it before leaving the office.', ['Please', 'turn', 'off it', 'office'], 2, 'Please turn it off before leaving the office.', 'الضمير it يجب أن يأتي بين الفعل وحرف الجر: turn it off.'],
      ['We need to come up to a better marketing plan.', ['need', 'come', 'to', 'plan'], 2, 'We need to come up with a better marketing plan.', 'حرف الجر الصحيح مع come up هو with.'],
      ['She looks for her younger brother while her parents work.', ['looks', 'for', 'brother', 'work'], 1, 'She looks after her younger brother while her parents work.', 'look after تعني يعتني بـ، أما look for فتعني يبحث عن.'],
    ],
    reorder: [
      ['Please turn the lights off before leaving.', 'يمكن فصل الفعل القابل للفصل بوضع الاسم في الوسط.'],
      ['She came up with a clever idea.', 'الفعل المركب الثلاثي come up with لا يُفصل.'],
      ['I ran into my teacher this morning.', 'run into فعل مركب غير قابل للفصل.'],
    ],
  },

  'ellipsis-discourse-c2': {
    mcq: [
      ['“Are they launching the product this month?” — “I certainly hope ___.”', ['it', 'so', 'that', 'this'], 1, 'للاستعاضة عن جملة كاملة بعد أفعال مثل hope / think / believe نستخدم so.'],
      ['She didn’t attend the gala, and neither ___ her business partner.', ['was', 'did', 'had', 'does'], 1, 'للموافقة على جملة منفية في الماضي البسيط نستخدم neither + did + الفاعل.'],
      ['I haven’t read the new report yet, though I intend ___.', ['it', 'to', 'so', 'doing'], 1, 'للحذف بعد أفعال تتبعها to نكتفي بـ to فقط (intend to) دون تكرار الفعل.'],
      ['I prefer the blue jacket to the green ___.', ['it', 'one', 'so', 'that'], 1, 'لتجنب تكرار اسم مفرد معدود نستخدم البديل one.'],
      ['The proposal is ambitious; ___, it requires significant funding.', ['nonetheless', 'so', 'one', 'neither'], 0, 'nonetheless رابط خطابي رسمي من مستوى C2 يعني «ومع ذلك».'],
    ],
    fill: [
      ['He promised to help us, and he truly intends ___.', ['to'], 'to / so', 'نكتفي بـ to في الحذف (ellipsis) لتجنب تكرار help us.'],
      ['“Will the weather improve tomorrow?” — “I’m afraid ___.”', ['not'], 'so / not', 'للنفي المختصر بعد I’m afraid نستخدم not.'],
      ['These leather boots are far more durable than the plastic ___.', ['ones'], 'one / ones', 'للبديل عن اسم جمع معدود (boots) نستخدم ones.'],
      ['She loves classical music, and ___ do I.', ['so'], 'so / neither', 'للموافقة على جملة مثبتة نستخدم so + الفعل المساعد + الفاعل.'],
    ],
    spot: [
      ['“Is the shop still open?” — “I don’t think it.”', ['shop', 'open', 'think', 'it'], 3, '“Is the shop still open?” — “I don’t think so.”', 'نستخدم so كبديل عن جملة بعد think وليس it.'],
      ['He couldn’t attend the seminar, and so couldn’t I.', ['couldn’t', 'seminar', 'so', 'I'], 2, 'He couldn’t attend the seminar, and neither could I.', 'للموافقة على النفي نستخدم neither + مساعد مثبت (could).'],
      ['I like the red shirt more than the black ones.', ['red', 'shirt', 'black', 'ones'], 3, 'I like the red shirt more than the black one.', 'كلمة shirt مفرد فتأخذ البديل المفرد one وليس ones.'],
    ],
    reorder: [
      ['She wanted to stay, and I did too.', 'الاختصار باستخدام الفعل المساعد did بدلاً من تكرار الجملة.'],
      ['I haven’t seen it, nor have they.', 'الموافقة الرسمية على النفي باستخدام nor + قلب المساعد.'],
      ['The task was tough; nevertheless, we prevailed.', 'استخدام الرابط الخطابي المتقدم nevertheless بين جملتين.'],
    ],
  },
};
