// Exact standalone HTML template provided by the user so merging with their
// original 18,000-word <script type="text/plain" id="embedded-vocab"> produces
// the exact ready-to-download index.html file.

export const STANDALONE_HTML_PREFIX = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="theme-color" content="#0f172a">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link rel="manifest" href="manifest.json">
<link rel="icon" type="image/png" href="icon-192.png">
<title>قاموس الألعاب الذكي A0–C2</title>
<style>
:root {
  --bg: #0f172a;
  --bg-soft: #1e293b;
  --card: #162032;
  --card-hover: #213049;
  --border: #2b3c57;
  --text: #f1f5f9;
  --text-muted: #94a3b8;
  --primary: #6366f1;
  --primary-hover: #4f46e5;
  --primary-soft: rgba(99, 102, 241, 0.18);
  --success: #10b981;
  --success-soft: rgba(16, 185, 129, 0.16);
  --danger: #ef4444;
  --danger-soft: rgba(239, 68, 68, 0.16);
  --warning: #f59e0b;
  --warning-soft: rgba(245, 158, 11, 0.16);
  --cyan: #06b6d4;
  --radius: 16px;
  --shadow: 0 6px 22px rgba(0, 0, 0, 0.28);
  --font: system-ui, -apple-system, "Segoe UI", Tahoma, Arial, sans-serif;
}

body.light {
  --bg: #f1f5f9;
  --bg-soft: #e2e8f0;
  --card: #ffffff;
  --card-hover: #f8fafc;
  --border: #cbd5e1;
  --text: #0f172a;
  --text-muted: #475569;
  --primary: #4f46e5;
  --primary-hover: #4338ca;
  --primary-soft: rgba(79, 70, 229, 0.12);
  --success: #059669;
  --success-soft: rgba(5, 150, 105, 0.13);
  --danger: #dc2626;
  --danger-soft: rgba(220, 38, 38, 0.13);
  --warning: #d97706;
  --warning-soft: rgba(217, 119, 6, 0.14);
  --shadow: 0 6px 20px rgba(15, 23, 42, 0.08);
}

*, *::before, *::after { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
html { height: auto; margin: 0; padding: 0; }
body {
  margin: 0; padding: 0; min-height: 100vh;
  background: var(--bg); color: var(--text);
  font-family: var(--font); line-height: 1.5;
  -webkit-overflow-scrolling: touch;
}
button, input, select { font-family: inherit; color: inherit; }

.topbar {
  position: fixed; top: 0; left: 0; right: 0; height: 56px;
  background: var(--card); border-bottom: 1px solid var(--border);
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 14px; z-index: 60;
}
.topbar-inner { width: 100%; max-width: 820px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.top-left { display: flex; align-items: center; gap: 10px; min-width: 0; }
.brand-logo {
  width: 34px; height: 34px; border-radius: 10px;
  background: linear-gradient(135deg, var(--primary), var(--cyan));
  display: flex; align-items: center; justify-content: center;
  font-weight: 900; font-size: 14px; color: #fff; flex-shrink: 0;
}
.top-title { font-weight: 800; font-size: 16px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.top-right { display: flex; align-items: center; gap: 6px; flex-shrink: 0; }
.icon-btn {
  background: var(--bg-soft); border: 1px solid var(--border); border-radius: 10px;
  height: 36px; min-width: 36px; padding: 0 9px;
  display: inline-flex; align-items: center; justify-content: center;
  cursor: pointer; font-size: 15px; font-weight: 700;
}
.icon-btn:active { opacity: 0.75; }

.main-wrap { width: 100%; max-width: 820px; margin: 0 auto; padding: 68px 14px 104px; }
body.in-game .main-wrap { padding-bottom: 185px; }

.bottom-nav {
  position: fixed; bottom: 0; left: 0; right: 0; height: 64px;
  background: var(--card); border-top: 1px solid var(--border); z-index: 60;
  display: flex; align-items: stretch; justify-content: center;
  padding-bottom: env(safe-area-inset-bottom);
}
body.in-game .bottom-nav { display: none; }
.bottom-nav-inner { width: 100%; max-width: 820px; display: grid; grid-template-columns: repeat(4, 1fr); }
.bnav-btn {
  background: transparent; border: none; display: flex; flex-direction: column;
  align-items: center; justify-content: center; gap: 2px; cursor: pointer;
  color: var(--text-muted); font-size: 11.5px; font-weight: 700; position: relative;
}
.bnav-btn .ico { font-size: 20px; line-height: 1.1; }
.bnav-btn.active { color: var(--primary); }
.bnav-btn.active::before {
  content: ""; position: absolute; top: 0; width: 36px; height: 3px;
  border-radius: 0 0 4px 4px; background: var(--primary);
}
.bnav-dot {
  position: absolute; top: 7px; right: 26%; background: var(--danger); color: #fff;
  font-size: 10px; font-weight: 800; padding: 0 5px; border-radius: 99px; min-width: 17px; text-align: center;
}

.action-dock {
  position: fixed; bottom: 0; left: 0; right: 0;
  background: var(--card); border-top: 1px solid var(--border);
  box-shadow: 0 -6px 24px rgba(0,0,0,0.32);
  padding: 10px 14px calc(12px + env(safe-area-inset-bottom)); z-index: 70;
}
.action-dock-inner { width: 100%; max-width: 820px; margin: 0 auto; display: flex; flex-direction: column; gap: 8px; }
.dock-row { display: flex; gap: 8px; align-items: center; }
.dock-feedback { padding: 9px 12px; border-radius: 12px; display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap; font-size: 13.5px; font-weight: 700; }
.dock-feedback.ok { background: var(--success-soft); border: 1px solid var(--success); color: var(--success); }
.dock-feedback.err { background: var(--danger-soft); border: 1px solid var(--danger); color: var(--danger); }
.dock-ans-text { color: var(--text); font-size: 14px; font-weight: 800; }

.card { background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); padding: 15px; box-shadow: var(--shadow); margin-bottom: 14px; }
.section-head { display: flex; align-items: center; justify-content: space-between; margin: 4px 2px 10px; }
.section-title { margin: 0; font-size: 15.5px; font-weight: 800; }
.muted { color: var(--text-muted); font-size: 13px; }
.band-pill { display: inline-flex; align-items: center; justify-content: center; padding: 2px 9px; border-radius: 99px; font-size: 11.5px; font-weight: 900; color: #fff; }

.btn { display: inline-flex; align-items: center; justify-content: center; gap: 7px; padding: 11px 16px; border-radius: 12px; border: 1px solid transparent; font-size: 14.5px; font-weight: 800; cursor: pointer; min-height: 44px; }
.btn:active { opacity: 0.82; }
.btn:disabled { opacity: 0.42; cursor: not-allowed; }
.btn-primary { background: var(--primary); color: #fff; }
.btn-success { background: var(--success); color: #fff; }
.btn-danger { background: var(--danger); color: #fff; }
.btn-warning { background: var(--warning); color: #111827; }
.btn-soft { background: var(--bg-soft); border-color: var(--border); color: var(--text); }
.btn-sm { padding: 7px 12px; font-size: 12.5px; min-height: 36px; border-radius: 10px; }
.btn-lg { padding: 13px 18px; font-size: 16px; min-height: 50px; border-radius: 14px; }
.btn-block { width: 100%; }
.input, .select { background: var(--bg-soft); border: 1px solid var(--border); border-radius: 11px; padding: 10px 12px; font-size: 14.5px; outline: none; max-width: 100%; }
.input:focus, .select:focus { border-color: var(--primary); }

.goal-strip { background: linear-gradient(135deg, rgba(99,102,241,0.22), rgba(6,182,212,0.14)); border: 1px solid rgba(99,102,241,0.42); border-radius: var(--radius); padding: 13px 15px; margin-bottom: 14px; }
.goal-top { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 8px; flex-wrap: wrap; }
.goal-bar { height: 7px; background: rgba(255,255,255,0.14); border-radius: 99px; overflow: hidden; }
.goal-bar > i { display: block; height: 100%; background: linear-gradient(90deg, var(--success), var(--cyan)); border-radius: 99px; }

.games-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
@media (min-width: 680px) { .games-grid { grid-template-columns: repeat(3, 1fr); } }
.game-card { background: var(--card); border: 1px solid var(--border); border-radius: 15px; padding: 14px 12px; cursor: pointer; display: flex; flex-direction: column; align-items: flex-start; gap: 6px; text-align: right; box-shadow: var(--shadow); }
.game-card:active { background: var(--card-hover); border-color: var(--primary); }
.game-card .g-ico { width: 42px; height: 42px; border-radius: 12px; background: var(--bg-soft); display: flex; align-items: center; justify-content: center; font-size: 22px; }
.game-card .g-name { font-size: 14.5px; font-weight: 800; line-height: 1.25; }
.game-card .g-desc { font-size: 11.5px; color: var(--text-muted); line-height: 1.35; }
.game-card.featured { border-color: rgba(168,85,247,0.55); background: linear-gradient(145deg, rgba(99,102,241,0.18), rgba(168,85,247,0.14)); }

.seg-bar { display: grid; gap: 6px; background: var(--bg-soft); padding: 4px; border-radius: 12px; margin-bottom: 14px; }
.seg-bar.c2 { grid-template-columns: repeat(2, 1fr); }
.seg-bar.c3 { grid-template-columns: repeat(3, 1fr); }
.seg-bar.c4 { grid-template-columns: repeat(4, 1fr); }
.seg-btn { border: none; background: transparent; padding: 9px 6px; border-radius: 9px; font-size: 12.5px; font-weight: 800; color: var(--text-muted); cursor: pointer; }
.seg-btn.active { background: var(--primary); color: #fff; }

.band-pills-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
@media (min-width: 600px) { .band-pills-grid { grid-template-columns: repeat(7, 1fr); } }
.band-pick-btn { background: var(--bg-soft); border: 2px solid var(--border); border-radius: 12px; padding: 10px 4px; text-align: center; cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 2px; }
.band-pick-btn .bc { font-size: 16px; font-weight: 900; }
.band-pick-btn .ba { font-size: 10.5px; color: var(--text-muted); font-weight: 700; }
.band-pick-btn.active { border-color: var(--primary); background: var(--primary-soft); }

.cefr-list { display: flex; flex-direction: column; gap: 10px; }
.cefr-row-card { background: var(--card); border: 1px solid var(--border); border-radius: 15px; padding: 14px; cursor: pointer; display: flex; align-items: center; gap: 13px; box-shadow: var(--shadow); }
.cefr-row-card:active { background: var(--card-hover); }
.cefr-badge-lg { width: 52px; height: 52px; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 20px; font-weight: 900; color: #fff; flex-shrink: 0; }
.cefr-row-info { flex: 1; min-width: 0; }
.cefr-row-top { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
.cefr-row-name { font-size: 16px; font-weight: 800; }
.cefr-row-cnt { font-size: 12px; color: var(--text-muted); font-weight: 700; }
.mini-bar { height: 6px; background: var(--bg-soft); border-radius: 99px; overflow: hidden; margin-top: 7px; }
.mini-bar > i { display: block; height: 100%; border-radius: 99px; }

.levels-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 9px; }
@media (min-width: 600px) { .levels-grid { grid-template-columns: repeat(3, 1fr); } }
.level-card { background: var(--card); border: 1px solid var(--border); border-radius: 13px; padding: 12px; cursor: pointer; display: flex; flex-direction: column; gap: 5px; }
.level-card:active { background: var(--card-hover); border-color: var(--primary); }
.level-card.done { border-color: rgba(16,185,129,0.55); }
.lvl-head { display: flex; justify-content: space-between; align-items: center; gap: 4px; }
.lvl-num { font-weight: 900; font-size: 14.5px; }
.lvl-tag { font-size: 11px; font-weight: 800; padding: 2px 7px; border-radius: 99px; }
.lvl-tag.done { background: var(--success-soft); color: var(--success); }
.lvl-tag.prog { background: var(--warning-soft); color: var(--warning); }
.lvl-tag.new { background: var(--bg-soft); color: var(--text-muted); }
.lvl-sample { font-size: 11.5px; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; direction: ltr; text-align: right; }
.pagination { display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 14px; flex-wrap: wrap; }

.game-progress-bar { width: 100%; height: 7px; background: var(--bg-soft); border-radius: 99px; overflow: hidden; margin-bottom: 14px; }
.game-progress-bar > i { display: block; height: 100%; background: linear-gradient(90deg, var(--primary), var(--cyan)); border-radius: 99px; transition: width 0.2s ease; }
.q-card { background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); padding: 18px 14px; text-align: center; box-shadow: var(--shadow); }
.q-label { display: inline-block; font-size: 12px; font-weight: 800; color: var(--primary); background: var(--primary-soft); padding: 3px 11px; border-radius: 99px; margin-bottom: 10px; }
.q-word { font-size: clamp(24px, 6.5vw, 36px); font-weight: 900; margin: 6px 0 8px; word-break: break-word; }
.q-word.ltr { direction: ltr; letter-spacing: 0.4px; }
.word-tools { display: flex; align-items: center; justify-content: center; gap: 8px; margin: 6px 0 12px; flex-wrap: wrap; }

.mcq-list { display: grid; grid-template-columns: 1fr; gap: 9px; margin-top: 10px; }
@media (min-width: 560px) { .mcq-list { grid-template-columns: repeat(2, 1fr); } }
.mcq-opt { background: var(--bg-soft); border: 2px solid var(--border); border-radius: 13px; padding: 14px 12px; font-size: 16px; font-weight: 700; cursor: pointer; min-height: 54px; display: flex; align-items: center; justify-content: center; word-break: break-word; }
.mcq-opt.correct { background: var(--success-soft); border-color: var(--success); color: var(--success); }
.mcq-opt.wrong { background: var(--danger-soft); border-color: var(--danger); color: var(--danger); }

.tf-box { background: var(--bg-soft); border: 1px dashed var(--border); border-radius: 14px; padding: 16px 12px; margin: 8px auto 14px; max-width: 480px; }
.tf-btns { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; max-width: 420px; margin: 0 auto; }
.tf-btn { padding: 15px 10px; border-radius: 14px; font-size: 18px; font-weight: 900; border: 2px solid var(--border); background: var(--bg-soft); cursor: pointer; }
.tf-btn.is-correct { background: var(--success-soft); border-color: var(--success); color: var(--success); }
.tf-btn.is-wrong { background: var(--danger-soft); border-color: var(--danger); color: var(--danger); }

.match-board { display: grid; grid-template-columns: 1fr 1fr; gap: 9px; margin-top: 10px; }
.match-col { display: flex; flex-direction: column; gap: 8px; }
.match-item { background: var(--bg-soft); border: 2px solid var(--border); border-radius: 12px; padding: 12px 8px; font-size: 14.5px; font-weight: 700; cursor: pointer; min-height: 52px; display: flex; align-items: center; justify-content: center; text-align: center; user-select: none; word-break: break-word; }
.match-item.ltr { direction: ltr; }
.match-item.selected { border-color: var(--primary); background: var(--primary-soft); }
.match-item.matched { border-color: var(--success); background: var(--success-soft); color: var(--success); opacity: 0.4; pointer-events: none; }
.match-item.shake { border-color: var(--danger); background: var(--danger-soft); animation: shake 0.28s; }

.slots-wrap { display: flex; flex-wrap: wrap; justify-content: center; gap: 6px; direction: ltr; margin: 14px auto; }
.letter-slot { min-width: 35px; height: 44px; padding: 0 5px; border-radius: 10px; border: 2px solid var(--border); background: var(--bg-soft); font-size: 20px; font-weight: 900; display: inline-flex; align-items: center; justify-content: center; user-select: none; }
.letter-slot.fixed { background: var(--primary-soft); border-color: rgba(99,102,241,0.45); }
.letter-slot.blank { border-style: dashed; border-color: var(--primary); }
.letter-slot.blank.cursor { border-style: solid; box-shadow: 0 0 0 3px var(--primary-soft); }
.letter-slot.filled { background: var(--primary); border-color: var(--primary); color: #fff; cursor: pointer; }
.letter-slot.correct { background: var(--success); border-color: var(--success); color: #fff; }
.letter-slot.wrong { background: var(--danger); border-color: var(--danger); color: #fff; }
.letter-slot.punct { min-width: 18px; border-color: transparent; background: transparent; color: var(--text-muted); }

.bank-wrap { display: flex; flex-wrap: wrap; justify-content: center; gap: 7px; direction: ltr; margin: 12px auto 6px; }
.bank-tile { min-width: 42px; height: 44px; padding: 0 10px; border-radius: 11px; border: 2px solid var(--border); background: var(--card-hover); font-size: 19px; font-weight: 800; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; box-shadow: 0 2px 0 var(--border); user-select: none; }
.bank-tile.used { opacity: 0.18; pointer-events: none; }

.type-input { width: 100%; max-width: 440px; margin: 8px auto 0; display: block; padding: 14px 16px; font-size: 19px; font-weight: 700; text-align: center; background: var(--bg-soft); border: 2px solid var(--border); border-radius: 14px; outline: none; }
.type-input:focus { border-color: var(--primary); }
.type-input.ltr { direction: ltr; }
.type-input.rtl { direction: rtl; }

.hint-line { font-size: 18px; font-weight: 800; letter-spacing: 3px; color: var(--warning); margin: 6px 0; }
.hint-line.ltr { direction: ltr; }
.diff-view { direction: ltr; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 17px; padding: 5px 10px; border-radius: 8px; background: rgba(0,0,0,0.22); margin-top: 8px; display: inline-block; }
.diff-ok { color: var(--success); font-weight: 900; }
.diff-bad { color: var(--danger); text-decoration: line-through; }

.flashcard { background: linear-gradient(145deg, var(--card-hover), var(--card)); border: 2px solid var(--border); border-radius: 20px; min-height: 230px; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 24px 18px; cursor: pointer; text-align: center; box-shadow: var(--shadow); }

.word-list { display: flex; flex-direction: column; gap: 7px; }
.word-row { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 10px 12px; display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.word-row-click { cursor: pointer; }
.word-row-click:active { background: var(--card-hover); border-color: var(--primary); }
.word-pair { flex: 1; min-width: 0; }
.word-en { font-weight: 800; font-size: 15.5px; direction: ltr; text-align: right; display: flex; align-items: center; justify-content: flex-end; gap: 7px; flex-wrap: wrap; }
.word-ar { font-size: 14px; color: var(--text-muted); margin-top: 2px; }

.set-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 12px 0; border-bottom: 1px solid var(--border); }
.set-row:last-child { border-bottom: none; padding-bottom: 2px; }
.set-row:first-child { padding-top: 2px; }

.mini-stats { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; margin-bottom: 14px; }
@media (min-width: 560px) { .mini-stats { grid-template-columns: repeat(4, 1fr); } }
.stat-tile { background: var(--card); border: 1px solid var(--border); border-radius: 13px; padding: 11px 8px; text-align: center; }
.stat-tile .sv { font-size: 20px; font-weight: 900; }
.stat-tile .sl { font-size: 11.5px; color: var(--text-muted); }

.detail-hero-card, .photo-card, .sentence-card, .video-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: var(--radius); box-shadow: var(--shadow); margin-bottom: 14px;
}
.detail-hero-card, .sentence-card { padding: 15px; }
.photo-card, .video-card { overflow: hidden; }
.detail-word-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; }
.detail-word-en { font-size: clamp(26px, 7vw, 36px); font-weight: 900; direction: ltr; text-align: left; line-height: 1.15; overflow-wrap: anywhere; }
.detail-word-ar { font-size: 20px; font-weight: 800; color: var(--cyan); margin-top: 6px; }
.word-meta-pills { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-top: 8px; }
.pos-pill { display: inline-flex; padding: 3px 10px; border-radius: 99px; background: var(--primary-soft); color: var(--primary); font-size: 12px; font-weight: 800; }
.ipa-pill { display: inline-flex; padding: 3px 10px; border-radius: 99px; background: var(--bg-soft); border: 1px solid var(--border); font-size: 13px; font-weight: 700; direction: ltr; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }

.photo-card-head, .video-card-head {
  padding: 11px 14px; border-bottom: 1px solid var(--border);
  display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap;
}
.sentence-card-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
.photo-frame { position: relative; width: 100%; aspect-ratio: 16 / 10; background: var(--bg-soft); display: flex; align-items: center; justify-content: center; overflow: hidden; }
.photo-img { width: 100%; height: 100%; object-fit: cover; display: block; opacity: 0; transition: opacity 0.28s ease; }
.photo-img.loaded { opacity: 1; }
.photo-skeleton {
  position: absolute; inset: 0;
  background: linear-gradient(90deg, var(--bg-soft) 25%, var(--card-hover) 50%, var(--bg-soft) 75%);
  background-size: 200% 100%; animation: photoShimmer 1.3s infinite linear;
  display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px;
  color: var(--text-muted); font-size: 13px; font-weight: 700;
}
@keyframes photoShimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
.photo-credit { padding: 9px 14px; font-size: 12px; color: var(--text-muted); display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap; border-top: 1px solid var(--border); overflow-wrap: anywhere; }
.photo-credit a { color: var(--primary); text-decoration: none; font-weight: 700; }
.photo-fallback, .video-launch-box { padding: 20px 14px; text-align: center; color: var(--text-muted); }

.sentence-text {
  direction: ltr; text-align: left; font-size: 17.5px; font-weight: 600; line-height: 1.6;
  background: var(--bg-soft); border-radius: 12px; padding: 13px 14px;
  border-left: 4px solid var(--primary); overflow-wrap: anywhere;
}
.target-word-underline {
  text-decoration: underline; text-decoration-color: var(--cyan); text-decoration-thickness: 3px;
  text-underline-offset: 4px; color: var(--cyan); font-weight: 900;
}
.sentence-footer { display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap; margin-top: 10px; }

.yt-embed-wrap { position: relative; width: 100%; aspect-ratio: 16 / 9; background: #000; }
.yt-embed-wrap iframe, .yt-embed-wrap > div { position: absolute; inset: 0; width: 100%; height: 100%; border: 0; }
.video-body { padding: 14px; }
.video-target-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap; margin-bottom: 8px; }
.verified-badge { display: inline-flex; align-items: center; gap: 4px; padding: 2px 9px; border-radius: 99px; font-size: 11.5px; font-weight: 800; background: var(--success-soft); color: var(--success); }
.video-transcript-box { direction: ltr; text-align: left; font-size: 16.5px; font-weight: 600; line-height: 1.55; background: var(--bg-soft); border-radius: 12px; padding: 12px; border-left: 4px solid var(--cyan); margin: 8px 0 12px; overflow-wrap: anywhere; }
.video-nav-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-bottom: 10px; }
@media (max-width: 380px) {
  .video-nav-grid { grid-template-columns: 1fr 1fr; }
  .video-nav-grid button:last-child { grid-column: 1 / -1; }
}
.video-sub-actions { display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap; }
.video-status-banner { margin-top: 10px; padding: 8px 12px; border-radius: 10px; background: var(--primary-soft); color: var(--text); font-size: 12.5px; font-weight: 700; text-align: center; }

.toast {
  position: fixed; top: 66px; left: 50%; transform: translateX(-50%) translateY(-10px);
  background: #0f172a; color: #fff; border: 1px solid var(--primary);
  padding: 9px 16px; border-radius: 99px; font-size: 13px; font-weight: 700;
  opacity: 0; pointer-events: none; transition: opacity 0.2s, transform 0.2s;
  z-index: 999; box-shadow: 0 8px 24px rgba(0,0,0,0.4); white-space: nowrap; max-width: 92vw; overflow: hidden; text-overflow: ellipsis;
}
.toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }
@keyframes shake { 0%,100% { transform: translateX(0); } 25% { transform: translateX(-6px); } 75% { transform: translateX(6px); } }
</style>
</head>
<body>

<header class="topbar">
  <div class="topbar-inner" id="topbarInner"></div>
</header>

<main class="main-wrap" id="appMain"></main>

<div id="actionDockWrap"></div>

<nav class="bottom-nav" id="bottomNav">
  <div class="bottom-nav-inner">
    <button class="bnav-btn active" data-tab="games" onclick="goTab('games')">
      <span class="ico">🎮</span><span>الألعاب</span>
    </button>
    <button class="bnav-btn" data-tab="levels" onclick="goTab('levels')">
      <span class="ico">📚</span><span>المستويات</span>
    </button>
    <button class="bnav-btn" data-tab="dict" onclick="goTab('dict')">
      <span class="ico">📖</span><span>القاموس</span>
      <span class="bnav-dot" id="bnavMistakes" style="display:none">0</span>
    </button>
    <button class="bnav-btn" data-tab="settings" onclick="goTab('settings')">
      <span class="ico">⚙️</span><span>الإعدادات</span>
    </button>
  </div>
</nav>

<div class="toast" id="toast"></div>

<script type="text/plain" id="embedded-vocab">
`;

export const STANDALONE_HTML_SUFFIX = `
</script>

<script>
(function() {
  'use strict';

  const BANDS = ['A0', 'A1', 'A2', 'B1', 'B2', 'C1', 'C2'];
  const BAND_META = {
    A0: { ar: 'تأسيسي', desc: 'أهم الكلمات الأساسية جداً', color: '#10b981' },
    A1: { ar: 'مبتدئ', desc: 'مستوى المبتدئ الأول', color: '#14b8a6' },
    A2: { ar: 'أساسي', desc: 'المحادثة والحياة اليومية', color: '#06b6d4' },
    B1: { ar: 'متوسط', desc: 'الطلاقة اليومية والدراسية', color: '#3b82f6' },
    B2: { ar: 'فوق المتوسط', desc: 'مستوى العمل والجامعة', color: '#6366f1' },
    C1: { ar: 'متقدم', desc: 'إتقان أكاديمي ومهني', color: '#a855f7' },
    C2: { ar: 'احترافي', desc: 'حصيلة لغوية شاملة', color: '#f43f5e' }
  };

  const GAMES = [
    { id: 'missing',  ico: '🧩', name: 'الحروف الناقصة',       desc: 'أكمل الأحرف المفقودة في الكلمة' },
    { id: 'scramble', ico: '🔀', name: 'ترتيب الحروف',          desc: 'رتّب الحروف المخربطة لتطلع الكلمة' },
    { id: 'type_en',  ico: '⌨️', name: 'اكتب بالإنكليزي',       desc: 'تظهر بالعربي وتكتبها بالإنكليزي' },
    { id: 'type_ar',  ico: '✍️', name: 'اكتب بالعربي',          desc: 'تظهر بالإنكليزي وتكتب معناها' },
    { id: 'mcq',      ico: '🎯', name: 'اختيار من متعدد',       desc: 'اختر الإجابة الصح من 4 خيارات' },
    { id: 'tf',       ico: '⚡', name: 'صح أم خطأ',             desc: 'اختبار سريع للترجمة' },
    { id: 'match',    ico: '🔗', name: 'لعبة التوصيل',          desc: 'وصّل كل كلمة بترجمتها العربية' },
    { id: 'mixed',    ico: '🌟', name: 'جولة منوّعة',           desc: 'مزيج من كل الألعاب معاً', featured: true },
    { id: 'study',    ico: '📖', name: 'بطاقات المراجعة',       desc: 'بطاقات للحفظ السريع مثل أنكي' }
  ];
  const GAME_MAP = {};
  GAMES.forEach(g => { GAME_MAP[g.id] = g; });

  const STORE_KEY = 'vocab_cefr_android_v3';
  const IDB_NAME = 'VocabCefrCustomDB';
  const IDB_STORE = 'csvStore';

  function todayStr() {
    const d = new Date();
    return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  }
  function safeLoadState() {
    try { const raw = localStorage.getItem(STORE_KEY); if (raw) return JSON.parse(raw); } catch (e) {}
    return null;
  }
  function safeSaveState() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({
        levelSize: S.levelSize, dailyGoal: S.dailyGoal, todayDate: S.todayDate, todayCount: S.todayCount,
        theme: S.theme, sfx: S.sfx, autoSpeak: S.autoSpeak, ttsRate: S.ttsRate, mcqDir: S.mcqDir,
        lastGame: S.lastGame, lastBand: S.lastBand, lastSubLevel: S.lastSubLevel,
        xp: S.xp, streak: S.streak, bestStreak: S.bestStreak, completed: S.completed,
        mistakes: Array.from(S.mistakes), favorites: Array.from(S.favorites), mastered: Array.from(S.mastered),
        pixabayKey: S.pixabayKey, unsplashKey: S.unsplashKey, backendUrl: S.backendUrl, usingCustom: S.usingCustom
      }));
    } catch (e) {}
  }

  let audioCtx = null;
  function playSfx(type) {
    if (!S.sfx) return;
    try {
      if (!audioCtx) { const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return; audioCtx = new AC(); }
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const now = audioCtx.currentTime, osc = audioCtx.createOscillator(), gain = audioCtx.createGain();
      osc.connect(gain); gain.connect(audioCtx.destination);
      if (type === 'ok') { osc.type='sine'; osc.frequency.setValueAtTime(523.25,now); osc.frequency.exponentialRampToValueAtTime(783.99,now+0.11); gain.gain.setValueAtTime(0.1,now); gain.gain.exponentialRampToValueAtTime(0.001,now+0.18); osc.start(now); osc.stop(now+0.19); }
      else if (type === 'err') { osc.type='triangle'; osc.frequency.setValueAtTime(240,now); osc.frequency.exponentialRampToValueAtTime(150,now+0.15); gain.gain.setValueAtTime(0.11,now); gain.gain.exponentialRampToValueAtTime(0.001,now+0.19); osc.start(now); osc.stop(now+0.2); }
      else if (type === 'tap') { osc.type='sine'; osc.frequency.setValueAtTime(420,now); gain.gain.setValueAtTime(0.04,now); gain.gain.exponentialRampToValueAtTime(0.001,now+0.045); osc.start(now); osc.stop(now+0.05); }
      else if (type === 'win') { [523.25,659.25,783.99,1046.5].forEach((freq,i)=>{ const o=audioCtx.createOscillator(), g=audioCtx.createGain(); o.connect(g); g.connect(audioCtx.destination); o.type='sine'; o.frequency.setValueAtTime(freq,now+i*0.08); g.gain.setValueAtTime(0.09,now+i*0.08); g.gain.exponentialRampToValueAtTime(0.001,now+i*0.08+0.22); o.start(now+i*0.08); o.stop(now+i*0.08+0.23); }); }
    } catch (e) {}
  }

  let cachedEnVoice = null, activeFallbackAudio = null, ttsTimer = null;
  function pickEnglishVoice() {
    try {
      if (!('speechSynthesis' in window)) return null;
      const voices = window.speechSynthesis.getVoices() || [];
      if (!voices.length) return null;
      cachedEnVoice =
        voices.find(v => /^en[-_]US$/i.test(v.lang) && !v.localService) ||
        voices.find(v => /^en[-_]US$/i.test(v.lang)) ||
        voices.find(v => /^en[-_]GB$/i.test(v.lang)) ||
        voices.find(v => /^en/i.test(v.lang)) || null;
      return cachedEnVoice;
    } catch (e) { return null; }
  }
  if ('speechSynthesis' in window) {
    pickEnglishVoice();
    try { window.speechSynthesis.onvoiceschanged = pickEnglishVoice; } catch (e) {}
  }

  async function playDictMp3Fallback(text) {
    const clean = String(text || '').trim();
    if (!clean || clean.split(/\\s+/).length > 2) { showToast('فعّل محرك الصوت Google TTS في إعدادات الهاتف لقراءة الجمل'); return false; }
    try {
      if (activeFallbackAudio) { activeFallbackAudio.pause(); activeFallbackAudio = null; }
      const r = await fetch('https://api.dictionaryapi.dev/api/v2/entries/en/' + encodeURIComponent(clean.toLowerCase()));
      if (r.ok) {
        const entries = await r.json(), urls = [];
        if (Array.isArray(entries)) entries.forEach(en => (en.phonetics || []).forEach(p => { if (p && p.audio) urls.push(p.audio.startsWith('//') ? 'https:' + p.audio : p.audio); }));
        const mp3 = urls.find(u => /-us\\.mp3$/i.test(u)) || urls.find(u => /-uk\\.mp3$/i.test(u)) || urls[0];
        if (mp3) { const a = new Audio(mp3); a.playbackRate = S.ttsRate || 0.92; activeFallbackAudio = a; await a.play(); return true; }
      }
    } catch (e) {}
    showToast('تعذر النطق: تأكد من تفعيل Google TTS أو الاتصال بالإنترنت');
    return false;
  }

  window.speakWordById = function(idx) { if (idx >= 0 && idx < WORDS_EN.length) window.speakEn(WORDS_EN[idx]); };
  window.speakEn = function(text) {
    const clean = String(text || '').trim(); if (!clean) return;
    try { if (window.AndroidTTS && typeof window.AndroidTTS.speak === 'function') { window.AndroidTTS.speak(clean, S.ttsRate || 0.92); return; } } catch (e) {}
    try {
      if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') { playDictMp3Fallback(clean); return; }
      const synth = window.speechSynthesis, wasBusy = synth.speaking || synth.pending;
      clearTimeout(ttsTimer);
      try { synth.resume(); } catch (e) {}
      if (wasBusy) { try { synth.cancel(); } catch (e) {} }
      const voice = cachedEnVoice || pickEnglishVoice();
      ttsTimer = setTimeout(() => {
        try {
          const u = new SpeechSynthesisUtterance(clean); window._activeUtterance = u;
          if (voice) u.voice = voice;
          u.lang = (voice && voice.lang) || 'en-US'; u.rate = S.ttsRate || 0.92;
          u.onerror = () => { playDictMp3Fallback(clean); };
          synth.speak(u);
        } catch (e) { playDictMp3Fallback(clean); }
      }, wasBusy ? 75 : 15);
    } catch (e) { playDictMp3Fallback(clean); }
  };

  let WORDS_BAND = [], WORDS_EN = [], WORDS_AR = [], BAND_INDICES = {}, NORM_EN_CACHE = null, NORM_AR_CACHE = null;
  function assignBandByIndex(i) { return i<400?'A0':i<900?'A1':i<1800?'A2':i<3000?'B1':i<6000?'B2':i<9000?'C1':'C2'; }
  function parseTSVIntoMemory(tsvText) {
    const bd = [], en = [], ar = [], byBand = {}; BANDS.forEach(b => { byBand[b] = []; });
    let start = 0; const len = tsvText.length;
    while (start < len) {
      let end = tsvText.indexOf('\\n', start); if (end === -1) end = len;
      const line = tsvText.slice(start, end);
      if (line && !line.startsWith('<!--')) {
        const t1 = line.indexOf('\\t');
        if (t1 > 0) {
          const t2 = line.indexOf('\\t', t1 + 1);
          let wBand, wEn, wAr;
          if (t2 > t1) { wBand = line.slice(0, t1).trim().toUpperCase(); if (!BAND_META[wBand]) wBand = assignBandByIndex(en.length); wEn = line.slice(t1 + 1, t2).trim(); wAr = line.slice(t2 + 1).trim(); }
          else { wBand = assignBandByIndex(en.length); wEn = line.slice(0, t1).trim(); wAr = line.slice(t1 + 1).trim(); }
          if (wEn && wAr) { const idx = en.length; bd.push(wBand); en.push(wEn); ar.push(wAr); byBand[wBand].push(idx); }
        }
      }
      start = end + 1;
    }
    WORDS_BAND = bd; WORDS_EN = en; WORDS_AR = ar; BAND_INDICES = byBand; NORM_EN_CACHE = null; NORM_AR_CACHE = null;
  }
  function loadEmbeddedVocab() { const el = document.getElementById('embedded-vocab'); parseTSVIntoMemory(el ? el.textContent : ''); }
  function idbSaveCustomTSV(tsv) { return new Promise(r=>{try{const q=indexedDB.open(IDB_NAME,1);q.onupgradeneeded=()=>q.result.createObjectStore(IDB_STORE);q.onsuccess=()=>{const t=q.result.transaction(IDB_STORE,'readwrite');t.objectStore(IDB_STORE).put(tsv,'custom_tsv');t.oncomplete=()=>r(true);t.onerror=()=>r(false);};q.onerror=()=>r(false);}catch(e){r(false);}}); }
  function idbLoadCustomTSV() { return new Promise(r=>{try{const q=indexedDB.open(IDB_NAME,1);q.onupgradeneeded=()=>q.result.createObjectStore(IDB_STORE);q.onsuccess=()=>{const t=q.result.transaction(IDB_STORE,'readonly'),g=t.objectStore(IDB_STORE).get('custom_tsv');g.onsuccess=()=>r(g.result||null);g.onerror=()=>r(null);};q.onerror=()=>r(null);}catch(e){r(null);}}); }
  function idbClearCustomTSV() { return new Promise(r=>{try{const q=indexedDB.open(IDB_NAME,1);q.onupgradeneeded=()=>q.result.createObjectStore(IDB_STORE);q.onsuccess=()=>{const t=q.result.transaction(IDB_STORE,'readwrite');t.objectStore(IDB_STORE).delete('custom_tsv');t.oncomplete=()=>r(true);t.onerror=()=>r(false);};q.onerror=()=>r(false);}catch(e){r(false);}}); }

  function normalizeEn(str) { return (str || '').normalize('NFKD').replace(/[\\u0300-\\u036f]/g, '').toLowerCase().replace(/\\s+/g, ' ').trim(); }
  function normalizeAr(str) { return (str || '').replace(/[\\u064B-\\u065F\\u0670\\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/[^\\u0600-\\u06FFa-zA-Z0-9\\s]/g, ' ').replace(/\\s+/g, ' ').trim(); }
  function stripAl(s) { return (s.startsWith('ال') && s.length > 4) ? s.slice(2) : s; }
  function checkArabicMatch(uIn, tAr) {
    const uNorm = normalizeAr(uIn); if (!uNorm) return false;
    const tFull = normalizeAr(tAr); if (uNorm === tFull || stripAl(uNorm) === stripAl(tFull)) return true;
    const parts = tAr.split(/[-–—/،,;؛|()]+/).map(p => normalizeAr(p)).filter(Boolean);
    for (let i = 0; i < parts.length; i++) if (uNorm === parts[i] || stripAl(uNorm) === stripAl(parts[i])) return true;
    return false;
  }
  function checkEnglishMatch(uIn, tEn) { const u = normalizeEn(uIn), t = normalizeEn(tEn); if (!u) return false; if (u === t) return true; return u.replace(/[-'\\s]/g, '') === t.replace(/[-'\\s]/g, ''); }
  function escapeHtml(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

  const saved = safeLoadState(), td = todayStr();
  const S = {
    screen: 'games', navTab: 'games',
    levelSize: (saved && saved.levelSize) || 20, dailyGoal: (saved && saved.dailyGoal) || 20,
    todayDate: td, todayCount: (saved && saved.todayDate === td) ? (saved.todayCount || 0) : 0,
    theme: (saved && saved.theme) || 'dark',
    sfx: saved && typeof saved.sfx === 'boolean' ? saved.sfx : true,
    autoSpeak: saved && typeof saved.autoSpeak === 'boolean' ? saved.autoSpeak : false,
    ttsRate: (saved && saved.ttsRate) || 0.92, mcqDir: (saved && saved.mcqDir) || 'en2ar',
    lastGame: (saved && saved.lastGame && GAME_MAP[saved.lastGame]) ? saved.lastGame : 'missing',
    lastBand: (saved && saved.lastBand && BAND_META[saved.lastBand]) ? saved.lastBand : 'A0',
    lastSubLevel: (saved && typeof saved.lastSubLevel === 'number') ? saved.lastSubLevel : 0,
    xp: (saved && saved.xp) || 0, streak: (saved && saved.streak) || 0, bestStreak: (saved && saved.bestStreak) || 0,
    completed: (saved && saved.completed) || {},
    mistakes: new Set((saved && saved.mistakes) || []), favorites: new Set((saved && saved.favorites) || []), mastered: new Set((saved && saved.mastered) || []),
    pixabayKey: (saved && saved.pixabayKey) || '', unsplashKey: (saved && saved.unsplashKey) || 'ofbUnj5e3vSjfGor04gqVKKkVBTUet-PqtFnRNqWPzI', backendUrl: (saved && saved.backendUrl) || '',
    usingCustom: !!(saved && saved.usingCustom),
    setupGame: 'missing', setupSource: 'level',
    setupBand: (saved && saved.lastBand && BAND_META[saved.lastBand]) ? saved.lastBand : 'A0',
    setupSub: (saved && typeof saved.lastSubLevel === 'number') ? saved.lastSubLevel : 0,
    browseBand: 'A0', browseFilter: 'all', browsePage: 0, detailBand: 'A0', detailSub: 0, detailTab: 'games',
    detailWordIdx: -1, detailReturnScreen: 'dict', dictTab: 'search', searchQuery: '', searchBand: 'ALL', searchLimit: 50, activeTimers: []
  };

  function clearAllTimers() { while (S.activeTimers.length) clearTimeout(S.activeTimers.pop()); }
  function setSafeTimeout(fn, ms) { const id = setTimeout(() => { const i = S.activeTimers.indexOf(id); if (i > -1) S.activeTimers.splice(i, 1); fn(); }, ms); S.activeTimers.push(id); return id; }
  function bumpDailyCount() { const nowD = todayStr(); if (S.todayDate !== nowD) { S.todayDate = nowD; S.todayCount = 0; } S.todayCount++; }
  function pushHist(scr) { try { history.pushState({ scr: scr }, ''); } catch (e) {} }
  window.addEventListener('popstate', function() { goBack(); });

  window.goBack = function() {
    clearAllTimers();
    if (S.screen === 'word_detail') { cleanupVideoPlayer(); S.screen = S.detailReturnScreen || 'dict'; render(); window.scrollTo(0, 0); return; }
    if (S.screen === 'game' || S.screen === 'study') { const rt = (G && G.returnScreen) || (studyState && studyState.returnScreen) || 'games'; G = null; studyState = null; S.screen = rt; render(); window.scrollTo(0, 0); return; }
    if (S.screen === 'game_setup') { S.screen = S.navTab === 'dict' ? 'dict' : 'games'; render(); window.scrollTo(0, 0); return; }
    if (S.screen === 'level_detail') { S.screen = 'band_levels'; render(); window.scrollTo(0, 0); return; }
    if (S.screen === 'band_levels') { S.screen = 'levels'; render(); window.scrollTo(0, 0); return; }
    if (S.screen !== 'games') { S.screen = 'games'; S.navTab = 'games'; render(); window.scrollTo(0, 0); }
  };

  let toastTimer = null;
  function showToast(msg) { const el = document.getElementById('toast'); el.textContent = msg; el.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2300); }
  function applyTheme() { document.body.classList.toggle('light', S.theme === 'light'); const mt = document.querySelector('meta[name="theme-color"]'); if (mt) mt.setAttribute('content', S.theme === 'light' ? '#f1f5f9' : '#0f172a'); }
  window.toggleTheme = function() { S.theme = S.theme === 'light' ? 'dark' : 'light'; applyTheme(); safeSaveState(); render(); };
  window.toggleSound = function() { S.sfx = !S.sfx; safeSaveState(); render(); showToast(S.sfx ? 'تم تشغيل الصوت' : 'تم كتم الصوت'); };

  function getBandSubCount(b) { const a = BAND_INDICES[b] || []; return Math.max(1, Math.ceil(a.length / S.levelSize)); }
  function getBandSubIndices(b, s) { const a = BAND_INDICES[b] || []; return a.slice(s * S.levelSize, (s + 1) * S.levelSize); }
  function lvlKey(b, s) { return b + ':' + s; }
  function getBandDoneCount(b) { const t = getBandSubCount(b); let c = 0; for (let i = 0; i < t; i++) if ((S.completed[lvlKey(b, i)] || 0) >= 80) c++; return c; }
  function bandPillHTML(b) { const m = BAND_META[b] || { color: '#6366f1' }; return '<span class="band-pill" style="background:' + m.color + '">' + b + '</span>'; }
  function shuffleArr(arr) { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function pickDistractors(targetIdx, count, checkByAr) {
    const chosen = new Set([targetIdx]), tk = checkByAr ? normalizeAr(WORDS_AR[targetIdx]) : normalizeEn(WORDS_EN[targetIdx]), out = [], ba = BAND_INDICES[WORDS_BAND[targetIdx]] || [];
    let g = 0;
    while (out.length < count && g < 120 && ba.length > count + 2) { g++; const r = ba[Math.floor(Math.random() * ba.length)]; if (chosen.has(r)) continue; if ((checkByAr ? normalizeAr(WORDS_AR[r]) : normalizeEn(WORDS_EN[r])) === tk) continue; chosen.add(r); out.push(r); }
    g = 0;
    while (out.length < count && g < 150) { g++; const r = Math.floor(Math.random() * WORDS_EN.length); if (chosen.has(r)) continue; if ((checkByAr ? normalizeAr(WORDS_AR[r]) : normalizeEn(WORDS_EN[r])) === tk) continue; chosen.add(r); out.push(r); }
    return out;
  }

  window.goTab = function(tab) { clearAllTimers(); cleanupVideoPlayer(); G = null; studyState = null; S.navTab = tab; S.screen = tab; render(); window.scrollTo(0, 0); };
  function updateBottomNav() {
    document.querySelectorAll('.bnav-btn').forEach(btn => btn.classList.toggle('active', btn.getAttribute('data-tab') === S.navTab));
    const dot = document.getElementById('bnavMistakes');
    if (S.mistakes.size > 0) { dot.style.display = 'inline-block'; dot.textContent = S.mistakes.size > 99 ? '99+' : S.mistakes.size; } else dot.style.display = 'none';
  }
  function renderTopBar() {
    const el = document.getElementById('topbarInner');
    const isInGame = (S.screen === 'game' || S.screen === 'study');
    const isSubScreen = (S.screen === 'game_setup' || S.screen === 'band_levels' || S.screen === 'level_detail' || S.screen === 'word_detail');
    if (isInGame) {
      let title = '', rightHTML = '';
      if (S.screen === 'game' && G) {
        const gm = GAME_MAP[G.mode] || { ico: '🎮', name: 'لعبة' }, tot = G.mode === 'match' ? G.matchRounds.length : G.pool.length, cur = G.finished ? tot : (G.mode === 'match' ? G.matchRound + 1 : G.qIndex + 1);
        title = gm.ico + ' ' + gm.name; rightHTML = '<span style="font-size:13px;font-weight:800;color:var(--text-muted)">' + cur + '/' + tot + '</span><span style="font-size:13px;font-weight:800;color:var(--success)">✓' + G.correctCount + '</span><span style="font-size:13px;font-weight:800;color:var(--danger)">✕' + G.wrongCount + '</span>';
      } else if (S.screen === 'study' && studyState) {
        title = '📖 بطاقات المراجعة'; rightHTML = '<span style="font-size:13px;font-weight:800;color:var(--text-muted)">' + (studyState.pos + 1) + '/' + studyState.indices.length + '</span>';
      }
      el.innerHTML = '<div class="top-left"><button class="icon-btn" onclick="goBack()">✕</button><div class="top-title">' + title + '</div></div><div class="top-right">' + rightHTML + '</div>';
      return;
    }
    if (isSubScreen) {
      let title = 'إعداد الجولة';
      if (S.screen === 'game_setup') { const gm = GAME_MAP[S.setupGame] || GAMES[0]; title = gm.ico + ' ' + gm.name; }
      else if (S.screen === 'band_levels') title = 'مستوى ' + S.browseBand + ' — ' + BAND_META[S.browseBand].ar;
      else if (S.screen === 'level_detail') title = S.detailBand + ' • المستوى ' + (S.detailSub + 1);
      else if (S.screen === 'word_detail') title = WORDS_EN[S.detailWordIdx] || 'تفاصيل الكلمة';
      el.innerHTML = '<div class="top-left"><button class="icon-btn" onclick="goBack()">→</button><div class="top-title">' + escapeHtml(title) + '</div></div><div class="top-right"><button class="icon-btn" onclick="toggleSound()">' + (S.sfx ? '🔊' : '🔇') + '</button></div>';
      return;
    }
    const tabTitles = { games: 'قاموس الألعاب A0–C2', levels: 'مستويات اللغة (A0–C2)', dict: 'القاموس والمراجعة', settings: 'الإعدادات' };
    el.innerHTML = '<div class="top-left"><div class="brand-logo">EN</div><div class="top-title">' + (tabTitles[S.screen] || 'قاموس الألعاب') + '</div></div><div class="top-right"><button class="icon-btn" onclick="toggleSound()">' + (S.sfx ? '🔊' : '🔇') + '</button><button class="icon-btn" onclick="toggleTheme()">' + (S.theme === 'light' ? '🌙' : '☀️') + '</button></div>';
  }

  function render() {
    const inGame = (S.screen === 'game' || S.screen === 'study' || S.screen === 'game_setup');
    document.body.classList.toggle('in-game', inGame);
    updateBottomNav(); renderTopBar();
    const main = document.getElementById('appMain'), dock = document.getElementById('actionDockWrap');
    dock.innerHTML = '';
    if (WORDS_EN.length === 0 && S.screen !== 'settings') {
      main.innerHTML = '<div class="card" style="text-align:center;padding:24px"><div style="font-size:38px">📖</div><h3>القاموس فارغ</h3><p class="muted">الصق جدول الكلمات من ملفك الأصلي داخل &lt;script id="embedded-vocab"&gt; أو استورد ملف CSV من الإعدادات.</p><button class="btn btn-primary" onclick="goTab(\\'settings\\')">الذهاب للإعدادات ⚙️</button></div>';
      return;
    }
    if (S.screen === 'games') renderGamesHome(main);
    else if (S.screen === 'game_setup') renderGameSetup(main, dock);
    else if (S.screen === 'levels') renderCefrBandsList(main);
    else if (S.screen === 'band_levels') renderBandSubLevels(main);
    else if (S.screen === 'level_detail') renderLevelDetail(main);
    else if (S.screen === 'dict') renderDictView(main);
    else if (S.screen === 'settings') renderSettingsView(main);
    else if (S.screen === 'game') renderGameArena(main, dock);
    else if (S.screen === 'study') renderStudyArena(main, dock);
    else if (S.screen === 'word_detail') renderWordDetailView(main);
  }
  window.render = render;

  function renderGamesHome(main) {
    const goalPct = Math.min(100, Math.round((S.todayCount / Math.max(1, S.dailyGoal)) * 100));
    const lg = GAME_MAP[S.lastGame] || GAMES[0], lb = BAND_META[S.lastBand] ? S.lastBand : 'A0', lsub = Math.min(Math.max(0, S.lastSubLevel), getBandSubCount(lb) - 1);
    main.innerHTML = '<div class="goal-strip"><div class="goal-top"><div><div style="font-weight:900;font-size:14.5px">🎯 هدف اليوم: ' + S.todayCount + ' / ' + S.dailyGoal + ' كلمة</div><div style="font-size:12px;color:var(--text-muted)">' + WORDS_EN.length.toLocaleString('en-US') + ' كلمة (A0–C2) • بدون إنترنت</div></div><div style="display:flex;gap:10px;font-size:13px;font-weight:900"><span style="color:var(--warning)">⚡ ' + S.xp + '</span><span style="color:var(--success)">✓ ' + S.mastered.size + '</span></div></div><div class="goal-bar"><i style="width:' + goalPct + '%"></i></div></div><div class="card" style="padding:12px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap"><div style="min-width:0"><div style="font-size:12px;color:var(--text-muted);font-weight:700">متابعة سريعة</div><div style="font-weight:800;font-size:14.5px;display:flex;align-items:center;gap:6px;flex-wrap:wrap">' + bandPillHTML(lb) + ' ' + lg.ico + ' ' + lg.name + ' — مستوى ' + (lsub + 1) + '</div></div><button class="btn btn-primary btn-sm" onclick="quickResume()">متابعة ▶</button></div><div class="section-head"><h2 class="section-title">اختر اللعبة اللي بدك تلعبها</h2><span class="muted">9 أوضاع</span></div><div class="games-grid">' + GAMES.map(g => '<div class="game-card ' + (g.featured?'featured':'') + '" onclick="openGameSetup(\\'' + g.id + '\\',\\'level\\')"><div class="g-ico">' + g.ico + '</div><div class="g-name">' + g.name + '</div><div class="g-desc">' + g.desc + '</div></div>').join('') + '</div>';
  }
  window.quickResume = function() { const lb = BAND_META[S.lastBand] ? S.lastBand : 'A0', lsub = Math.min(Math.max(0, S.lastSubLevel), getBandSubCount(lb) - 1); if (S.lastGame === 'study') openStudy(lb, lsub, 'games'); else startGame(S.lastGame, 'level', lb, lsub, 'games'); };
  window.openGameSetup = function(gameId, defaultSource) { S.setupGame = gameId; S.setupSource = defaultSource || 'level'; S.setupBand = BAND_META[S.lastBand] ? S.lastBand : 'A0'; S.setupSub = Math.min(Math.max(0, S.lastSubLevel), getBandSubCount(S.setupBand) - 1); S.screen = 'game_setup'; pushHist('game_setup'); render(); window.scrollTo(0, 0); };
  function renderGameSetup(main, dock) {
    const gm = GAME_MAP[S.setupGame] || GAMES[0], subTot = getBandSubCount(S.setupBand);
    if (S.setupSub >= subTot) S.setupSub = subTot - 1; if (S.setupSub < 0) S.setupSub = 0;
    const score = S.completed[lvlKey(S.setupBand, S.setupSub)] || 0, previewWords = getBandSubIndices(S.setupBand, S.setupSub).slice(0, 4).map(i => WORDS_EN[i]).join(' • ');
    let srcHTML = '';
    if (S.setupSource === 'level' || S.setupSource === 'random') {
      srcHTML = '<div class="card"><div style="font-weight:800;font-size:14px;margin-bottom:10px">1. اختر مستوى اللغة (CEFR)</div><div class="band-pills-grid">' + BANDS.map(b => '<button class="band-pick-btn ' + (S.setupBand===b?'active':'') + '" onclick="setSetupBand(\\'' + b + '\\')"><span class="bc" style="color:' + BAND_META[b].color + '">' + b + '</span><span class="ba">' + BAND_META[b].ar + '</span></button>').join('') + '</div><div class="muted" style="margin-top:8px;text-align:center">' + BAND_META[S.setupBand].ar + ': ' + (BAND_INDICES[S.setupBand]||[]).length.toLocaleString('en-US') + ' كلمة (' + subTot + ' مستوى)</div></div>';
      if (S.setupSource === 'level') {
        const opts = []; for (let i = 0; i < subTot; i++) { const sc = S.completed[lvlKey(S.setupBand, i)] || 0; opts.push('<option value="' + i + '" ' + (i===S.setupSub?'selected':'') + '>المستوى ' + (i+1) + (sc>=80?' ✓':(sc>0?' ('+sc+'%)':'')) + '</option>'); }
        srcHTML += '<div class="card"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px"><span style="font-weight:800;font-size:14px">2. اختر رقم المستوى داخل ' + S.setupBand + '</span><span class="lvl-tag ' + (score>=80?'done':(score>0?'prog':'new')) + '">' + (score>0?score+'%':'جديد') + '</span></div><div style="display:flex;gap:8px;align-items:center"><button class="btn btn-soft" ' + (S.setupSub===0?'disabled':'') + ' onclick="stepSetupSub(-1)">‹</button><select class="select" style="flex:1;text-align:center;font-weight:800" onchange="setSetupSub(this.value)">' + opts.join('') + '</select><button class="btn btn-soft" ' + (S.setupSub>=subTot-1?'disabled':'') + ' onclick="stepSetupSub(1)">›</button></div><div class="muted" style="margin-top:9px;direction:ltr;text-align:center">' + escapeHtml(previewWords) + '</div></div>';
      }
    } else if (S.setupSource === 'mistakes') srcHTML = '<div class="card" style="text-align:center"><div style="font-size:34px">🔥</div><div style="font-weight:800;font-size:16px;margin-top:4px">بنك الأخطاء (' + S.mistakes.size + ' كلمة)</div><div class="muted">' + (S.mistakes.size>0?'رح تلعب بالكلمات اللي أخطأت فيها.':'ما عندك أخطاء مسجلة حالياً!') + '</div></div>';
    else srcHTML = '<div class="card" style="text-align:center"><div style="font-size:34px">⭐</div><div style="font-weight:800;font-size:16px;margin-top:4px">الكلمات المفضلة (' + S.favorites.size + ' كلمة)</div><div class="muted">' + (S.favorites.size>0?'رح تلعب بالكلمات اللي حطيت عليها نجمة.':'ما أضفت كلمات للمفضلة بعد.') + '</div></div>';
    const dirPicker = S.setupGame === 'mcq' ? '<div class="card"><div style="font-weight:800;font-size:14px;margin-bottom:8px">اتجاه السؤال</div><div class="seg-bar c2" style="margin:0"><button class="seg-btn ' + (S.mcqDir==='en2ar'?'active':'') + '" onclick="setMcqDir(\\'en2ar\\')">إنكليزي ⟵ عربي</button><button class="seg-btn ' + (S.mcqDir==='ar2en'?'active':'') + '" onclick="setMcqDir(\\'ar2en\\')">عربي ⟵ إنكليزي</button></div></div>' : '';
    main.innerHTML = '<div class="card" style="display:flex;align-items:center;gap:12px"><div style="width:48px;height:48px;border-radius:14px;background:var(--bg-soft);display:flex;align-items:center;justify-content:center;font-size:26px;flex-shrink:0">' + gm.ico + '</div><div><div style="font-weight:900;font-size:17px">' + gm.name + '</div><div class="muted">' + gm.desc + '</div></div></div><div class="seg-bar c4"><button class="seg-btn ' + (S.setupSource==='level'?'active':'') + '" onclick="setSetupSource(\\'level\\')">مستوى</button><button class="seg-btn ' + (S.setupSource==='random'?'active':'') + '" onclick="setSetupSource(\\'random\\')">عشوائي</button><button class="seg-btn ' + (S.setupSource==='mistakes'?'active':'') + '" onclick="setSetupSource(\\'mistakes\\')">الأخطاء (' + S.mistakes.size + ')</button><button class="seg-btn ' + (S.setupSource==='favorites'?'active':'') + '" onclick="setSetupSource(\\'favorites\\')">المفضلة (' + S.favorites.size + ')</button></div>' + srcHTML + dirPicker;
    const canStart = (S.setupSource === 'mistakes' ? S.mistakes.size > 0 : (S.setupSource === 'favorites' ? S.favorites.size > 0 : true));
    dock.innerHTML = '<div class="action-dock"><div class="action-dock-inner"><button class="btn btn-primary btn-lg btn-block" ' + (!canStart?'disabled':'') + ' onclick="launchFromSetup()">ابدأ اللعب الآن ▶</button></div></div>';
  }
  window.setSetupSource = function(s) { S.setupSource = s; playSfx('tap'); render(); };
  window.setSetupBand = function(b) { S.setupBand = b; S.setupSub = 0; playSfx('tap'); render(); };
  window.setSetupSub = function(v) { S.setupSub = parseInt(v, 10) || 0; render(); };
  window.stepSetupSub = function(d) { const max = getBandSubCount(S.setupBand); S.setupSub = Math.min(max - 1, Math.max(0, S.setupSub + d)); playSfx('tap'); render(); };
  window.setMcqDir = function(v) { S.mcqDir = v; safeSaveState(); playSfx('tap'); render(); };
  window.launchFromSetup = function() {
    if (S.setupGame === 'study') {
      if (S.setupSource === 'level') openStudy(S.setupBand, S.setupSub, 'games');
      else if (S.setupSource === 'random') openStudyPool(getRandomPool(S.setupBand), S.setupBand + ' عشوائي', 'games');
      else if (S.setupSource === 'mistakes') openStudyPool(Array.from(S.mistakes), 'بنك الأخطاء', 'games');
      else openStudyPool(Array.from(S.favorites), 'المفضلة', 'games');
      return;
    }
    startGame(S.setupGame, S.setupSource, S.setupBand, S.setupSub, 'games');
  };
  function getRandomPool(band) {
    const arr = (band && BAND_INDICES[band] && BAND_INDICES[band].length) ? BAND_INDICES[band] : null, pool = [], used = new Set(), n = Math.min(S.levelSize, arr ? arr.length : WORDS_EN.length);
    while (pool.length < n) { const r = arr ? arr[Math.floor(Math.random()*arr.length)] : Math.floor(Math.random()*WORDS_EN.length); if (!used.has(r)) { used.add(r); pool.push(r); } }
    return pool;
  }

  function renderCefrBandsList(main) {
    main.innerHTML = '<div class="muted" style="margin-bottom:12px">اضغط على أي مستوى لتفتح مجموعات الكلمات الخاصة فيه:</div><div class="cefr-list">' + BANDS.map(b => {
      const m = BAND_META[b], wCnt = (BAND_INDICES[b]||[]).length, subTot = getBandSubCount(b), subDone = getBandDoneCount(b), pct = Math.round((subDone/Math.max(1,subTot))*100);
      return '<div class="cefr-row-card" onclick="openBandLevels(\\'' + b + '\\')"><div class="cefr-badge-lg" style="background:' + m.color + '">' + b + '</div><div class="cefr-row-info"><div class="cefr-row-top"><span class="cefr-row-name">' + m.ar + '</span><span class="cefr-row-cnt">' + wCnt.toLocaleString('en-US') + ' كلمة</span></div><div class="muted" style="font-size:12px">' + m.desc + ' • مكتمل ' + subDone + ' / ' + subTot + '</div><div class="mini-bar"><i style="width:' + pct + '%;background:' + m.color + '"></i></div></div><span style="color:var(--text-muted);font-size:18px">‹</span></div>';
    }).join('') + '</div>';
  }
  window.openBandLevels = function(b) { S.browseBand = b; S.browseFilter = 'all'; S.browsePage = 0; S.screen = 'band_levels'; pushHist('band_levels'); render(); window.scrollTo(0, 0); };
  function renderBandSubLevels(main) {
    const band = S.browseBand, subTot = getBandSubCount(band), filtered = [];
    for (let i = 0; i < subTot; i++) { const sc = S.completed[lvlKey(band, i)] || 0; if (S.browseFilter==='done' && sc<80) continue; if (S.browseFilter==='todo' && sc>=80) continue; filtered.push(i); }
    const perPage = 20, totPages = Math.max(1, Math.ceil(filtered.length / perPage));
    if (S.browsePage >= totPages) S.browsePage = totPages - 1; if (S.browsePage < 0) S.browsePage = 0;
    const slice = filtered.slice(S.browsePage * perPage, (S.browsePage + 1) * perPage);
    main.innerHTML = '<div class="seg-bar c3"><button class="seg-btn ' + (S.browseFilter==='all'?'active':'') + '" onclick="setBrowseFilter(\\'all\\')">الكل (' + subTot + ')</button><button class="seg-btn ' + (S.browseFilter==='todo'?'active':'') + '" onclick="setBrowseFilter(\\'todo\\')">غير مكتمل</button><button class="seg-btn ' + (S.browseFilter==='done'?'active':'') + '" onclick="setBrowseFilter(\\'done\\')">مكتمل</button></div><div style="display:flex;gap:8px;margin-bottom:12px"><input type="number" id="jumpSubInp" class="input" style="flex:1" min="1" max="' + subTot + '" placeholder="انتقال سريع لرقم مستوى (1 – ' + subTot + ')"><button class="btn btn-soft btn-sm" onclick="jumpBrowseSub()">انتقال</button></div>' + (slice.length===0?'<div class="card" style="text-align:center">لا توجد مستويات مطابقة.</div>':'<div class="levels-grid">' + slice.map(subIdx => { const idxs = getBandSubIndices(band, subIdx), sc = S.completed[lvlKey(band, subIdx)]||0, cls = sc>=80?'done':(sc>0?'prog':'new'), lbl = sc>=80?(sc+'% ✓'):(sc>0?(sc+'%'):'جديد'); return '<div class="level-card ' + (sc>=80?'done':'') + '" onclick="openLevelDetail(\\'' + band + '\\', ' + subIdx + ')"><div class="lvl-head"><span class="lvl-num">المستوى ' + (subIdx+1) + '</span><span class="lvl-tag ' + cls + '">' + lbl + '</span></div><div class="lvl-sample">' + escapeHtml(idxs.slice(0,3).map(id=>WORDS_EN[id]).join(', ')) + '</div><div class="mini-bar" style="margin-top:4px"><i style="width:' + sc + '%;background:var(--success)"></i></div></div>'; }).join('') + '</div>') + (totPages>1?'<div class="pagination"><button class="btn btn-soft btn-sm" ' + (S.browsePage===0?'disabled':'') + ' onclick="setBrowsePage(' + (S.browsePage-1) + ')">‹ السابق</button><span style="font-size:13px;font-weight:800">' + (S.browsePage+1) + ' / ' + totPages + '</span><button class="btn btn-soft btn-sm" ' + (S.browsePage>=totPages-1?'disabled':'') + ' onclick="setBrowsePage(' + (S.browsePage+1) + ')">التالي ›</button></div>':'');
  }
  window.setBrowseFilter = function(f) { S.browseFilter = f; S.browsePage = 0; render(); };
  window.setBrowsePage = function(p) { S.browsePage = p; render(); window.scrollTo(0, 0); };
  window.jumpBrowseSub = function() { const val = parseInt(document.getElementById('jumpSubInp').value, 10), max = getBandSubCount(S.browseBand); if (!val || val < 1 || val > max) { showToast('أدخل رقماً بين 1 و ' + max); return; } openLevelDetail(S.browseBand, val - 1); };
  window.openLevelDetail = function(b, s) { S.detailBand = b; S.detailSub = s; S.detailTab = 'games'; S.lastBand = b; S.lastSubLevel = s; safeSaveState(); S.screen = 'level_detail'; pushHist('level_detail'); render(); window.scrollTo(0, 0); };

  function renderLevelDetail(main) {
    const band = S.detailBand, sub = S.detailSub, indices = getBandSubIndices(band, sub), best = S.completed[lvlKey(band, sub)] || 0, totSub = getBandSubCount(band);
    main.innerHTML = '<div class="card" style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;padding:12px 14px"><div><div style="display:flex;align-items:center;gap:7px">' + bandPillHTML(band) + ' <strong>المستوى ' + (sub+1) + '</strong></div><div class="muted">' + indices.length + ' كلمة • أفضل نتيجة: <strong style="color:var(--success)">' + best + '%</strong></div></div><div style="display:flex;gap:6px"><button class="btn btn-soft btn-sm" ' + (sub===0?'disabled':'') + ' onclick="openLevelDetail(\\'' + band + '\\', ' + (sub-1) + ')">‹</button><button class="btn btn-soft btn-sm" ' + (sub>=totSub-1?'disabled':'') + ' onclick="openLevelDetail(\\'' + band + '\\', ' + (sub+1) + ')">›</button></div></div><div class="seg-bar c2"><button class="seg-btn ' + (S.detailTab==='games'?'active':'') + '" onclick="setDetailTab(\\'games\\')">🎮 اختر لعبة</button><button class="seg-btn ' + (S.detailTab==='words'?'active':'') + '" onclick="setDetailTab(\\'words\\')">📝 كلمات المستوى (' + indices.length + ')</button></div>' + (S.detailTab==='games'?'<div class="games-grid">' + GAMES.map(g=>'<div class="game-card ' + (g.featured?'featured':'') + '" onclick="' + (g.id==='study'?'openStudy(\\''+band+'\\','+sub+',\\'level_detail\\')':'startGame(\\''+g.id+'\\',\\'level\\',\\''+band+'\\','+sub+',\\'level_detail\\')') + '"><div class="g-ico">' + g.ico + '</div><div class="g-name">' + g.name + '</div><div class="g-desc">' + g.desc + '</div></div>').join('') + '</div>':'<div class="word-list">' + indices.map(idx=>wordRowHTML(idx)).join('') + '</div>');
  }
  window.setDetailTab = function(t) { S.detailTab = t; playSfx('tap'); render(); };

  function wordRowHTML(idx) {
    const isFav = S.favorites.has(idx), isMis = S.mistakes.has(idx);
    return '<div class="word-row word-row-click" onclick="openWordDetail(' + idx + ')"><div class="word-pair"><div class="word-en"><span>' + escapeHtml(WORDS_EN[idx]) + '</span>' + bandPillHTML(WORDS_BAND[idx]) + '</div><div class="word-ar">' + escapeHtml(WORDS_AR[idx]) + (isMis?' • 🔥':'') + (S.mastered.has(idx)?' • ✓':'') + '</div></div><div style="display:flex;gap:6px;flex-shrink:0" onclick="event.stopPropagation()"><button class="icon-btn" onclick="speakWordById(' + idx + ')">🔊</button><button class="icon-btn" onclick="toggleFavorite(' + idx + ', this)">' + (isFav?'⭐':'☆') + '</button><button class="icon-btn" onclick="openWordDetail(' + idx + ')" title="تفاصيل الكلمة">🖼️</button></div></div>';
  }
  window.toggleFavorite = function(idx, btn) { if (S.favorites.has(idx)) S.favorites.delete(idx); else S.favorites.add(idx); safeSaveState(); playSfx('tap'); if (btn) btn.textContent = S.favorites.has(idx) ? '⭐' : '☆'; else render(); };

  let searchDebounce = null;
  function ensureSearchCache() { if (NORM_EN_CACHE && NORM_AR_CACHE) return; const len = WORDS_EN.length; NORM_EN_CACHE = new Array(len); NORM_AR_CACHE = new Array(len); for (let i = 0; i < len; i++) { NORM_EN_CACHE[i] = WORDS_EN[i].toLowerCase(); NORM_AR_CACHE[i] = normalizeAr(WORDS_AR[i]); } }
  function renderDictView(main) {
    let body = '';
    if (S.dictTab === 'search') {
      body = '<div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap"><input id="searchBox" class="input" style="flex:1;min-width:180px" type="search" placeholder="ابحث بأي كلمة إنكليزية أو عربية..." value="' + escapeHtml(S.searchQuery) + '" oninput="onSearchInput(this.value)"><select class="select" onchange="onSearchBandChange(this.value)"><option value="ALL" ' + (S.searchBand==='ALL'?'selected':'') + '>الكل</option>' + BANDS.map(b=>'<option value="' + b + '" ' + (S.searchBand===b?'selected':'') + '>' + b + '</option>').join('') + '</select></div><div id="searchMeta" class="muted" style="margin-bottom:8px"></div><div id="searchResults" class="word-list"></div>';
    } else {
      const isM = S.dictTab === 'mistakes', list = Array.from(isM ? S.mistakes : S.favorites).filter(i => i >= 0 && i < WORDS_EN.length);
      body = list.length === 0 ? '<div class="card" style="text-align:center;padding:30px 14px"><div style="font-size:38px;margin-bottom:6px">' + (isM?'✨':'⭐') + '</div><div style="font-weight:800">' + (isM?'ما في أخطاء مسجلة حالياً!':'المفضلة فاضية') + '</div></div>' : '<div class="card" style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap"><div><div style="font-weight:800">' + (isM?'🔥 بنك الأخطاء':'⭐ المفضلة') + ' (' + list.length + ' كلمة)</div></div><div style="display:flex;gap:6px"><button class="btn btn-primary btn-sm" onclick="openGameSetup(\\'' + S.lastGame + '\\',\\'' + S.dictTab + '\\')">العب بها 🎮</button><button class="btn btn-soft btn-sm" onclick="clearCollection(\\'' + S.dictTab + '\\')">مسح</button></div></div><div class="word-list">' + list.slice(0,80).map(idx=>wordRowHTML(idx)).join('') + '</div>';
    }
    main.innerHTML = '<div class="seg-bar c3"><button class="seg-btn ' + (S.dictTab==='search'?'active':'') + '" onclick="setDictTab(\\'search\\')">🔍 بحث</button><button class="seg-btn ' + (S.dictTab==='mistakes'?'active':'') + '" onclick="setDictTab(\\'mistakes\\')">🔥 الأخطاء (' + S.mistakes.size + ')</button><button class="seg-btn ' + (S.dictTab==='favorites'?'active':'') + '" onclick="setDictTab(\\'favorites\\')">⭐ المفضلة (' + S.favorites.size + ')</button></div>' + body;
    if (S.dictTab === 'search') runSearchRender();
  }
  window.setDictTab = function(t) { S.dictTab = t; playSfx('tap'); render(); };
  window.onSearchInput = function(v) { S.searchQuery = v; S.searchLimit = 50; clearTimeout(searchDebounce); searchDebounce = setTimeout(runSearchRender, 100); };
  window.onSearchBandChange = function(b) { S.searchBand = b; S.searchLimit = 50; runSearchRender(); };
  window.loadMoreSearch = function() { S.searchLimit += 50; runSearchRender(); };
  window.clearCollection = function(type) { if (!confirm('متأكد بدك تمسح القائمة؟')) return; if (type==='mistakes') S.mistakes.clear(); else S.favorites.clear(); safeSaveState(); render(); };
  function runSearchRender() {
    const resEl = document.getElementById('searchResults'), metaEl = document.getElementById('searchMeta'); if (!resEl || !metaEl) return;
    const raw = (S.searchQuery || '').trim();
    if (!raw) { metaEl.textContent = 'ابحث في ' + WORDS_EN.length.toLocaleString('en-US') + ' كلمة خلال أجزاء من الثانية.'; resEl.innerHTML = ''; return; }
    ensureSearchCache();
    const qEn = raw.toLowerCase(), qAr = normalizeAr(raw), isAr = /[\\u0600-\\u06FF]/.test(raw), pool = S.searchBand === 'ALL' ? null : (BAND_INDICES[S.searchBand] || []), matches = [];
    if (pool) { for (let k=0; k<pool.length; k++) { const i=pool[k]; if (isAr ? NORM_AR_CACHE[i].includes(qAr) : NORM_EN_CACHE[i].includes(qEn)) matches.push(i); } }
    else { for (let i=0; i<WORDS_EN.length; i++) { if (isAr ? NORM_AR_CACHE[i].includes(qAr) : NORM_EN_CACHE[i].includes(qEn)) matches.push(i); } }
    metaEl.textContent = 'النتائج: ' + matches.length.toLocaleString('en-US');
    if (!matches.length) { resEl.innerHTML = '<div class="card" style="text-align:center">لا توجد نتائج مطابقة.</div>'; return; }
    resEl.innerHTML = matches.slice(0, S.searchLimit).map(idx => wordRowHTML(idx)).join('') + (matches.length > S.searchLimit ? '<button class="btn btn-soft btn-block" style="margin-top:8px" onclick="loadMoreSearch()">عرض المزيد (' + (matches.length - S.searchLimit) + ')</button>' : '');
  }

  let studyState = null;
  window.openStudy = function(b, s, r) { S.lastGame='study'; S.lastBand=b; S.lastSubLevel=s; safeSaveState(); openStudyPool(getBandSubIndices(b,s), b + ' — مستوى ' + (s+1), r||'games'); };
  function openStudyPool(indices, label, returnScreen) {
    if (!indices || !indices.length) { showToast('لا توجد كلمات للمراجعة'); return; }
    studyState = { indices: indices.slice(), pos: 0, flipped: false, label, returnScreen };
    S.screen = 'study'; pushHist('study'); render(); window.scrollTo(0, 0); if (S.autoSpeak) speakWordById(studyState.indices[0]);
  }
  function renderStudyArena(main, dock) {
    if (!studyState) return goTab('games');
    const idx = studyState.indices[studyState.pos], en = WORDS_EN[idx], ar = WORDS_AR[idx], pct = Math.round(((studyState.pos+1)/studyState.indices.length)*100);
    main.innerHTML = '<div class="game-progress-bar"><i style="width:' + pct + '%"></i></div><div class="flashcard" onclick="flipStudyCard()"><div style="margin-bottom:8px">' + bandPillHTML(WORDS_BAND[idx]) + '</div><div class="q-label">' + (studyState.flipped?'المعنى بالعربية':'اضغط على البطاقة لإظهار الترجمة') + '</div><div class="q-word ' + (studyState.flipped?'':'ltr') + '">' + escapeHtml(studyState.flipped?ar:en) + '</div>' + (studyState.flipped?'<div class="muted" style="direction:ltr;font-size:16px">' + escapeHtml(en) + '</div>':'') + '</div><div class="word-tools" style="margin-top:14px"><button class="btn btn-soft btn-sm" onclick="openWordDetail(' + idx + ',\\'study\\')">🖼️ التفاصيل</button><button class="btn btn-soft btn-sm" onclick="speakWordById(' + idx + ')">🔊 اسمع النطق</button><button class="btn btn-soft btn-sm" onclick="toggleFavorite(' + idx + ')">' + (S.favorites.has(idx)?'⭐ في المفضلة':'☆ مفضلة') + '</button></div>';
    dock.innerHTML = '<div class="action-dock"><div class="action-dock-inner"><div class="dock-row"><button class="btn btn-soft" style="flex:1" onclick="studyMark(false)">أعدها لاحقاً ↻</button><button class="btn btn-success" style="flex:1.4" onclick="studyMark(true)">' + (studyState.pos>=studyState.indices.length-1?'إنهاء المراجعة ✓':'أعرفها • التالية ←') + '</button></div></div></div>';
  }
  window.flipStudyCard = function() { if (!studyState) return; studyState.flipped = !studyState.flipped; playSfx('tap'); render(); };
  window.studyMark = function(known) {
    if (!studyState) return; const idx = studyState.indices[studyState.pos]; bumpDailyCount();
    if (known) { S.mastered.add(idx); S.mistakes.delete(idx); S.xp += 5; playSfx('ok'); } else { S.mistakes.add(idx); playSfx('tap'); }
    safeSaveState();
    if (studyState.pos >= studyState.indices.length - 1) { showToast('أنهيت بطاقات المراجعة ✓'); goBack(); }
    else { studyState.pos++; studyState.flipped = false; render(); window.scrollTo(0, 0); if (S.autoSpeak) speakWordById(studyState.indices[studyState.pos]); }
  };

  let G = null;
  window.startGame = function(mode, sourceType, band, subIdx, returnScreen) {
    let pool = [];
    if (sourceType === 'level') { pool = getBandSubIndices(band, subIdx); S.lastGame=mode; S.lastBand=band; S.lastSubLevel=subIdx; safeSaveState(); }
    else if (sourceType === 'random') { pool = getRandomPool(band); S.lastGame=mode; if(band) S.lastBand=band; safeSaveState(); }
    else if (sourceType === 'mistakes') { pool = Array.from(S.mistakes).filter(i => i>=0 && i<WORDS_EN.length); if (!pool.length) { showToast('لا توجد أخطاء'); return; } if (pool.length>30) pool = shuffleArr(pool).slice(0,30); }
    else { pool = Array.from(S.favorites).filter(i => i>=0 && i<WORDS_EN.length); if (!pool.length) { showToast('المفضلة فارغة'); return; } if (pool.length>30) pool = shuffleArr(pool).slice(0,30); }
    launchGameWithPool(mode, sourceType, band||'', subIdx, pool, returnScreen||'games');
  };
  function launchGameWithPool(mode, sourceType, band, subIdx, rawPool, returnScreen) {
    clearAllTimers(); const pool = shuffleArr(rawPool);
    G = { mode, sourceType, band, subIdx, pool, returnScreen, qIndex:0, correctCount:0, wrongCount:0, sessionWrong:[], finished:false, answered:false, lastCorrect:false, lastUserAnswer:'', currentSubMode:mode, qData:null, matchRound:0, matchRounds:[], matchRoundDone:false };
    if (mode === 'match') { for (let i=0; i<pool.length; i+=5) G.matchRounds.push(pool.slice(i, i+5)); initMatchRound(); } else prepareQuestion();
    S.screen = 'game'; pushHist('game'); render(); window.scrollTo(0, 0);
  }
  function recordOutcome(wordIdx, isCorrect) {
    bumpDailyCount();
    if (isCorrect) { G.correctCount++; S.xp += 10; S.streak++; if (S.streak > S.bestStreak) S.bestStreak = S.streak; S.mastered.add(wordIdx); if (G.sourceType === 'mistakes') S.mistakes.delete(wordIdx); playSfx('ok'); }
    else { G.wrongCount++; S.streak = 0; S.mistakes.add(wordIdx); if (!G.sessionWrong.includes(wordIdx)) G.sessionWrong.push(wordIdx); playSfx('err'); }
    safeSaveState();
  }
  function prepareQuestion() {
    G.answered = false; G.lastCorrect = false; G.lastUserAnswer = '';
    const idx = G.pool[G.qIndex], en = WORDS_EN[idx], ar = WORDS_AR[idx];
    let sub = G.mode; if (G.mode === 'mixed') { const m = ['mcq','tf','missing','scramble','type_en','type_ar']; sub = m[G.qIndex % m.length]; }
    G.currentSubMode = sub;
    if (sub === 'mcq') { const en2ar = S.mcqDir==='en2ar', dist = pickDistractors(idx,3,en2ar); G.qData = { idx, en, ar, en2ar, opts: shuffleArr([idx,...dist]).map(id=>({id,label:en2ar?WORDS_AR[id]:WORDS_EN[id],isCorrect:id===idx})), pickedId:null }; }
    else if (sub === 'tf') { const isTrue = Math.random()<0.5; let shownAr = ar; if (!isTrue) { const d = pickDistractors(idx,1,true); if (d.length) shownAr = WORDS_AR[d[0]]; } G.qData = { idx, en, ar, shownAr, isTrue, userPicked:null }; }
    else if (sub === 'missing') G.qData = buildMissingLettersData(idx, en, ar);
    else if (sub === 'scramble') G.qData = buildScrambleData(idx, en, ar);
    else if (sub === 'type_en') G.qData = { idx, en, ar, hintLevel:0 };
    else if (sub === 'type_ar') G.qData = { idx, en, ar, hintLevel:0, overridden:false };
    if (S.autoSpeak && ((sub==='mcq'&&S.mcqDir==='en2ar')||sub==='tf'||sub==='type_ar')) setSafeTimeout(() => speakWordById(idx), 120);
  }
  function buildMissingLettersData(idx, en, ar) {
    const chars = Array.from(en), lp = []; chars.forEach((ch,i) => { if (/[a-zA-Z]/.test(ch)) lp.push(i); });
    const L = lp.length, hc = L<=2?1:(L<=4?2:(L<=7?Math.ceil(L*0.45):Math.min(Math.ceil(L*0.5),7))), hs = new Set(shuffleArr(lp).slice(0,hc));
    const slots = chars.map((ch,i) => !/[a-zA-Z]/.test(ch)?{type:'punct',target:ch,value:ch,tileId:null}:(hs.has(i)?{type:'blank',target:ch.toLowerCase(),value:'',tileId:null}:{type:'fixed',target:ch,value:ch,tileId:null}));
    const mc = slots.filter(s=>s.type==='blank').map(s=>s.target), alpha = 'abcdefghijklmnopqrstuvwxyz', dc = Math.min(4,Math.max(2,8-mc.length)), dec = [];
    for (let i=0; i<dc; i++) dec.push(alpha[Math.floor(Math.random()*alpha.length)]);
    return { idx, en, ar, slots, bank: shuffleArr([...mc,...dec]).map((ch,i)=>({id:i,ch,used:false})) };
  }
  function buildScrambleData(idx, en, ar) {
    const slots = Array.from(en).map(ch => /[a-zA-Z]/.test(ch)?{type:'blank',target:ch.toLowerCase(),value:'',tileId:null}:{type:'punct',target:ch,value:ch,tileId:null});
    const letters = slots.filter(s=>s.type==='blank').map(s=>s.target); let tc = letters.slice(), hasD = false;
    if (tc.length === 1) { hasD = true; const al = 'aeiourstln'; while (tc.length<4) { const c=al[Math.floor(Math.random()*al.length)]; if(!tc.includes(c)) tc.push(c); } }
    let sc = shuffleArr(tc); if (new Set(tc).size>1 && !hasD) { let t=0; while (sc.join('')===letters.join('') && t<20) { sc=shuffleArr(tc); t++; } }
    return { idx, en, ar, slots, bank: sc.map((ch,i)=>({id:i,ch,used:false})) };
  }
  function initMatchRound() { G.matchRoundDone = false; const ids = G.matchRounds[G.matchRound]; G.qData = { left: shuffleArr(ids), right: shuffleArr(ids), matched: new Set(), selLeft: null, selRight: null, wrongFlash: null, roundMistakes: new Set() }; }
  function renderGameArena(main, dock) {
    if (!G) return goTab('games');
    if (G.finished) return renderGameSummary(main, dock);
    const totalSteps = G.mode==='match'?G.matchRounds.length:G.pool.length, curStep = G.mode==='match'?G.matchRound:G.qIndex;
    const pct = Math.round(((curStep+(G.answered||G.matchRoundDone?1:0))/Math.max(1,totalSteps))*100);
    let bodyHTML = '';
    if (G.mode==='match') bodyHTML = renderMatchBody(); else if (G.currentSubMode==='mcq') bodyHTML = renderMcqBody(); else if (G.currentSubMode==='tf') bodyHTML = renderTfBody(); else if (G.currentSubMode==='missing') bodyHTML = renderSlotPuzzleBody('missing'); else if (G.currentSubMode==='scramble') bodyHTML = renderSlotPuzzleBody('scramble'); else if (G.currentSubMode==='type_en') bodyHTML = renderTypeEnBody(); else bodyHTML = renderTypeArBody();
    main.innerHTML = '<div class="game-progress-bar"><i style="width:' + pct + '%"></i></div><div class="q-card">' + bodyHTML + '</div>';
    renderGameDock(dock);
    const inp = document.getElementById('typingAnswerInput'); if (inp && !G.answered) setSafeTimeout(() => { try{inp.focus();}catch(e){} }, 40);
  }
  function renderGameDock(dock) {
    if (G.mode === 'match') {
      const q = G.qData, isLast = G.matchRound >= G.matchRounds.length - 1;
      dock.innerHTML = G.matchRoundDone ? '<div class="action-dock"><div class="action-dock-inner"><div class="dock-feedback ok"><span>✅ أحسنت! أنهيت توصيل كل الكلمات</span></div><button class="btn btn-success btn-lg btn-block" onclick="nextMatchRound()">' + (isLast?'عرض النتيجة 🏆':'المجموعة التالية ←') + '</button></div></div>' : '<div class="action-dock"><div class="action-dock-inner"><div class="dock-row"><div style="flex:1;font-size:13px;font-weight:800;color:var(--text-muted)">تم توصيل ' + q.matched.size + ' / ' + q.left.length + '</div><button class="btn btn-soft btn-sm" onclick="nextMatchRound()">' + (isLast?'إنهاء ⏭':'تخطي ⏭') + '</button></div></div></div>';
      return;
    }
    const q = G.qData, isLast = G.qIndex >= G.pool.length - 1;
    if (G.answered) {
      const showOv = (G.currentSubMode==='type_ar' && !G.lastCorrect && G.lastUserAnswer && !q.overridden);
      dock.innerHTML = '<div class="action-dock"><div class="action-dock-inner"><div class="dock-feedback ' + (G.lastCorrect?'ok':'err') + '"><div><div>' + (G.lastCorrect?'✅ إجابة صحيحة!':'❌ إجابة خاطئة') + '</div><div class="dock-ans-text"><span style="direction:ltr;display:inline-block">' + escapeHtml(WORDS_EN[q.idx]) + '</span> = ' + escapeHtml(WORDS_AR[q.idx]) + '</div></div><div style="display:flex;gap:6px"><button class="icon-btn" onclick="openWordDetail(' + q.idx + ',\\'game\\')" title="تفاصيل">🖼️</button><button class="icon-btn" onclick="speakWordById(' + q.idx + ')">🔊</button>' + (showOv?'<button class="btn btn-success btn-sm" onclick="overrideArabicCorrect()">✓ مرادف صح</button>':'') + '</div></div><button class="btn ' + (G.lastCorrect?'btn-success':'btn-primary') + ' btn-lg btn-block" onclick="nextQuestion()">' + (isLast?'عرض النتيجة النهائية 🏆':'الكلمة التالية ←') + '</button></div></div>';
      return;
    }
    if (G.currentSubMode==='mcq'||G.currentSubMode==='tf') dock.innerHTML = '<div class="action-dock"><div class="action-dock-inner"><button class="btn btn-soft btn-block" onclick="skipQuestion()">تخطي للكلمة التالية ⏭</button></div></div>';
    else if (G.currentSubMode==='missing'||G.currentSubMode==='scramble') {
      const allFilled = !q.slots.some(s=>s.type==='blank'&&!s.value);
      dock.innerHTML = '<div class="action-dock"><div class="action-dock-inner"><div class="dock-row"><button class="btn btn-soft btn-sm" onclick="hintSlotPuzzle()">💡 تلميح</button><button class="btn btn-soft btn-sm" onclick="backspaceSlotPuzzle()">⌫</button><button class="btn btn-primary" style="flex:1" ' + (!allFilled?'disabled':'') + ' onclick="submitSlotPuzzle()">تحقق ✓</button><button class="btn btn-soft btn-sm" onclick="skipQuestion()">التالي ⏭</button></div></div></div>';
    } else {
      const fn = G.currentSubMode==='type_en'?'submitTypeEn()':'submitTypeAr()';
      dock.innerHTML = '<div class="action-dock"><div class="action-dock-inner"><div class="dock-row"><button class="btn btn-soft btn-sm" onclick="revealTypingHint()">💡 تلميح</button><button class="btn btn-primary" style="flex:1" onclick="' + fn + '">تحقق ✓</button><button class="btn btn-soft btn-sm" onclick="skipTypingQuestion()">أظهر الحل</button></div></div></div>';
    }
  }
  function renderMcqBody() { const q=G.qData; return '<div class="q-label">' + (q.en2ar?'اختر الترجمة العربية':'اختر الكلمة الإنكليزية') + '</div><div class="q-word ' + (q.en2ar?'ltr':'') + '">' + escapeHtml(q.en2ar?q.en:q.ar) + '</div><div class="word-tools">' + (q.en2ar?'<button class="btn btn-soft btn-sm" onclick="speakWordById(' + q.idx + ')">🔊 نطق</button>':'') + '<button class="btn btn-soft btn-sm" onclick="toggleFavorite(' + q.idx + ')">' + (S.favorites.has(q.idx)?'⭐':'☆') + '</button></div><div class="mcq-list">' + q.opts.map(o=>'<button class="mcq-opt ' + (G.answered?(o.isCorrect?'correct':(o.id===q.pickedId?'wrong':'')):'') + '" ' + (G.answered?'disabled':'') + ' style="' + (!q.en2ar?'direction:ltr':'') + '" onclick="answerMcq(' + o.id + ')">' + escapeHtml(o.label) + '</button>').join('') + '</div>'; }
  window.answerMcq = function(pickedId) { if (!G||G.answered) return; G.qData.pickedId=pickedId; G.answered=true; G.lastCorrect=(pickedId===G.qData.idx); recordOutcome(G.qData.idx,G.lastCorrect); if(S.autoSpeak&&!G.qData.en2ar) speakWordById(G.qData.idx); render(); };
  function renderTfBody() { const q=G.qData; return '<div class="q-label">هل الترجمة صحيحة أم خاطئة؟</div><div class="tf-box"><div class="q-word ltr" style="margin:0">' + escapeHtml(q.en) + '</div><div class="muted" style="margin:6px 0">معناها بالعربي:</div><div style="font-size:24px;font-weight:900;color:var(--cyan)">' + escapeHtml(q.shownAr) + '</div></div><div class="word-tools"><button class="btn btn-soft btn-sm" onclick="speakWordById(' + q.idx + ')">🔊 اسمع النطق</button></div><div class="tf-btns"><button class="tf-btn ' + (G.answered?(q.isTrue?'is-correct':(q.userPicked===true?'is-wrong':'')):'') + '" ' + (G.answered?'disabled':'') + ' onclick="answerTf(true)">✓ صح</button><button class="tf-btn ' + (G.answered?(!q.isTrue?'is-correct':(q.userPicked===false?'is-wrong':'')):'') + '" ' + (G.answered?'disabled':'') + ' onclick="answerTf(false)">✕ خطأ</button></div>'; }
  window.answerTf = function(v) { if (!G||G.answered) return; G.qData.userPicked=v; G.answered=true; G.lastCorrect=(v===G.qData.isTrue); recordOutcome(G.qData.idx,G.lastCorrect); render(); };
  function renderMatchBody() { const q=G.qData; return '<div class="q-label">وصّل كل كلمة إنكليزية بمعناها العربي</div><div class="match-board"><div class="match-col">' + q.left.map(id=>'<div class="match-item ltr ' + (q.matched.has(id)?'matched':'') + ' ' + (q.selLeft===id?'selected':'') + ' ' + (q.wrongFlash&&q.wrongFlash.l===id?'shake':'') + '" onclick="pickMatch(\\'left\\',' + id + ')">' + escapeHtml(WORDS_EN[id]) + '</div>').join('') + '</div><div class="match-col">' + q.right.map(id=>'<div class="match-item ' + (q.matched.has(id)?'matched':'') + ' ' + (q.selRight===id?'selected':'') + ' ' + (q.wrongFlash&&q.wrongFlash.r===id?'shake':'') + '" onclick="pickMatch(\\'right\\',' + id + ')">' + escapeHtml(WORDS_AR[id]) + '</div>').join('') + '</div></div>'; }
  window.pickMatch = function(side, id) {
    if (!G||G.mode!=='match'||G.matchRoundDone) return; const q=G.qData; if(q.matched.has(id)||q.wrongFlash) return; playSfx('tap');
    if (side==='left') q.selLeft=(q.selLeft===id?null:id); else q.selRight=(q.selRight===id?null:id);
    if (q.selLeft!==null&&q.selRight!==null) {
      const l=q.selLeft, r=q.selRight;
      if (l===r || normalizeAr(WORDS_AR[l])===normalizeAr(WORDS_AR[r])) {
        q.matched.add(l); if(l!==r) q.matched.add(r); q.selLeft=null; q.selRight=null;
        if(!q.roundMistakes.has(l)) recordOutcome(l,true); else playSfx('ok');
        if(q.matched.size>=q.left.length) G.matchRoundDone=true;
      } else {
        q.wrongFlash={l,r}; if(!q.roundMistakes.has(l)){q.roundMistakes.add(l); recordOutcome(l,false);} else playSfx('err');
        render(); setSafeTimeout(()=>{if(!G||G.mode!=='match')return; q.wrongFlash=null; q.selLeft=null; q.selRight=null; render();}, 380); return;
      }
    }
    render();
  };
  window.nextMatchRound = function() { if(!G||G.mode!=='match') return; G.matchRound++; if(G.matchRound>=G.matchRounds.length) finishGame(); else { initMatchRound(); render(); window.scrollTo(0,0); } };
  function renderSlotPuzzleBody(kind) { const q=G.qData, nb=q.slots.findIndex(s=>s.type==='blank'&&!s.value); return '<div class="q-label">' + (kind==='missing'?'🧩 أكمل الأحرف الناقصة':'🔀 رتّب الأحرف المخربطة') + '</div><div class="q-word">' + escapeHtml(q.ar) + '</div><div class="word-tools"><button class="btn btn-soft btn-sm" onclick="speakWordById(' + q.idx + ')">🔊 اسمع النطق</button>' + (!G.answered?'<button class="btn btn-soft btn-sm" onclick="clearSlotPuzzle()">↺ مسح الكل</button>':'') + '</div><div class="slots-wrap">' + q.slots.map((s,i)=>{ if(s.type==='punct') return '<span class="letter-slot punct">' + escapeHtml(s.value) + '</span>'; let c=s.type==='fixed'?'fixed':(s.value?'filled':'blank'); if(!G.answered&&i===nb) c+=' cursor'; if(G.answered&&s.type==='blank') c=(s.value.toLowerCase()===s.target.toLowerCase())?'correct':'wrong'; return '<span class="letter-slot ' + c + '" ' + ((!G.answered&&s.type==='blank'&&s.value)?'onclick="removeSlotLetter(' + i + ')"':'') + '>' + escapeHtml(s.value||'') + '</span>'; }).join('') + '</div>' + (!G.answered?'<div class="bank-wrap">' + q.bank.map(t=>'<button class="bank-tile ' + (t.used?'used':'') + '" onclick="pickBankTile(' + t.id + ')">' + escapeHtml(t.ch) + '</button>').join('') + '</div>':''); }
  window.pickBankTile = function(tid) { if(!G||G.answered) return; const q=G.qData, t=q.bank.find(x=>x.id===tid); if(!t||t.used) return; const s=q.slots.find(x=>x.type==='blank'&&!x.value); if(!s) return; t.used=true; s.value=t.ch; s.tileId=t.id; playSfx('tap'); if(!q.slots.some(x=>x.type==='blank'&&!x.value)&&checkEnglishMatch(q.slots.map(x=>x.value).join(''),q.en)){submitSlotPuzzle();return;} render(); };
  window.removeSlotLetter = function(si) { if(!G||G.answered) return; const q=G.qData, s=q.slots[si]; if(!s||s.type!=='blank'||!s.value) return; if(s.tileId!==null){const t=q.bank.find(x=>x.id===s.tileId); if(t) t.used=false;} s.value=''; s.tileId=null; playSfx('tap'); render(); };
  window.backspaceSlotPuzzle = function() { if(!G||G.answered) return; const q=G.qData; for(let i=q.slots.length-1;i>=0;i--) if(q.slots[i].type==='blank'&&q.slots[i].value){removeSlotLetter(i);return;} };
  window.clearSlotPuzzle = function() { if(!G||G.answered) return; const q=G.qData; q.slots.forEach(s=>{if(s.type==='blank'){s.value='';s.tileId=null;}}); q.bank.forEach(t=>{t.used=false;}); playSfx('tap'); render(); };
  window.hintSlotPuzzle = function() {
    if(!G||G.answered) return; const q=G.qData, idx=q.slots.findIndex(s=>s.type==='blank'&&s.value.toLowerCase()!==s.target.toLowerCase()); if(idx===-1) return;
    const slot=q.slots[idx]; if(slot.tileId!==null){const ot=q.bank.find(x=>x.id===slot.tileId); if(ot) ot.used=false; slot.value=''; slot.tileId=null;}
    let mt=q.bank.find(t=>!t.used&&t.ch.toLowerCase()===slot.target.toLowerCase());
    if(!mt){const d=q.slots.find((s,si)=>si>idx&&s.type==='blank'&&s.value.toLowerCase()===slot.target.toLowerCase()); if(d&&d.tileId!==null){mt=q.bank.find(t=>t.id===d.tileId); d.value=''; d.tileId=null; if(mt) mt.used=false;}}
    if(mt){mt.used=true; slot.value=mt.ch; slot.tileId=mt.id;} else {slot.value=slot.target; slot.tileId=null;}
    playSfx('tap'); if(!q.slots.some(s=>s.type==='blank'&&!s.value)&&checkEnglishMatch(q.slots.map(s=>s.value).join(''),q.en)){submitSlotPuzzle();return;} render();
  };
  window.submitSlotPuzzle = function() { if(!G||G.answered) return; const q=G.qData, b=q.slots.map(s=>s.value).join(''); G.lastUserAnswer=b; G.answered=true; G.lastCorrect=checkEnglishMatch(b,q.en); recordOutcome(q.idx,G.lastCorrect); if(S.autoSpeak) speakWordById(q.idx); render(); };
  function buildCharDiffHTML(uS, tS) { const u=Array.from(uS), t=Array.from(tS), m=Math.max(u.length,t.length); let o=''; for(let i=0;i<m;i++){const uc=u[i]||'', tc=t[i]||''; if(uc.toLowerCase()===tc.toLowerCase()&&tc) o+='<span class="diff-ok">'+escapeHtml(tc)+'</span>'; else{if(uc) o+='<span class="diff-bad">'+escapeHtml(uc)+'</span>'; if(tc) o+='<span style="color:var(--warning);font-weight:900">'+escapeHtml(tc)+'</span>';}} return '<div class="diff-view">'+o+'</div>'; }
  function renderTypeEnBody() { const q=G.qData, h=q.hintLevel>0?Array.from(q.en).map((ch,i)=>(i<q.hintLevel||!/[a-zA-Z]/.test(ch))?ch:'_').join(' '):''; return '<div class="q-label">⌨️ اكتب الكلمة بالإنكليزية</div><div class="q-word">' + escapeHtml(q.ar) + '</div><div class="muted">عدد الأحرف: ' + q.en.length + '</div><div class="word-tools"><button class="btn btn-soft btn-sm" onclick="speakWordById(' + q.idx + ')">🔊 تلميح صوتي</button></div>' + (h&&!G.answered?'<div class="hint-line ltr">' + escapeHtml(h) + '</div>':'') + '<input id="typingAnswerInput" class="type-input ltr" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Type English word..." value="' + escapeHtml(G.lastUserAnswer) + '" ' + (G.answered?'disabled':'') + ' onkeydown="if(event.key===\\'Enter\\'){event.preventDefault();' + (G.answered?'nextQuestion()':'submitTypeEn()') + ';}">' + ((G.answered&&!G.lastCorrect&&G.lastUserAnswer)?buildCharDiffHTML(G.lastUserAnswer,q.en):''); }
  window.submitTypeEn = function() { if(!G||G.answered) return; const inp=document.getElementById('typingAnswerInput'), v=inp?inp.value.trim():''; if(!v){showToast('اكتب الإجابة أولاً');return;} G.lastUserAnswer=v; G.answered=true; G.lastCorrect=checkEnglishMatch(v,G.qData.en); recordOutcome(G.qData.idx,G.lastCorrect); if(S.autoSpeak) speakWordById(G.qData.idx); render(); };
  function renderTypeArBody() { const q=G.qData, h=q.hintLevel>0?Array.from(q.ar).map((ch,i)=>(i<q.hintLevel||ch===' ')?ch:'ـ').join(''):''; return '<div class="q-label">✍️ اكتب المعنى بالعربية</div><div class="q-word ltr">' + escapeHtml(q.en) + '</div><div class="word-tools"><button class="btn btn-soft btn-sm" onclick="speakWordById(' + q.idx + ')">🔊 اسمع النطق</button></div>' + (h&&!G.answered?'<div class="hint-line" style="letter-spacing:1px">' + escapeHtml(h) + '</div>':'') + '<input id="typingAnswerInput" class="type-input rtl" type="text" autocomplete="off" placeholder="اكتب المعنى بالعربية..." value="' + escapeHtml(G.lastUserAnswer) + '" ' + (G.answered?'disabled':'') + ' onkeydown="if(event.key===\\'Enter\\'){event.preventDefault();' + (G.answered?'nextQuestion()':'submitTypeAr()') + ';}">'; }
  window.submitTypeAr = function() { if(!G||G.answered) return; const inp=document.getElementById('typingAnswerInput'), v=inp?inp.value.trim():''; if(!v){showToast('اكتب المعنى أولاً');return;} G.lastUserAnswer=v; G.answered=true; G.lastCorrect=checkArabicMatch(v,G.qData.ar); recordOutcome(G.qData.idx,G.lastCorrect); render(); };
  window.revealTypingHint = function() { if(!G||G.answered) return; G.qData.hintLevel=(G.qData.hintLevel||0)+1; playSfx('tap'); render(); };
  window.skipTypingQuestion = function() { if(!G||G.answered) return; G.lastUserAnswer=''; G.answered=true; G.lastCorrect=false; recordOutcome(G.qData.idx,false); render(); };
  window.skipQuestion = function() { if(!G) return; playSfx('tap'); nextQuestion(); };
  window.overrideArabicCorrect = function() { if(!G||!G.answered||G.lastCorrect||G.qData.overridden) return; const idx=G.qData.idx; G.qData.overridden=true; G.lastCorrect=true; G.wrongCount=Math.max(0,G.wrongCount-1); G.correctCount++; S.mistakes.delete(idx); S.mastered.add(idx); S.xp+=10; const p=G.sessionWrong.indexOf(idx); if(p>-1) G.sessionWrong.splice(p,1); safeSaveState(); playSfx('ok'); showToast('تم احتساب إجابتك صح ✓'); render(); };
  window.nextQuestion = function() { if(!G) return; if(G.qIndex>=G.pool.length-1) finishGame(); else { G.qIndex++; prepareQuestion(); render(); window.scrollTo(0,0); } };
  function finishGame() { G.finished=true; const tot=Math.max(1,G.correctCount+G.wrongCount), pct=Math.round((G.correctCount/tot)*100); if(G.sourceType==='level'&&G.band&&G.subIdx>=0){const k=lvlKey(G.band,G.subIdx); if(pct>(S.completed[k]||0)) S.completed[k]=pct; safeSaveState();} playSfx('win'); render(); window.scrollTo(0,0); }
  function renderGameSummary(main, dock) {
    const tot=Math.max(1,G.correctCount+G.wrongCount), pct=Math.round((G.correctCount/tot)*100), em=pct>=90?'🏆':(pct>=70?'🎉':'💪'), ns=(G.sourceType==='level'&&G.band&&G.subIdx+1<getBandSubCount(G.band))?G.subIdx+1:-1;
    main.innerHTML = '<div class="card" style="text-align:center;padding:24px 16px"><div style="font-size:48px">' + em + '</div><h2 style="margin:6px 0">أنهيت الجولة!</h2><div style="font-size:38px;font-weight:900;color:' + (pct>=80?'var(--success)':(pct>=50?'var(--warning)':'var(--danger)')) + '">' + pct + '%</div><div class="muted" style="margin:6px 0 14px">صحيح: <strong style="color:var(--success)">' + G.correctCount + '</strong> • خطأ: <strong style="color:var(--danger)">' + G.wrongCount + '</strong> • XP: <strong>' + S.xp + '</strong></div>' + (G.sessionWrong.length>0?'<button class="btn btn-warning btn-sm" onclick="retrySessionWrong()">🔥 العب بأخطاء الجولة (' + G.sessionWrong.length + ')</button>':'') + '</div>' + (G.sessionWrong.length>0?'<div class="section-head"><h3 class="section-title">كلمات أخطأت بها</h3></div><div class="word-list">' + G.sessionWrong.map(idx=>wordRowHTML(idx)).join('') + '</div>':'');
    dock.innerHTML = '<div class="action-dock"><div class="action-dock-inner"><div class="dock-row"><button class="btn btn-soft" style="flex:1" onclick="startGame(\\'' + G.mode + '\\',\\'' + G.sourceType + '\\',\\'' + G.band + '\\',' + G.subIdx + ',\\'' + G.returnScreen + '\\')">↻ إعادة</button>' + (ns>=0?'<button class="btn btn-success" style="flex:1.5" onclick="startGame(\\'' + G.mode + '\\',\\'level\\',\\'' + G.band + '\\',' + ns + ',\\'' + G.returnScreen + '\\')">المستوى التالي (' + (ns+1) + ') ←</button>':'<button class="btn btn-primary" style="flex:1.5" onclick="goBack()">العودة للألعاب</button>') + '</div></div></div>';
  }
  window.retrySessionWrong = function() { if(!G||!G.sessionWrong.length) return; launchGameWithPool(G.mode,'mistakes','',-1,G.sessionWrong.slice(),G.returnScreen); };

  const MEDIA_DB_NAME = 'VocabCefrMediaDB';
  const pendingPhotoReq = new Map(), pendingInfoReq = new Map();
  const photoMem = new Map(), infoMem = new Map(), videoMem = new Map();
  let ygScriptPromise = null, ytApiPromise = null, activeYtPlayer = null, segWatcherId = null;

  function openMediaDB() {
    return new Promise((resolve, reject) => {
      try {
        const req = indexedDB.open(MEDIA_DB_NAME, 3);
        req.onupgradeneeded = () => { ['images', 'wordInfo', 'videos'].forEach(s => { if (!req.result.objectStoreNames.contains(s)) req.result.createObjectStore(s); }); };
        req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error);
      } catch (e) { reject(e); }
    });
  }
  async function idbMediaGet(storeName, key) {
    try { const db = await openMediaDB(); return await new Promise(res => { const tx = db.transaction(storeName,'readonly'), g = tx.objectStore(storeName).get(key); g.onsuccess = () => { const e=g.result; res((!e||(e.expiresAt&&e.expiresAt<=Date.now()))?null:e.data); }; g.onerror = () => res(null); }); } catch (e) { return null; }
  }
  async function idbMediaSet(storeName, key, data, ttlMs) {
    try { const db = await openMediaDB(); return await new Promise(res => { const tx = db.transaction(storeName,'readwrite'); tx.objectStore(storeName).put({data, expiresAt:Date.now()+ttlMs}, key); tx.oncomplete = () => res(true); tx.onerror = () => res(false); }); } catch (e) { return false; }
  }
  window.clearAllMediaCache = async function() {
    try {
      const db = await openMediaDB(), stores = ['images','wordInfo','videos'].filter(s => db.objectStoreNames.contains(s));
      await new Promise(res => { const tx = db.transaction(stores,'readwrite'); stores.forEach(s=>tx.objectStore(s).clear()); tx.oncomplete=()=>res(true); tx.onerror=()=>res(false); });
      photoMem.clear(); infoMem.clear(); videoMem.clear(); showToast('تم مسح ذاكرة الصور والجمل والفيديو ✓');
    } catch (e) { showToast('تعذر مسح الكاش'); }
  };

  function getServerBase() { return (S.backendUrl || '').trim().replace(/\\/+$/, ''); }
  function stopSegmentWatcher() { if (segWatcherId !== null) { clearInterval(segWatcherId); segWatcherId = null; } }
  function cleanupVideoPlayer() { stopSegmentWatcher(); if (activeYtPlayer) { try{activeYtPlayer.stopVideo();}catch(_){} try{activeYtPlayer.destroy();}catch(_){} activeYtPlayer = null; } }

  window.openWordDetail = function(idx, returnScreen) {
    if (idx < 0 || idx >= WORDS_EN.length) return;
    cleanupVideoPlayer(); S.detailWordIdx = idx; S.detailReturnScreen = returnScreen || S.screen; S.screen = 'word_detail';
    pushHist('word_detail'); render(); window.scrollTo(0, 0);
    loadWordPhoto(idx, 1, false); loadWordInfo(idx, false);
  };

  const FUNC_WORDS = new Set(['the','a','an','to','of','in','on','at','by','for','with','from','into','onto','upon','if','or','and','but','nor','yet','so','as','than','that','which','who','whom','whose','what','this','these','those','it','its','he','him','his','she','her','they','them','their','we','us','our','you','your','i','me','my','be','is','am','are','was','were','been','have','has','had','do','does','did','will','would','shall','should','can','could','may','might','must','not','no','yes','very','too','also','just','only','even','still','already','although','though','however','therefore','unless','whereas','meanwhile','because']);
  const BAD_PHOTO_TERMS = ['illustration','vector','clipart','icon','logo','3d render','cartoon','drawing','sketch','typography','screenshot','mockup'];

  async function loadWordPhoto(idx, page, force) {
    const word = WORDS_EN[idx]; if (!word) return;
    const p = page || 1, cacheKey = word.toLowerCase() + '::p' + p;
    if (!force) { const c = await idbMediaGet('images', cacheKey); if (c) { photoMem.set(idx, {status:c.found?'ready':'empty', data:c, page:p}); if (S.screen==='word_detail'&&S.detailWordIdx===idx) renderPhotoBox(idx); return; } }
    if (FUNC_WORDS.has(word.toLowerCase())) { const e={found:false}; await idbMediaSet('images',cacheKey,e,30*864e5); photoMem.set(idx,{status:'empty',data:e,page:p}); if(S.screen==='word_detail'&&S.detailWordIdx===idx) renderPhotoBox(idx); return; }
    const srv = getServerBase(), pixKey = (S.pixabayKey||'').trim(), unsKey = (S.unsplashKey||'').trim();
    if (!srv && !pixKey && !unsKey) { photoMem.set(idx, {status:'nokey',data:null,page:p}); if (S.screen==='word_detail'&&S.detailWordIdx===idx) renderPhotoBox(idx); return; }
    photoMem.set(idx, {status:'loading',data:null,page:p}); if (S.screen==='word_detail'&&S.detailWordIdx===idx) renderPhotoBox(idx);
    if (pendingPhotoReq.has(cacheKey)) { await pendingPhotoReq.get(cacheKey); if (S.screen==='word_detail'&&S.detailWordIdx===idx) renderPhotoBox(idx); return; }

    const job = (async () => {
      try {
        let out = null;
        if (srv) { const r = await fetch(srv + '/api/image?word=' + encodeURIComponent(word) + '&page=' + p); const j = await r.json(); if (r.ok && j.ok) out = Object.assign({}, j, { ttl: j.provider==='pixabay'?23*3600*1000:7*864e5 }); }
        if (!out && unsKey) {
          const r = await fetch('https://api.unsplash.com/search/photos?query=' + encodeURIComponent(word) + '&page=' + p + '&per_page=8&content_filter=high&client_id=' + encodeURIComponent(unsKey));
          if (r.ok) {
            const j = await r.json(), hit = (j.results||[]).find(ph => { const desc = ((ph.alt_description||'')+' '+(ph.description||'')).toLowerCase(); return ph.urls&&ph.urls.regular&&!BAD_PHOTO_TERMS.some(t=>desc.includes(t)); });
            if (hit) { const utm='utm_source=smart_vocab_cefr&utm_medium=referral', un=(hit.user&&hit.user.name)||'Unsplash', up=(hit.user&&hit.user.links&&hit.user.links.html)||'https://unsplash.com', pp=(hit.links&&hit.links.html)||'https://unsplash.com'; out={found:true,providerLabel:'Unsplash',imageUrl:hit.urls.regular,alt:hit.alt_description||word,photographer:un,photographerUrl:up+'?'+utm,photoPageUrl:pp+'?'+utm,providerHomeUrl:'https://unsplash.com/?'+utm,ttl:7*864e5}; }
          }
        }
        if (!out && pixKey) {
          const r = await fetch('https://pixabay.com/api/?key=' + encodeURIComponent(pixKey) + '&q=' + encodeURIComponent(word) + '&image_type=photo&safesearch=true&lang=en&per_page=8&page=' + p, { mode:'cors' });
          if (r.ok) {
            const j = await r.json(), wLow = word.toLowerCase(), hit = (j.hits||[]).find(h => { const tags=(h.tags||'').toLowerCase(); return h.webformatURL&&!BAD_PHOTO_TERMS.some(t=>tags.includes(t))&&tags.includes(wLow.slice(0,Math.max(3,wLow.length-1))); });
            if (hit) out = {found:true,providerLabel:'Pixabay',imageUrl:hit.webformatURL,alt:hit.tags||word,photographer:hit.user||'Pixabay',photographerUrl:'https://pixabay.com/',photoPageUrl:hit.pageURL||'https://pixabay.com/',providerHomeUrl:'https://pixabay.com/',ttl:23*3600*1000};
          }
        }
        if (!out) out = { found:false, ttl:12*3600*1000 };
        await idbMediaSet('images', cacheKey, out, out.ttl || 864e5);
        photoMem.set(idx, { status: out.found?'ready':'empty', data: out, page: p });
      } catch (e) { photoMem.set(idx, { status:'error', data:{message: navigator.onLine?'تأكد من صحة مفتاح الصور أو الاتصال بالإنترنت.':'أنت غير متصل بالإنترنت.'}, page: p }); }
    })();
    pendingPhotoReq.set(cacheKey, job); try { await job; } finally { pendingPhotoReq.delete(cacheKey); }
    if (S.screen==='word_detail'&&S.detailWordIdx===idx) renderPhotoBox(idx);
  }
  window.loadWordPhoto = loadWordPhoto;
  window.nextWordPhoto = function(idx) { const st = photoMem.get(idx); loadWordPhoto(idx, st ? ((st.page % 3) + 1) : 2, false); };

  function buildTargetRx(word) {
    const clean = String(word||'').trim(); if (!clean) return null; const esc = s => s.replace(/[.*+?^$()|[\\]\\\\{}]/g,'\\\\$&');
    if (/[\\s-]/.test(clean)) return new RegExp('(^|[^a-zA-Z0-9])('+esc(clean).replace(/[\\s-]+/g,'[\\\\s-]+')+')(?=$|[^a-zA-Z0-9])','i');
    const l = clean.toLowerCase(), vars = [esc(l),esc(l+'s'),esc(l+'es'),esc(l+'ed'),esc(l+'d'),esc(l+'ing'),esc(l+'er'),esc(l+'est'),esc(l+'ly')];
    if (l.endsWith('e') && l.length>2) { const b=l.slice(0,-1); vars.push(esc(b+'ing'),esc(b+'ed'),esc(b+'es')); }
    if (l.endsWith('y') && l.length>2) { const b=l.slice(0,-1); vars.push(esc(b+'ies'),esc(b+'ied')); }
    vars.sort((a,b)=>b.length-a.length);
    return new RegExp('(^|[^a-zA-Z0-9])('+vars.join('|')+')(?=$|[^a-zA-Z0-9])','i');
  }
  function underlineTargetHtml(text, word) {
    const rx = buildTargetRx(word); if (!rx) return { ok:false, html:escapeHtml(text) };
    const m = rx.exec(text); if (!m) return { ok:false, html:escapeHtml(text) };
    const pre = m[1]?m[1].length:0, s = m.index+pre, e = s+m[2].length;
    return { ok:true, html: escapeHtml(text.slice(0,s))+'<u class="target-word-underline">'+escapeHtml(text.slice(s,e))+'</u>'+escapeHtml(text.slice(e)) };
  }
  const POS_AR = { noun:'اسم', verb:'فعل', adjective:'صفة', adverb:'ظرف', pronoun:'ضمير', preposition:'حرف جر', conjunction:'أداة عطف', interjection:'تعجب' };

  async function loadWordInfo(idx, force) {
    const word = WORDS_EN[idx]; if (!word) return; const cacheKey = word.toLowerCase();
    if (!force) { const c = await idbMediaGet('wordInfo', cacheKey); if (c) { infoMem.set(idx,{status:'ready',data:c,exIdx:0}); if(S.screen==='word_detail'&&S.detailWordIdx===idx) renderInfoBox(idx); return; } }
    infoMem.set(idx, {status:'loading',data:null,exIdx:0}); if (S.screen==='word_detail'&&S.detailWordIdx===idx) renderInfoBox(idx);
    if (pendingInfoReq.has(cacheKey)) { await pendingInfoReq.get(cacheKey); if (S.screen==='word_detail'&&S.detailWordIdx===idx) renderInfoBox(idx); return; }

    const job = (async () => {
      try {
        const srv = getServerBase();
        if (srv) {
          const r = await fetch(srv + '/api/word-info?word=' + encodeURIComponent(word));
          if (r.ok) { const j = await r.json(); if (j.ok) { const out={phonetic:j.phonetic||'',posEn:j.partOfSpeech?j.partOfSpeech.en:'',posAr:j.partOfSpeech?j.partOfSpeech.ar:'',examples:j.examples||[]}; await idbMediaSet('wordInfo',cacheKey,out,out.examples.length?14*864e5:6*3600*1000); infoMem.set(idx,{status:'ready',data:out,exIdx:0}); return; } }
        }
        let phonetic = '', pos = '', examples = [];
        const r = await fetch('https://api.dictionaryapi.dev/api/v2/entries/en/' + encodeURIComponent(cacheKey));
        if (r.ok) {
          const entries = await r.json();
          if (Array.isArray(entries)) {
            for (const en of entries) {
              if (!phonetic && en.phonetic) phonetic = en.phonetic;
              if (!phonetic && Array.isArray(en.phonetics)) { const ph = en.phonetics.find(p => p && p.text); if (ph) phonetic = ph.text; }
              for (const m of (en.meanings || [])) {
                if (!pos && m.partOfSpeech) pos = m.partOfSpeech.toLowerCase();
                for (const d of (m.definitions || [])) {
                  if (d && d.example) {
                    let t = d.example.trim(); if (!/[.!?]$/.test(t)) t += '.'; t = t.charAt(0).toUpperCase() + t.slice(1);
                    const hl = underlineTargetHtml(t, word);
                    if (hl.ok && t.split(/\\s+/).length <= 18) examples.push({ text: t, html: hl.html, source: 'Free Dictionary' });
                  }
                }
              }
            }
          }
        }
        if (!examples.length || !pos) {
          try {
            const wr = await fetch('https://en.wiktionary.org/api/rest_v1/page/definition/' + encodeURIComponent(cacheKey));
            if (wr.ok) {
              const wj = await wr.json();
              for (const item of (wj.en || [])) {
                if (!pos && item.partOfSpeech) pos = item.partOfSpeech.toLowerCase();
                for (const def of (item.definitions || []).slice(0, 6)) {
                  const arr = [].concat((def.parsedExamples || []).map(x => x && x.example), def.examples || []);
                  for (let ex of arr) {
                    if (typeof ex !== 'string') continue;
                    ex = ex.replace(/<[^>]+>/g, ' ').replace(/\\s+/g, ' ').trim();
                    if (ex.length < 10 || ex.length > 120) continue;
                    const hl = underlineTargetHtml(ex, word);
                    if (hl.ok) examples.push({ text: ex, html: hl.html, source: 'Wiktionary' });
                  }
                }
              }
            }
          } catch (_) {}
        }
        examples.sort((a,b) => Math.abs(a.text.split(/\\s+/).length - 8) - Math.abs(b.text.split(/\\s+/).length - 8));
        const out = { phonetic, posEn: pos, posAr: POS_AR[pos] || pos, examples: examples.slice(0, 4) };
        await idbMediaSet('wordInfo', cacheKey, out, out.examples.length ? 14*864e5 : 6*3600*1000);
        infoMem.set(idx, { status: 'ready', data: out, exIdx: 0 });
      } catch (e) { infoMem.set(idx, { status:'error', data:{message: navigator.onLine?'تعذر جلب الجملة الآن.':'أنت غير متصل بالإنترنت.'}, exIdx:0 }); }
    })();
    pendingInfoReq.set(cacheKey, job); try { await job; } finally { pendingInfoReq.delete(cacheKey); }
    if (S.screen==='word_detail'&&S.detailWordIdx===idx) renderInfoBox(idx);
  }
  window.loadWordInfo = loadWordInfo;
  window.cycleExample = function(idx) { const st=infoMem.get(idx); if(!st||!st.data||!st.data.examples||st.data.examples.length<=1) return; st.exIdx=(st.exIdx+1)%st.data.examples.length; playSfx('tap'); renderInfoBox(idx); };
  window.speakExample = function(idx) { const st=infoMem.get(idx); if(!st||!st.data||!st.data.examples.length) return; speakEn(st.data.examples[st.exIdx||0].text); };

  function renderPhotoBox(idx) {
    const host = document.getElementById('wordPhotoContainer'); if (!host) return;
    const st = photoMem.get(idx) || { status: 'loading', page: 1 };
    if (st.status==='loading') { host.innerHTML='<div class="photo-card"><div class="photo-card-head"><span style="font-weight:800;font-size:14px">📷 صورة واقعية للكلمة</span><span class="muted">جاري البحث...</span></div><div class="photo-frame"><div class="photo-skeleton"><span>🖼️ جاري جلب الصورة...</span></div></div></div>'; return; }
    if (st.status==='nokey') { host.innerHTML='<div class="photo-card"><div class="photo-card-head"><span style="font-weight:800;font-size:14px">📷 صورة واقعية للكلمة</span><button class="btn btn-primary btn-sm" onclick="goTab(\\'settings\\')">إضافة مفتاح ⚙️</button></div><div class="photo-fallback"><div style="font-size:28px;margin-bottom:6px">🔑</div><div style="font-weight:700;font-size:13px">لعرض صور حقيقية، أضف مفتاح Pixabay أو Unsplash المجاني في الإعدادات.</div></div></div>'; return; }
    if (st.status==='ready'&&st.data&&st.data.imageUrl) { const d=st.data; host.innerHTML='<div class="photo-card"><div class="photo-card-head"><span style="font-weight:800;font-size:14px">📷 صورة واقعية للكلمة</span><button class="btn btn-soft btn-sm" onclick="nextWordPhoto(' + idx + ')">↻ صورة أخرى</button></div><div class="photo-frame"><div class="photo-skeleton" id="pSkel"><span>جاري العرض...</span></div><img class="photo-img" src="' + escapeHtml(d.imageUrl) + '" alt="' + escapeHtml(d.alt||WORDS_EN[idx]) + '" onload="this.classList.add(\\'loaded\\');var s=document.getElementById(\\'pSkel\\');if(s)s.style.display=\\'none\\';" onerror="this.style.display=\\'none\\'"></div><div class="photo-credit"><span>تصوير: <a href="' + escapeHtml(d.photographerUrl||'#') + '" target="_blank" rel="noopener">' + escapeHtml(d.photographer||'Contributor') + '</a> (' + escapeHtml(d.providerLabel||d.provider||'') + ')</span><a href="' + escapeHtml(d.photoPageUrl||'#') + '" target="_blank" rel="noopener">الأصلية ↗</a></div></div>'; return; }
    const isErr = st.status === 'error';
    host.innerHTML='<div class="photo-card"><div class="photo-card-head"><span style="font-weight:800;font-size:14px">📷 صورة واقعية للكلمة</span><button class="btn btn-soft btn-sm" onclick="loadWordPhoto(' + idx + ',1,true)">↻ إعادة</button></div><div class="photo-fallback"><div style="font-size:28px;margin-bottom:6px">' + (isErr?'📡':'🔍') + '</div><div style="font-weight:700;font-size:13px">' + escapeHtml(isErr?st.data.message:'لا توجد صورة واقعية مطابقة لهذه الكلمة.') + '</div></div></div>';
  }
  function renderInfoBox(idx) {
    const metaHost=document.getElementById('wordMetaPills'), sentHost=document.getElementById('wordSentenceContainer'), st=infoMem.get(idx)||{status:'loading',exIdx:0};
    if (metaHost) { if (st.status==='ready'&&st.data) metaHost.innerHTML=(st.data.posEn?'<span class="pos-pill">'+escapeHtml(st.data.posEn)+' • '+escapeHtml(st.data.posAr)+'</span>':'')+(st.data.phonetic?'<span class="ipa-pill">/'+escapeHtml(st.data.phonetic.replace(/^\\/|\\/$/g,''))+'/</span>':''); else metaHost.innerHTML=''; }
    if (!sentHost) return;
    if (st.status==='loading') { sentHost.innerHTML='<div class="sentence-card"><div class="sentence-card-head"><span style="font-weight:800;font-size:14px">💬 مثال في جملة طبيعية</span><span class="muted">جاري التحميل...</span></div></div>'; return; }
    if (st.status==='error') { sentHost.innerHTML='<div class="sentence-card"><div class="sentence-card-head"><span style="font-weight:800;font-size:14px">💬 مثال في جملة طبيعية</span><button class="btn btn-soft btn-sm" onclick="loadWordInfo(' + idx + ',true)">↻ إعادة</button></div><div class="muted">' + escapeHtml(st.data.message) + '</div></div>'; return; }
    const list=(st.data&&st.data.examples)||[];
    if (!list.length) { sentHost.innerHTML='<div class="sentence-card"><div class="sentence-card-head"><span style="font-weight:800;font-size:14px">💬 مثال في جملة طبيعية</span></div><div class="muted">لم يتم العثور على جملة مثال مناسبة لهذه الكلمة.</div></div>'; return; }
    const i=(st.exIdx||0)%list.length, ex=list[i];
    sentHost.innerHTML='<div class="sentence-card"><div class="sentence-card-head"><span style="font-weight:800;font-size:14px">💬 مثال في جملة طبيعية</span>' + (list.length>1?'<button class="btn btn-soft btn-sm" onclick="cycleExample(' + idx + ')">↻ مثال آخر (' + (i+1) + '/' + list.length + ')</button>':'') + '</div><div class="sentence-text">"' + ex.html + '"</div><div class="sentence-footer"><button class="btn btn-soft btn-sm" onclick="speakExample(' + idx + ')">🔊 اسمع الجملة</button><span class="muted" style="font-size:12px">المصدر: ' + escapeHtml(ex.source) + '</span></div></div>';
  }

  function loadYouglishScript() {
    if (window.YG && window.YG.Widget) return Promise.resolve();
    if (ygScriptPromise) return ygScriptPromise;
    ygScriptPromise = new Promise((res, rej) => { window.onYouglishAPIReady = () => res(); const s = document.createElement('script'); s.src = 'https://youglish.com/public/emb/widget.js'; s.async = true; s.onerror = () => { ygScriptPromise = null; rej(new Error('YouGlish failed')); }; document.head.appendChild(s); });
    return ygScriptPromise;
  }
  function loadYtIframeApi() {
    if (window.YT && window.YT.Player) return Promise.resolve(window.YT);
    if (ytApiPromise) return ytApiPromise;
    ytApiPromise = new Promise((res, rej) => { window.onYouTubeIframeAPIReady = () => res(window.YT); const s = document.createElement('script'); s.src = 'https://www.youtube.com/iframe_api'; s.async = true; s.onerror = () => { ytApiPromise = null; rej(new Error('YT failed')); }; document.head.appendChild(s); });
    return ytApiPromise;
  }

  window.watchWordInConversations = async function(idx, forceRefresh) {
    const word = WORDS_EN[idx], srv = getServerBase();
    if (!srv) {
      videoMem.set(idx, { mode:'youglish', status:'active' }); renderVideoBox(idx);
      try {
        await loadYouglishScript();
        if (S.screen!=='word_detail'||S.detailWordIdx!==idx) return;
        const box = document.getElementById('ygEmbedHost'); if (!box) return;
        box.innerHTML = '<div id="yg-widget-el"></div>';
        const w = new window.YG.Widget('yg-widget-el', {
          width: Math.min(640, Math.max(280, box.clientWidth || 320)), components: 8415,
          events: {
            onFetchDone: e => { if (!e||!e.totalResult) { const el=document.getElementById('ygStatusNote'); if(el) el.textContent='لم يعثر YouGlish على نتائج لهذه الكلمة.'; } },
            onError: () => { const el=document.getElementById('ygStatusNote'); if(el) el.textContent='تعذر تشغيل مشغل YouGlish المضمّن. استخدم زر "فتح في YouGlish ↗".'; }
          }
        });
        w.fetch(word, 'english');
      } catch (e) { const el=document.getElementById('ygStatusNote'); if(el) el.textContent='تعذر تحميل المشغل المضمّن. استخدم زر "فتح في YouGlish ↗".'; }
      return;
    }

    const cacheKey = word.toLowerCase();
    if (!forceRefresh) {
      const cached = await idbMediaGet('videos', cacheKey);
      if (cached) {
        const hasV = Array.isArray(cached.verifiedExamples) && cached.verifiedExamples.length > 0;
        videoMem.set(idx, { mode:'server', status:hasV?'ready':'empty', totalVerified:cached.totalVerified||0, verifiedExamples:cached.verifiedExamples||[], unverifiedCandidates:cached.unverifiedCandidates||[], hasMore:!!cached.hasMore, exIndex:0, continueWatching:false, segmentEnded:false });
        if (S.screen==='word_detail'&&S.detailWordIdx===idx) { renderVideoBox(idx); if(hasV) mountYtServerClip(idx); }
        return;
      }
    }
    videoMem.set(idx, { mode:'server', status:'loading' }); renderVideoBox(idx);
    try {
      const r = await fetch(srv + '/api/videos?word=' + encodeURIComponent(word) + '&offset=0&limit=10'), j = await r.json();
      if (!r.ok || !j.ok) { videoMem.set(idx, {mode:'server',status:'error',errorMsg:j.message||'تعذر البحث'}); renderVideoBox(idx); return; }
      const hasV = Array.isArray(j.verifiedExamples) && j.verifiedExamples.length > 0;
      await idbMediaSet('videos', cacheKey, j, hasV ? 7*864e5 : 2*3600*1000);
      videoMem.set(idx, { mode:'server', status:hasV?'ready':'empty', totalVerified:j.totalVerified||0, verifiedExamples:j.verifiedExamples||[], unverifiedCandidates:j.unverifiedCandidates||[], hasMore:!!j.hasMore, exIndex:0, continueWatching:false, segmentEnded:false });
      if (S.screen==='word_detail'&&S.detailWordIdx===idx) { renderVideoBox(idx); if(hasV) mountYtServerClip(idx); }
    } catch (e) { videoMem.set(idx, {mode:'server',status:'error',errorMsg:'تعذر الاتصال بخادم الفيديو.'}); if(S.screen==='word_detail'&&S.detailWordIdx===idx) renderVideoBox(idx); }
  };

  function startSegmentWatcher(idx) {
    stopSegmentWatcher();
    segWatcherId = setInterval(() => {
      const st = videoMem.get(idx); if (!st || st.status !== 'ready' || !activeYtPlayer) { stopSegmentWatcher(); return; }
      if (st.continueWatching || st.segmentEnded) return;
      const ex = st.verifiedExamples[st.exIndex]; if (!ex) return;
      try {
        if (activeYtPlayer.getPlayerState() === 1 && activeYtPlayer.getCurrentTime() >= ex.clipEndSec) {
          activeYtPlayer.pauseVideo(); st.segmentEnded = true;
          const b = document.getElementById('videoStatusBanner');
          if (b) { b.style.display='block'; b.textContent='⏸️ انتهى المقطع (3 ثوانٍ قبل + 3 ثوانٍ بعد). اضغط Replay أو إكمال المشاهدة.'; }
        }
      } catch (_) {}
    }, 150);
  }
  async function mountYtServerClip(idx) {
    const st = videoMem.get(idx); if (!st || !st.verifiedExamples.length) return;
    const ex = st.verifiedExamples[st.exIndex]; cleanupVideoPlayer(); st.segmentEnded = false;
    const m = document.getElementById('ytPlayerMount'); if (!m) return;
    try {
      const YT = await loadYtIframeApi(); if (S.screen!=='word_detail'||S.detailWordIdx!==idx) return;
      m.innerHTML = '<div id="ytInnerPlayer"></div>';
      const pv = { autoplay:1, controls:1, playsinline:1, rel:0, modestbranding:1, start:Math.floor(ex.clipStartSec) };
      if (location.protocol==='http:'||location.protocol==='https:') pv.origin = location.origin;
      activeYtPlayer = new YT.Player('ytInnerPlayer', {
        videoId: ex.videoId, playerVars: pv,
        events: {
          onReady: ev => { try{ev.target.seekTo(ex.clipStartSec,true);ev.target.playVideo();}catch(_){} startSegmentWatcher(idx); },
          onStateChange: ev => { if (ev.data === YT.PlayerState.PLAYING) startSegmentWatcher(idx); },
          onError: () => { stopSegmentWatcher(); const b=document.getElementById('videoStatusBanner'); if(b){b.style.display='block'; b.textContent='⚠️ تعذر تشغيل الفيديو مضمناً. جرب Next Video أو فتح الأصلي.';} }
        }
      });
    } catch (_) {}
  }
  window.replayServerClip = function(idx) { const st=videoMem.get(idx); if(!st||!st.verifiedExamples.length) return; const ex=st.verifiedExamples[st.exIndex]; st.segmentEnded=false; const b=document.getElementById('videoStatusBanner'); if(b)b.style.display='none'; if(activeYtPlayer&&activeYtPlayer.seekTo){try{activeYtPlayer.seekTo(ex.clipStartSec,true);activeYtPlayer.playVideo();startSegmentWatcher(idx);return;}catch(_){}} mountYtServerClip(idx); };
  window.toggleContinueClip = function(idx) { const st=videoMem.get(idx); if(!st) return; st.continueWatching=!st.continueWatching; if(st.continueWatching&&st.segmentEnded&&activeYtPlayer){st.segmentEnded=false;try{activeYtPlayer.playVideo();}catch(_){}} const btn=document.getElementById('btnContinueWatching'); if(btn){btn.className='btn btn-sm '+(st.continueWatching?'btn-success':'btn-soft'); btn.textContent=st.continueWatching?'✓ إكمال المشاهدة مفعّل':'🔓 إكمال المشاهدة';} };
  window.prevServerClip = function(idx) { const st=videoMem.get(idx); if(!st||st.exIndex<=0) return; st.exIndex--; st.continueWatching=false; st.segmentEnded=false; playSfx('tap'); renderVideoBox(idx); mountYtServerClip(idx); };
  window.nextServerClip = function(idx) { const st=videoMem.get(idx); if(!st||st.exIndex+1>=st.verifiedExamples.length) return; st.exIndex++; st.continueWatching=false; st.segmentEnded=false; playSfx('tap'); renderVideoBox(idx); mountYtServerClip(idx); };

  function renderVideoBox(idx) {
    const host = document.getElementById('wordVideoContainer'); if (!host) return;
    const word = WORDS_EN[idx], ygUrl = 'https://youglish.com/pronounce/' + encodeURIComponent(word) + '/english', st = videoMem.get(idx);
    if (!st) { host.innerHTML = '<div class="video-card"><div class="video-card-head"><span style="font-weight:800;font-size:14px">🎬 أمثلة فيديو من محادثات حقيقية</span><a class="btn btn-soft btn-sm" style="text-decoration:none" href="' + ygUrl + '" target="_blank" rel="noopener">YouGlish ↗</a></div><div class="video-launch-box"><div class="muted" style="margin-bottom:12px">شاهد متحدثين أصليين ينطقون هذه الكلمة في محادثات حقيقية.</div><button class="btn btn-primary btn-lg btn-block" onclick="watchWordInConversations(' + idx + ',false)">🎬 Watch This Word in Real Conversations</button></div></div>'; return; }
    if (st.mode === 'youglish') { host.innerHTML = '<div class="video-card"><div class="video-card-head"><span style="font-weight:800;font-size:14px">🎬 أمثلة فيديو من محادثات حقيقية</span><a class="btn btn-soft btn-sm" style="text-decoration:none" href="' + ygUrl + '" target="_blank" rel="noopener">فتح في YouGlish ↗</a></div><div class="video-launch-box"><div id="ygEmbedHost" style="width:100%;min-height:240px;display:flex;justify-content:center">جاري تحميل مشغل المحادثات...</div><div id="ygStatusNote" class="muted" style="margin-top:8px"></div></div></div>'; return; }
    if (st.status === 'loading') { host.innerHTML = '<div class="video-card"><div class="video-card-head"><span style="font-weight:800;font-size:14px">🎬 المحادثات الحقيقية</span></div><div class="video-launch-box">🔎 جاري البحث في ترجمات يوتيوب...</div></div>'; return; }
    if (st.status === 'error') { host.innerHTML = '<div class="video-card"><div class="video-card-head"><span style="font-weight:800;font-size:14px">🎬 المحادثات الحقيقية</span><button class="btn btn-soft btn-sm" onclick="watchWordInConversations(' + idx + ',true)">↻ إعادة</button></div><div class="video-launch-box">' + escapeHtml(st.errorMsg||'تعذر التحميل') + '</div></div>'; return; }
    if (st.status === 'empty' || !st.verifiedExamples.length) { host.innerHTML = '<div class="video-card"><div class="video-card-head"><span style="font-weight:800;font-size:14px">🎬 المحادثات الحقيقية</span><a class="btn btn-soft btn-sm" style="text-decoration:none" href="' + ygUrl + '" target="_blank" rel="noopener">جرّب YouGlish ↗</a></div><div class="video-launch-box">لم نعثر على مقاطع موثقة التوقيت لهذه الكلمة حالياً.</div></div>'; return; }
    const ex = st.verifiedExamples[st.exIndex], tot = st.totalVerified || st.verifiedExamples.length;
    host.innerHTML = '<div class="video-card"><div class="video-card-head"><span style="font-weight:800;font-size:14px">🎬 المحادثات الحقيقية</span><span style="font-size:12.5px;font-weight:900;color:var(--primary)">Example ' + (st.exIndex+1) + ' of ' + tot + '</span></div><div class="yt-embed-wrap"><div id="ytPlayerMount"></div></div><div class="video-body"><div class="video-target-row"><div style="font-weight:900;font-size:14px">Target word: <span style="color:var(--cyan);direction:ltr;display:inline-block">' + escapeHtml(word.toUpperCase()) + '</span></div><span class="verified-badge">موثق من النطق ✓</span></div><div style="font-size:12.5px;font-weight:700;color:var(--text-muted);margin-bottom:4px">' + escapeHtml(ex.title) + ' • ' + escapeHtml(ex.source) + '</div><div class="video-transcript-box">"' + ex.transcriptHtml + '"</div><div class="video-nav-grid"><button class="btn btn-soft btn-sm" onclick="replayServerClip(' + idx + ')">↻ Replay</button><button class="btn btn-soft btn-sm" ' + (st.exIndex<=0?'disabled':'') + ' onclick="prevServerClip(' + idx + ')">‹ Previous</button><button class="btn btn-primary btn-sm" ' + (st.exIndex>=st.verifiedExamples.length-1?'disabled':'') + ' onclick="nextServerClip(' + idx + ')">Next Video ›</button></div><div class="video-sub-actions"><button id="btnContinueWatching" class="btn btn-sm ' + (st.continueWatching?'btn-success':'btn-soft') + '" onclick="toggleContinueClip(' + idx + ')">' + (st.continueWatching?'✓ إكمال المشاهدة مفعّل':'🔓 إكمال المشاهدة') + '</button><a class="btn btn-soft btn-sm" style="text-decoration:none" href="' + escapeHtml(ex.watchUrl) + '" target="_blank" rel="noopener">فتح الأصلي ↗</a></div><div id="videoStatusBanner" class="video-status-banner" style="display:none"></div></div></div>';
  }

  function renderWordDetailView(main) {
    const idx = S.detailWordIdx; if (idx < 0 || idx >= WORDS_EN.length) { goBack(); return; }
    const isFav = S.favorites.has(idx), isMast = S.mastered.has(idx), isMis = S.mistakes.has(idx);
    main.innerHTML = '<div class="detail-hero-card"><div class="detail-word-top"><div style="min-width:0;flex:1"><div style="margin-bottom:6px">' + bandPillHTML(WORDS_BAND[idx]) + '</div><div class="detail-word-en">' + escapeHtml(WORDS_EN[idx]) + '</div><div class="detail-word-ar">' + escapeHtml(WORDS_AR[idx]) + '</div><div id="wordMetaPills" class="word-meta-pills"></div></div><div style="display:flex;gap:6px;flex-shrink:0"><button class="icon-btn" onclick="speakWordById(' + idx + ')">🔊</button><button class="icon-btn" onclick="toggleFavorite(' + idx + ',this)">' + (isFav?'⭐':'☆') + '</button></div></div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button class="btn btn-sm ' + (isMast?'btn-success':'btn-soft') + '" onclick="toggleDetailMast(' + idx + ')">' + (isMast?'✓ كلمة متقنة':'تحديد كمتقنة') + '</button><button class="btn btn-sm ' + (isMis?'btn-warning':'btn-soft') + '" onclick="toggleDetailMis(' + idx + ')">' + (isMis?'🔥 في بنك الأخطاء':'إضافة للأخطاء') + '</button></div></div><div id="wordPhotoContainer"></div><div id="wordSentenceContainer"></div><div id="wordVideoContainer"></div>';
    renderPhotoBox(idx); renderInfoBox(idx); renderVideoBox(idx);
  }
  window.toggleDetailMast = function(idx) { if(S.mastered.has(idx)) S.mastered.delete(idx); else{S.mastered.add(idx);S.mistakes.delete(idx);} safeSaveState(); playSfx('tap'); render(); };
  window.toggleDetailMis = function(idx) { if(S.mistakes.has(idx)) S.mistakes.delete(idx); else S.mistakes.add(idx); safeSaveState(); playSfx('tap'); render(); };

  function renderSettingsView(main) {
    const doneAll = Object.values(S.completed).filter(p => p >= 80).length, totSubAll = BANDS.reduce((a, b) => a + getBandSubCount(b), 0);
    main.innerHTML = '<div class="mini-stats"><div class="stat-tile"><div class="sv">' + WORDS_EN.length.toLocaleString('en-US') + '</div><div class="sl">إجمالي الكلمات</div></div><div class="stat-tile"><div class="sv" style="color:var(--success)">' + S.mastered.size + '</div><div class="sl">كلمات متقنة</div></div><div class="stat-tile"><div class="sv" style="color:var(--warning)">' + S.xp + '</div><div class="sl">نقاط XP</div></div><div class="stat-tile"><div class="sv" style="color:var(--cyan)">' + doneAll + '/' + totSubAll + '</div><div class="sl">مستويات مكتملة</div></div></div><div class="card"><div class="set-row"><div><div style="font-weight:800">الهدف اليومي</div><div class="muted" style="font-size:12px">كم كلمة بدك تتدرب يومياً</div></div><select class="select" onchange="changeDailyGoal(this.value)">' + [10,20,30,50,100].map(n=>'<option value="'+n+'" '+(S.dailyGoal===n?'selected':'')+'>'+n+' كلمة</option>').join('') + '</select></div><div class="set-row"><div><div style="font-weight:800">عدد الكلمات في كل مستوى</div><div class="muted" style="font-size:12px">حجم الجولة الواحدة</div></div><select class="select" onchange="changeLevelSize(this.value)">' + [10,15,20,30,50].map(n=>'<option value="'+n+'" '+(S.levelSize===n?'selected':'')+'>'+n+' كلمة</option>').join('') + '</select></div><div class="set-row"><div><div style="font-weight:800">النطق الصوتي التلقائي</div><div class="muted" style="font-size:12px">ينطق الكلمة تلقائياً أثناء اللعب</div></div><button class="btn btn-sm ' + (S.autoSpeak?'btn-success':'btn-soft') + '" onclick="toggleAutoSpeak()">' + (S.autoSpeak?'مُفعّل ✓':'مُطفأ') + '</button></div><div class="set-row"><div><div style="font-weight:800">سرعة النطق الصوتي</div><div class="muted" style="font-size:12px">تحكم بسرعة القراءة</div></div><select class="select" onchange="changeTtsRate(this.value)"><option value="0.7" ' + (S.ttsRate===0.7?'selected':'') + '>بطيء (0.7x)</option><option value="0.92" ' + (S.ttsRate===0.92?'selected':'') + '>طبيعي (0.9x)</option><option value="1.1" ' + (S.ttsRate===1.1?'selected':'') + '>سريع (1.1x)</option></select></div><div class="set-row" style="flex-direction:column;align-items:stretch"><div><div style="font-weight:800">مفاتيح الصور الحقيقية (اختياري — تُحفظ على جهازك فقط)</div><div class="muted" style="font-size:12px">أضف مفتاح Pixabay أو Unsplash المجاني لتفعيل الصور</div></div><input class="input" style="direction:ltr;margin-top:6px" placeholder="Pixabay API Key" value="' + escapeHtml(S.pixabayKey) + '" onchange="savePixabayKey(this.value)"><input class="input" style="direction:ltr;margin-top:6px" placeholder="Unsplash Access Key" value="' + escapeHtml(S.unsplashKey) + '" onchange="saveUnsplashKey(this.value)"></div><div class="set-row" style="flex-direction:column;align-items:stretch"><div><div style="font-weight:800">رابط خادم الفيديو المتقدم (اختياري)</div><div class="muted" style="font-size:12px">اتركه فارغاً للتشغيل المستقل بملف واحد</div></div><input class="input" style="direction:ltr;margin-top:6px" placeholder="https://your-server.com" value="' + escapeHtml(S.backendUrl) + '" onchange="saveBackendUrl(this.value)"></div><div class="set-row"><div><div style="font-weight:800">ذاكرة الوسائط المؤقتة</div><div class="muted" style="font-size:12px">مسح الصور والجمل والفيديوهات المخزنة</div></div><button class="btn btn-soft btn-sm" onclick="clearAllMediaCache()">مسح الكاش</button></div><div class="set-row"><div><div style="font-weight:800">نسخ احتياطي للتقدم</div></div><div style="display:flex;gap:6px"><button class="btn btn-primary btn-sm" onclick="exportBackup()">تصدير</button><label class="btn btn-soft btn-sm" style="cursor:pointer">استيراد<input type="file" accept=".json" style="display:none" onchange="importBackup(this)"></label></div></div><div class="set-row"><div><div style="font-weight:800">ملف كلمات مخصص (CSV)</div></div><div style="display:flex;gap:6px"><label class="btn btn-soft btn-sm" style="cursor:pointer">📂 CSV<input type="file" accept=".csv,.txt" style="display:none" onchange="importCustomCSV(this)"></label>' + (S.usingCustom?'<button class="btn btn-warning btn-sm" onclick="restoreEmbeddedCSV()">استعادة</button>':'') + '</div></div><div class="set-row"><div><div style="font-weight:800;color:var(--danger)">تصفير التقدم</div></div><button class="btn btn-danger btn-sm" onclick="resetProgress()">تصفير</button></div></div>';
  }

  window.changeDailyGoal = function(v) { S.dailyGoal=parseInt(v,10)||20; safeSaveState(); showToast('الهدف اليومي: ' + S.dailyGoal + ' كلمة'); render(); };
  window.changeLevelSize = function(v) { S.levelSize=parseInt(v,10)||20; safeSaveState(); showToast('حجم المستوى: ' + S.levelSize + ' كلمة'); render(); };
  window.toggleAutoSpeak = function() { S.autoSpeak=!S.autoSpeak; safeSaveState(); render(); showToast(S.autoSpeak?'تم تفعيل النطق التلقائي':'تم إيقاف النطق التلقائي'); };
  window.changeTtsRate = function(v) { S.ttsRate=parseFloat(v)||0.92; safeSaveState(); speakEn('Ready to practice'); };
  window.savePixabayKey = function(v) { S.pixabayKey=String(v||'').trim(); safeSaveState(); showToast('تم حفظ مفتاح Pixabay ✓'); };
  window.saveUnsplashKey = function(v) { S.unsplashKey=String(v||'').trim(); safeSaveState(); showToast('تم حفظ مفتاح Unsplash ✓'); };
  window.saveBackendUrl = function(v) { S.backendUrl=String(v||'').trim(); safeSaveState(); showToast('تم حفظ رابط الخادم ✓'); };

  window.exportBackup = function() { try { const blob=new Blob([localStorage.getItem(STORE_KEY)||'{}'],{type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='vocab_cefr_backup.json'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000); showToast('تم تنزيل النسخة الاحتياطية ✓'); } catch(e){ showToast('تعذر التصدير'); } };
  window.importBackup = function(input) {
    const file = input.files && input.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const o = JSON.parse(reader.result);
        S.levelSize=o.levelSize||S.levelSize; S.dailyGoal=o.dailyGoal||S.dailyGoal; S.xp=o.xp||0; S.streak=o.streak||0; S.bestStreak=o.bestStreak||0;
        S.lastBand=o.lastBand||'A0'; S.lastSubLevel=o.lastSubLevel||0; S.completed=o.completed||{};
        S.mistakes=new Set(o.mistakes||[]); S.favorites=new Set(o.favorites||[]); S.mastered=new Set(o.mastered||[]);
        if (typeof o.pixabayKey === 'string') S.pixabayKey = o.pixabayKey;
        if (typeof o.unsplashKey === 'string') S.unsplashKey = o.unsplashKey;
        if (typeof o.backendUrl === 'string') S.backendUrl = o.backendUrl;
        safeSaveState(); showToast('تم استيراد التقدم ✓'); render();
      } catch (e) { showToast('الملف غير صالح'); }
    };
    reader.readAsText(file, 'utf-8');
  };
  function parseCSVTextToTSV(text) {
    const rows=[]; let row=[], cur='', inQ=false;
    for(let i=0;i<text.length;i++){const c=text[i]; if(inQ){if(c==='"'&&text[i+1]==='"'){cur+='"';i++;}else if(c==='"')inQ=false;else cur+=c;} else{if(c==='"')inQ=true;else if(c===','){row.push(cur);cur='';}else if(c==='\\n'||c==='\\r'){if(c==='\\r'&&text[i+1]==='\\n')i++;row.push(cur);cur='';if(row.length>=2)rows.push(row);row=[];}else cur+=c;}}
    if(cur||row.length){row.push(cur);if(row.length>=2)rows.push(row);}
    const seen=new Set(), out=[];
    for(let i=0;i<rows.length;i++){
      let b='',en='',ar='';
      if(rows[i].length>=3&&BAND_META[(rows[i][0]||'').trim().toUpperCase()]){b=rows[i][0].trim().toUpperCase();en=(rows[i][1]||'').normalize('NFKC').trim().replace(/[\\t\\r\\n]/g,' ');ar=(rows[i][2]||'').trim().replace(/[\\t\\r\\n]/g,' ');}
      else{en=(rows[i][0]||'').normalize('NFKC').trim().replace(/[\\t\\r\\n]/g,' ');ar=(rows[i][1]||'').trim().replace(/[\\t\\r\\n]/g,' ');b=assignBandByIndex(out.length);}
      if(!en||!ar)continue; if(i===0&&/english|word/i.test(en))continue;
      const k=en.toLowerCase(); if(seen.has(k))continue; seen.add(k); out.push(b+'\\t'+en+'\\t'+ar);
    }
    return out.join('\\n');
  }
  window.importCustomCSV = function(input) { const f=input.files&&input.files[0]; if(!f)return; const r=new FileReader(); r.onload=async()=>{const t=parseCSVTextToTSV(r.result||''); if(!t){showToast('لم يتم العثور على كلمات صالحة');return;} parseTSVIntoMemory(t); S.usingCustom=true; S.lastBand='A0'; S.lastSubLevel=0; S.completed={}; S.mistakes.clear(); S.favorites.clear(); S.mastered.clear(); await idbSaveCustomTSV(t); safeSaveState(); showToast('تم استيراد ' + WORDS_EN.length.toLocaleString('en-US') + ' كلمة ✓'); goTab('games');}; r.readAsText(f,'utf-8'); };
  window.restoreEmbeddedCSV = async function() { await idbClearCustomTSV(); loadEmbeddedVocab(); S.usingCustom=false; S.lastBand='A0'; S.lastSubLevel=0; safeSaveState(); showToast('تمت استعادة ' + WORDS_EN.length.toLocaleString('en-US') + ' كلمة ✓'); goTab('games'); };
  window.resetProgress = function() { if(!confirm('متأكد بدك تصفّر كل تقدمك؟')) return; S.xp=0; S.streak=0; S.bestStreak=0; S.todayCount=0; S.lastBand='A0'; S.lastSubLevel=0; S.completed={}; S.mistakes.clear(); S.favorites.clear(); S.mastered.clear(); safeSaveState(); showToast('تم تصفير التقدم'); render(); };

  window.onerror = function() { return false; };
  async function init() {
    applyTheme();
    if (S.usingCustom) { const custom = await idbLoadCustomTSV(); if (custom) parseTSVIntoMemory(custom); else { S.usingCustom = false; loadEmbeddedVocab(); } }
    else loadEmbeddedVocab();
    render();
  }
  init();
})();
</script>
</body>
</html>
`;
