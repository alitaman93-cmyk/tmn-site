// Built-in starter vocabulary across all 7 CEFR bands (A0–C2)
// Users can import their full 18,000-word HTML/CSV file at any time.
export const STARTER_VOCAB_TSV = `A0\twater\tماء
A0\tbread\tخبز
A0\thouse\tمنزل
A0\tbook\tكتاب
A0\tapple\tتفاحة
A0\tsun\tشمس
A0\tmoon\tقمر
A0\tday\tيوم
A0\tnight\tليل
A0\tfriend\tصديق
A0\tfamily\tعائلة
A0\tschool\tمدرسة
A0\tteacher\tمعلم
A0\tstudent\tطالب
A0\tcar\tسيارة
A0\troad\tطريق
A0\tcity\tمدينة
A0\ttime\tوقت
A0\twork\tعمل
A0\tfood\tطعام
A0\tcoffee\tقهوة
A0\tmilk\tحليب
A0\thand\tيد
A0\teye\tعين
A0\theart\tقلب
A0\tname\tاسم
A0\thappy\tسعيد
A0\tgood\tجيد
A0\tbig\tكبير
A0\tsmall\tصغير
A1\tmorning\tصباح
A1\tevening\tمساء
A1\tmarket\tسوق
A1\tkitchen\tمطبخ
A1\twindow\tنافذة
A1\tgarden\tحديقة
A1\tweather\tطقس
A1\train\tمطر
A1\twinter\tشتاء
A1\tsummer\tصيف
A1\ttravel\tيسافر
A1\ttrain\tقطار
A1\tairport\tمطار
A1\thotel\tفندق
A1\tticket\tتذكرة
A1\tmoney\tمال
A1\tprice\tسعر
A1\tphone\tهاتف
A1\tletter\tرسالة
A1\tmusic\tموسيقى
A1\tmovie\tفيلم
A1\tdoctor\tطبيب
A1\thospital\tمستشفى
A1\thealth\tصحة
A1\tlanguage\tلغة
A1\tquestion\tسؤال
A1\tanswer\tإجابة
A1\tlearn\tيتعلم
A1\twrite\tيكتب
A1\tlisten\tيستمع
A2\tadventure\tمغامرة
A2\tbridge\tجسر
A2\tcalendar\tتقويم
A2\tcustomer\tعميل
A2\tdecision\tقرار
A2\tdelicious\tلذيذ
A2\tdirection\tاتجاه
A2\tdiscover\tيكتشف
A2\teducation\tتعليم
A2\tenergy\tطاقة
A2\texercise\tتمرين
A2\texperience\tتجربة
A2\tfavorite\tمفضل
A2\tfuture\tمستقبل
A2\thistory\tتاريخ
A2\timportant\tمهم
A2\timprove\tيحسّن
A2\tjourney\tرحلة
A2\tknowledge\tمعرفة
A2\tlibrary\tمكتبة
A2\tmemory\tذاكرة
A2\tmessage\tرسالة
A2\tnature\tطبيعة
A2\tneighbor\tجار
A2\topinion\tرأي
A2\tpatient\tصبور
A2\tpractice\tممارسة
A2\tpromise\tوعد
A2\tsuccess\tنجاح
A2\ttraffic\tمرور
B1\tachieve\tيحقق
B1\tadvantage\tميزة
B1\tambition\tطموح
B1\tapproach\tمنهج
B1\tattitude\tموقف
B1\tavailable\tمتاح
B1\tbenefit\tفائدة
B1\tchallenge\tتحدٍ
B1\tcommunity\tمجتمع
B1\tcompare\tيقارن
B1\tconfident\tواثق
B1\tconsider\tيفكر في
B1\tcreative\tمبدع
B1\tculture\tثقافة
B1\tdevelop\tيطوّر
B1\teffective\tفعّال
B1\tencourage\tيشجع
B1\tenvironment\tبيئة
B1\tessential\tأساسي
B1\tevidence\tدليل
B1\tflexible\tمرن
B1\tgenerous\tكريم
B1\tinfluence\tتأثير
B1\tmanage\tيدير
B1\topportunity\tفرصة
B1\torganize\tينظّم
B1\tquality\tجودة
B1\treliable\tموثوق
B1\tresource\tمورد
B1\tsolution\tحل
B2\tabstract\tمجرد
B2\taccurate\tدقيق
B2\tadequate\tكافٍ
B2\tanalyze\tيحلل
B2\tanticipate\tيتوقع
B2\tcapacity\tقدرة
B2\tcoherent\tمتماسك
B2\tcollaborate\tيتعاون
B2\tcomprehensive\tشامل
B2\tconsequence\tنتيجة
B2\tconsistent\tمتسق
B2\tcontribute\tيساهم
B2\tcriteria\tمعايير
B2\tdemonstrate\tيبرهن
B2\tdistinguish\tيميز
B2\tefficiency\tكفاءة
B2\temphasize\tيؤكد
B2\testablish\tيؤسس
B2\tevaluate\tيقيّم
B2\tfundamental\tجوهري
B2\timplement\tينفّذ
B2\tinevitable\tحتمي
B2\tinnovation\tابتكار
B2\tinterpret\tيفسّر
B2\tmaintain\tيحافظ على
B2\tperspective\tمنظور
B2\tpriority\tأولوية
B2\tstrategy\tاستراتيجية
B2\tsustainable\tمستدام
B2\ttransform\tيحوّل
C1\tadvocate\tيناصر
C1\talleviate\tيخفف
C1\tambiguous\tغامض
C1\tarticulate\tيعبّر بوضوح
C1\tbolster\tيعزز
C1\tcatastrophe\tكارثة
C1\tcompelling\tمقنع
C1\tconsensus\tإجماع
C1\tcontemplate\tيتأمل
C1\tcorroborate\tيؤيد بدليل
C1\tdelineate\tيحدد بدقة
C1\tdisparity\tتفاوت
C1\telucidate\tيوضح
C1\tendeavor\tمسعى
C1\texacerbate\tيفاقم
C1\tfoster\tيرعى
C1\timperative\tحتمي وملح
C1\tintricate\tمعقد ودقيق
C1\tmitigate\tيحد من
C1\tmeticulous\tشديد الدقة
C1\tnuance\tفارق دقيق
C1\tparadigm\tنموذج فكري
C1\tpragmatic\tعملي
C1\tprevalent\tسائد
C1\tprofound\tعميق
C1\tresilient\tمرن وقادر على التعافي
C1\tscrutinize\tيدقق في
C1\tsubstantiate\tيثبت بالأدلة
C1\ttangible\tملموس
C1\tubiquitous\tمنتشر في كل مكان
C2\taberration\tانحراف عن المألوف
C2\tacumen\tفطنة وبصيرة
C2\tanachronism\tمفارقة تاريخية
C2\tcacophony\tنشاز صوتي
C2\tcognizant\tمدرك وواعٍ
C2\tconundrum\tلغز محيّر
C2\tdearth\tندرة شديدة
C2\tdichotomy\tثنائية متقابلة
C2\tebullient\tمفعم بالحماس
C2\tephemeral\tعابر وزائل
C2\tequanimity\tرباطة جأش
C2\tesoteric\tباطني نخبوي
C2\texpedient\tملائم للمصلحة
C2\tfastidious\tشديد التدقيق
C2\tgrandiloquent\tفخم العبارة
C2\thegemony\tهيمنة
C2\ticonoclast\tمحطم للتقاليد
C2\tineffable\tيعجز الوصف عنه
C2\tjuxtapose\tيضع جنباً إلى جنب
C2\tlaconic\tموجز ومقتضب
C2\tmagnanimous\tشهم وكريم النفس
C2\tobfuscate\tيُعمّي ويُربك
C2\tpanacea\tعلاج شامل
C2\tperspicacious\tثاقب البصيرة
C2\tquixotic\tمثالي حالم
C2\trecalcitrant\tعنيد ومتمرد
C2\tsagacious\tحكيم وفطن
C2\tserendipity\tصدفة سعيدة
C2\tverisimilitude\tشبه بالحقيقة
C2\tzephyr\tنسيم عليل`;
