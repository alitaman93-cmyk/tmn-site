import { Suspense, lazy, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { BAND_META, GAME_MAP } from './data/constants';
import { STARTER_VOCAB_TSV } from './data/starterVocab';
import { getTranslations } from './i18n/translations';
import type {
  AiCoachModeId,
  ArcadeGameModeId,
  ArticleItem,
  CefrBand,
  DailyPaceMinutes,
  DailyPlanStepId,
  GameModeId,
  LearningGoalId,
  NavTab,
  PersistedSettings,
  PlacementResult,
  SavedWordNote,
  ScreenId,
  SentenceGameModeId,
  SourceType,
  SrsRating,
  VocabEntry,
  VocabStore,
  WordMasteryRecord,
} from './types';
import {
  markDailyPlanStep,
  recordDailyStudyActivity,
} from './utils/learningFeaturesLogic';
import { playSfx, speakEn, type SfxType } from './utils/audio';
import {
  fetchCloudAccountState,
  mergeCloudAndLocalSettings,
  upsertCloudProfile,
  upsertCloudSrsCard,
} from './utils/cloudSync';
import { prefetchSecondaryChunks, prefetchWordsBatch } from './utils/prefetchEngine';
import { getSrsStats, orderPoolForSrs, reviewSrsCard } from './utils/srsLogic';
import {
  idbGetDataset,
  idbSetDataset,
  loadPersistedSettings,
  requestPersistentStorage,
  savePersistedSettings,
  todayStr,
} from './utils/storage';
import {
  getBandSubCount,
  getBandSubIndices,
  getRandomPool,
  lvlKey,
  parseTSVToStore,
  shuffleArr,
} from './utils/vocabLogic';
import {
  computeWordMastery,
  findWordInStore,
  normalizeWordKey,
} from './utils/wordHubLogic';
import { ErrorBoundary } from './components/ErrorBoundary';
import type { GameSessionConfig } from './components/GameArena';
import { GamesHome } from './components/GamesHome';
import { GuestSavePromptModal } from './components/GuestSavePromptModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { TopBar } from './components/TopBar';
import { ZeroArabicLeakTranslator } from './components/ZeroArabicLeakTranslator';

// Lazy-load heavy views & modals so initial bundle & mobile first paint stay instant
const loadAuthModal = () =>
  import('./components/AuthModal').then((m) => ({ default: m.AuthModal }));
const loadDictView = () =>
  import('./components/DictView').then((m) => ({ default: m.DictView }));
const loadGameArena = () =>
  import('./components/GameArena').then((m) => ({ default: m.GameArena }));
const loadGameSetup = () =>
  import('./components/GameSetup').then((m) => ({ default: m.GameSetup }));
const loadLevelsView = () => import('./components/LevelsView');
const loadPlacementTestModal = () =>
  import('./components/PlacementTestModal').then((m) => ({ default: m.PlacementTestModal }));
const loadSentenceGamesArena = () =>
  import('./components/SentenceGamesArena').then((m) => ({ default: m.SentenceGamesArena }));
const loadStudyArena = () =>
  import('./components/StudyArena').then((m) => ({ default: m.StudyArena }));
const loadAiCoachView = () =>
  import('./components/AiCoachView').then((m) => ({ default: m.AiCoachView }));
const loadArticlesView = () =>
  import('./components/ArticlesView').then((m) => ({ default: m.ArticlesView }));
const loadGrammarView = () =>
  import('./components/GrammarView').then((m) => ({ default: m.GrammarView }));
const loadListeningView = () =>
  import('./components/ListeningView').then((m) => ({ default: m.ListeningView }));
const loadSentencesView = () =>
  import('./components/SentencesView').then((m) => ({ default: m.SentencesView }));
const loadSettingsView = () =>
  import('./components/SettingsView').then((m) => ({ default: m.SettingsView }));
const loadStatsView = () =>
  import('./components/StatsView').then((m) => ({ default: m.StatsView }));
const loadWordDetailView = () =>
  import('./components/WordDetailView').then((m) => ({ default: m.WordDetailView }));

const AuthModal = lazy(loadAuthModal);
const DictView = lazy(loadDictView);
const GameArena = lazy(loadGameArena);
const GameSetup = lazy(loadGameSetup);
const CefrBandsList = lazy(() => loadLevelsView().then((m) => ({ default: m.CefrBandsList })));
const BandSubLevels = lazy(() => loadLevelsView().then((m) => ({ default: m.BandSubLevels })));
const LevelDetail = lazy(() => loadLevelsView().then((m) => ({ default: m.LevelDetail })));
const PlacementTestModal = lazy(loadPlacementTestModal);
const SentenceGamesArena = lazy(loadSentenceGamesArena);
const StudyArena = lazy(loadStudyArena);
const AiCoachView = lazy(loadAiCoachView);
const ArticlesView = lazy(loadArticlesView);
const GrammarView = lazy(loadGrammarView);
const ListeningView = lazy(loadListeningView);
const SentencesView = lazy(loadSentencesView);
const SettingsView = lazy(loadSettingsView);
const StatsView = lazy(loadStatsView);
const WordDetailView = lazy(loadWordDetailView);

// Lazy-load new flagship modals so initial bundle stays lean
const OnboardingModal = lazy(() =>
  import('./components/OnboardingModal').then((m) => ({ default: m.OnboardingModal }))
);
const GlobalSearchModal = lazy(() =>
  import('./components/GlobalSearchModal').then((m) => ({ default: m.GlobalSearchModal }))
);
const MistakeFixerModal = lazy(() =>
  import('./components/MistakeFixerModal').then((m) => ({ default: m.MistakeFixerModal }))
);
const CertificateModal = lazy(() =>
  import('./components/CertificateModal').then((m) => ({ default: m.CertificateModal }))
);
const NotebookModal = lazy(() =>
  import('./components/NotebookModal').then((m) => ({ default: m.NotebookModal }))
);
const ArcadeGamesArena = lazy(() =>
  import('./components/ArcadeGamesArena').then((m) => ({ default: m.ArcadeGamesArena }))
);
const SentenceGamesProArena = lazy(() =>
  import('./components/SentenceGamesProArena').then((m) => ({ default: m.SentenceGamesProArena }))
);
const SentencePatternSwapGame = lazy(() =>
  import('./components/SentencePatternSwapGame').then((m) => ({
    default: m.SentencePatternSwapGame,
  }))
);

function ViewFallback() {
  return (
    <div className="mx-auto max-w-4xl space-y-4 py-8">
      <div className="h-24 animate-pulse rounded-2xl bg-slate-200/70 dark:bg-slate-800/70" />
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="h-28 animate-pulse rounded-2xl bg-slate-200/70 dark:bg-slate-800/70" />
        <div className="h-28 animate-pulse rounded-2xl bg-slate-200/70 dark:bg-slate-800/70" />
      </div>
    </div>
  );
}

function TmnAppContent() {
  const { user, authReady } = useAuth();

  const [settings, setSettings] = useState<PersistedSettings>(() => loadPersistedSettings());
  const [store, setStore] = useState<VocabStore>(() => parseTSVToStore(STARTER_VOCAB_TSV));

  const [navTab, setNavTab] = useState<NavTab>('games');
  const [screen, setScreen] = useState<ScreenId>('games');

  // Setup state
  const [setupGame, setSetupGame] = useState<GameModeId>('listen_type');
  const [setupSource, setSetupSource] = useState<SourceType>('level');
  const [setupBand, setSetupBand] = useState<CefrBand>(settings.lastBand || 'A0');
  const [setupSub, setSetupSub] = useState<number>(settings.lastSubLevel || 0);

  // Level browsing state
  const [browseBand, setBrowseBand] = useState<CefrBand>('A0');
  const [detailBand, setDetailBand] = useState<CefrBand>('A0');
  const [detailSub, setDetailSub] = useState<number>(0);

  // Active gameplay / study / sentence game / word detail state
  const [gameSession, setGameSession] = useState<GameSessionConfig | null>(null);
  const [gameReturnScreen, setGameReturnScreen] = useState<ScreenId>('games');
  const [studySession, setStudySession] = useState<{
    id: number;
    indices: number[];
    returnScreen: ScreenId;
  } | null>(null);
  const [sentenceGameSession, setSentenceGameSession] = useState<{
    id: number;
    mode: SentenceGameModeId;
    returnScreen: ScreenId;
  } | null>(null);
  const [arcadeSession, setArcadeSession] = useState<{
    id: number;
    mode: ArcadeGameModeId;
    returnScreen: ScreenId;
  } | null>(null);

  const [gameHud, setGameHud] = useState<{
    current: number;
    total: number;
    correct: number;
    wrong: number;
  } | null>(null);

  const [detailWordIdx, setDetailWordIdx] = useState<number>(-1);
  const [adHocWord, setAdHocWord] = useState<VocabEntry | null>(null);
  const [wordDetailHistory, setWordDetailHistory] = useState<
    Array<{ idx: number; adHoc: VocabEntry | null }>
  >([]);
  const [detailReturnScreen, setDetailReturnScreen] = useState<ScreenId>('dict');
  const [summaryArticle, setSummaryArticle] = useState<ArticleItem | null>(null);
  const [coachInitialMode, setCoachInitialMode] = useState<AiCoachModeId>('chat');

  // Auth, Placement Test, Onboarding, Search, Mistake Fixer, Certificate & Notebook Modals
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'signup' | 'signin'>('signup');
  const [placementOpen, setPlacementOpen] = useState(false);
  const [guestPromptOpen, setGuestPromptOpen] = useState(false);
  const guestPromptShownRef = useRef(false);
  const [onboardingOpen, setOnboardingOpen] = useState<boolean>(
    () => !settings.onboardingCompleted
  );
  const [globalSearchOpen, setGlobalSearchOpen] = useState(false);
  const [mistakeFixerOpen, setMistakeFixerOpen] = useState(false);
  const [notebookOpen, setNotebookOpen] = useState(false);
  const [certificateModal, setCertificateModal] = useState<{
    band: CefrBand;
    reasonAr: string;
  } | null>(null);
  const [sentencesInitialQuery, setSentencesInitialQuery] = useState('');
  const [grammarInitialLessonId, setGrammarInitialLessonId] = useState<string | null>(null);

  // Cloud sync refs
  const cloudProfileExistsRef = useRef(false);
  const cloudHydratedUidRef = useRef<string | null>(null);
  const cloudSrsIdsRef = useRef<Set<number>>(new Set());
  const syncTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const latestSettingsRef = useRef(settings);

  // Toast
  const [toastMsg, setToastMsg] = useState('');
  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const sessionCounterRef = useRef(1);

  const openAuthModal = useCallback((mode: 'signup' | 'signin') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  }, []);

  const openPlacementModal = useCallback(() => {
    setPlacementOpen(true);
  }, []);

  useEffect(() => {
    latestSettingsRef.current = settings;
  }, [settings]);

  // Global Ctrl+K / Cmd+K Instant Search Palette shortcut
  useEffect(() => {
    const onGlobalKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setGlobalSearchOpen((open) => !open);
      }
    };
    window.addEventListener('keydown', onGlobalKeyDown);
    return () => window.removeEventListener('keydown', onGlobalKeyDown);
  }, []);

  // Dynamic canonical & og:url sync + speculative idle chunk preloading after first paint
  useEffect(() => {
    try {
      const canonicalUrl = `${window.location.origin}${window.location.pathname}`;
      let link = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
      if (!link) {
        link = document.createElement('link');
        link.rel = 'canonical';
        document.head.appendChild(link);
      }
      link.href = canonicalUrl;
      const ogUrl = document.querySelector<HTMLMetaElement>('meta[property="og:url"]');
      if (ogUrl) ogUrl.content = canonicalUrl;
    } catch {
      // Ignore
    }

    // Ask browser for persistent IndexedDB storage so offline cache isn't evicted
    requestPersistentStorage();

    prefetchSecondaryChunks([
      loadGameSetup,
      loadGameArena,
      loadLevelsView,
      loadSentencesView,
      loadSentenceGamesArena,
      loadStudyArena,
      loadDictView,
      loadListeningView,
      loadArticlesView,
      loadGrammarView,
      loadWordDetailView,
      loadAiCoachView,
      loadStatsView,
      loadSettingsView,
    ]);

    // Speculatively warm the 21k sentences dataset into IndexedDB during idle time
    const warmSentencesTimer = window.setTimeout(() => {
      void (async () => {
        try {
          const cached = await idbGetDataset('sentences-21k');
          if (cached && cached.length > 1000) return;
          const res = await fetch('/sentences-21k.tsv');
          if (res.ok) {
            const text = await res.text();
            if (text.length > 1000) {
              void idbSetDataset('sentences-21k', text);
            }
          }
        } catch {
          // Ignore if offline
        }
      })();
    }, 900);

    return () => window.clearTimeout(warmSentencesTimer);
  }, []);

  // Aggressively prefetch the next 12 words (photos + Word Hub + video clips) of the active level
  useEffect(() => {
    const band = BAND_META[settings.lastBand] ? settings.lastBand : 'A0';
    const indices = getBandSubIndices(store, band, settings.lastSubLevel || 0, settings.levelSize);
    const sample = indices
      .slice(0, 12)
      .map((id) => store.words[id])
      .filter((w): w is NonNullable<typeof w> => Boolean(w));
    if (sample.length > 0) {
      prefetchWordsBatch(
        sample,
        {
          backendUrl: settings.backendUrl,
          pixabayKey: settings.pixabayKey,
          unsplashKey: settings.unsplashKey,
          uiLang: settings.uiLang || 'ar',
        },
        12,
        true
      );
    }
  }, [
    store.words.length,
    settings.lastBand,
    settings.lastSubLevel,
    settings.levelSize,
    settings.uiLang,
    settings.backendUrl,
    settings.pixabayKey,
    settings.unsplashKey,
  ]);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToastMsg(''), 2400);
  }, []);

  // Load immutable built-in 18,484-word dictionary (IndexedDB offline-first + network refresh)
  useEffect(() => {
    let active = true;
    const loadVocab = async () => {
      try {
        const cachedTsv = await idbGetDataset('vocab-18k');
        if (active && cachedTsv && cachedTsv.length > 1000) {
          const cachedStore = parseTSVToStore(cachedTsv);
          if (active && cachedStore.words.length > 100) {
            setStore(cachedStore);
          }
        }
      } catch {
        // Proceed to network fetch
      }

      try {
        const res = await fetch('/vocab-18k.tsv');
        if (res.ok) {
          const text = await res.text();
          if (active && text.trim().length > 1000) {
            const cleanTsv = text.replace(/^\r?\n/, '').replace(/\r?\n$/, '');
            const fullStore = parseTSVToStore(cleanTsv);
            if (active && fullStore.words.length > 0) {
              setStore(fullStore);
              void idbSetDataset('vocab-18k', cleanTsv);
            }
          }
        }
      } catch {
        // Keep cached or embedded starter vocab if offline
      }
    };
    void loadVocab();
    return () => {
      active = false;
    };
  }, []);

  // Hydrate and merge user's private cloud progress upon Google Sign-In
  useEffect(() => {
    if (!authReady) return;
    if (!user) {
      cloudProfileExistsRef.current = false;
      cloudHydratedUidRef.current = null;
      cloudSrsIdsRef.current = new Set();
      return;
    }

    if (cloudHydratedUidRef.current === user.uid) return;
    let active = true;

    const hydrateCloud = async () => {
      try {
        const { profileExists, profileData, srsCards } = await fetchCloudAccountState(user);
        if (!active) return;

        cloudProfileExistsRef.current = profileExists;
        cloudSrsIdsRef.current = new Set(Object.keys(srsCards).map((k) => Number(k)));

        const merged = profileData
          ? mergeCloudAndLocalSettings(latestSettingsRef.current, profileData, srsCards)
          : latestSettingsRef.current;

        cloudHydratedUidRef.current = user.uid;
        setSettings(merged);

        // Persist initial or merged profile to Firestore
        await upsertCloudProfile(user, merged, profileExists);
        if (active) {
          cloudProfileExistsRef.current = true;
        }
      } catch (err) {
        console.error('Cloud hydration error:', err);
      }
    };

    void hydrateCloud();
    return () => {
      active = false;
    };
  }, [authReady, user]);

  // Sync dark/light mode class on <html>, persist locally, and debounce sync to Firestore when signed in
  useEffect(() => {
    document.documentElement.classList.toggle('dark', settings.theme === 'dark');
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', settings.theme === 'dark' ? '#090e1a' : '#f5f7fb');
    savePersistedSettings(settings);

    if (user && cloudHydratedUidRef.current === user.uid) {
      if (syncTimerRef.current) clearTimeout(syncTimerRef.current);
      syncTimerRef.current = setTimeout(() => {
        void upsertCloudProfile(user, settings, cloudProfileExistsRef.current)
          .then(() => {
            cloudProfileExistsRef.current = true;
          })
          .catch((err) => {
            console.error('Cloud profile sync error:', err);
          });
      }, 900);
    }

    return () => {
      if (syncTimerRef.current) clearTimeout(syncTimerRef.current);
    };
  }, [settings, user]);

  const favoritesSet = useMemo(() => new Set(settings.favorites), [settings.favorites]);
  const mistakesSet = useMemo(() => new Set(settings.mistakes), [settings.mistakes]);
  const masteredSet = useMemo(() => new Set(settings.mastered), [settings.mastered]);
  const srsDueCount = useMemo(() => getSrsStats(settings.srsCards || {}).dueNow, [settings.srsCards]);

  const handleSfx = useCallback(
    (type: SfxType) => {
      playSfx(type, settings.sfx);
    },
    [settings.sfx]
  );

  const handleSpeak = useCallback(
    (text: string) => {
      speakEn(text, settings.ttsRate, showToast);
    },
    [settings.ttsRate, showToast]
  );

  const handleSpeakSlow = useCallback(
    (text: string) => {
      speakEn(text, 0.65, showToast);
    },
    [showToast]
  );

  const updateSettings = useCallback((patch: Partial<PersistedSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  const toggleFavorite = useCallback(
    (id: number) => {
      setSettings((prev) => {
        const exists = prev.favorites.includes(id);
        return {
          ...prev,
          favorites: exists ? prev.favorites.filter((x) => x !== id) : [...prev.favorites, id],
        };
      });
      playSfx('tap', settings.sfx);
    },
    [settings.sfx]
  );

  const toggleMastered = useCallback(
    (id: number) => {
      setSettings((prev) => {
        const exists = prev.mastered.includes(id);
        return {
          ...prev,
          mastered: exists ? prev.mastered.filter((x) => x !== id) : [...prev.mastered, id],
          mistakes: exists ? prev.mistakes : prev.mistakes.filter((x) => x !== id),
        };
      });
      playSfx('tap', settings.sfx);
    },
    [settings.sfx]
  );

  const toggleMistake = useCallback(
    (id: number) => {
      setSettings((prev) => {
        const exists = prev.mistakes.includes(id);
        return {
          ...prev,
          mistakes: exists ? prev.mistakes.filter((x) => x !== id) : [...prev.mistakes, id],
        };
      });
      playSfx('tap', settings.sfx);
    },
    [settings.sfx]
  );

  const toggleFavoriteSentence = useCallback(
    (num: number) => {
      setSettings((prev) => {
        const list = prev.favoriteSentences || [];
        const exists = list.includes(num);
        return {
          ...prev,
          favoriteSentences: exists ? list.filter((x) => x !== num) : [...list, num],
        };
      });
      playSfx('tap', settings.sfx);
    },
    [settings.sfx]
  );

  const markPracticedSentence = useCallback(
    (num: number) => {
      const td = todayStr();
      let bonusXp = 0;
      setSettings((prev) => {
        const list = prev.practicedSentences || [];
        const already = list.includes(num);
        const todayCount = prev.todayDate === td ? prev.todayCount + 1 : 1;
        const dailySentencesCount =
          prev.dailyPlanDate === td ? (prev.dailySentencesCount || 0) + 1 : 1;
        const activity = recordDailyStudyActivity(prev, 1);
        let next: PersistedSettings = {
          ...prev,
          ...activity.settingsPatch,
          todayDate: td,
          todayCount,
          dailyPlanDate: td,
          dailySentencesCount,
          xp: prev.xp + (already ? 2 : 5),
          practicedSentences: already ? list : [...list, num],
        };
        if (dailySentencesCount >= 3) {
          const stepUp = markDailyPlanStep(next, 'sentences', td);
          bonusXp = stepUp.awardedDailyBonusXp;
          next = { ...next, ...stepUp.settingsPatch };
        }
        return next;
      });
      playSfx('ok', settings.sfx);
      if (bonusXp > 0) {
        showToast(`أكملت خطة اليوم بالكامل! مكافأة +${bonusXp} XP`);
      }
    },
    [settings.sfx, showToast]
  );

  const handleEarnXp = useCallback((xpDelta: number) => {
    const td = todayStr();
    setSettings((prev) => {
      const todayCount = prev.todayDate === td ? prev.todayCount + 1 : 1;
      const activity = recordDailyStudyActivity(prev, 1);
      return {
        ...prev,
        ...activity.settingsPatch,
        todayDate: td,
        todayCount,
        xp: prev.xp + xpDelta,
      };
    });
  }, []);

  const handleRecordListeningComplete = useCallback(
    (band: CefrBand, videoId: string, durationSec: number, quizScorePct: number) => {
      const td = todayStr();
      let bonusXp = 0;
      setSettings((prev) => {
        const allProgress = { ...(prev.listeningProgress || {}) };
        const bandProg = allProgress[band] || {
          watchedSec: 0,
          completedVideoIds: [],
          quizScores: {},
        };
        const alreadyCompleted = bandProg.completedVideoIds.includes(videoId);
        const nextCompletedIds = alreadyCompleted
          ? bandProg.completedVideoIds
          : [...bandProg.completedVideoIds, videoId];
        const nextWatchedSec = alreadyCompleted
          ? bandProg.watchedSec
          : bandProg.watchedSec + Math.max(60, Math.round(durationSec));
        const prevBest = bandProg.quizScores[videoId] || 0;
        allProgress[band] = {
          watchedSec: nextWatchedSec,
          completedVideoIds: nextCompletedIds,
          quizScores: {
            ...bandProg.quizScores,
            [videoId]: Math.max(prevBest, quizScorePct),
          },
        };
        const activity = recordDailyStudyActivity(prev, 2);
        const withActivity: PersistedSettings = {
          ...prev,
          ...activity.settingsPatch,
          listeningProgress: allProgress,
        };
        const stepUp = markDailyPlanStep(withActivity, 'grammarOrListening', td);
        bonusXp = stepUp.awardedDailyBonusXp;
        return {
          ...withActivity,
          ...stepUp.settingsPatch,
        };
      });
      if (bonusXp > 0) {
        showToast(`أكملت خطة اليوم بالكامل! مكافأة +${bonusXp} XP`);
      }
    },
    [showToast]
  );

  const handleCompleteGrammarRule = useCallback(
    (lessonId: string, xpDelta: number) => {
      const td = todayStr();
      let bonusXp = 0;
      setSettings((prev) => {
        const current = prev.completedGrammarIds || [];
        const already = current.includes(lessonId);
        const todayCount = prev.todayDate === td ? prev.todayCount + 1 : 1;
        const activity = recordDailyStudyActivity(prev, 2);
        const withActivity: PersistedSettings = {
          ...prev,
          ...activity.settingsPatch,
          todayDate: td,
          todayCount,
          xp: prev.xp + (already ? Math.round(xpDelta / 2) : xpDelta),
          completedGrammarIds: already ? current : [...current, lessonId],
        };
        const stepUp = markDailyPlanStep(withActivity, 'grammarOrListening', td);
        bonusXp = stepUp.awardedDailyBonusXp;
        return {
          ...withActivity,
          ...stepUp.settingsPatch,
        };
      });
      if (bonusXp > 0) {
        showToast(`أكملت خطة اليوم بالكامل! مكافأة +${bonusXp} XP`);
      }
    },
    [showToast]
  );

  const toggleSaveWordNote = useCallback(
    (note: Omit<SavedWordNote, 'savedAt'>) => {
      let added = false;
      setSettings((prev) => {
        const current = prev.savedWordNotes || [];
        const exists = current.some((n) => n.id === note.id);
        added = !exists;
        return {
          ...prev,
          savedWordNotes: exists
            ? current.filter((n) => n.id !== note.id)
            : [{ ...note, savedAt: Date.now() }, ...current].slice(0, 300),
        };
      });
      playSfx('tap', settings.sfx);
      showToast(added ? `تم حفظ «${note.text}» في ملاحظاتك` : `تمت إزالة «${note.text}» من المحفوظات`);
    },
    [settings.sfx, showToast]
  );

  const handleAddWordNote = useCallback((note: SavedWordNote) => {
    setSettings((prev) => ({
      ...prev,
      savedWordNotes: [note, ...(prev.savedWordNotes || [])].slice(0, 300),
    }));
  }, []);

  const handleDeleteWordNote = useCallback(
    (noteId: string) => {
      setSettings((prev) => ({
        ...prev,
        savedWordNotes: (prev.savedWordNotes || []).filter((n) => n.id !== noteId),
      }));
      showToast('تم حذف الملاحظة');
    },
    [showToast]
  );

  const handleGraduateMistakeWord = useCallback((wordId: number, xpAwarded: number) => {
    const td = todayStr();
    setSettings((prev) => {
      const activity = recordDailyStudyActivity(prev, 2);
      return {
        ...prev,
        ...activity.settingsPatch,
        todayDate: td,
        todayCount: prev.todayDate === td ? prev.todayCount + 1 : 1,
        xp: prev.xp + xpAwarded,
        mistakes: prev.mistakes.filter((id) => id !== wordId),
        mastered: prev.mastered.includes(wordId) ? prev.mastered : [...prev.mastered, wordId],
      };
    });
  }, []);

  const handleUpdateWordMastery = useCallback(
    (
      wordEn: string,
      wordId: number,
      updater: (prev: WordMasteryRecord) => WordMasteryRecord,
      markMistakeOnWrong = false
    ) => {
      const key = normalizeWordKey(wordEn);
      if (!key) return;
      setSettings((prev) => {
        const existing: WordMasteryRecord = (prev.wordMastery || {})[key] || {
          wordKey: key,
          completedGames: [],
          correctAnswers: 0,
          wrongAnswers: 0,
          updatedAt: Date.now(),
        };
        const nextRecord = updater(existing);
        const { isEarnedMastered } = computeWordMastery(nextRecord);
        const nextMastered =
          wordId >= 0 && isEarnedMastered && !prev.mastered.includes(wordId)
            ? [...prev.mastered, wordId]
            : prev.mastered;
        const nextMistakes =
          wordId >= 0 && markMistakeOnWrong && !prev.mistakes.includes(wordId)
            ? [...prev.mistakes, wordId]
            : isEarnedMastered && wordId >= 0
              ? prev.mistakes.filter((id) => id !== wordId)
              : prev.mistakes;

        return {
          ...prev,
          wordMastery: {
            ...(prev.wordMastery || {}),
            [key]: nextRecord,
          },
          mastered: nextMastered,
          mistakes: nextMistakes,
        };
      });
    },
    []
  );

  const handleReviewSrsCard = useCallback(
    (wordIdx: number, rating: SrsRating) => {
      const td = todayStr();
      const now = Date.now();
      const currentCard = (latestSettingsRef.current.srsCards || {})[wordIdx];
      const nextCard = reviewSrsCard(currentCard, wordIdx, rating, now);
      let bonusXp = 0;

      setSettings((prev) => {
        const todayCount = prev.todayDate === td ? prev.todayCount + 1 : 1;
        const known = rating !== 'again';
        const xpGain = rating === 'easy' ? 8 : rating === 'good' ? 6 : rating === 'hard' ? 4 : 0;
        const activity = recordDailyStudyActivity(prev, 1);
        const withActivity: PersistedSettings = {
          ...prev,
          ...activity.settingsPatch,
          todayDate: td,
          todayCount,
          xp: prev.xp + xpGain,
          srsCards: {
            ...(prev.srsCards || {}),
            [wordIdx]: nextCard,
          },
          mastered: known
            ? prev.mastered.includes(wordIdx)
              ? prev.mastered
              : [...prev.mastered, wordIdx]
            : prev.mastered,
          mistakes: known
            ? prev.mistakes.filter((x) => x !== wordIdx)
            : prev.mistakes.includes(wordIdx)
              ? prev.mistakes
              : [...prev.mistakes, wordIdx],
        };
        const stepUp = markDailyPlanStep(withActivity, 'srs', td);
        bonusXp = stepUp.awardedDailyBonusXp;
        return {
          ...withActivity,
          ...stepUp.settingsPatch,
        };
      });

      if (bonusXp > 0) {
        showToast(`أكملت خطة اليوم بالكامل! مكافأة +${bonusXp} XP`);
      }

      if (user && cloudProfileExistsRef.current) {
        const exists = cloudSrsIdsRef.current.has(wordIdx);
        void upsertCloudSrsCard(user, nextCard, exists)
          .then(() => {
            cloudSrsIdsRef.current.add(wordIdx);
          })
          .catch((err) => {
            console.error('SRS card cloud sync error:', err);
          });
      }
    },
    [user, showToast]
  );

  const handleRecordOutcome = useCallback(
    (wordIdx: number, isCorrect: boolean, sourceType: SourceType) => {
      const td = todayStr();
      let freezeUsed = false;
      setSettings((prev) => {
        const todayCount = prev.todayDate === td ? prev.todayCount + 1 : 1;
        const activity = recordDailyStudyActivity(prev, 1);
        freezeUsed = activity.usedStreakFreeze;
        if (isCorrect) {
          const nextMastered = prev.mastered.includes(wordIdx)
            ? prev.mastered
            : [...prev.mastered, wordIdx];
          const nextMistakes =
            sourceType === 'mistakes'
              ? prev.mistakes.filter((x) => x !== wordIdx)
              : prev.mistakes;
          return {
            ...prev,
            ...activity.settingsPatch,
            todayDate: td,
            todayCount,
            xp: prev.xp + 10,
            mastered: nextMastered,
            mistakes: nextMistakes,
          };
        }
        const nextMistakes = prev.mistakes.includes(wordIdx)
          ? prev.mistakes
          : [...prev.mistakes, wordIdx];
        return {
          ...prev,
          ...activity.settingsPatch,
          todayDate: td,
          todayCount,
          mistakes: nextMistakes,
        };
      });
      if (freezeUsed) {
        showToast('تم استخدام تجميد السلسلة تلقائياً لحماية سلسلتك!');
      }
    },
    [showToast]
  );

  const handleOverrideCorrect = useCallback((wordIdx: number) => {
    setSettings((prev) => ({
      ...prev,
      xp: prev.xp + 10,
      mistakes: prev.mistakes.filter((x) => x !== wordIdx),
      mastered: prev.mastered.includes(wordIdx) ? prev.mastered : [...prev.mastered, wordIdx],
    }));
  }, []);

  const handleFinishLevel = useCallback(
    (band: CefrBand, subIdx: number, pct: number) => {
      const key = lvlKey(band, subIdx);
      const td = todayStr();
      let bonusXp = 0;
      setSettings((prev) => {
        const nextCompleted =
          pct > (prev.completed[key] || 0)
            ? { ...prev.completed, [key]: pct }
            : prev.completed;
        const stepUp = markDailyPlanStep(
          { ...prev, completed: nextCompleted },
          'words',
          td
        );
        bonusXp = stepUp.awardedDailyBonusXp;
        return {
          ...prev,
          completed: nextCompleted,
          ...stepUp.settingsPatch,
        };
      });
      if (bonusXp > 0) {
        showToast(`أكملت خطة اليوم بالكامل! مكافأة +${bonusXp} XP`);
      }
    },
    [showToast]
  );

  const startStudyPool = useCallback(
    (indices: number[], returnScreen: ScreenId) => {
      if (!indices.length) {
        showToast('لا توجد كلمات للمراجعة');
        return;
      }
      sessionCounterRef.current += 1;
      setStudySession({ id: sessionCounterRef.current, indices: indices.slice(), returnScreen });
      setGameSession(null);
      setSentenceGameSession(null);
      setArcadeSession(null);
      setScreen('study');
      window.scrollTo({ top: 0 });
    },
    [showToast]
  );

  const startDueSrsReview = useCallback(() => {
    const now = Date.now();
    const dueIds = Object.values(settings.srsCards || {})
      .filter((c) => c.lastReviewedAt > 0 && c.dueAt <= now && c.wordId < store.words.length)
      .map((c) => c.wordId);
    const pool =
      dueIds.length > 0
        ? orderPoolForSrs(dueIds, settings.srsCards || {}, now).slice(0, 30)
        : getBandSubIndices(store, settings.lastBand || 'A0', settings.lastSubLevel || 0, settings.levelSize);
    startStudyPool(pool, screen === 'stats' ? 'stats' : 'games');
  }, [settings.srsCards, settings.lastBand, settings.lastSubLevel, settings.levelSize, store, startStudyPool, screen]);

  const startSentenceGame = useCallback((mode: SentenceGameModeId, returnScreen: ScreenId) => {
    sessionCounterRef.current += 1;
    setSentenceGameSession({ id: sessionCounterRef.current, mode, returnScreen });
    setGameSession(null);
    setStudySession(null);
    setArcadeSession(null);
    setScreen('sentence_game');
    window.scrollTo({ top: 0 });
  }, []);

  const startArcadeGame = useCallback((mode: ArcadeGameModeId, returnScreen: ScreenId) => {
    sessionCounterRef.current += 1;
    setArcadeSession({ id: sessionCounterRef.current, mode, returnScreen });
    setGameSession(null);
    setStudySession(null);
    setSentenceGameSession(null);
    setScreen('arcade_game');
    window.scrollTo({ top: 0 });
  }, []);

  const markWordMistake = useCallback((wordId: number) => {
    if (wordId < 0) return;
    setSettings((prev) =>
      prev.mistakes.includes(wordId)
        ? prev
        : { ...prev, mistakes: [...prev.mistakes, wordId] }
    );
  }, []);

  const markWordMastered = useCallback((wordId: number) => {
    if (wordId < 0) return;
    setSettings((prev) =>
      prev.mastered.includes(wordId)
        ? prev
        : { ...prev, mastered: [...prev.mastered, wordId] }
    );
  }, []);

  const startGame = useCallback(
    (
      mode: GameModeId,
      sourceType: SourceType,
      band: CefrBand,
      subIdx: number,
      returnScreen: ScreenId,
      explicitPool?: number[]
    ) => {
      if (mode === 'study') {
        let pool: number[] = [];
        if (explicitPool) pool = explicitPool;
        else if (sourceType === 'level') {
          pool = getBandSubIndices(store, band, subIdx, settings.levelSize);
          updateSettings({ lastGame: 'study', lastBand: band, lastSubLevel: subIdx });
        } else if (sourceType === 'random') {
          pool = getRandomPool(store, band, settings.levelSize);
        } else if (sourceType === 'mistakes') {
          pool = settings.mistakes.filter((i) => i >= 0 && i < store.words.length);
        } else {
          pool = settings.favorites.filter((i) => i >= 0 && i < store.words.length);
        }
        startStudyPool(pool, returnScreen);
        return;
      }

      let pool: number[] = [];
      if (explicitPool) {
        pool = explicitPool;
      } else if (sourceType === 'level') {
        pool = getBandSubIndices(store, band, subIdx, settings.levelSize);
        updateSettings({ lastGame: mode, lastBand: band, lastSubLevel: subIdx });
      } else if (sourceType === 'random') {
        pool = getRandomPool(store, band, settings.levelSize);
        updateSettings({ lastGame: mode, lastBand: band });
      } else if (sourceType === 'mistakes') {
        pool = settings.mistakes.filter((i) => i >= 0 && i < store.words.length);
        if (!pool.length) {
          showToast('لا توجد أخطاء مسجلة');
          return;
        }
        if (pool.length > 30) pool = shuffleArr(pool).slice(0, 30);
      } else {
        pool = settings.favorites.filter((i) => i >= 0 && i < store.words.length);
        if (!pool.length) {
          showToast('المفضلة فارغة');
          return;
        }
        if (pool.length > 30) pool = shuffleArr(pool).slice(0, 30);
      }

      if (!pool.length) {
        showToast('لا توجد كلمات متاحة في هذا المستوى');
        return;
      }

      sessionCounterRef.current += 1;
      setGameSession({
        id: sessionCounterRef.current,
        mode,
        sourceType,
        band: sourceType === 'level' || sourceType === 'random' ? band : '',
        subIdx,
        pool: shuffleArr(pool),
      });
      setStudySession(null);
      setSentenceGameSession(null);
      setArcadeSession(null);
      setGameReturnScreen(returnScreen);
      setScreen('game');
      window.scrollTo({ top: 0 });
    },
    [store, settings.levelSize, settings.mistakes, settings.favorites, updateSettings, startStudyPool, showToast]
  );

  // Support ?autostart=1, ?placement=1, and PWA shortcut ?tab=... URLs
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      startGame('mcq', 'level', 'A0', 0, 'games');
      return;
    }
    if (params.get('placement') === '1') {
      setPlacementOpen(true);
      return;
    }
    const tabParam = params.get('tab');
    if (tabParam === 'study') {
      startDueSrsReview();
    } else if (
      tabParam === 'games' ||
      tabParam === 'levels' ||
      tabParam === 'sentences' ||
      tabParam === 'listening' ||
      tabParam === 'ai_coach' ||
      tabParam === 'articles' ||
      tabParam === 'grammar' ||
      tabParam === 'dict' ||
      tabParam === 'stats' ||
      tabParam === 'settings'
    ) {
      setNavTab(tabParam);
      setScreen(tabParam);
    }
  }, []);

  // Global soft tactile click tick on buttons/interactive controls (respects settings.sfx)
  useEffect(() => {
    const onPointerClick = (ev: MouseEvent) => {
      if (!latestSettingsRef.current.sfx) return;
      const target = ev.target as HTMLElement | null;
      if (!target) return;
      const btn = target.closest('button:not(:disabled), [role="button"]:not([aria-disabled="true"])');
      if (btn) {
        playSfx('tap', true);
      }
    };
    document.addEventListener('click', onPointerClick, { capture: true, passive: true });
    return () => document.removeEventListener('click', onPointerClick, { capture: true });
  }, []);

  const handleSelectTab = useCallback((tab: NavTab) => {
    setGameSession(null);
    setStudySession(null);
    setSentenceGameSession(null);
    setArcadeSession(null);
    setGameHud(null);
    if (tab === 'ai_coach') {
      setCoachInitialMode('chat');
    }
    setNavTab(tab);
    setScreen(tab);
    window.scrollTo({ top: 0 });
  }, []);

  const handleSummarizeArticleWithAi = useCallback((article: ArticleItem) => {
    setSummaryArticle(article);
    setCoachInitialMode('article_summary');
    setGameSession(null);
    setStudySession(null);
    setSentenceGameSession(null);
    setArcadeSession(null);
    setGameHud(null);
    setNavTab('ai_coach');
    setScreen('ai_coach');
    window.scrollTo({ top: 0 });
  }, []);

  const handleBack = useCallback(() => {
    if (screen === 'word_detail') {
      if (wordDetailHistory.length > 0) {
        const prevItem = wordDetailHistory[wordDetailHistory.length - 1];
        setWordDetailHistory((h) => h.slice(0, -1));
        setDetailWordIdx(prevItem.idx);
        setAdHocWord(prevItem.adHoc);
        window.scrollTo({ top: 0 });
        return;
      }
      setAdHocWord(null);
      setScreen(detailReturnScreen || 'dict');
      window.scrollTo({ top: 0 });
      return;
    }
    if (screen === 'game') {
      setGameSession(null);
      setGameHud(null);
      setScreen(gameReturnScreen || 'games');
      window.scrollTo({ top: 0 });
      return;
    }
    if (screen === 'study') {
      const rt = studySession?.returnScreen || 'games';
      setStudySession(null);
      setGameHud(null);
      setScreen(rt);
      window.scrollTo({ top: 0 });
      return;
    }
    if (screen === 'sentence_game') {
      const rt = sentenceGameSession?.returnScreen || 'games';
      setSentenceGameSession(null);
      setGameHud(null);
      setScreen(rt);
      window.scrollTo({ top: 0 });
      return;
    }
    if (screen === 'arcade_game') {
      const rt = arcadeSession?.returnScreen || 'games';
      setArcadeSession(null);
      setGameHud(null);
      setScreen(rt);
      window.scrollTo({ top: 0 });
      return;
    }
    if (screen === 'game_setup') {
      setScreen(navTab === 'dict' ? 'dict' : 'games');
      window.scrollTo({ top: 0 });
      return;
    }
    if (screen === 'level_detail') {
      setScreen('band_levels');
      window.scrollTo({ top: 0 });
      return;
    }
    if (screen === 'band_levels') {
      setScreen('levels');
      window.scrollTo({ top: 0 });
      return;
    }
    setNavTab('games');
    setScreen('games');
    window.scrollTo({ top: 0 });
  }, [
    screen,
    wordDetailHistory,
    detailReturnScreen,
    gameReturnScreen,
    studySession,
    sentenceGameSession,
    arcadeSession,
    navTab,
  ]);

  const openGameSetup = useCallback(
    (mode: GameModeId, defaultSource: SourceType = 'level') => {
      const lb = BAND_META[settings.lastBand] ? settings.lastBand : 'A0';
      const maxSub = getBandSubCount(store, lb, settings.levelSize);
      setSetupGame(mode);
      setSetupSource(defaultSource);
      setSetupBand(lb);
      setSetupSub(Math.min(Math.max(0, settings.lastSubLevel), maxSub - 1));
      setScreen('game_setup');
      window.scrollTo({ top: 0 });
    },
    [settings.lastBand, settings.lastSubLevel, settings.levelSize, store]
  );

  const openWordDetail = useCallback(
    (idx: number, returnTo?: ScreenId) => {
      if (idx < 0 || idx >= store.words.length) return;
      setWordDetailHistory([]);
      setAdHocWord(null);
      setDetailWordIdx(idx);
      setDetailReturnScreen(returnTo || screen);
      setScreen('word_detail');
      window.scrollTo({ top: 0 });
    },
    [store.words.length, screen]
  );

  const handleExploreWordByText = useCallback(
    (targetWord: string, glossAr?: string) => {
      const clean = String(targetWord || '').trim();
      if (!clean) return;
      // Push current word into history stack so Back navigates cleanly step-by-step
      if (screen === 'word_detail' && (detailWordIdx >= 0 || adHocWord)) {
        setWordDetailHistory((prev) => [
          ...prev.slice(-14),
          { idx: detailWordIdx, adHoc: adHocWord },
        ]);
      } else {
        setDetailReturnScreen(screen);
      }

      const matched = findWordInStore(store, clean);
      if (matched) {
        setAdHocWord(null);
        setDetailWordIdx(matched.id);
      } else {
        const currentBand =
          (detailWordIdx >= 0 && store.words[detailWordIdx]?.band) ||
          adHocWord?.band ||
          'B1';
        setDetailWordIdx(-1);
        setAdHocWord({
          id: -1,
          band: currentBand,
          en: clean,
          ar: glossAr || '',
        });
      }
      setScreen('word_detail');
      window.scrollTo({ top: 0 });
    },
    [screen, detailWordIdx, adHocWord, store]
  );

  const handleStartWordSrs = useCallback(
    (wordId: number) => {
      if (wordId < 0 || wordId >= store.words.length) return;
      startStudyPool([wordId], 'word_detail');
    },
    [store.words.length, startStudyPool]
  );

  const handleResetProgress = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      xp: 0,
      streak: 0,
      bestStreak: 0,
      todayCount: 0,
      lastBand: 'A0',
      lastSubLevel: 0,
      completed: {},
      mistakes: [],
      favorites: [],
      mastered: [],
      favoriteSentences: [],
      practicedSentences: [],
      srsCards: {},
      listeningProgress: undefined,
      completedGrammarIds: [],
      savedWordNotes: [],
      wordMastery: {},
    }));
    showToast('تم تصفير التقدم');
  }, [showToast]);

  // Global desktop keyboard navigation (Alt+1..5 for primary tabs, Esc to close/back, / to search)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (placementOpen) {
          setPlacementOpen(false);
          return;
        }
        if (authModalOpen) {
          setAuthModalOpen(false);
          return;
        }
        if (guestPromptOpen) {
          setGuestPromptOpen(false);
          return;
        }
        if (
          screen === 'word_detail' ||
          screen === 'game_setup' ||
          screen === 'band_levels' ||
          screen === 'level_detail'
        ) {
          handleBack();
        }
        return;
      }

      if (e.altKey && !e.ctrlKey && !e.metaKey) {
        const map: Record<string, NavTab> = {
          '1': 'games',
          '2': 'levels',
          '3': 'sentences',
          '4': 'listening',
          '5': 'ai_coach',
          '6': 'articles',
          '7': 'grammar',
        };
        const target = map[e.key];
        if (target) {
          e.preventDefault();
          handleSelectTab(target);
        }
        return;
      }

      if (
        e.key === '/' &&
        !e.ctrlKey &&
        !e.metaKey &&
        !e.altKey &&
        !authModalOpen &&
        !placementOpen &&
        !guestPromptOpen
      ) {
        const active = document.activeElement as HTMLElement | null;
        const tag = active?.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || active?.isContentEditable) {
          return;
        }
        const searchInput = document.querySelector<HTMLInputElement>(
          'main input[type="search"], main input[type="text"]'
        );
        if (searchInput) {
          e.preventDefault();
          searchInput.focus();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [placementOpen, authModalOpen, guestPromptOpen, screen, handleBack, handleSelectTab]);

  const handleRoundCompleteForGuest = useCallback(() => {
    if (!user && !guestPromptShownRef.current) {
      guestPromptShownRef.current = true;
      window.setTimeout(() => {
        setGuestPromptOpen(true);
      }, 650);
    }
  }, [user]);

  const handlePlacementComplete = useCallback(
    (result: PlacementResult) => {
      updateSettings({
        placementResult: result,
        lastBand: result.cefrBand,
        lastSubLevel: 0,
      });
      const dict = getTranslations(latestSettingsRef.current.uiLang || 'ar');
      showToast(`${dict.placementYourLevel}: ${result.cefrBand} (${result.overallScore}%)`);
    },
    [updateSettings, showToast]
  );

  const uiTranslations = useMemo(
    () => getTranslations(settings.uiLang || 'ar'),
    [settings.uiLang]
  );

  const subTitle = useMemo(() => {
    if (screen === 'game' && gameSession) {
      return uiTranslations.games[gameSession.mode]?.name || GAME_MAP[gameSession.mode].name;
    }
    if (screen === 'study') return uiTranslations.games.study.name;
    if (screen === 'arcade_game' && arcadeSession) {
      const titles: Record<ArcadeGameModeId, string> = {
        wordle: 'تحدي الكلمة — Wordle',
        speed_blitz: 'سباق 60 ثانية',
        memory_flip: 'بطاقات الذاكرة',
        word_rain: 'مطر الكلمات',
        save_rocket: 'أنقذ الصاروخ',
      };
      return titles[arcadeSession.mode];
    }
    if (screen === 'sentence_game' && sentenceGameSession) {
      if (sentenceGameSession.mode === 'sentence_order') return uiTranslations.sentOrderTitle;
      if (sentenceGameSession.mode === 'sentence_error') return uiTranslations.sentErrorTitle;
      if (sentenceGameSession.mode === 'sentence_dictation') return uiTranslations.sentDictTitle;
      if (sentenceGameSession.mode === 'sentence_vanish') return 'الجملة المتلاشية';
      if (sentenceGameSession.mode === 'sentence_cloze') return 'أكمل الفراغ الذكي';
      if (sentenceGameSession.mode === 'sentence_chat_reply') return 'الرد السريع في المحادثة';
      if (sentenceGameSession.mode === 'sentence_speak') return 'تحدي النطق المباشر';
      if (sentenceGameSession.mode === 'sentence_blitz') return 'سباق الجمل — 60 ثانية';
      return 'تحدي تبديل الأنماط';
    }
    if (screen === 'game_setup') {
      return uiTranslations.games[setupGame]?.name || GAME_MAP[setupGame].name;
    }
    if (screen === 'band_levels') return `${browseBand} — ${BAND_META[browseBand].ar}`;
    if (screen === 'level_detail') return `${detailBand} · #${detailSub + 1}`;
    if (screen === 'word_detail') {
      return adHocWord?.en || store.words[detailWordIdx]?.en || 'TMN';
    }
    return 'TMN';
  }, [
    screen,
    gameSession,
    arcadeSession,
    sentenceGameSession,
    setupGame,
    browseBand,
    detailBand,
    detailSub,
    detailWordIdx,
    adHocWord,
    store.words,
    uiTranslations,
  ]);

  return (
    <LanguageProvider
      lang={settings.uiLang || 'ar'}
      onChangeLang={(uiLang) => updateSettings({ uiLang })}
    >
      <ZeroArabicLeakTranslator backendUrl={settings.backendUrl} />
      <div className="tmn-canvas min-h-screen">
        <PWAInstallBanner />
        <TopBar
          screen={screen}
          navTab={navTab}
          subTitle={subTitle}
          mistakesCount={settings.mistakes.length}
          srsDueCount={srsDueCount}
          gameHud={
            screen === 'game' ||
            screen === 'study' ||
            screen === 'sentence_game' ||
            screen === 'arcade_game'
              ? gameHud
              : null
          }
          onSelectTab={handleSelectTab}
          onBack={handleBack}
          onOpenAuth={openAuthModal}
          onOpenPlacement={openPlacementModal}
          onOpenGlobalSearch={() => setGlobalSearchOpen(true)}
          onOpenNotebook={() => setNotebookOpen(true)}
          onToast={showToast}
        />

        <main
          className={`mx-auto max-w-6xl px-3 pt-4 sm:px-6 sm:pt-7 ${
            screen === 'games' ||
            screen === 'levels' ||
            screen === 'band_levels' ||
            screen === 'level_detail' ||
            screen === 'sentences'
              ? 'pb-24 md:pb-12'
              : 'pb-12'
          }`}
        >
          {screen === 'games' && (
            <GamesHome
              settings={settings}
              onSelectGame={(mode) => openGameSetup(mode, 'level')}
              onStartArcadeGame={(mode) => startArcadeGame(mode, 'games')}
              onStartSentenceGame={(mode) => startSentenceGame(mode, 'games')}
            />
          )}

        <Suspense fallback={<ViewFallback />}>
        {screen === 'game_setup' && (
          <GameSetup
            store={store}
            settings={settings}
            gameMode={setupGame}
            source={setupSource}
            band={setupBand}
            subIdx={setupSub}
            onChangeSource={(src) => {
              setSetupSource(src);
              handleSfx('tap');
            }}
            onChangeBand={(b) => {
              setSetupBand(b);
              setSetupSub(0);
              handleSfx('tap');
            }}
            onChangeSub={(idx) => setSetupSub(idx)}
            onChangeMcqDir={(dir) => {
              updateSettings({ mcqDir: dir });
              handleSfx('tap');
            }}
            onLaunch={() => startGame(setupGame, setupSource, setupBand, setupSub, 'games')}
          />
        )}

        {screen === 'game' && gameSession && (
          <GameArena
            key={gameSession.id}
            store={store}
            settings={settings}
            session={gameSession}
            favoritesSet={favoritesSet}
            mistakesSet={mistakesSet}
            masteredSet={masteredSet}
            onSpeak={handleSpeak}
            onSpeakSlow={handleSpeakSlow}
            onSfx={handleSfx}
            onRecordOutcome={handleRecordOutcome}
            onOverrideCorrect={handleOverrideCorrect}
            onFinishLevel={handleFinishLevel}
            onToggleFavorite={toggleFavorite}
            onOpenWordDetail={(id) => openWordDetail(id, 'game')}
            onRestart={(overridePool, overrideSubIdx) => {
              const targetSub = overrideSubIdx !== undefined ? overrideSubIdx : gameSession.subIdx;
              const targetBand = (gameSession.band || 'A0') as CefrBand;
              if (overridePool) {
                startGame(
                  gameSession.mode,
                  'mistakes',
                  targetBand,
                  -1,
                  gameReturnScreen,
                  overridePool
                );
              } else {
                startGame(
                  gameSession.mode,
                  gameSession.sourceType,
                  targetBand,
                  targetSub,
                  gameReturnScreen
                );
              }
            }}
            onExit={handleBack}
            onHudChange={setGameHud}
            onRoundComplete={handleRoundCompleteForGuest}
            onToast={showToast}
          />
        )}

        {screen === 'study' && studySession && (
          <StudyArena
            key={studySession.id}
            store={store}
            settings={settings}
            indices={studySession.indices}
            autoSpeak={settings.autoSpeak}
            favoritesSet={favoritesSet}
            onSpeak={handleSpeak}
            onSfx={handleSfx}
            onReviewSrsCard={handleReviewSrsCard}
            onToggleFavorite={toggleFavorite}
            onOpenWordDetail={(id) => openWordDetail(id, 'study')}
            onHudChange={setGameHud}
            onDone={() => {
              showToast('تم حفظ جدول مراجعة أنكي');
              handleRoundCompleteForGuest();
              handleBack();
            }}
          />
        )}

        {screen === 'sentence_game' &&
          sentenceGameSession &&
          (sentenceGameSession.mode === 'sentence_order' ||
            sentenceGameSession.mode === 'sentence_error' ||
            sentenceGameSession.mode === 'sentence_dictation') && (
            <SentenceGamesArena
              key={sentenceGameSession.id}
              mode={sentenceGameSession.mode}
              ttsRate={settings.ttsRate}
              onSpeak={handleSpeak}
              onSpeakSlow={handleSpeakSlow}
              onSfx={handleSfx}
              onEarnXp={handleEarnXp}
              onHudChange={setGameHud}
              onRoundComplete={handleRoundCompleteForGuest}
              onExit={handleBack}
            />
          )}

        </Suspense>

        <Suspense fallback={<ViewFallback />}>
          {screen === 'arcade_game' && arcadeSession && (
            <ArcadeGamesArena
              key={arcadeSession.id}
              mode={arcadeSession.mode}
              store={store}
              settings={settings}
              onSpeak={handleSpeak}
              onSfx={handleSfx}
              onEarnXp={handleEarnXp}
              onMarkMistake={markWordMistake}
              onMarkMastered={markWordMastered}
              onUpdateSettings={updateSettings}
              onOpenWordDetail={(id) => openWordDetail(id, 'arcade_game')}
              onHudChange={setGameHud}
              onExit={handleBack}
            />
          )}

          {screen === 'sentence_game' &&
            sentenceGameSession &&
            (sentenceGameSession.mode === 'sentence_vanish' ||
              sentenceGameSession.mode === 'sentence_cloze' ||
              sentenceGameSession.mode === 'sentence_chat_reply' ||
              sentenceGameSession.mode === 'sentence_speak' ||
              sentenceGameSession.mode === 'sentence_blitz') && (
              <SentenceGamesProArena
                key={sentenceGameSession.id}
                mode={sentenceGameSession.mode}
                settings={settings}
                onSpeak={handleSpeak}
                onSpeakSlow={handleSpeakSlow}
                onSfx={handleSfx}
                onEarnXp={handleEarnXp}
                onMarkPracticedSentence={markPracticedSentence}
                onToggleFavoriteSentence={toggleFavoriteSentence}
                onUpdateSettings={updateSettings}
                onHudChange={setGameHud}
                onRoundComplete={handleRoundCompleteForGuest}
                onExit={handleBack}
              />
            )}

          {screen === 'sentence_game' &&
            sentenceGameSession &&
            sentenceGameSession.mode === 'sentence_pattern_swap' && (
              <SentencePatternSwapGame
                key={sentenceGameSession.id}
                onSpeak={handleSpeak}
                onSpeakSlow={handleSpeakSlow}
                onSfx={handleSfx}
                onEarnXp={handleEarnXp}
                onMarkPracticedSentence={markPracticedSentence}
                onHudChange={setGameHud}
                onRoundComplete={handleRoundCompleteForGuest}
                onExit={handleBack}
              />
            )}
        </Suspense>

        <Suspense fallback={<ViewFallback />}>
        {screen === 'levels' && (
          <CefrBandsList
            store={store}
            settings={settings}
            onOpenBand={(b) => {
              setBrowseBand(b);
              setScreen('band_levels');
              window.scrollTo({ top: 0 });
            }}
          />
        )}

        {screen === 'band_levels' && (
          <BandSubLevels
            store={store}
            settings={settings}
            band={browseBand}
            onOpenLevelDetail={(b, s) => {
              setDetailBand(b);
              setDetailSub(s);
              updateSettings({ lastBand: b, lastSubLevel: s });
              setScreen('level_detail');
              window.scrollTo({ top: 0 });
            }}
            onToast={showToast}
          />
        )}

        {screen === 'level_detail' && (
          <LevelDetail
            store={store}
            settings={settings}
            band={detailBand}
            subIdx={detailSub}
            favoritesSet={favoritesSet}
            mistakesSet={mistakesSet}
            masteredSet={masteredSet}
            onNavigateLevel={(b, s) => {
              setDetailBand(b);
              setDetailSub(s);
              updateSettings({ lastBand: b, lastSubLevel: s });
            }}
            onStartMode={(mode, b, s) => startGame(mode, 'level', b, s, 'level_detail')}
            onOpenWordDetail={(id) => openWordDetail(id, 'level_detail')}
            onSpeak={handleSpeak}
            onToggleFavorite={toggleFavorite}
          />
        )}

        {screen === 'dict' && (
          <DictView
            store={store}
            favorites={settings.favorites}
            mistakes={settings.mistakes}
            savedWordNotes={settings.savedWordNotes || []}
            favoriteSentences={settings.favoriteSentences || []}
            favoritesSet={favoritesSet}
            mistakesSet={mistakesSet}
            masteredSet={masteredSet}
            onOpenWordDetail={(id) => openWordDetail(id, 'dict')}
            onSpeak={handleSpeak}
            onToggleFavorite={toggleFavorite}
            onPlayCollection={(src) => openGameSetup(settings.lastGame || 'mcq', src)}
            onClearCollection={(src) => {
              setSettings((prev) =>
                src === 'mistakes' ? { ...prev, mistakes: [] } : { ...prev, favorites: [] }
              );
              showToast(src === 'mistakes' ? 'تم مسح بنك الأخطاء' : 'تم مسح المفضلة');
            }}
            onOpenMistakeFixer={() => setMistakeFixerOpen(true)}
            onAddWordNote={handleAddWordNote}
            onDeleteWordNote={handleDeleteWordNote}
            onToast={showToast}
          />
        )}

        </Suspense>

        <Suspense fallback={<ViewFallback />}>
          {screen === 'word_detail' &&
            (adHocWord || (detailWordIdx >= 0 && store.words[detailWordIdx])) && (
              <WordDetailView
                word={adHocWord || store.words[detailWordIdx]}
                store={store}
                settings={settings}
                isFavorite={!adHocWord && favoritesSet.has(detailWordIdx)}
                isMastered={!adHocWord && masteredSet.has(detailWordIdx)}
                isMistake={!adHocWord && mistakesSet.has(detailWordIdx)}
                isAdHoc={Boolean(adHocWord)}
                historyCount={wordDetailHistory.length}
                onSpeak={handleSpeak}
                onSfx={handleSfx}
                onEarnXp={handleEarnXp}
                onToggleFavorite={toggleFavorite}
                onToggleMastered={toggleMastered}
                onToggleMistake={toggleMistake}
                onToggleSaveWordNote={toggleSaveWordNote}
                onUpdateWordMastery={handleUpdateWordMastery}
                onExploreWord={handleExploreWordByText}
                onStartWordSrs={handleStartWordSrs}
                onGoSettings={() => handleSelectTab('settings')}
                onToast={showToast}
              />
            )}

          {screen === 'sentences' && (
            <SentencesView
              ttsRate={settings.ttsRate}
              favoriteSentences={settings.favoriteSentences || []}
              practicedSentences={settings.practicedSentences || []}
              initialSearchQuery={sentencesInitialQuery}
              onToggleFavoriteSentence={toggleFavoriteSentence}
              onMarkPracticedSentence={markPracticedSentence}
              onStartSentenceGame={(mode) => startSentenceGame(mode, 'sentences')}
              onToast={showToast}
            />
          )}

          {screen === 'listening' && (
            <ListeningView
              settings={settings}
              onRecordListeningComplete={handleRecordListeningComplete}
              onEarnXp={handleEarnXp}
              onToast={showToast}
            />
          )}

          {screen === 'ai_coach' && (
            <AiCoachView
              ttsRate={settings.ttsRate}
              defaultBand={settings.lastBand || 'A2'}
              unsplashKey={settings.unsplashKey}
              initialMode={coachInitialMode}
              summaryArticle={summaryArticle}
              onOpenArticles={() => handleSelectTab('articles')}
              onToast={showToast}
            />
          )}

          {screen === 'articles' && (
            <ArticlesView
              store={store}
              ttsRate={settings.ttsRate}
              defaultBand={settings.lastBand || 'B1'}
              favoritesSet={favoritesSet}
              onToggleFavorite={toggleFavorite}
              onSummarizeWithAi={handleSummarizeArticleWithAi}
              onToast={showToast}
            />
          )}

          {screen === 'grammar' && (
            <GrammarView
              settings={settings}
              initialLessonId={grammarInitialLessonId}
              onSpeak={handleSpeak}
              onSfx={handleSfx}
              onCompleteRule={handleCompleteGrammarRule}
              onToast={showToast}
            />
          )}

          {screen === 'stats' && (
            <StatsView
              store={store}
              settings={settings}
              onStartDueSrsReview={startDueSrsReview}
              onReviewMistakes={() => openGameSetup('mcq', 'mistakes')}
              onOpenMistakeFixer={() => setMistakeFixerOpen(true)}
              onOpenCertificate={(band, reasonAr) => setCertificateModal({ band, reasonAr })}
              onStartDailyPlanStep={(stepId: DailyPlanStepId) => {
                if (stepId === 'srs') {
                  if (srsDueCount > 0) {
                    startDueSrsReview();
                  } else {
                    const band = settings.lastBand || 'A0';
                    const warmPool = getBandSubIndices(
                      store,
                      band,
                      settings.lastSubLevel || 0,
                      settings.levelSize
                    ).slice(0, 5);
                    startStudyPool(
                      warmPool.length > 0 ? warmPool : getRandomPool(store, band, 5),
                      'stats'
                    );
                  }
                } else if (stepId === 'words') {
                  const band = settings.lastBand || 'A0';
                  const sub = settings.lastSubLevel || 0;
                  startGame('mixed', 'level', band, sub, 'stats');
                } else if (stepId === 'sentences') {
                  handleSelectTab('sentences');
                } else {
                  handleSelectTab('grammar');
                }
              }}
              onOpenOnboarding={() => setOnboardingOpen(true)}
              onOpenAuth={openAuthModal}
              onOpenPlacement={openPlacementModal}
              onToast={showToast}
            />
          )}

          {screen === 'settings' && (
            <SettingsView
              settings={settings}
              onUpdateSettings={updateSettings}
              onSpeakSample={(rate) => speakEn('Ready to practice', rate, showToast)}
              onResetProgress={handleResetProgress}
              onOpenAuth={openAuthModal}
              onOpenPlacement={openPlacementModal}
              onOpenOnboarding={() => setOnboardingOpen(true)}
              onToast={showToast}
            />
          )}
        </Suspense>
      </main>

      <Suspense fallback={null}>
        {authModalOpen && (
          <AuthModal
            open={authModalOpen}
            initialMode={authModalMode}
            onClose={() => setAuthModalOpen(false)}
            onStartPlacement={openPlacementModal}
          />
        )}

        {placementOpen && (
          <PlacementTestModal
            open={placementOpen}
            sfxEnabled={settings.sfx}
            ttsRate={settings.ttsRate}
            existingResult={settings.placementResult || null}
            onClose={() => setPlacementOpen(false)}
            onComplete={handlePlacementComplete}
          />
        )}
      </Suspense>

      <GuestSavePromptModal
        open={guestPromptOpen && !user}
        onClose={() => setGuestPromptOpen(false)}
        onOpenAuth={openAuthModal}
        onOpenPlacement={openPlacementModal}
      />

      {/* Lazy-Loaded New Flagship Modals */}
      <Suspense fallback={null}>
        {onboardingOpen && (
          <OnboardingModal
            open={onboardingOpen}
            initialGoal={settings.learningGoal}
            initialPace={settings.dailyPaceMinutes}
            initialBand={settings.lastBand}
            onComplete={(res: {
              learningGoal: LearningGoalId;
              dailyPaceMinutes: DailyPaceMinutes;
              dailyGoal: number;
              lastBand: CefrBand;
            }) => {
              updateSettings({
                onboardingCompleted: true,
                learningGoal: res.learningGoal,
                dailyPaceMinutes: res.dailyPaceMinutes,
                dailyGoal: res.dailyGoal,
                lastBand: res.lastBand,
                lastSubLevel: 0,
              });
              setOnboardingOpen(false);
              showToast(`تم إعداد خطتك اليومية لمستوى ${res.lastBand}`);
            }}
            onLaunchPlacement={(res) => {
              updateSettings({
                onboardingCompleted: true,
                learningGoal: res.learningGoal,
                dailyPaceMinutes: res.dailyPaceMinutes,
                dailyGoal: res.dailyGoal,
              });
              setOnboardingOpen(false);
              setPlacementOpen(true);
            }}
            onSkip={() => {
              updateSettings({ onboardingCompleted: true });
              setOnboardingOpen(false);
            }}
          />
        )}

        {globalSearchOpen && (
          <GlobalSearchModal
            open={globalSearchOpen}
            store={store}
            onClose={() => setGlobalSearchOpen(false)}
            onSelectWord={(wordId) => openWordDetail(wordId, screen)}
            onSelectSentence={(sentenceText) => {
              setSentencesInitialQuery(sentenceText);
              handleSelectTab('sentences');
            }}
            onSelectGrammar={(lessonId) => {
              setGrammarInitialLessonId(lessonId);
              handleSelectTab('grammar');
            }}
          />
        )}

        {mistakeFixerOpen && (
          <MistakeFixerModal
            open={mistakeFixerOpen}
            store={store}
            mistakeIds={settings.mistakes}
            onClose={() => setMistakeFixerOpen(false)}
            onSpeak={handleSpeak}
            onSfx={handleSfx}
            onGraduateWord={handleGraduateMistakeWord}
          />
        )}

        {certificateModal && (
          <CertificateModal
            open={Boolean(certificateModal)}
            band={certificateModal.band}
            defaultStudentName={user?.displayName || ''}
            masteredWordsCount={settings.mastered.length}
            reasonAr={certificateModal.reasonAr}
            onClose={() => setCertificateModal(null)}
            onToast={showToast}
          />
        )}

        {notebookOpen && (
          <NotebookModal
            open={notebookOpen}
            store={store}
            favoriteWordIds={settings.favorites}
            savedWordNotes={settings.savedWordNotes || []}
            favoriteSentenceNums={settings.favoriteSentences || []}
            onClose={() => setNotebookOpen(false)}
            onSpeak={handleSpeak}
            onOpenWordDetail={(id) => {
              setNotebookOpen(false);
              openWordDetail(id, screen);
            }}
            onAddNote={handleAddWordNote}
            onDeleteNote={handleDeleteWordNote}
            onToast={showToast}
          />
        )}
      </Suspense>

      <OfflineIndicator />

      {/* Accessible Toast Notification */}
      {toastMsg && (
        <div
          role="status"
          aria-live="polite"
          className="fixed top-16 left-1/2 z-50 -translate-x-1/2 rounded-full border border-indigo-500/40 bg-slate-900 px-5 py-2.5 text-xs font-bold text-white shadow-xl"
        >
          {toastMsg}
        </div>
      )}
    </div>
    </LanguageProvider>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <TmnAppContent />
      </AuthProvider>
    </ErrorBoundary>
  );
}
